import TextSearchManager from '@jbrowse/core/TextSearch/TextSearchManager';
import RpcManager from '@jbrowse/core/rpc/RpcManager';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { BaseAssemblyConfigSchema } from '@jbrowse/core/assemblyManager';
import type { IAnyType, Instance, SnapshotIn } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel BaseRootModel
 * #category root
 * factory function for the Base-level root model shared by all products
 */
export declare function BaseRootModelFactory({ pluginManager, jbrowseModelType, sessionModelType, assemblyConfigSchema, }: {
    pluginManager: PluginManager;
    jbrowseModelType: IAnyType;
    sessionModelType: IAnyType;
    assemblyConfigSchema: BaseAssemblyConfigSchema;
}): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     * `jbrowse` is a mapping of the config.json into the in-memory state
     * tree
     */
    jbrowse: IAnyType;
    /**
     * #property
     * `session` encompasses the currently active state of the app, including
     * views open, tracks open in those views, etc.
     */
    session: import("@jbrowse/mobx-state-tree").IMaybe<IAnyType>;
    /**
     * #property
     */
    sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
        assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }, {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }, {
        readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }> & {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }, {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
    } & {
        getCanonicalAssemblyName(asmName: string): string | undefined;
        getDisplayName(asmName: string): string;
        get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }> & {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }, {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
        has(asmName: string): boolean;
        readonly assemblyNamesList: string[];
        readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
            setSubschema(slotName: string, data: Record<string, unknown>): any;
            setSlot(slotName: string, value: unknown): void;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
        readonly rpcManager: RpcManager;
    } & {
        waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }> & {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
        }, {
            error: unknown;
            loadingP: Promise<void> | undefined;
            adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
            volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
            cytobands: import("@jbrowse/core/util").Feature[] | undefined;
            loadedGeneticCodes: Record<string, number> | undefined;
            lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        } & {
            getConf(arg: string): any;
        } & {
            readonly name: string;
            readonly aliases: string[];
            readonly displayName: string;
            readonly refNameColors: string[];
        } & {
            readonly allAliases: string[];
            hasName(name: string): boolean;
        } & {
            setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                regions: import("@jbrowse/core/util").Region[];
                cytobands: import("@jbrowse/core/util").Feature[];
                geneticCodes: Record<string, number>;
            }): void;
            setError(e: unknown): void;
            setLoadingP(p?: Promise<void>): void;
            loadPre(): Promise<void>;
        } & {
            load(): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            readonly initialized: boolean;
            readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
            readonly allRefNames: string[] | undefined;
            readonly rpcManager: RpcManager;
        } & {
            readonly refNames: string[] | undefined;
        } & {
            readonly refNameToIndex: Map<string, number> | undefined;
        } & {
            getCanonicalRefName(refName: string): string | undefined;
            getRefNameColor(refName: string): string | undefined;
            getGeneticCodeId(refName: string): number;
            getSeqAdapterRefName(canonicalRefName: string): string;
        } & {
            getCanonicalRefName2(refName: string): string;
            isValidRefName(refName: string): boolean;
        } & {
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        isValidRefName(refName: string, assemblyName: string): boolean;
    } & {
        afterAttach(): void;
        removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
        addAssembly(configuration: any): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
}, {
    /**
     * #volatile
     */
    rpcManager: RpcManager;
    /**
     * #volatile
     */
    adminMode: boolean;
    /**
     * #volatile
     */
    error: unknown;
    /**
     * #volatile
     */
    textSearchManager: TextSearchManager;
    /**
     * #volatile
     */
    pluginManager: PluginManager;
} & {
    /**
     * #action
     */
    setError(error: unknown): void;
    /**
     * #action
     * Sets the active session. Remaps any legacy display type names
     * (e.g. LinearPileupDisplay → LinearAlignmentsDisplay), then walks the
     * resulting MST tree to drop open tracks whose config can't hydrate so
     * shared sessions still load when referencing tracks that no longer
     * exist. Dropped tracks are surfaced to the user via a snackbar. If
     * filtering throws, the previous session is restored.
     */
    setSession(sessionSnapshot?: SnapshotIn<IAnyType>): void;
    /**
     * #action
     */
    setDefaultSession(): void;
    /**
     * #action
     */
    setSessionPath(path: string): void;
    /**
     * #action
     */
    renameCurrentSession(newName: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseRootModelType = ReturnType<typeof BaseRootModelFactory>;
export type BaseRootModel = Instance<BaseRootModelType>;
/** Type guard for checking if something is a JB root model */
export declare function isRootModel(thing: unknown): thing is BaseRootModel;
