/**
 * #config HierarchicalConfigSchema
 * #category root
 * generally exists on the config.json or root config as configuration.hierarchical
 */
export declare function HierarchicalConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly sort: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        /**
         * #slot configuration.hierarchical.sort.trackNames
         */
        readonly trackNames: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        /**
         * #slot configuration.hierarchical.sort.categories
         */
        readonly categories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    /**
     * #slot configuration.hierarchical.defaultFolderCategories
     */
    readonly defaultFolderCategories: {
        readonly type: "stringArray";
        readonly description: "list of category names to display as folders by default";
        readonly defaultValue: readonly [];
    };
    readonly defaultCollapsed: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        /**
         * #slot configuration.hierarchical.defaultCollapsed.categoryNames
         */
        readonly categoryNames: {
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
        /**
         * #slot configuration.hierarchical.defaultCollapsed.topLevelCategories
         */
        readonly topLevelCategories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        /**
         * #slot configuration.hierarchical.defaultCollapsed.subCategories
         */
        readonly subCategories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
