/**
 * #config FormatDetails
 * #category root
 * generally exists on the tracks in the config.json or as a 'session' config as
 * configuration.formatDetails
 */
export declare function FormatDetailsConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    /**
     * #slot configuration.formatDetails.feature
     */
    readonly feature: {
        readonly type: "frozen";
        readonly description: "adds extra fields to the feature details";
        readonly defaultValue: {};
        readonly contextVariable: ["feature"];
    };
    /**
     * #slot configuration.formatDetails.subfeatures
     */
    readonly subfeatures: {
        readonly type: "frozen";
        readonly description: "adds extra fields to the subfeatures of a feature";
        readonly defaultValue: {};
        readonly contextVariable: ["feature"];
    };
    /**
     * #slot configuration.formatDetails.depth
     */
    readonly depth: {
        readonly type: "number";
        readonly defaultValue: 2;
        readonly description: "depth to iterate the formatDetails->subfeatures callback on subfeatures (used for example to only apply the callback to the first layer of subfeatures)";
    };
    /**
     * #slot configuration.formatDetails.maxDepth
     */
    readonly maxDepth: {
        readonly type: "number";
        readonly defaultValue: 10000;
        readonly description: "hide subfeatures greater than a certain depth";
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
