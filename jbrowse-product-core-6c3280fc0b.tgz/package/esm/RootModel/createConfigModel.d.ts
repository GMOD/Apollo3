import RpcManager from '@jbrowse/core/rpc/RpcManager';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export declare function createConfigModel(pluginManager: PluginManager, assemblyConfigSchemasType: IAnyType): import("@jbrowse/mobx-state-tree").IModelType<{
    configuration: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly rpc: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly defaultDriver: {
                readonly type: "string";
                readonly description: "the RPC driver to use for tracks and tasks that are not configured to use a specific RPC backend";
                readonly defaultValue: "";
                readonly advanced: true;
            };
            readonly workerCount: {
                readonly type: "number";
                readonly description: "The number of workers to use. If 0 (the default) JBrowse will decide how many workers to use.";
                readonly defaultValue: 0;
                readonly advanced: true;
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
        readonly hierarchical: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly sort: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
                readonly trackNames: {
                    readonly type: "boolean";
                    readonly defaultValue: false;
                };
                readonly categories: {
                    readonly type: "boolean";
                    readonly defaultValue: false;
                };
            }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
            readonly defaultFolderCategories: {
                readonly type: "stringArray";
                readonly description: "list of category names to display as folders by default";
                readonly defaultValue: readonly [];
            };
            readonly defaultCollapsed: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
                readonly categoryNames: {
                    readonly type: "stringArray";
                    readonly defaultValue: readonly [];
                };
                readonly topLevelCategories: {
                    readonly type: "boolean";
                    readonly defaultValue: false;
                };
                readonly subCategories: {
                    readonly type: "boolean";
                    readonly defaultValue: false;
                };
            }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
        readonly preferences: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly animationMode: {
                readonly model: import("@jbrowse/mobx-state-tree").ISimpleType<"disabled" | "enabled" | "system">;
                readonly type: "stringEnum";
                readonly defaultValue: "enabled";
            };
            readonly scrollZoom: {
                readonly type: "boolean";
                readonly defaultValue: false;
            };
            readonly numberGrouping: {
                readonly type: "boolean";
                readonly defaultValue: true;
            };
            readonly useWorkspaces: {
                readonly type: "boolean";
                readonly defaultValue: false;
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
        readonly formatDetails: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly feature: {
                readonly type: "frozen";
                readonly description: "adds extra fields to the feature details";
                readonly defaultValue: {};
                readonly contextVariable: ["feature"];
            };
            readonly subfeatures: {
                readonly type: "frozen";
                readonly description: "adds extra fields to the subfeatures of a feature";
                readonly defaultValue: {};
                readonly contextVariable: ["feature"];
            };
            readonly depth: {
                readonly type: "number";
                readonly defaultValue: 2;
                readonly description: "depth to iterate the formatDetails->subfeatures callback on subfeatures (used for example to only apply the callback to the first layer of subfeatures)";
            };
            readonly maxDepth: {
                readonly type: "number";
                readonly defaultValue: 10000;
                readonly description: "hide subfeatures greater than a certain depth";
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
        readonly formatAbout: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly config: {
                readonly type: "frozen";
                readonly description: "formats configuration object in about dialog";
                readonly defaultValue: {};
                readonly contextVariable: ["config"];
            };
            readonly hideUris: {
                readonly type: "boolean";
                readonly defaultValue: false;
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
        readonly theme: {
            readonly type: "frozen";
            readonly defaultValue: {};
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    assembly: IAnyType;
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    internetAccounts: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    connections: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    aggregateTextSearchAdapters: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    plugins: import("@jbrowse/mobx-state-tree").IType<any, any, any>;
}, {
    readonly assemblies: any[];
    readonly assemblyName: string;
    readonly rpcManager: RpcManager;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
