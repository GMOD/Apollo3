/**
 * #config FormatAbout
 * #category root
 * generally exists on the config.json or root config as configuration.formatAbout
 */
export declare function FormatAboutConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    /**
     * #slot configuration.formatAbout.config
     */
    readonly config: {
        readonly type: "frozen";
        readonly description: "formats configuration object in about dialog";
        readonly defaultValue: {};
        readonly contextVariable: ["config"];
    };
    /**
     * #slot configuration.formatAbout.hideUris
     */
    readonly hideUris: {
        readonly type: "boolean";
        readonly defaultValue: false;
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
