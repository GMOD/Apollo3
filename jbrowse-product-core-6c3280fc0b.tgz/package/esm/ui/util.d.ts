import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
import type { JexlInstance } from '@jbrowse/core/util/jexlStrings';
import type { ComponentType } from 'react';
export type AboutConfig = AnyConfigurationModel | Record<string, unknown>;
export interface AboutPanelProps {
    session: AbstractSessionModel;
    config: AboutConfig;
}
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-extraAboutPanel': {
            args: ComponentType<AboutPanelProps>[];
            result: ComponentType<AboutPanelProps>[];
            props: AboutPanelProps;
        };
        /** #extensionPoint Core-replaceAbout | sync | Replace or wrap a track's About dialog body */
        'Core-replaceAbout': {
            args: ComponentType<AboutPanelProps>;
            result: ComponentType<AboutPanelProps>;
            props: AboutPanelProps;
        };
        'Core-customizeAbout': {
            args: {
                config: Record<string, unknown>;
            };
            result: {
                config: {
                    metadata?: Record<string, unknown>;
                    [key: string]: unknown;
                };
            };
            props: AboutPanelProps;
        };
    }
}
/**
 * Read a single config slot from either a live MST config or a plain snapshot
 * object, evaluating the value if it is a `jexl:` expression. A plain snapshot
 * routes through the same `isCallbackValue`/`evaluateJexl` boundary as the MST
 * path, so callback handling (empty-body guard, feature proxy) stays identical.
 */
export declare function readConfSlot<T = unknown>(config: AnyConfigurationModel | Record<string, unknown>, slotPath: string | string[], args?: Record<string, unknown>, jexl?: JexlInstance): T;
/**
 * Build the config object shown in a track's About dialog: the base config
 * merged with session- and track-level `formatAbout` overrides, then passed
 * through the `Core-customizeAbout` extension point.
 */
export declare function getAboutDialogConfig({ config, session, pluginManager, }: {
    config: AnyConfigurationModel | Record<string, unknown>;
    session: AbstractSessionModel;
    pluginManager: PluginManager;
}): {
    config: {
        metadata?: Record<string, unknown>;
        [key: string]: unknown;
    };
};
