import type PluginManager from '@jbrowse/core/PluginManager';
import type { SerializableThemeArgs, ThemeMap } from '@jbrowse/core/ui';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel ThemeManagerSessionMixin
 */
export declare function ThemeManagerSessionMixin(_pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    sessionThemeName: string;
} & {
    /**
     * #method
     */
    allThemes(): ThemeMap;
    /**
     * #getter
     */
    readonly themeName: string;
    /**
     * #getter
     */
    readonly themeOptions: SerializableThemeArgs;
    /**
     * #getter
     * Every color JBrowse renders, resolved to plain strings. This is what
     * rendering reads: it needs no React context, it crosses the RPC worker
     * boundary as itself, and it costs no UI toolkit. Prefer it over
     * `theme` anywhere the answer wanted is a color rather than a Material
     * UI component style.
     */
    readonly palette: import("@jbrowse/core/ui/palette").JBrowsePalette;
    /**
     * #getter
     * The Material UI theme, for the components that are Material UI. Its
     * palette is spliced from the same `resolvePalette` call as `palette`
     * above, so the two cannot disagree.
     */
    readonly theme: import("@mui/material").Theme;
    /**
     * #method
     * Raw `ThemeOptions` for the active theme, or a named override (used by
     * the SVG-export theme picker). Unlike `theme` (a built,
     * non-serializable MUI theme), this is the plain options object every
     * view's SVG export threads into each display's `renderSvg`, which
     * rebuilds the theme via `createJBrowseTheme` outside React context.
     */
    getActiveThemeOptions(name?: string): (import("@mui/material").ThemeOptions & {
        name?: string;
    }) | undefined;
} & {
    /**
     * #action
     */
    setThemeName(name: string): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
/** Session mixin MST type for a session that supports theming */
export type SessionWithThemesType = ReturnType<typeof ThemeManagerSessionMixin>;
/** Instance of a session that has theming support */
export type SessionWithThemes = Instance<SessionWithThemesType>;
/** Type guard for SessionWithThemes */
export declare function isSessionWithThemes(session: IAnyStateTreeNode): session is SessionWithThemes;
