import type PluginManager from '@jbrowse/core/PluginManager';
/**
 * #stateModel PreferencesSessionMixin
 *
 * loads and persists user-preference overrides (the BaseSession
 * `preferencesOverrides` volatile) to localStorage. Compose into products that
 * let users edit preferences (web, desktop); embedded sessions omit it and
 * resolve preferences from `configuration.preferences` admin defaults only.
 */
export declare function PreferencesSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    margin: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    focusedViewId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    highlightsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, never>, never>, {
    selection: unknown;
    hovered: unknown;
    queueOfDialogs: [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>][];
    preferencesOverrides: import("mobx").ObservableMap<string, unknown>;
} & {
    readonly root: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        jbrowse: import("@jbrowse/mobx-state-tree").IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            readonly assemblyNamesList: string[];
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }> & {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<import("@jbrowse/mobx-state-tree").IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        jbrowse: import("@jbrowse/mobx-state-tree").IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            readonly assemblyNamesList: string[];
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }, {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<import("@jbrowse/mobx-state-tree").IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
} & {
    readonly jbrowse: any;
    readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    readonly configuration: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>;
    readonly adminMode: boolean;
    readonly textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
} & {
    readonly assemblies: import("@jbrowse/core/assemblyManager").BaseAssemblyConfigModel[];
    readonly DialogComponent: import("@jbrowse/core/util").DialogComponentType | undefined;
    readonly DialogProps: Record<string, unknown> | undefined;
} & {
    getPreference(key: string): unknown;
    getDisplayTypeDefault(displayType: string, slot: string): unknown;
    getPreferenceChanges(): import("@jbrowse/core/util").TrackConfigChange[];
} & {
    readonly animationMode: import("@jbrowse/core/util").AnimationMode;
    readonly scrollZoom: boolean;
    readonly numberGrouping: boolean;
} & {
    afterAttach(): void;
    setSelection(thing: unknown): void;
    clearSelection(): void;
    setHovered(thing: unknown): void;
    setHighlightsVisible(arg: boolean): void;
    revealHighlights(): void;
    setPreferenceOverride(key: string, value: unknown): void;
    clearPreferenceOverrides(): void;
    clearPreferenceOverride(key: string): void;
    resetPreferenceChange(path: string[]): void;
    setScrollZoom(flag: boolean): void;
    setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
    setName(str: string): void;
    setFocusedViewId(viewId: string): void;
    removeActiveDialog(): void;
    queueDialog(doneCallback: (doneCallback: () => void) => [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>]): void;
} & {
    snackbarMessages: import("mobx").IObservableArray<import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
    errorDialog: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined;
} & {
    readonly snackbarMessageSet: Map<string, import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
} & {
    notify(message: string, level?: import("@jbrowse/core/util").NotificationLevel, action?: import("@jbrowse/core/util").SnackAction | import("@jbrowse/core/util").SnackAction[]): void;
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: import("@jbrowse/core/util").SnackAction): void;
    setErrorDialog(state: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined): void;
    pushSnackbarMessage(message: string, level?: import("@jbrowse/core/util").NotificationLevel, actions?: import("@jbrowse/core/util").SnackAction[]): void;
    popSnackbarMessage(): import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage | undefined;
    removeSnackbarMessage(message: string): void;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
