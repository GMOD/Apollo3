import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { BaseConnectionConfigModel } from '@jbrowse/core/pluggableElementTypes/models/baseConnectionConfig';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
/**
 * Persisted config of a connection track the user has opened. Keyed by trackId
 * in `connectionTrackConfigs`. `connectionId` records provenance so the track
 * can be grouped under its connection and re-hydrated on demand.
 */
export interface ConnectionTrackConfigEntry {
    connectionId: string;
    config: Record<string, unknown>;
}
/**
 * #stateModel ConnectionManagementSessionMixin
 */
export declare function ConnectionManagementSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    connectionInstances: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    /**
     * #property
     * Persisted configs of connection tracks the user has opened, keyed by
     * trackId. Unlike `connectionInstances` (stripped from snapshots, holds
     * the whole fetched hub), this holds only the tracks in use, so an open
     * connection track resolves synchronously on session load without
     * re-establishing the connection.
     */
    connectionTrackConfigs: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Record<string, ConnectionTrackConfigEntry>, Record<string, ConnectionTrackConfigEntry>, Record<string, ConnectionTrackConfigEntry>>, [undefined]>;
}, {
    /**
     * #getter
     */
    readonly connections: BaseConnectionConfigModel[];
} & {
    /**
     * #action
     */
    makeConnection(configuration: AnyConfigurationModel, initialSnapshot?: any): any;
    /**
     * #action
     * Remove a live connection instance. Tolerant of an already-dormant
     * connection (its instance is stripped from the session on reload).
     * Leaves persisted open-track configs alone — the connect() error path
     * calls this and the user's already-open tracks must survive a transient
     * failure. Full removal goes through `deleteConnection`.
     */
    breakConnection(configuration: AnyConfigurationModel): void;
    /**
     * #action
     * Close every track a connection contributed — the live instance's
     * tracks plus any persisted open-track configs (a dormant connection,
     * never expanded this session, still renders its opened tracks from
     * `connectionTrackConfigs`) — from all views/widgets, drop the live
     * instance, and drop the persisted configs. The session is left as if the
     * connection had never loaded.
     */
    teardownConnection(configuration: AnyConfigurationModel): void;
    /**
     * #action
     * Fully remove a connection: tear down its tracks and live instance, then
     * delete its config.
     */
    deleteConnection(configuration: AnyConfigurationModel): any;
    /**
     * #action
     */
    addConnectionConf(connectionConf: AnyConfigurationModel): any;
    /**
     * #action
     */
    clearConnections(): void;
    /**
     * #action
     * Snapshot a just-opened connection track's config into
     * `connectionTrackConfigs` so it survives session reload. No-op if the
     * track isn't connection-provided or is already captured (edits go
     * through `updateConnectionTrackConfig`).
     */
    captureConnectionTrack(trackId: string): void;
    /**
     * #action
     * Persist an edit to an opened connection track. The full config is
     * stored (not a delta): the connection's fetched "base" isn't present at
     * load, so only a complete config resolves synchronously.
     */
    updateConnectionTrackConfig(trackConf: Record<string, unknown> & {
        trackId: string;
    }): void;
    /**
     * #action
     * Upsert one opened connection track's persisted config.
     */
    setConnectionTrackConfig(trackId: string, connectionId: string, config: Record<string, unknown>): void;
    /**
     * #action
     * Drop a connection track's persisted config once no open view still
     * references it, so the session doesn't accumulate closed tracks.
     */
    pruneConnectionTrackConfig(trackId: string): void;
    /**
     * #action
     * Lazily establish a single connection by id if it isn't already live —
     * used when its category is expanded in the track selector. Fetches
     * silently (no view launch / success snackbar); already-open tracks keep
     * rendering from `connectionTrackConfigs` meanwhile. Idempotent.
     */
    hydrateConnection(connectionId: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
/** Session mixin MST type for a session that has connections */
export type SessionWithConnectionsType = ReturnType<typeof ConnectionManagementSessionMixin>;
/** Instance of a session that has connections: `connectionInstances`,
 * `makeConnection()`, etc. */
export type SessionWithConnections = Instance<SessionWithConnectionsType>;
/** Type guard for SessionWithConnections */
export declare function isSessionWithConnections(session: IAnyStateTreeNode): session is SessionWithConnections;
