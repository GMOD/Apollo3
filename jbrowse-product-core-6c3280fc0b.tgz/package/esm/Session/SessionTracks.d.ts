import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfiguration, AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { IAnyStateTreeNode, IAnyType, Instance } from '@jbrowse/mobx-state-tree';
export interface PlainTrackConfig {
    trackId: string;
    [key: string]: unknown;
}
/**
 * #stateModel SessionTracksManagerSessionMixin
 */
export declare function SessionTracksManagerSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    margin: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    focusedViewId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    highlightsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, never>, never>, "sessionTracks" | "trackConfigDeltas"> & {
    /**
     * #property
     * User-added session tracks (no matching admin config track). A non-admin's
     * *edits* to an existing config track are stored as deltas
     * (trackConfigDeltas), not here.
     */
    sessionTracks: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>, [undefined]>;
    /**
     * #property
     * Per-track config overrides for a non-admin, keyed by trackId, stored as a
     * *delta* against the admin-owned base config (jbrowse.tracks entry) rather
     * than a full copy — so a later admin change to an untouched field still
     * flows through (see trackConfigDelta.ts). Frozen (not a typed track array)
     * on purpose: a typed create() would fill defaults, erasing the "unset vs
     * default" distinction the delta merge relies on.
     */
    trackConfigDeltas: import("@jbrowse/mobx-state-tree").IType<Record<string, PlainTrackConfig> | null | undefined, Record<string, PlainTrackConfig>, Record<string, PlainTrackConfig>>;
}, {
    selection: unknown;
    hovered: unknown;
    queueOfDialogs: [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>][];
    preferencesOverrides: import("mobx").ObservableMap<string, unknown>;
} & {
    readonly root: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        jbrowse: IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            readonly assemblyNamesList: string[];
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }> & {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        jbrowse: IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            readonly assemblyNamesList: string[];
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }, {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
} & {
    readonly jbrowse: any;
    readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    readonly configuration: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>;
    readonly adminMode: boolean;
    readonly textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
} & {
    readonly assemblies: import("@jbrowse/core/assemblyManager").BaseAssemblyConfigModel[];
    readonly DialogComponent: import("@jbrowse/core/util").DialogComponentType | undefined;
    readonly DialogProps: Record<string, unknown> | undefined;
} & {
    getPreference(key: string): unknown;
    getDisplayTypeDefault(displayType: string, slot: string): unknown;
    getPreferenceChanges(): import("@jbrowse/core/util").TrackConfigChange[];
} & {
    readonly animationMode: import("@jbrowse/core/util").AnimationMode;
    readonly scrollZoom: boolean;
    readonly numberGrouping: boolean;
} & {
    afterAttach(): void;
    setSelection(thing: unknown): void;
    clearSelection(): void;
    setHovered(thing: unknown): void;
    setHighlightsVisible(arg: boolean): void;
    revealHighlights(): void;
    setPreferenceOverride(key: string, value: unknown): void;
    clearPreferenceOverrides(): void;
    clearPreferenceOverride(key: string): void;
    resetPreferenceChange(path: string[]): void;
    setScrollZoom(flag: boolean): void;
    setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
    setName(str: string): void;
    setFocusedViewId(viewId: string): void;
    removeActiveDialog(): void;
    queueDialog(doneCallback: (doneCallback: () => void) => [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>]): void;
} & {
    snackbarMessages: import("mobx").IObservableArray<import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
    errorDialog: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined;
} & {
    readonly snackbarMessageSet: Map<string, import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
} & {
    notify(message: string, level?: import("@jbrowse/core/util").NotificationLevel, action?: import("@jbrowse/core/util").SnackAction | import("@jbrowse/core/util").SnackAction[]): void;
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: import("@jbrowse/core/util").SnackAction): void;
    setErrorDialog(state: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined): void;
    pushSnackbarMessage(message: string, level?: import("@jbrowse/core/util").NotificationLevel, actions?: import("@jbrowse/core/util").SnackAction[]): void;
    popSnackbarMessage(): import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage | undefined;
    removeSnackbarMessage(message: string): void;
} & {
    getReferringMultiple(trackIds: string[]): Map<string, import("./ReferenceManagement.ts").ReferringNode[]>;
} & {
    getReferring(trackId: string): import("./ReferenceManagement.ts").ReferringNode[];
} & {
    dereferenceTrack(trackId: string, referring: import("./ReferenceManagement.ts").ReferringNode[]): void;
} & {
    readonly tracks: AnyConfigurationModel[];
} & {
    getTrackById(id: string): AnyConfigurationModel | undefined;
    getTracksById(): Record<string, AnyConfigurationModel>;
} & {
    addTrackConf(trackConf: AnyConfiguration): any;
    updateTrackConfiguration(trackConf: {
        trackId: string;
        [key: string]: unknown;
    }): void;
    deleteTrackConf(trackConf: AnyConfigurationModel): any;
} & {
    /**
     * Per-track private working copies (non-admin), keyed by trackId. A plain
     * Map — not observable, not persisted — mirroring the pluginManager
     * hydration cache: it holds the live MST config node a shown track's
     * in-place quick-edits mutate, so the shared frozen base is never touched.
     * See
     * [ADR-032](https://github.com/GMOD/jbrowse-components/blob/main/agent-docs/architecture-decision-records/adr-032-track-config-nodes-are-throwaway-views.md).
     *
     * Not evicted: it's a pure memoization cache, bounded by the count of
     * distinct tracks shown this session (each entry a lazily-hydrated config
     * node), holding no authoritative state — the persisted delta is the
     * source of truth, and reset/programmatic edits keep a retained copy in
     * sync. Retention is volatile RAM only (never serialized), so it's not
     * worth a reference-counted prune at every track-removal path.
     */
    editableTrackConfigs: Map<string, IAnyStateTreeNode>;
} & {
    /**
     * #getter
     * User-added session tracks first, then each admin config track with its
     * delta (trackConfigDeltas) merged over it. A base track without a delta
     * is returned unchanged by identity to keep the hydration cache warm.
     */
    readonly tracks: AnyConfigurationModel[];
    /**
     * #method
     * The overridden slots for `trackId` (empty when it has no delta): each
     * changed setting's path, its base/default value and the edited value.
     * Drives the "view changes" dialog opened from the edited badge.
     */
    getTrackConfigChanges(trackId: string): import("@jbrowse/core/util").TrackConfigChange[];
    /**
     * #method
     * A non-admin's private working copy of a track config, created on first
     * access from the current frozen (base+delta) value and cached by
     * trackId, so a shown track's in-place quick-edits (setSlot) mutate this
     * copy and never the shared frozen base node (see ADR-032). Undefined in
     * admin mode — there the base jbrowse.tracks entry is edited in place.
     * Called by TrackConfigurationReference during lazy hydration.
     */
    getEditableTrackConfig(trackId: string, frozenConfig: unknown, schemaType: IAnyType): IAnyStateTreeNode | undefined;
} & {
    afterAttach(): void;
} & {
    /**
     * #action
     */
    addTrackConf(trackConf: AnyConfiguration): any;
    /**
     * #action
     * Persist a non-admin's edited track config as a delta (trackConfigDeltas)
     * against the admin-owned base — only the changed slots — so the edits
     * persist and are shared while admin changes to untouched fields still
     * flow through. A user-added session track (no base) is edited in place.
     * Everything else (admin edits, opened connection tracks) defers to the
     * base mixin, which routes connection tracks to connectionTrackConfigs and
     * the rest to the jbrowse config.
     */
    updateTrackConfiguration(trackConf: PlainTrackConfig): void;
    /**
     * #action
     * Drop a non-admin's delta (trackConfigDeltas) so the track reverts to
     * its admin config (jbrowse.tracks) default. Unlike deleteTrackConf this
     * does not dereference the track from open views — the base config
     * re-resolves in place, so an open track stays open and simply reverts.
     */
    resetTrackConfiguration(trackId: string): void;
    /**
     * #action
     */
    deleteTrackConf(trackConf: AnyConfigurationModel): any[] | undefined;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
/** Session mixin MST type for a session that has `sessionTracks` */
export type SessionWithSessionTracksType = ReturnType<typeof SessionTracksManagerSessionMixin>;
/** Instance of a session that has `sessionTracks` */
export type SessionWithSessionTracks = Instance<SessionWithSessionTracksType>;
/** Type guard for SessionWithSessionTracks */
export declare function isSessionWithSessionTracks(thing: IAnyStateTreeNode): thing is SessionWithSessionTracks;
