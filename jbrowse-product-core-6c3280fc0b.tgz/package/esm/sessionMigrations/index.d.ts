/**
 * Migrates old session and config snapshots to be compatible with the current
 * display type registrations. Handles display types that were removed or
 * renamed in the v4 rendering rearchitecture.
 *
 * Remapped display types (see `displayTypeMap` for the band settings each one
 * carries over):
 *   LinearPileupDisplay → LinearAlignmentsDisplay
 *   LinearSNPCoverageDisplay → LinearAlignmentsDisplay
 *   LinearReadArcsDisplay → LinearAlignmentsDisplay
 *   LinearReadCloudDisplay → LinearAlignmentsDisplay
 *   LinearFeatureDisplay → LinearBasicDisplay
 *
 * Also lifts per-instance color/filter settings off the pre-4.x nested
 * `LinearAlignmentsDisplay` container (which held `PileupDisplay` /
 * `SNPCoverageDisplay` sub-nodes carrying `colorBy` / `filterBy`) into the
 * config where those settings now live as slots — see
 * `extractNestedAlignmentsSettings` — and routes the legacy per-instance
 * `heightPreConfig` display-height prop onto the `height` config slot — see
 * `extractInstanceHeight`.
 */
/**
 * Walks a session snapshot and remaps old display types to their new names.
 * Handles displays nested inside views, tracks, and sessionTracks.
 */
export declare function migrateSessionSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
/**
 * Walks a config snapshot and remaps old display types in track definitions.
 * Config tracks have displays in their configuration (not in views).
 */
export declare function migrateConfigSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
