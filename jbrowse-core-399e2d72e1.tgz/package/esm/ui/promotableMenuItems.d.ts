import type { Pin } from '../configuration/promotableDefaults.ts';
import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
import type { CheckboxItemOptions, RadioOption } from './toggleMenuItems.ts';
export declare function promotableToggleItem({ label, checked, onToggle, pin, ...opts }: {
    label: string;
    checked: boolean;
    onToggle: () => void;
    pin: Pin;
} & CheckboxItemOptions): CheckboxMenuItem;
export declare function promotableRadioItem({ label, subLabel, helpText, checked, onClick, pin, keepMenuOpen, }: {
    label: string;
    subLabel?: string;
    helpText?: string;
    checked: boolean;
    onClick: () => void;
    pin?: Pin;
    keepMenuOpen?: boolean;
}): RadioMenuItem;
export declare function promotableRadioItems<T extends string>(options: readonly RadioOption<T>[], current: T | undefined, setMode: (m: T) => void, pin: (value: T) => Pin): RadioMenuItem[];
