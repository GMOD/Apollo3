import type { ConfigurationSchemaDefinition, MergedConfigurationSchemaOptions } from './configurationSchema.ts';
import type { AnyConfigurationModel } from './types.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export interface ConfigurationSchemaMetadata {
    /** the raw slot/sub-schema/constant table, also carrying per-slot editor metadata */
    definition: ConfigurationSchemaDefinition;
    /**
     * construction options (identifier kind, baseConfiguration, etc.) as stored,
     * i.e. with any `baseConfiguration`'s hooks already composed in
     */
    options: MergedConfigurationSchemaOptions<any, any>;
}
export declare function registerConfigurationSchema(type: IAnyType, metadata: ConfigurationSchemaMetadata): void;
export declare function getConfigurationSchemaMetadata(type: IAnyType): ConfigurationSchemaMetadata | undefined;
export declare function isRegisteredConfigurationSchema(type: IAnyType): boolean;
/**
 * The slot/sub-schema/constant table for a config (includes slots merged in from
 * `baseConfiguration` at schema construction). Undefined when the argument isn't
 * a registered configuration schema. The single accessor for "what are this
 * config's slots?" — shared by the slot facade, promotable defaults, and
 * `fullConfSnapshot`.
 *
 * Takes a live node *or* the schema type itself. Every in-tree reader holds a
 * node, which is why the `getType` hop is here; a caller enumerating registered
 * element types (`ConfigSlotDefaults.test.ts`) holds only the type, and for a
 * track schema it cannot get a node — `explicitIdentifier` makes `trackId` a
 * required MST identifier, so there is nothing to `create({})`.
 */
export declare function getConfigurationSchemaDefinition(nodeOrType: AnyConfigurationModel | IAnyType): ConfigurationSchemaDefinition | undefined;
/**
 * The construction options a live config node's schema was built with
 * (identifier kind, `explicitlyTyped`, the `preProcessSnapshot` hook). Undefined
 * when the node's type isn't a registered configuration schema.
 */
export declare function getConfigurationSchemaOptions(node: AnyConfigurationModel): MergedConfigurationSchemaOptions<any, any> | undefined;
