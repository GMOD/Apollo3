import type { AnyConfigurationModel } from './types.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
/**
 * Takes a live config node *or* the schema type itself, for the reason
 * `getConfigurationSchemaDefinition` does: every resolver here holds a node,
 * while a caller enumerating registered display types
 * (`displayTypesWithPromotableSlots`) holds only `DisplayType.configSchema` and
 * has nothing to create a node from. Caching under whichever handle it was
 * given is safe — a schema registers both its outer `stripDefault` wrapper and
 * its inner model against the same slot table, so the two entries agree.
 */
export declare function promotableSlotNames(configOrType: AnyConfigurationModel | IAnyType): ReadonlySet<string>;
