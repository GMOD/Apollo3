import type { AnyConfigurationModel } from './types.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Everything the cascade needs to read a promotable slot: the display type it
 * keys the session-wide default on, and the config holding the track's own
 * value. Every entry point takes this — `resolveConf`, the control builders,
 * the worker snapshot, the badge diff — so each can take a display state node
 * directly rather than through a cast.
 *
 * Read-only, and there is no write-capable variant. A `PromotableDisplay` used
 * to exist for the one member the subsystem wrote (`setIgnorePromotedDefaults`,
 * the received-session opt-out); with that flag gone the subsystem writes
 * nothing to a display but a config slot, which `setConf` reaches through
 * `configuration`.
 *
 * **`CONF` is a parameter rather than always `AnyConfigurationModel` because
 * intersecting is not narrowing.** A caller wanting the cascade's members *and*
 * a concrete schema — a mixin casting to reach its host — writes
 * `ResolvableDisplay<XConfigModel>`. Spelling it
 * `ResolvableDisplay & { configuration: XConfigModel }` instead reads identical
 * and silently does the opposite: the intersected `configuration` is
 * `AnyConfigurationModel & XConfigModel`, `ConfigurationSchemaForModel` infers
 * the widened brand off it, and every slot name typechecks again. Two mixins
 * shipped that spelling and only a sabotage found it.
 */
export type ResolvableDisplay<CONF extends AnyConfigurationModel = AnyConfigurationModel> = IStateTreeNode & {
    type: string;
    configuration: CONF;
};
/**
 * Where the session-wide tier of the cascade is read from. Narrowed to the one
 * method so the resolver doesn't depend on the whole session type — and exported
 * for the same reason, so an entry point taking the store directly
 * (`getTrackConfigWithPromotables`) can ask for what it uses instead of for a
 * whole session a test then has to fake.
 */
export interface PromotedDefaultStore {
    getDisplayTypeDefault: (displayType: string, slot: string) => unknown;
}
/**
 * The cascade's inputs, stated directly rather than read off a display state
 * node. `ResolvableDisplay` is the usual way to supply them (see
 * `cascadeContextFor`), but nothing here *needs* a state node: the About
 * dialog's "Copy config" resolves a track's display configs directly, which is
 * what lets it answer "what would this render as" for a track that was never
 * opened. Reaching for the open display instead buys nothing — its
 * `configuration` is the same node, and its `type` is that config's own.
 */
export interface CascadeContext {
    config: AnyConfigurationModel;
    displayType: string;
    defaults: PromotedDefaultStore;
}
export declare function cascadeContextFor(self: ResolvableDisplay): CascadeContext;
/**
 * What the slot literally holds, unevaluated — a stray `jexl:` string yields the
 * raw string rather than running it. Both callers ask "is the slot set, and to
 * what kind of thing?", which has to be answerable with no feature context.
 *
 * Deliberately not `readConfObject`: for a promotable slot this is the whole
 * stored read, and both of that reader's extra behaviors are unwanted here — it
 * evaluates a `jexl:` string (which `isUsableValue` refuses anyway) and it
 * snapshots an MST-node value, which a `maybe*` slot never holds.
 */
export declare function storedSlotValue(config: AnyConfigurationModel, slot: string): unknown;
/**
 * Whether `value` could actually become this slot's promoted default — the same
 * `isUsableValue` gate the cascade puts both tiers through, asked ahead of time
 * about a value a caller is about to offer as a pin's on-value.
 *
 * Exists because a pin built over a value the gate refuses is inert in a way
 * nothing reports: `applyDefaultToggle` writes it to the session store happily,
 * `resolveSlotIn` then drops it and every track keeps resolving to the tier
 * below, and `isPromotableDefault` compares the *raw* stored value, so the pin
 * draws outline forever while a dead key sits in the user's localStorage. See
 * `makePin`, which is the one caller.
 */
export declare function isPromotableValue(config: AnyConfigurationModel, slot: string, value: unknown): boolean;
/**
 * The outcome of walking the cascade for one slot: the two tiers that fed it,
 * whether the track customized it, and the settled value.
 *
 * There is deliberately **no callback case** — a `jexl:` value fails
 * `isUsableValue` like any other unusable value and degrades to the inherited
 * one, so `value` is always readable. See `isUsableValue`.
 */
export interface SlotResolution {
    /** value a track following the default shows with nothing promoted (CSS `initial`) */
    base: unknown;
    /** the raw session-wide promoted default, if any */
    promoted: unknown;
    /** track holds its own value rather than following the default */
    customized: boolean;
    /**
     * the value came from the session-wide tier — the track follows the default
     * *and* that default moves it off `base`. The "this display picked something
     * up from the session" predicate, for the badge diff and the About dialog's
     * copy-config note. A field rather than a `!customized && !deepEqual(value,
     * base)` at each call site, because getting either half wrong is silent:
     * dropping `customized` reports a customized track as inheriting, dropping
     * the `base` compare flags a promoted default that changes nothing.
     */
    inherited: boolean;
    /** the final cascaded value (never the `undefined` inherit sentinel) */
    value: unknown;
}
export declare function resolveSlot(self: ResolvableDisplay, slot: string): SlotResolution;
export declare function resolveSlotIn(ctx: CascadeContext, slot: string): SlotResolution;
