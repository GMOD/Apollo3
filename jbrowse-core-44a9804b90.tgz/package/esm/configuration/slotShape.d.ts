import type { ConfigSlotDefinition } from './configurationSlot.ts';
/**
 * Whether a stored value could really be a value of this slot. An unusable value
 * is dropped by the cascade, so the getter, the pin and the badge all fall back
 * in lockstep.
 *
 * The `jexl:` check is the only place the subsystem handles a callback, and it
 * handles it by refusing it — a hand-edited config or default store is untyped,
 * and a callback string would otherwise reach a renderer as a literal value.
 * DISPLAY_TYPE_DEFAULTS.md §"No callbacks".
 */
export declare function isUsableValue(def: ConfigSlotDefinition, value: unknown): boolean;
