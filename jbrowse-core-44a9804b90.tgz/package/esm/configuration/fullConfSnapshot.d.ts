import type { AnyConfigurationModel } from './types.ts';
/**
 * Plain-object snapshot of a configuration model including ALL values, even
 * defaults. Unlike `getSnapshot()`, which strips a slot sitting at its default
 * via `types.stripDefault`, this returns every slot's current value, so the
 * result is a self-contained config object an RPC worker can read with no
 * schema. JEXL callback slots keep their raw `"jexl:..."` string for the worker
 * to evaluate per-feature.
 *
 * **Why this isn't exported from `@jbrowse/core/configuration`.** It was
 * (as `getConfSnapshot`), and being reachable was the hazard. A promotable slot
 * resolves against the session at read time, so snapshotting one raw ships the
 * bare `undefined` inherit sentinel to a worker with no session to resolve it
 * against — and every display in the repo now has promotable slots. The public
 * form used to defend itself by *throwing* on such a config, which meant the
 * obvious spelling in a new `rpcProps()` failed at runtime, on the first fetch,
 * in whichever product exercised that display. Off the barrel, the same mistake
 * is an unresolved import: it can't be written at all, and
 * `getConfigSnapshotWithPromotables(display)` is the one way across the boundary.
 * So this is the shared walker those resolvers are built on, not an entry point.
 *
 * The nested-schema guard below is the part of that defense still worth
 * enforcing at runtime, since no import can express it.
 *
 * Note: only handles slots and direct sub-configuration models. Arrays or maps
 * of sub-schemas are silently dropped — nothing has needed them.
 */
export declare function fullConfSnapshot(confObject: AnyConfigurationModel): Record<string, unknown>;
