import type { Feature } from '../util/index.ts';
import type { JexlInstance } from '../util/jexlStrings.ts';
import type { AnyConfigurationModel, AnyConfigurationSchemaType, AnyConfigurationSnapshot, ConfigurationSchemaForModel, ConfigurationSlotName, ConfigurationSlotValue } from './types.ts';
import type { IMSTMap } from '@jbrowse/mobx-state-tree';
/**
 * #api core/configuration
 * Given a configuration model (an instance of a ConfigurationSchema), read the
 * configuration value at the given path. Use this when you hold the
 * configuration model directly, e.g. an entry from `session.tracks`.
 *
 * Wants a **live config node**, not a snapshot of one, and passing a snapshot is
 * a type error. Slots are built with `types.stripDefault`, so a slot sitting at
 * its default is absent from a snapshot — "unset" and "at its default" are
 * indistinguishable there, and a read off one reports a default as missing.
 *
 * That is enforced in the types only, deliberately: it can't be a runtime check.
 * `generateHierarchy` reads slots straight off the **un-hydrated frozen** entries
 * of `jbrowse.tracks` on purpose, because hydrating every track to answer the
 * track selector is what `types.frozen` exists to avoid — and those reads are
 * indistinguishable at runtime from the broken spelling.
 *
 * @param model - instance of ConfigurationSchema
 * @param slotPaths - array of paths to read
 * @param args - extra arguments e.g. for a feature callback,
 *  will be sent to each of the slotNames
 */
export declare function readConfObject(confObject: AnyConfigurationModel): AnyConfigurationSnapshot;
export declare function readConfObject<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>> | string[] = ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(confObject: CONFMODEL, slotPath?: SLOT, args?: Record<string, unknown>): SLOT extends string ? ConfigurationSlotValue<ConfigurationSchemaForModel<CONFMODEL>, SLOT> : any;
export declare function readConfObject(confObject: IMSTMap<AnyConfigurationSchemaType>, slotPath?: string | string[], args?: Record<string, unknown>): any;
/**
 * Read a value from a plain config snapshot object. Automatically evaluates
 * "jexl:..." strings per-feature. Works without MST — intended for use in
 * rendering code (GPU, Canvas2D, workers). Pass the realm's `pluginManager.jexl`
 * so plugin-registered functions (e.g. in a custom `mouseover` slot) resolve.
 */
export declare function readConfigValue<T>(config: Record<string, unknown>, key: string | string[], feature: Feature, jexl: JexlInstance): T;
/**
 * #api core/configuration
 * Read a single config slot from a config that may be **either** a live MST
 * node or a plain snapshot object, evaluating the value if it is a `jexl:`
 * expression. For the dialogs and panels that are handed a track config without
 * knowing which of the two they got. An About panel gets a hydrated track
 * config from the session and a bare object from an embedded caller.
 *
 * Reach for `readConfObject` or `readConfigValue` when the shape is known:
 * this one decides at runtime, and the plain branch inherits the snapshot
 * caveat (a slot at its default is absent from a snapshot, so it reads
 * `undefined`).
 *
 * @param config - live config model or plain config object
 * @param slotPath - slot name, or path of sub-config names ending in a slot
 * @param args - extra arguments for a callback slot, e.g. `{ feature }`
 * @param jexl - realm jexl instance, required only to evaluate a callback slot
 *  on a plain object (a live node resolves its own from env)
 */
export declare function readConfSlot<T = unknown>(config: AnyConfigurationModel | Record<string, unknown>, slotPath: string | string[], args?: Record<string, unknown>, jexl?: JexlInstance): T;
