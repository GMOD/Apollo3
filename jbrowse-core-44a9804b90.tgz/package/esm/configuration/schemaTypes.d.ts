import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationModel, AnyConfigurationSchemaType } from './types.ts';
/**
 * given a union of explicitly typed configuration schema types,
 * extract an array of the type names contained in the union
 *
 * @param unionType -
 * @returns Array of type names contained in the union
 */
export declare function getTypeNamesFromExplicitlyTypedUnion(maybeUnionType: unknown): string[];
export declare function isBareConfigurationSchemaType(thing: unknown): thing is AnyConfigurationSchemaType;
export declare function isConfigurationSchemaType(thing: unknown): thing is AnyConfigurationSchemaType;
/**
 * A configuration schema definition maps each key to exactly one of three kinds
 * of entry:
 *
 *  - constant   → a bare string/number (becomes a volatile instance constant)
 *  - slot       → a ConfigSlotDefinition object (has a `type` field, not a type)
 *  - sub-schema → an MST configuration-schema type, see isConfigurationSchemaType
 */
export declare function isConstantEntry(def: unknown): def is string | number;
export declare function isSlotDefinitionEntry(def: unknown): def is ConfigSlotDefinition;
export declare function isConfigurationModel(thing: unknown): thing is AnyConfigurationModel;
