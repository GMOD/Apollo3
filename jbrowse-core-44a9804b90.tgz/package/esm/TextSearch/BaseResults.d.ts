export interface BaseResultArgs {
    /** #resultField primary display text, and the fallback for `displayString` */
    label: string;
    /** #resultField alternate display text; falls back to `label` */
    displayString?: string;
    /** #resultField where to navigate, e.g. `chr1:1000..2000`. A hit with neither this nor `results` is treated as a refName */
    locString?: string;
    /** #resultField a refName to navigate to; `RefSequenceResult` reads it in place of `locString` */
    refName?: string;
    /** #resultField the track to open or highlight alongside the navigation */
    trackId?: string;
    /** #resultField nested hits, shown as a disambiguation dialog instead of navigating */
    results?: BaseResult[];
    /**
     * #resultField this hit matched the query exactly, as the adapter judges it
     *
     * Whether this hit matched the query exactly, as the adapter judges it —
     * which is not something a caller can recompute. Trix calls a hit exact when
     * *any* indexed attribute equals the query, so searching a feature's ID
     * matches exactly even though neither the label nor the display string is
     * the query. Set it and a single unrestricted search answers both "what
     * matches?" and "what matches precisely?"; leave it unset and an adapter's
     * results simply never win the exact-first pass.
     */
    exact?: boolean;
}
export default class BaseResult {
    label: string;
    displayString?: string;
    trackId?: string;
    locString?: string;
    results?: BaseResult[];
    exact?: boolean;
    constructor(args: BaseResultArgs);
    getLabel(): string;
    getDisplayString(): string;
    getTrackId(): string | undefined;
    getId(): string;
    isExact(): boolean;
    hasLocation(): boolean;
    getLocation(): string | undefined;
}
export declare class RefSequenceResult extends BaseResult {
    constructor(args: BaseResultArgs);
}
