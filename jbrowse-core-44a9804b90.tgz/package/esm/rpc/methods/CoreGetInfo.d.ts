import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetInfo extends RpcMethodType<'CoreGetInfo'> {
    name: 'CoreGetInfo';
    execute(args: RpcExecuteArgs<'CoreGetInfo'>): Promise<unknown>;
}
