import RpcMethodTypeWithRenameRegions from '../../pluggableElementTypes/RpcMethodTypeWithRenameRegions.ts';
import SimpleFeature from '../../util/simpleFeature.ts';
import type { SimpleFeatureSerialized } from '../../util/simpleFeature.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetFeatures extends RpcMethodTypeWithRenameRegions<'CoreGetFeatures'> {
    name: 'CoreGetFeatures';
    deserializeReturn(feats: SimpleFeatureSerialized[], _args: unknown): Promise<SimpleFeature[]>;
    execute(args: RpcExecuteArgs<'CoreGetFeatures'>): Promise<SimpleFeatureSerialized[]>;
}
