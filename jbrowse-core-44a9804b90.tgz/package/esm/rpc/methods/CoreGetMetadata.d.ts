import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetMetadata extends RpcMethodType<'CoreGetMetadata'> {
    name: 'CoreGetMetadata';
    execute(args: RpcExecuteArgs<'CoreGetMetadata'>): Promise<unknown>;
}
