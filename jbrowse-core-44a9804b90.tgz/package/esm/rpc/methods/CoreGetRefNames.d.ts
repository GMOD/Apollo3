import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetRefNames extends RpcMethodType<'CoreGetRefNames'> {
    name: 'CoreGetRefNames';
    execute(args: RpcExecuteArgs<'CoreGetRefNames'>): Promise<string[] | never[]>;
}
