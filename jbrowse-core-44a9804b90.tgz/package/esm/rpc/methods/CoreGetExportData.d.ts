import RpcMethodTypeWithRenameRegions from '../../pluggableElementTypes/RpcMethodTypeWithRenameRegions.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetExportData extends RpcMethodTypeWithRenameRegions<'CoreGetExportData'> {
    name: 'CoreGetExportData';
    execute(args: RpcExecuteArgs<'CoreGetExportData'>): Promise<string | undefined>;
}
