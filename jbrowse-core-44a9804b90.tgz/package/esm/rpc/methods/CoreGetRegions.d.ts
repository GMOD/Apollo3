import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetRegions extends RpcMethodType<'CoreGetRegions'> {
    name: 'CoreGetRegions';
    execute(args: RpcExecuteArgs<'CoreGetRegions'>): Promise<never[] | import("../../util/index.ts").NoAssemblyRegion[]>;
}
