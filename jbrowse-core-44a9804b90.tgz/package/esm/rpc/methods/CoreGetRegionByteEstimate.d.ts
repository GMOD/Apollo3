import RpcMethodTypeWithRenameRegions from '../../pluggableElementTypes/RpcMethodTypeWithRenameRegions.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetRegionByteEstimate extends RpcMethodTypeWithRenameRegions<'CoreGetRegionByteEstimate'> {
    name: 'CoreGetRegionByteEstimate';
    execute(args: RpcExecuteArgs<'CoreGetRegionByteEstimate'>): Promise<number | undefined>;
}
