import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { RpcExecuteArgs } from '../RpcRegistry.ts';
export default class CoreGetSequence extends RpcMethodType<'CoreGetSequence'> {
    name: 'CoreGetSequence';
    execute(args: RpcExecuteArgs<'CoreGetSequence'>): Promise<string | undefined>;
}
