/**
 * What a container holds, as `[path, value]` — the one place that knows a Map
 * and a Set carry payload the way an object's fields do.
 *
 * `Object.entries` yields `[]` for both, so a matrix keyed by sample name read
 * as an EMPTY payload to every walk in this file. That is the shape
 * `MultiWiggleGetScoreMatrix` and `MultiSampleVariantGetGenotypeMatrix` return,
 * and it failed in both directions at once: the wiggle matrix's hand-built list
 * is correct and `checkTransferList` reported every entry of it as "not in the
 * payload" — the exact wording {@link bufferPaths} exists to avoid — while the
 * variant matrix transfers nothing and no check could say so.
 *
 * A Map's key is worth printing (`rows.HG002` names the sample); a Set has no
 * name for its members, so they get their position.
 */
export declare function containerEntries(obj: object, prefix: string): Generator<[string, unknown]>;
/**
 * Every payload field each transferred buffer is reachable by.
 *
 * Several fields can name one buffer, so this collects all of them rather than
 * the first: subarrays of a shared allocation are exactly how a duplicate entry
 * gets into a hand-built list, and naming both ends is what makes that
 * actionable.
 */
export declare function bufferPaths(value: unknown): Map<ArrayBufferLike, string[]>;
/**
 * The error to send when `postMessage` rejects a reply, with the transfer-list
 * entry it blamed named by field.
 *
 * Returns the original error untouched when the message addresses no index: an
 * unserializable payload ("() => {} could not be cloned") reports that way and
 * has nothing to do with the transfer list, so a report about transfers would
 * point at the wrong thing entirely.
 */
export declare function explainTransferError(error: unknown, value: unknown, transferables: readonly Transferable[], method?: string): unknown;
