import type { StatusCallback } from '../util/progress.ts';
import type { StopToken, StopTokenChecker } from '../util/stopToken.ts';
import type { AugmentedRegion } from '../util/types/data.ts';
/**
 * Which question a byte budget asks of a region set: the gate's per-region
 * budget, or the save dialog's bound on the whole download.
 */
export type ByteEstimateScope = 'largestRegion' | 'wholeRequest';
export interface ByteMeasurableAdapter {
    getRegionByteSize: (regions: AugmentedRegion[], opts?: {
        stopToken?: StopToken;
        statusCallback?: StatusCallback;
    }) => Promise<number | undefined>;
}
/**
 * What a gated fetch RPC answers instead of a payload when a region is over
 * budget on either axis, carrying everything measured on the way: the byte
 * stage runs first, so a density refusal still has `bytes`.
 */
export interface RegionTooLargeResult {
    regionTooLarge: true;
    featureCount?: number;
    bytes?: number;
}
export declare function isRegionRefused(result: unknown): result is RegionTooLargeResult;
/** Undefined, never 0, when no region could be measured. */
export declare function largestRegionBytes(perRegion: (number | undefined)[]): number | undefined;
/** A non-positive declared limit means "no opinion" (htsget reports 0). */
export declare function adapterByteLimit(declared: unknown, fallback: number): number;
export declare function overByteBudget(bytes: number | undefined, byteLimit: number | undefined): bytes is number;
/** The bytes a fetch result reports, payload or refusal; absent means unmeasured. */
export declare function measuredBytes(result: unknown): number | undefined;
/**
 * The first await of every gated feature fetch: each region's index-only byte
 * estimate, judged by the largest because the budget is per region. `bytes`
 * comes back either way; when `tooLarge` is set the caller returns it and
 * fetches nothing. No budget means no measurement.
 */
export declare function measureRegionBytes({ dataAdapter, regions, byteLimit, stopToken, statusCallback, stopTokenCheck, }: {
    dataAdapter: ByteMeasurableAdapter;
    regions: AugmentedRegion[];
    byteLimit: number | undefined;
    stopToken?: StopToken;
    statusCallback?: StatusCallback;
    stopTokenCheck?: StopTokenChecker;
}): Promise<{
    bytes?: number;
    tooLarge?: RegionTooLargeResult;
}>;
