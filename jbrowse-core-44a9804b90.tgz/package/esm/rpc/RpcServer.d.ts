import type { ErrorObject } from './serializeError/index.ts';
export interface RpcResult<T = unknown> {
    __rpcResult: true;
    value: T;
    transferables: Transferable[];
}
export declare function rpcResult<T>(value: T, transferables: Transferable[]): RpcResult<T>;
export declare function rpcResultWithArrayBuffers<T extends object>(value: T): RpcResult<T>;
type Procedure = (data: unknown) => Promise<unknown>;
interface RpcMessageData {
    method: string;
    uid: string;
    libRpc?: true;
    data: unknown;
    stopToken?: string;
}
export default class RpcServer {
    protected methods: Record<string, Procedure>;
    private self;
    constructor(methods: Record<string, Procedure>);
    handler(e: MessageEvent<RpcMessageData>): void;
    private post;
    protected reply(uid: string, response: unknown, method?: string): void;
    /**
     * The only frame that must never fail to send, because it is the last one: a
     * `throw` that throws leaves the call unsettled, and an unsettled call is a
     * display spinning forever with no error to show. Everything upstream of here
     * routes a failure into this, including {@link reply}'s own catch, so there is
     * nothing left to catch it.
     *
     * It can fail. `serializeError` copies an error's own-enumerable properties so
     * custom data survives the boundary, and it only skips the ones that are
     * *themselves* functions — a property holding an object with a method on it
     * (an arrow-function class field, an adapter, a `cause` that is a `Response`)
     * is copied whole and is not structured-cloneable. So fall back to the
     * message, which by construction is a string.
     */
    protected throw(uid: string, error: ErrorObject | string): void;
    emit(eventName: string, data: unknown, transferables?: Transferable[]): void;
}
export {};
