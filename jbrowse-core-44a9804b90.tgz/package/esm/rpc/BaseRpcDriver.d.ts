import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type RpcMethodType from '../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { RpcHandles } from './RpcRegistry.ts';
/**
 * The method that drops a session's cached adapters, named once because
 * {@link BaseRpcDriver.freeSession} is the only thing that dispatches it.
 */
export declare const CORE_FREE_RESOURCES = "CoreFreeResources";
export default abstract class BaseRpcDriver {
    protected pluginManager: PluginManager;
    config: AnyConfigurationModel;
    abstract name: string;
    constructor(pluginManager: PluginManager, config: AnyConfigurationModel);
    /**
     * Drop everything this driver holds for a session — the worker-side adapter
     * cache, and whatever bookkeeping the transport keeps alongside it.
     *
     * A driver operation rather than a `call`, because a free has nothing to do on
     * a transport that never ran this session and must not outlive `destroy`;
     * routing it through `call` did both. ADR-086.
     *
     * The base behavior is the main-thread one: run the method in this realm,
     * where `dataAdapterCache` lives. `invoke`, not `execute`, for the reason
     * `MainThreadRpcDriver.transport` uses it.
     */
    freeSession(sessionId: string): Promise<void>;
    destroy(): void;
    call(sessionId: string, functionName: string, args: Record<string, unknown> & RpcHandles): Promise<unknown>;
    protected abstract transport(sessionId: string, rpcMethod: RpcMethodType, serializedArgs: Record<string, unknown>, statusCallback: StatusCallback | undefined): Promise<unknown>;
}
