import BaseRpcDriver from './BaseRpcDriver.ts';
import type RpcMethodType from '../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../util/progress.ts';
/**
 * RPC driver that runs RPC functions in-band on the main thread. It owns no
 * worker pool, so `destroy` stays the BaseRpcDriver no-op and `freeSession`
 * stays that class's in-realm free — the adapter cache this driver fills is the
 * main thread's own.
 */
export default class MainThreadRpcDriver extends BaseRpcDriver {
    name: string;
    protected transport(_sessionId: string, rpcMethod: RpcMethodType, serializedArgs: Record<string, unknown>, statusCallback: StatusCallback | undefined): Promise<unknown>;
}
