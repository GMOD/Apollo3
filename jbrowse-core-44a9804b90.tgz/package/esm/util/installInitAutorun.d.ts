import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
interface InitAutorunHost<T> extends IStateTreeNode {
    init?: T;
    setInit: (init?: T) => void;
    setError: (error: unknown) => void;
}
export interface InitApplyContext {
    /**
     * True once this init can no longer be the one being applied: the node is
     * gone, or a newer `setInit` has replaced it. Any mid-apply wait that can
     * park indefinitely must fold this into its condition — an unbounded wait on
     * state that never arrives holds the drain open, and the newer init that
     * would have superseded it is exactly what gets stranded. This is the causal
     * form of the wait ceiling; a fixed timeout bounds the same hazard only by
     * guessing, and pays for it by expiring on slow-but-healthy loads.
     */
    superseded: () => boolean;
}
interface InitAutorunOptions<T> {
    /** autorun name, for the MobX devtools/spy stream */
    name: string;
    /**
     * Read synchronously at the top of the autorun, so whatever it touches is
     * the dependency set that re-fires this. Typically the measured width plus
     * whatever the view needs before `apply` can run.
     */
    ready: () => boolean;
    /**
     * Whether the view has materialized — the same line each view's
     * postProcessSnapshot draws for persistence (dotplot: assemblyNames set;
     * synteny: rows built). Decides the failure policy, see below.
     */
    materialized: () => boolean;
    /** Apply one init blob. Owns the ordered steps; never clears `init`. */
    apply: (init: T, ctx: InitApplyContext) => Promise<void>;
}
/**
 * The init state machine shared by the views that take a declarative `init`
 * blob (LinearGenomeView, DotplotView, LinearSyntenyView): the re-entry guard,
 * the readiness gate, the serialized drain, the identity-checked clear, the
 * isAlive guards, and one failure policy.
 *
 * The failure policy keys off `materialized`, the same line each view's
 * postProcessSnapshot already draws for persistence:
 *
 * - Not materialized — nothing is on screen and `init` is still persisted, so
 *   keep it for a reload retry and `setError`. That flips the view onto its
 *   import form, which renders the error in its own banner; a snackbar would
 *   state the same failure twice and the banner is the one that persists.
 * - Materialized — the view works, so a later failure is one sub-step's
 *   problem and must not take the view down with it. `setError` would, since
 *   showImportForm keys off `error` alone and would discard rows that loaded
 *   fine, so report it as a snackbar instead. Clearing `init` is also what
 *   disarms the re-fire: `ready` usually folds in the measured width, so
 *   leaving it set lets any resize re-run `apply` over a half-applied init.
 *
 * `apply` therefore never clears `init` and never catches for reporting — it
 * catches only the failures it wants to keep going through (a bad locstring in
 * one row), and everything it lets escape is fatal-as-of-that-point.
 */
export declare function installInitAutorun<T>(self: InitAutorunHost<T>, opts: InitAutorunOptions<T>): void;
export {};
