import type { DialogHost, NotificationSink, PaletteHost, RpcHost, SessionServices } from './types/services.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * #api core/util
 * The services a session offers that cost nothing application-shaped to name.
 * Prefer one of the narrower accessors below, which say which of them the
 * calling module actually uses.
 */
export declare function getSessionServices(node: IAnyStateTreeNode): SessionServices;
/**
 * #api core/util
 * The host's RPC entry point, for a module that issues RPCs and nothing else.
 */
export declare function getRpcHost(node: IAnyStateTreeNode): RpcHost;
/**
 * #api core/util
 * Where a display puts a message it cannot draw itself.
 */
export declare function getNotificationSink(node: IAnyStateTreeNode): NotificationSink;
/**
 * #api core/util
 * Where a display puts a dialog it cannot mount itself.
 */
export declare function getDialogHost(node: IAnyStateTreeNode): DialogHost;
/**
 * #api core/util
 * The colors to draw with, and the args that rebuild them in a worker.
 */
export declare function getPaletteHost(node: IAnyStateTreeNode): PaletteHost;
