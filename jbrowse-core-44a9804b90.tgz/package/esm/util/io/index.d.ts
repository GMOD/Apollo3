import type PluginManager from '../../PluginManager.ts';
import type { FileLocation, UriLocation } from '../types/data.ts';
import type { Fetcher, GenericFilehandle } from 'generic-filehandle2';
/** if a UriLocation has a baseUri, resolves its uri with respect to that base */
export declare function resolveUriLocation(location: UriLocation): UriLocation;
export declare function openLocation(location: FileLocation, pluginManager?: PluginManager): GenericFilehandle;
/**
 * Open a tabix-style index (TBI or CSI) and return it under the correct
 * filehandle key for `new TabixIndexedFile(...)`. Centralizes the CSI-vs-TBI
 * branch so callers can't mismatch the two — e.g. writing `=== 'CSI'` on both
 * the csi and tbi lines, which silently yields no index at all.
 */
export declare function openTabixIndexFilehandle(location: FileLocation, indexType: string | undefined, pluginManager?: PluginManager): {
    csiFilehandle: GenericFilehandle;
    tbiFilehandle?: undefined;
} | {
    csiFilehandle?: undefined;
    tbiFilehandle: GenericFilehandle;
};
export declare function getFetcher(location: FileLocation, pluginManager?: PluginManager): Fetcher;
export { CachedFilehandle, RemoteFileWithRangeCache, } from './RemoteFileWithRangeCache.ts';
