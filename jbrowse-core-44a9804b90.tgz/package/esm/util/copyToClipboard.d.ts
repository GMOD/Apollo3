export interface CopyOptions {
    format?: string;
}
export default function copyToClipboard(text: string, options?: CopyOptions): Promise<void>;
