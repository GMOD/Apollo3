/**
 * Shared utilities for interval-based layout algorithms, used by
 * GranularRectLayout.
 */
/**
 * Check if a range [left, right) is clear (no overlaps) in a sorted interval array.
 * Intervals are stored as flat array: [start1, end1, start2, end2, ...]
 *
 * Uses linear scan for small arrays (< 40 elements) and binary search for larger.
 */
export declare function isRangeClear(intervals: number[], left: number, right: number): boolean;
/**
 * Find insertion point for a new interval in a sorted interval array.
 * Returns the index where [left, right] should be inserted.
 */
export declare function findInsertionPoint(intervals: number[], left: number): number;
/**
 * Insert an interval into a sorted interval array using manual shift
 * (avoids splice GC pressure).
 */
export declare function insertInterval(intervals: number[], idx: number, left: number, right: number): void;
