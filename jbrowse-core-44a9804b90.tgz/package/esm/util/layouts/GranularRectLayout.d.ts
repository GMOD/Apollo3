import type { BaseLayout, RectTuple, Rectangle, SerializedLayout } from './BaseLayout.ts';
export default class GranularRectLayout<T> implements BaseLayout<T> {
    private pitchX;
    private pitchY;
    private hardRowLimit;
    private bitmap;
    private rectangles;
    maxHeightReached: boolean;
    private maxHeight;
    private pTotalHeight;
    /**
     * pitchX - layout grid pitch in the X direction
     * pitchY - layout grid pitch in the Y direction
     * maxHeight - maximum layout height in pixels, default 10000
     */
    constructor({ pitchX, pitchY, maxHeight, hardRowLimit, }?: {
        pitchX?: number;
        pitchY?: number;
        maxHeight?: number;
        hardRowLimit?: number;
    });
    /**
     * @returns top position for the rect, or Null if laying
     *  out the rect would exceed maxHeight
     */
    addRect(id: string, left: number, right: number, height: number, data?: T, serializableData?: T): number | null;
    private getOrCreateRow;
    addRectToBitmap(rect: Rectangle<T>): void;
    /**
     *  Given a range of X coordinates, deletes all data dealing with
     *  the features.
     */
    discardRange(left: number, right: number): void;
    getByCoord(x: number, y: number): string | undefined;
    getByID(id: string): RectTuple | undefined;
    getDataByID(id: string): T | undefined;
    getTotalHeight(): number;
    getRectangles(): Map<string, RectTuple>;
    serializeRegion(region: {
        start: number;
        end: number;
    }): SerializedLayout;
    toJSON(): SerializedLayout;
}
