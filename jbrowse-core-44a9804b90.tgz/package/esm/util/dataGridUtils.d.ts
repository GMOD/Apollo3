import type { GridRowId, GridRowSelectionModel } from '@mui/x-data-grid';
export declare function measureGridWidth(elements: unknown[], args?: {
    minWidth?: number;
    fontSize?: number;
    maxWidth?: number;
    padding?: number;
    stripHTML?: boolean;
}): number;
export declare function resolveSelectedIds(model: GridRowSelectionModel, allIds: Iterable<GridRowId>): Set<GridRowId>;
