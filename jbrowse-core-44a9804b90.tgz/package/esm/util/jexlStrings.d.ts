export interface JexlExpression {
    eval(context?: Record<string, unknown>): unknown;
    _exprStr?: string;
}
export interface JexlInstance {
    compile(code: string): JexlExpression;
}
/** The `jexl:` prefix marks a config value as a deferred callback expression. */
export declare const JEXL_PREFIX = "jexl:";
export declare function isJexl(str: unknown): str is string;
/** Add the `jexl:` prefix unless the string already carries it. */
export declare function ensureJexlPrefix(code: string): string;
/**
 * Compile a `jexl:...` string to an Expression. Compilation is memoized on the
 * jexl instance (see `createJexlInstance`), so this is a thin prefix-stripping
 * wrapper.
 *
 * @param str - string of code like `jexl:...`
 * @param jexl - the instance whose registered functions the expression may call
 *   (`pluginManager.jexl` on eval paths)
 */
export declare function stringToJexlExpression(str: string, jexl: JexlInstance): JexlExpression;
