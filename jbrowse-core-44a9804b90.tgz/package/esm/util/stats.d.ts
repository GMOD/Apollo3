import type { Feature } from './simpleFeature.ts';
import type { NoAssemblyRegion } from './types/data.ts';
import type { Observable } from 'rxjs';
export interface UnrectifiedQuantitativeStats {
    scoreMin: number;
    scoreMax: number;
    scoreSum: number;
    scoreSumSquares: number;
    featureCount?: number;
    basesCovered: number;
    scoreMeanMin?: number;
    scoreMeanMax?: number;
}
export interface RectifiedQuantitativeStats extends UnrectifiedQuantitativeStats {
    featureDensity: number;
    scoreMean: number;
    scoreStdDev: number;
}
export interface QuantitativeStats extends RectifiedQuantitativeStats {
    currStatsBpPerPx: number;
}
/**
 * calculate standard deviation using the 'shortcut method' that accepts
 * the sum and the sum squares of the elements
 *
 * @param sum - sum(i, 1..n)
 * @param sumSquares - sum(i^2, 1..n)
 * @param n - number of elements
 * @param population - boolean: use population instead of sample correction
 * @returns - the estimated std deviation
 */
export declare function calcStdFromSums(sum: number, sumSquares: number, n: number, population?: boolean): number;
/**
 * @param stats - a summary stats object with scoreSum, featureCount,
 * scoreSumSquares, and basesCovered
 * @returns - a summary stats object with
 * scoreMean, scoreStdDev, and featureDensity added
 */
export declare function rectifyStats(s: UnrectifiedQuantitativeStats): RectifiedQuantitativeStats;
/**
 * transform a list of scores to summary statistics
 *
 * @param region - object with start, end
 * @param features - array of features which are possibly summary features
 * @returns - object with scoreMax, scoreMin, scoreSum, scoreSumSquares, etc
 */
export declare function scoresToStats(region: NoAssemblyRegion, feats: Observable<Feature>): Promise<RectifiedQuantitativeStats>;
export declare function blankStats(): RectifiedQuantitativeStats;
