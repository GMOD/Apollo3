import type PluginManager from '../PluginManager.ts';
import type { AdapterConfig } from './tracks.ts';
import type { FileLocation } from './types/data.ts';
import type { AdapterSpec } from '@jbrowse/add-track-core';
/**
 * The adapter config one format-table entry describes: the data file under the
 * field that format's adapter reads it from, plus wherever that adapter expects
 * its index — nested under `index` for BAM and the tabix formats, a top-level
 * sidecar field for CRAM and FASTA.
 *
 * `index` is the location the caller was handed (the "index file" field of the
 * add-track form); every sidecar the caller did not name is derived from the
 * data file's own location.
 */
export declare function adapterConfigFromSpec(spec: AdapterSpec, file: FileLocation, index?: FileLocation): AdapterConfig | undefined;
/**
 * Guess every format `@jbrowse/add-track-core`'s table describes — the same
 * table `@jbrowse/cli`'s `add-track` reads, so a file resolves to the same
 * adapter config in the app and on the command line.
 *
 * Whether a build can open a format is decided by `hasAdapterType`, not by the
 * table: guessing `BamAdapter` in a build with no alignments plugin writes a
 * track config that fails at render. A plugin therefore registers its adapters
 * and nothing else — there is no format list to keep in step. ADR-077.
 *
 * `CorePlugin` installs this first, so any `addAdapterGuesser` a plugin
 * registers is later in the chain and wins over the table. That is how a format
 * the table cannot express is added, and how a third-party plugin claims one.
 */
export declare function installFormatGuessers(pluginManager: PluginManager): void;
