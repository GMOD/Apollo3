export declare function clamp(num: number, min: number, max: number): number;
export declare function minmax(a: number, b: number): readonly [number, number];
export declare function max(arr: ArrayLike<number>, init?: number): number;
export declare function maxFinite(arr: ArrayLike<number>, init?: number): number;
export declare function min(arr: ArrayLike<number>, init?: number): number;
export declare function sum(arr: ArrayLike<number>): number;
export declare function avg(arr: ArrayLike<number>): number;
export declare function setNumberGrouping(enabled: boolean): void;
export declare function getNumberGrouping(): boolean;
export declare function toLocale(n: number): string;
export declare function toPrecision(s: number, n?: number): number;
export declare function reducePrecision(s: number, n?: number): string;
/**
 * A byte count as a person reads it. Shared by the region-too-large banner and
 * the save-track-data dialog, which quote the same index estimate and would
 * otherwise word the same number two ways.
 */
export declare function getDisplayStr(totalBytes: number): string;
export declare function radToDeg(radians: number): number;
export declare function polarToCartesian(rho: number, theta: number): [number, number];
