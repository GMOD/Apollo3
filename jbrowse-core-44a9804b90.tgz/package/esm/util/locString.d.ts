export interface ParsedLocString {
    assemblyName?: string;
    refName: string;
    start?: number;
    end?: number;
    reversed?: boolean;
}
export declare class UnknownRefNameError extends Error {
    name: string;
}
export declare function parseLocStringOneBased(locString: string, isValidRefName: (refName: string, assemblyName?: string) => boolean): ParsedLocString;
export declare function parseLocString(locString: string, isValidRefName: (refName: string, assemblyName?: string) => boolean): ParsedLocString;
/**
 * Assemble a 1-based "locString" from an interbase genomic location
 * @param region - Region
 * @example
 * ```ts
 * assembleLocString({ refName: 'chr1', start: 0, end: 100 })
 * // ↳ 'chr1:1..100'
 * ```
 * @example
 * ```ts
 * assembleLocString({ assemblyName: 'hg19', refName: 'chr1', start: 0, end: 100 })
 * // ↳ '{hg19}chr1:1..100'
 * ```
 * @example
 * ```ts
 * assembleLocString({ refName: 'chr1' })
 * // ↳ 'chr1'
 * ```
 * @example
 * ```ts
 * assembleLocString({ refName: 'chr1', start: 0 })
 * // ↳ 'chr1:1..'
 * ```
 * @example
 * ```ts
 * assembleLocString({ refName: 'chr1', end: 100 })
 * // ↳ 'chr1:1..100'
 * ```
 * @example
 * ```ts
 * assembleLocString({ refName: 'chr1', start: 0, end: 1 })
 * // ↳ 'chr1:1'
 * ```
 */
export declare function assembleLocString(region: ParsedLocString): string;
/**
 * Same as {@link assembleLocString}, but with the coordinates left unformatted:
 * no thousand separators, and never affected by the `numberGrouping` display
 * preference. Use this wherever the result is compared, keyed on, or parsed
 * rather than read — block keys, dedup buckets, locStrings handed back to
 * `parseLocString` — both because it is faster (block calculations assemble a
 * great many of these) and because a display convention shifting under an
 * identity string is a correctness bug, not a cosmetic one.
 */
export declare function assembleLocStringRaw(region: ParsedLocString): string;
/**
 * One space-separated string for a set of regions — what the header of a
 * multi-region view says it is showing, and what an export of those regions
 * labels itself with.
 *
 * The assembly name appears only when the regions disagree about it: naming it
 * on every one of a dozen same-assembly blocks is noise, and dropping it where
 * they differ loses the only thing telling them apart.
 */
export declare function assembleLocStrings(regions: ParsedLocString[]): string;
export declare function compareLocs(locA: ParsedLocString, locB: ParsedLocString): number;
export declare function compareLocStrings(a: string, b: string, isValidRefName: (refName: string, assemblyName?: string) => boolean): number;
/**
 * A cursor/coordinate readout: `{assembly}chr1:1,234`, with the refName
 * shortened and the coordinate locale-grouped. The *display* counterpart to
 * {@link assembleLocString} — this one is for showing a single position to a
 * user, never for a location string that will be parsed back.
 */
export declare function stringify({ refName, coord, assemblyName, oob, }: {
    assemblyName?: string;
    coord: number;
    refName?: string;
    oob?: boolean;
}, useAssemblyName?: boolean): string;
