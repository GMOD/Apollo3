import type { StatusCallback } from './progress.ts';
import type { StopToken } from './stopToken.ts';
import type { AssemblyManager, Region } from './types/index.ts';
import type { Region as MUIRegion } from './types/mst.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
export declare function renameRegionIfNeeded(refNameMap: Record<string, string> | undefined, region: Region | Instance<typeof MUIRegion>, getSeqAdapterRefName?: (refName: string) => string): Region & {
    originalRefName?: string;
};
export declare function renameRegionsIfNeeded<ARGTYPE extends {
    assemblyName?: string;
    regions?: Region[];
    stopToken?: StopToken;
    adapterConfig: Record<string, unknown>;
    sessionId: string;
    statusCallback?: StatusCallback;
}>(assemblyManager: AssemblyManager, args: ARGTYPE): Promise<ARGTYPE & {
    sequenceAdapter: Record<string, unknown> | undefined;
    regions: (Region & {
        originalRefName?: string;
    })[];
}>;
