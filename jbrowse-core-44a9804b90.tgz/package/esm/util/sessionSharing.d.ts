export declare function b64PadSuffix(b64: string): string;
/**
 * Decode and inflate a url-safe base64 to a string
 * See {@link https://en.wikipedia.org/wiki/Base64#URL_applications}
 */
export declare function fromUrlSafeB64(b64: string): Promise<string>;
/**
 * Compress and encode a string as url-safe base64
 * See {@link https://en.wikipedia.org/wiki/Base64#URL_applications}
 */
export declare function toUrlSafeB64(str: string): Promise<string>;
/**
 * The `?session=` value prefixes, named here because this module is what
 * produces them. The decoder half (jbrowse-web's SessionLoader) has its own
 * list covering the two prefixes nothing here writes (`spec-`, `local-`).
 */
export declare const SHARE_PREFIX = "share-";
export declare const ENCODED_PREFIX = "encoded-";
export declare const JSON_PREFIX = "json-";
/**
 * Joins a configured `shareURL` with one of the share service's two endpoints.
 * A plain `${shareURL}share` silently produced `https://host/api/v1share` for
 * the (natural) configured value without a trailing slash, and the 404 that
 * followed read as "the share service is down". An empty shareURL is left
 * alone: web honors an explicit empty string as "resolve relative to the page".
 */
export declare function shareEndpoint(shareURL: string, path: 'share' | 'load'): string;
export type SessionShareMode = 'short' | 'long' | 'json';
export interface EncodedSessionParam {
    sessionParam: string;
    password?: string;
    plaintext?: string;
}
export declare function encodeSessionParam(mode: SessionShareMode, session: unknown, options: {
    shareURL: string;
    referer: string;
}): Promise<EncodedSessionParam>;
export declare function readSessionFromDynamo(loadUrl: string, sessionQueryParam: string, password: string, signal?: AbortSignal): Promise<string>;
