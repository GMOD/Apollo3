/**
 * Given a scale ( bp/px ) and minimum distances (px) between major and minor
 * gridlines, return an object like `{ majorPitch: bp, minorPitch: bp }` giving
 * the gridline pitches to use.
 */
export declare function chooseGridPitch(scale: number, minMajorPitchPx: number, minMinorPitchPx: number): {
    majorPitch: number;
    minorPitch: number;
};
