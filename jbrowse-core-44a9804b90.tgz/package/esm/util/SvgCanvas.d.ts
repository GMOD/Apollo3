/**
 * Restart clip-id numbering for a new export document.
 *
 * Without it the counter runs for the lifetime of the process, so an export is
 * numbered from wherever the previous one stopped and the same view exported
 * twice differs in every clip id. That is the churn `svgNodeId` was written to
 * get rid of, arriving by a second route: diffing two saved SVGs shows changes
 * that aren't real, and `jest -t` on any export test but the first fails its
 * checked-in snapshot with a diff that is nothing but renumbering.
 *
 * Called by `wrapSvgExport`, and safe there and only there: the
 * `renderToStaticMarkup` it wraps is synchronous, so every `PaintLayer` in the
 * document draws before any other export can begin. Anything that resets on a
 * boundary an `await` can cross would let two exports share a numbering run.
 */
export declare function resetSvgClipIds(): void;
export declare class SvgCanvas {
    private parts;
    private pathData;
    private stack;
    private pendingGroups;
    private openGroups;
    fillStyle: string | CanvasGradient | CanvasPattern;
    strokeStyle: string | CanvasGradient | CanvasPattern;
    lineWidth: number;
    font: string;
    textAlign: CanvasTextAlign;
    textBaseline: CanvasTextBaseline;
    lineCap: CanvasLineCap;
    lineJoin: CanvasLineJoin;
    private lineDash;
    private a;
    private b;
    private c;
    private d;
    private e;
    private f;
    private get axisAligned();
    private transformPoint;
    private transformSize;
    private originMatrixAttr;
    private transformRect;
    private textAnchor;
    private paintAttr;
    private strokeAttrs;
    private emit;
    save(): void;
    restore(): void;
    translate(x: number, y: number): void;
    scale(x: number, y: number): void;
    rotate(angle: number): void;
    resetTransform(): void;
    setTransform(a: number, b: number, c: number, d: number, e: number, f: number): void;
    transform(a: number, b: number, c: number, d: number, e: number, f: number): void;
    setLineDash(segments: number[]): void;
    getLineDash(): number[];
    fillRect(x: number, y: number, w: number, h: number): void;
    clearRect(_x: number, _y: number, _w: number, _h: number): void;
    strokeRect(x: number, y: number, w: number, h: number): void;
    beginPath(): void;
    moveTo(x: number, y: number): void;
    lineTo(x: number, y: number): void;
    arc(x: number, y: number, radius: number, startAngle: number, endAngle: number, counterclockwise?: boolean): void;
    ellipse(x: number, y: number, radiusX: number, radiusY: number, rotation: number, startAngle: number, endAngle: number, counterclockwise?: boolean): void;
    bezierCurveTo(cp1x: number, cp1y: number, cp2x: number, cp2y: number, x: number, y: number): void;
    quadraticCurveTo(cpx: number, cpy: number, x: number, y: number): void;
    rect(x: number, y: number, w: number, h: number): void;
    closePath(): void;
    stroke(): void;
    fill(): void;
    private dominantBaseline;
    fillText(text: string, x: number, y: number): void;
    strokeText(text: string, x: number, y: number): void;
    drawImage(..._args: unknown[]): void;
    putImageData(..._args: unknown[]): void;
    clip(..._args: unknown[]): void;
    measureText(text: string): {
        width: number;
    };
    getSerializedSvg(): string;
}
