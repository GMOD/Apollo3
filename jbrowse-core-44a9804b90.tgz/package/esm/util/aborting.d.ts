declare class AbortError extends Error {
    code: string | undefined;
}
export declare function makeAbortError(): AbortError | DOMException;
/**
 * The one way a fetch's catch block answers a thrown error, shared by every
 * fetch family (FetchMixin's runFetch, the comparative installer, chord): an
 * abort is the ordinary end of a superseded or cancelled fetch and is
 * swallowed, and so is any failure of a fetch that is no longer the current
 * one — a superseded fetch's error is routinely its teardown's side effect,
 * and it must not overwrite the error slot (or the console) its successor
 * owns. Only a current fetch's real failure is logged and published. The
 * three sites used to spell this independently and had drifted on whether the
 * log was currency-guarded; the comparative family's pin ("does not let a
 * superseded fetch raise its error") is the semantic that was deliberate.
 */
export declare function handleFetchError(exception: unknown, isCurrent: () => boolean, setError: (e: unknown) => void): void;
/**
 * check if the given exception was caused by an operation being intentionally aborted
 * @param exception -
 */
export declare function isAbortException(exception: unknown): boolean;
export {};
