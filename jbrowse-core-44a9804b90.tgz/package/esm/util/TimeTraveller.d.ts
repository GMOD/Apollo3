/**
 * #stateModel TimeTraveller
 * Undo/redo history for a target state-tree node: records snapshots as it
 * changes and exposes canUndo/canRedo with undo/redo actions.
 */
declare const TimeTraveller: import("@jbrowse/mobx-state-tree").IModelType<{
    undoIdx: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    targetPath: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
}, {
    history: unknown[];
    notTrackingUndo: boolean;
} & {
    readonly canUndo: boolean;
    readonly canRedo: boolean;
} & {
    stopTrackingUndo(): void;
    resumeTrackingUndo(): void;
    addUndoState(snapshot: unknown): void;
    beforeDestroy(): void;
    /**
     * Start recording history for the target store. Re-runs whenever the root
     * swaps in a new session node, so it must be idempotent: the previous
     * registration is disposed and the history reset, because `history` is
     * volatile while `undoIdx` is a persisted prop — carrying the old
     * session's snapshots forward would make undo apply them to the new one.
     */
    initialize(): void;
    undo(): void;
    redo(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default TimeTraveller;
