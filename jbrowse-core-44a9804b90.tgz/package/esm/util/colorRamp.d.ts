/** One evenly-spaced ramp stop: 8-bit red, green, blue, alpha. */
export type ColorRampStop = readonly [number, number, number, number];
/**
 * #api
 * The color at `t` in `[0, 1]` across a list of EVENLY SPACED stops, linearly
 * interpolated per channel. `t` is clamped, so the ends are the end stops
 * rather than an extrapolation past them, and a one-stop ramp is that stop
 * everywhere.
 */
export declare function sampleColorRamp(stops: readonly ColorRampStop[], t: number): ColorRampStop;
/**
 * #api
 * A 256-entry RGBA lookup table over {@link sampleColorRamp}, laid out as the
 * 256x1 texture both GPU backends upload and the Canvas2D twins index — entry
 * `i` is the color at `t = i / 255`.
 */
export declare function buildColorRampLut(stops: readonly ColorRampStop[]): Uint8Array<ArrayBuffer>;
