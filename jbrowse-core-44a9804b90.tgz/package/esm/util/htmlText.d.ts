/**
 * Whether a string is markup to RENDER rather than text that merely contains
 * angle brackets — a VCF symbolic allele (`<DEL>`), an email in brackets, `a<b`.
 *
 * The one place that question is answered, because two callers answer it about
 * the same string and a disagreement is silent: `SanitizedHTML` escapes what
 * this rejects (so `<DEL>` reaches the screen intact), and anything extracting
 * that string's words for the clipboard has to make the same call or a parser
 * eats the allele the tooltip displayed.
 */
export declare function looksLikeHTML(str: string): boolean;
/** Angle brackets and friends as entities, so text renders as itself. */
export declare function escapeHTML(str: string): string;
