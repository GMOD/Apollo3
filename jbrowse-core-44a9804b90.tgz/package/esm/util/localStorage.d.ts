export declare const localStorageAvailable: () => boolean, localStorageGetItem: (key: string) => string | undefined, localStorageSetItem: (key: string, value: string) => boolean, localStorageRemoveItem: (key: string) => boolean;
/**
 * Call `fn` whenever `key` changes — in another tab, or here via
 * {@link notifyLocalStorageKey}. Returns the unsubscribe.
 *
 * `fn` takes no argument on purpose: it is told that the key changed, and reads
 * the store itself. A payload would be a second copy of the value, and a
 * `clear()` has none to hand over.
 */
export declare function subscribeToLocalStorageKey(key: string, fn: () => void): () => void;
/** Announce a write made in this tab, which `storage` never reports back. */
export declare function notifyLocalStorageKey(key: string): void;
export declare function localStorageGetNumber(key: string, defaultVal: number): number;
export declare function localStorageGetJSON<T>(key: string, defaultVal: T): T;
/**
 * The list of strings at `key` — absent, unreadable, malformed, or holding
 * anything else all read as empty.
 *
 * The element filter is the part {@link localStorageGetJSON} cannot do: a
 * stored array of the wrong element type parses fine and then behaves as a list
 * of values that match nothing, which looks the same as an empty list except
 * that it is never noticed. Three keys wanted exactly this and each spelled it
 * out — hidden facet columns, trusted plugin URLs, and the desktop safe-mode
 * marker, which additionally has to survive the bare `1` older builds wrote
 * there.
 */
export declare function localStorageGetStringArray(key: string): string[];
/**
 * Writes `val` as JSON, except when it is null/undefined — those are skipped
 * rather than stored, so a tri-state setting whose "unset" value means "follow
 * the config" leaves whatever was there instead of pinning `null` over it.
 */
export declare function localStorageSetJSON(key: string, val: unknown): void;
export declare function localStorageGetBoolean(key: string, defaultVal: boolean): boolean;
export declare function localStorageSetBoolean(key: string, value: boolean): void;
export declare function localStorageSetNumber(key: string, value: number): void;
