import type { CxArg } from './tools/classnames.ts';
export { keyframes } from '@emotion/react';
export declare const makeStyles: () => <RuleName extends string>(cssObjectByRuleNameOrGetCssObjectByRuleName: Record<RuleName, import("./types.ts").CSSObject> | ((theme: import("../../ui/styleTheme.ts").JBrowseStyleTheme) => Record<RuleName, import("./types.ts").CSSObject>)) => (_params?: unknown, muiStyleOverridesParams?: {
    props: {
        classes?: Record<string, string>;
    };
} | undefined) => {
    classes: Record<RuleName, string>;
    theme: import("../../ui/styleTheme.ts").JBrowseStyleTheme;
    css: import("./types.ts").Css;
    cx: import("./types.ts").Cx;
};
export declare function cx(...args: CxArg[]): string;
