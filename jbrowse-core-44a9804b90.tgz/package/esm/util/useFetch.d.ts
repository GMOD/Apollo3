import type { RpcStatus, StatusCallback } from './progress.ts';
import type { StopToken } from './stopToken.ts';
export type FetchKey = string | readonly unknown[] | null | undefined | false;
type FetchingKey<Key> = Exclude<Key, null | undefined | false>;
/**
 * The fetcher's parameter list, derived from the key. An array key is spread
 * into the parameters, so a tuple key gives the fetcher one typed parameter per
 * element (`MafSequenceWidget` destructures its key that way, to reuse the
 * narrowing the null-key ternary already did); a string key arrives as the
 * single argument (`useGenomesData`). Most fetchers close over what they need
 * and declare no parameters at all, which stays assignable either way.
 *
 * A stop token and a status callback follow the key arguments. The token is
 * created per fetch and stopped when the key changes or the component unmounts,
 * so a fetcher that forwards it to an RPC cancels the worker instead of leaving
 * it grinding on an answer nobody is waiting for. The callback is what the RPC's
 * own progress comes back through, and it surfaces on the hook's `status` — a
 * dialog that forwards both gets "Downloading features 42%" and a cancel that
 * works, instead of a bare spinner over an uninterruptible whole-chromosome
 * read. Fetchers that take neither are unaffected.
 */
type FetcherArgs<Key> = FetchingKey<Key> extends readonly unknown[] ? [...FetchingKey<Key>, StopToken, StatusCallback] : [FetchingKey<Key>, StopToken, StatusCallback];
interface FetchState<Data> {
    data: Data | undefined;
    error: unknown;
    isLoading: boolean;
}
interface UseFetchOptions<Data> {
    onError?: (error: unknown) => void;
    onSuccess?: (data: Data) => void;
}
interface UseFetchResponse<Data> extends FetchState<Data> {
    /**
     * Trigger a refetch. Returns nothing: the result arrives through
     * `data`/`error`/`isLoading` like the initial fetch, and a promise here could
     * only resolve before the refetch it schedules had run.
     */
    mutate: () => void;
    isValidating: boolean;
    /**
     * Latest progress the in-flight fetcher reported through its status callback,
     * or undefined when it reported none or the fetch has settled. Render it with
     * `statusProgressLabel` (and `statusFraction` for a bar); a fetcher that never
     * calls its callback leaves this undefined and the consumer shows whatever it
     * showed before.
     */
    status: RpcStatus | undefined;
}
/**
 * Revalidate every mounted `useFetch` on this key. Synchronous for the same
 * reason the per-hook `mutate` is: it schedules the refetches, and each hook
 * reports its own result through the state it already exposes.
 */
export declare function mutate(key: FetchKey): void;
export declare function useFetch<Data = unknown, Key extends FetchKey = FetchKey>(key: Key, fetcher: ((...args: FetcherArgs<Key>) => Promise<Data>) | null, options?: UseFetchOptions<Data>): UseFetchResponse<Data>;
export {};
