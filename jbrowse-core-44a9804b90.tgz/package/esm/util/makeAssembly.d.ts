export interface MakeAssemblyOptions {
    /** URL to a FASTA (`.fa`/`.fasta`, optionally bgzipped) or a `.2bit` file */
    fastaUri: string;
    /** defaults to the file's base name, e.g. `hg38.fa.gz` -> `hg38` */
    name?: string;
    faiUri?: string;
    gziUri?: string;
    aliases?: string[];
    refNameAliasesUri?: string;
}
/** true when a string names a sequence file (vs. a hub name like `hg38`) */
export declare function isSequenceUri(uri: string): boolean;
/** strip path and sequence extension: `.../hg19.fa.gz` -> `hg19` */
export declare function assemblyNameFromUri(uri: string): string;
/**
 * Build an assembly config for a sequence file (indexed FASTA, bgzipped FASTA,
 * or `.2bit`) — the boilerplate you'd otherwise write by hand. In the common
 * case it is the flat `{ name, uri }` shorthand: jbrowse-core's assembly config
 * picks the concrete adapter type (`IndexedFastaAdapter`/`BgzipFastaAdapter`/
 * `TwoBitAdapter`) from the extension, derives the `.fai`/`.gzi` siblings, and
 * fills in the `ReferenceSequenceTrack` at load time, so no adapter-type
 * knowledge lives here. A non-sibling index (`faiUri`/`gziUri`) widens `sequence`
 * to its adapter form, the only shape with a slot for the override.
 * `refNameAliasesUri` points at a tab-separated aliases file (as UCSC publishes)
 * so a track whose reference names differ from the sequence (e.g. a BAM using
 * `chr1` against a `1`-named reference) still lines up.
 */
export declare function makeAssembly(opts: MakeAssemblyOptions): {
    name: string;
    aliases: string[];
    sequence: {
        type: string;
        trackId: string;
        adapter: {
            uri: string;
            faiLocation?: {
                uri: string;
            } | undefined;
            gziLocation?: {
                uri: string;
            } | undefined;
        };
    };
    refNameAliases?: {
        uri: string;
    } | undefined;
} | {
    name: string;
    aliases: string[];
    uri: string;
    refNameAliases?: {
        uri: string;
    } | undefined;
};
