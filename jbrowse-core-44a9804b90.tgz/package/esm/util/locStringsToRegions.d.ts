import type { Region } from './types/data.ts';
export interface RefNameSource {
    isValidRefName: (refName: string) => boolean;
    getCanonicalRefName2: (refName: string) => string;
    regions?: readonly {
        refName: string;
        end: number;
    }[];
}
export declare function locStringsToRegions(locStrings: string, assembly: RefNameSource, assemblyName: string): Region[];
