import type PluginManager from '../PluginManager.ts';
import type { AbstractDisplayModel, AbstractSessionModel, AbstractTrackModel, AbstractViewModel } from './types/index.ts';
import type { AssemblyHost, RenderingServices } from './types/renderingServices.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export { findParentThat, findParentThatIs, getRpcSessionId, } from './parentWalk.ts';
/**
 * #api core/util
 * Returns the JBrowse session model for any node in the state tree. Throws if
 * the node has no session ancestor.
 */
export declare function getSession(node: IAnyStateTreeNode): AbstractSessionModel;
/**
 * #api core/util
 * Returns the view model that contains the given node. Throws if the node has no
 * containing view.
 */
export declare function getContainingView(node: IAnyStateTreeNode): AbstractViewModel;
/**
 * #api core/util
 * Returns the track model that contains the given node. Throws if the node has
 * no containing track.
 */
export declare function getContainingTrack(node: IAnyStateTreeNode): AbstractTrackModel;
/**
 * #api core/util
 * Returns the display model that contains the given node. Throws if the node has
 * no containing display.
 */
export declare function getContainingDisplay(node: IAnyStateTreeNode): AbstractDisplayModel;
/**
 * #api core/util
 * The host's assembly manager, for a module that resolves names and nothing
 * else.
 *
 * Unlike the accessors in `sessionServices.ts` this one buys the caller no
 * smaller type graph — an `AssemblyManager` is an MST model a `PluginManager`
 * built, so naming it costs what naming a session costs. It is here to say
 * which service is wanted, and because that cost is the finding: the assembly
 * manager is the one thing on `AbstractSessionModel` a third-party host cannot
 * simply implement.
 */
export declare function getAssemblyHost(node: IAnyStateTreeNode): AssemblyHost;
/**
 * #api core/util
 * Everything a display needs of its host in order to draw a region: the
 * assemblies, the RPC entry point and the colors.
 */
export declare function getRenderingServices(node: IAnyStateTreeNode): RenderingServices;
/**
 * #api core/util
 * Resolve user-authored refName text against the assembly of the view
 * containing `node` — the one normalization layer, which resolves aliases and
 * casing together. Falls back to the input when the assembly is absent or its
 * aliases have not loaded.
 *
 * Keyed off the VIEW's assembly rather than the track's, because the view is
 * what the comparison is against: displayed regions, loaded regions and blocks
 * all carry the refNames the view laid out.
 *
 * Reach for this wherever a refName a *person* wrote is about to be compared
 * against regions, features or blocks, which carry the assembly's canonical
 * name. A refName a display copied off a region is canonical already and needs
 * nothing; one that arrived in a session spec, a config slot or a URL is
 * whatever the author read out of the location box.
 *
 * Skipping it fails silently and, worse, assembly-dependently: `chr12` matches
 * on an assembly canonicalized `chr12` and matches nothing on one canonicalized
 * `12`, so the same spec key works on one config and quietly does nothing on
 * the next, with no error for anyone to act on.
 *
 * Resolves through `getCanonicalRefName2`, whose fallback is what keeps a spec
 * read before the alias file has loaded from throwing — and the getters that
 * read user specs do run from the first render.
 *
 * Takes a refName, not a spec that might hold one: the resolver reads
 * `refName.toLowerCase()`, so anything else throws once the aliases are there,
 * and a caller reading an untyped `frozen` slot has to establish that it names
 * a refName at all before this is the right question to ask of it.
 */
export declare function canonicalizeViewRefName(node: IAnyStateTreeNode, refName: string): string;
/**
 * #api core/util
 * Returns the MST environment for a node, which carries the `pluginManager`.
 */
export declare function getEnv(obj: IAnyStateTreeNode): {
    pluginManager: PluginManager;
};
export declare function hashCode(str: string): number;
export declare function objectHash(obj: object): string;
