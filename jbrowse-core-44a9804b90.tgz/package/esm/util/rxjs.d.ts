import { Observable } from 'rxjs';
import type { StopToken } from './stopToken.ts';
import type { Observer } from 'rxjs';
/**
 * Wrapper for rxjs Observable.create with improved error handling and aborting
 * support.
 *
 * A `stopToken` errors the subscriber with an abort error the moment the token
 * is stopped, rather than waiting for `func` to finish work whose result is
 * already discarded. The fetch paths filter abort errors out (`isAbortException`)
 * so a cancel does not surface as a track error. It cannot interrupt `func`
 * itself — a body doing long synchronous work still needs its own
 * `checkStopToken` ticks — but it does stop delivery downstream.
 *
 * @param func - observer function, could be async
 */
export declare function ObservableCreate<T>(func: (arg: Observer<T>) => void | Promise<void>, stopToken?: StopToken): Observable<T>;
