/**
 * fast low-level intersection of 2 coordinate ranges. assumes interbase coordinates.
 *
 * assumes `left <= right` for both ranges
 *
 * @returns array of [left, right], or [] if the ranges do not intersect. the choice of [] is because it allows destructuring array assignment without check for undefined return
 */
export declare function intersection2(left1: number, right1: number, left2: number, right2: number): [number, number] | [];
/**
 * Return whether 2 interbase coordinate ranges intersect.
 *
 * @param left1 -
 * @param right1 -
 * @param left2 -
 * @param right2 -
 *
 * @returns true if the two ranges intersect
 */
export declare function doesIntersect2(left1: number, right1: number, left2: number, right2: number): boolean;
/**
 * Compute the expanded fetch range a tabix adapter must "redispatch" to when
 * features found in a query extend past the requested window. Returns the union
 * of the query with the bounds of every feature whose type is not in
 * `dontRedispatchSet`, or `undefined` when nothing extends past the query (no
 * redispatch needed).
 *
 * Feature coordinates arrive interbase, matching the query: @gmod/tabix applies
 * the index's coordinate offset before invoking the line callback, so a GFF/GTF
 * line's 1-based start is already decremented by the time it gets here.
 *
 * Seeding the accumulator with the query bounds is what makes the result a
 * union rather than just the feature bounds. A redispatch narrower than the
 * original window would drop a dontRedispatch-typed feature that the first
 * fetch found inside the query but that falls outside the expanded range, since
 * those types are deliberately excluded from the bounds.
 */
export declare function calculateRedispatchRange(features: {
    start: number;
    end: number;
    type: string;
}[], dontRedispatchSet: Set<string>, queryStart: number, queryEnd: number): {
    start: number;
    end: number;
} | undefined;
