export interface ParsedMotif {
    name: string;
    site: string;
    line: string;
    cutOffset?: number;
    cutOffsetBottom?: number;
}
export interface MotifParseError {
    line: number;
    text: string;
    message: string;
}
export interface MotifListParse {
    motifs: ParsedMotif[];
    errors: MotifParseError[];
}
export declare function parseMotifList(text: string): MotifListParse;
