declare global {
    interface FileSystemFileHandle {
        queryPermission(options: {
            mode: 'read' | 'readwrite';
        }): Promise<PermissionState>;
        requestPermission(options: {
            mode: 'read' | 'readwrite';
        }): Promise<PermissionState>;
    }
}
export declare function isFileSystemAccessSupported(): boolean;
/**
 * Which stored handles the pruner drops: everything past the
 * MAX_STORED_HANDLES first-picked most recently.
 *
 * Split out and exported for the same reason staleSessionIds is — jsdom has no
 * IndexedDB, so the transaction around it never runs under jest, and this is the
 * one part of the decision that is testable at all.
 */
export declare function staleHandleIds(keys: string[]): string[];
export declare function storeFileHandle(handle: FileSystemFileHandle): Promise<string>;
export declare function getFileHandle(handleId: string): Promise<FileSystemFileHandle | undefined>;
export declare function verifyPermission(handle: FileSystemFileHandle, requestPermission?: boolean): Promise<boolean>;
