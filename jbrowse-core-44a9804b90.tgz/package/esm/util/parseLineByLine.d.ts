import { IntervalTree } from './IntervalTree.ts';
import type { StatusCallback } from './progress.ts';
import type { StopToken } from './stopToken.ts';
export type { StatusCallback };
export type LineCallback = (line: string, lineIndex: number) => boolean | undefined;
/**
 * Scan a tab-delimited genomic flat file (GFF3, GTF, BED, …), grouping
 * feature lines by reference name (first tab-delimited column).
 * Stops at an embedded FASTA section (`>`). Lines starting with `#` are
 * collected as header lines.
 */
export declare function groupLinesByRef(buffer: Uint8Array, statusCallback?: StatusCallback): {
    headerLines: string[];
    linesByRef: Record<string, string[]>;
};
/**
 * Build a `refName -> lazy IntervalTree` map from feature lines grouped by ref
 * (the output of {@link groupLinesByRef}). Each ref's lines are parsed and
 * indexed into an interval tree on first access, then the raw lines are
 * released. Shared scaffolding for the plain-text GFF3 and GTF adapters, which
 * differ only in how they parse a ref's lines into features.
 */
export declare function makeFeatureIntervalTreeMap<T extends {
    start: number;
    end: number;
}>(linesByRef: Record<string, string[]>, parse: (lines: string[], refName: string) => T[], parsingStatusMessage: string): {
    [k: string]: (statusCallback?: StatusCallback) => IntervalTree<T>;
};
/**
 * Parse buffer line by line, calling a callback for each line
 * @param buffer - The buffer to parse
 * @param lineCallback - Callback function called for each line. Return false to stop parsing.
 * @param statusCallback - Progress channel, or `undefined` for none. A required
 *   parameter with a nullable value rather than an optional one, so a caller
 *   states which it means; `undefined` is the value the rest of this module's
 *   contract is built on ("no channel, skip the bookkeeping"), and it used to
 *   default to `() => {}`, which says the opposite.
 * @param opts - `label` names the phase on the progress bar (a multi-phase
 *   adapter wants "Parsing PAF", not another "Loading" indistinguishable from
 *   the download that preceded it); `stopToken` makes a multi-GB parse
 *   interruptible instead of running to completion after a cancel.
 */
export declare function parseLineByLine(buffer: Uint8Array, lineCallback: LineCallback, statusCallback: StatusCallback | undefined, opts?: {
    label?: string;
    stopToken?: StopToken;
}): void;
