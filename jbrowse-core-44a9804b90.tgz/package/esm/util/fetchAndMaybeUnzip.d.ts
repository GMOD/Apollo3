import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
import type { StatusPhase } from './progress.ts';
import type { GenericFilehandle } from 'generic-filehandle2';
export declare function isGzip(buf: Uint8Array): boolean;
export declare function fetchAndMaybeUnzip(loc: GenericFilehandle, opts?: BaseOptions, label?: string | StatusPhase): Promise<Uint8Array<ArrayBufferLike>>;
export declare function fetchAndMaybeUnzipText(loc: GenericFilehandle, opts?: BaseOptions, label?: string | StatusPhase): Promise<string>;
