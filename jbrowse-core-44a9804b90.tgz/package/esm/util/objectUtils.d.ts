export declare function isObject(x: unknown): x is Record<string | symbol | number, unknown>;
export declare function isPlainObject(x: unknown): x is Record<string, unknown>;
