import { BlockSet } from './blockTypes.ts';
import type { Base1DViewModel } from './calculateStaticBlocks.ts';
/**
 * Returns a BlockSet covering only the regions currently visible in the view.
 * Used by tracks where static blocks are not feasible. start/end/offsetPx may
 * be fractional.
 */
export default function calculateDynamicBlocks(model: Base1DViewModel, padding?: boolean, elision?: boolean): BlockSet;
