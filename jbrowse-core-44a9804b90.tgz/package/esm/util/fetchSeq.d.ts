import type { StatusCallback } from './progress.ts';
import type { StopToken } from './stopToken.ts';
import type { AbstractSessionModel } from './types/index.ts';
export declare function fetchSeq({ start, end, refName, assemblyName, session, stopToken, statusCallback, }: {
    start: number;
    end: number;
    refName: string;
    assemblyName: string;
    session: AbstractSessionModel;
    stopToken?: StopToken;
    statusCallback?: StatusCallback;
}): Promise<string>;
