interface RowResizeTarget {
    effectiveRowHeight: number;
    scrollTop: number;
    nrow: number;
    viewportHeight: number;
    setRowHeight: (n: number) => void;
    setScrollTop: (n: number) => void;
}
export declare function applyRowResizeWheel(e: WheelEvent, el: HTMLElement, model: RowResizeTarget): void;
export {};
