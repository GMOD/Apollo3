import type { RpcCallArgs, RpcCallReturn } from '../../rpc/RpcRegistry.ts';
import type { JBrowsePalette } from '../../ui/palette.ts';
import type { SerializableThemeArgs } from '../../ui/theme.ts';
import type React from 'react';
/**
 * The one thing a fetch needs of an RPC manager: the registry-typed call. A
 * real {@link RpcManager} satisfies it, and so does a host that routes RPCs
 * somewhere else entirely.
 */
export interface RpcCaller {
    call<M extends string>(sessionId: string, method: M, args: RpcCallArgs<M>): Promise<RpcCallReturn<M>>;
}
export interface RpcHost {
    rpcManager: RpcCaller;
}
/**
 * The colors a renderer draws with. `palette` is plain data — no toolkit, and
 * serializable, so a worker baking labels reads the same values the React
 * chrome does. `themeOptions` is what rebuilds it on the far side of an RPC.
 */
export interface PaletteHost {
    palette: JBrowsePalette;
    themeOptions?: SerializableThemeArgs;
}
export type NotificationLevel = 'error' | 'info' | 'warning' | 'success';
export interface SnackAction {
    name: React.ReactElement | string;
    onClick: () => void;
}
/** where a display puts a message it cannot draw itself */
export interface NotificationSink {
    notify: (message: string, level?: NotificationLevel, action?: SnackAction | SnackAction[]) => void;
    notifyError: (message: string, error?: unknown, extra?: unknown, action?: SnackAction) => void;
}
export type DialogComponentType = React.LazyExoticComponent<React.FC<any>> | React.FC<any>;
/**
 * The single member a host has to implement to be somewhere a display can put a
 * dialog. It is the most-called session member from plugin code (49 sites), and
 * nearly all of them are a display saying "the user wants to configure
 * something" — so a host drawing its own UI needs exactly this one name, not a
 * session. `agent-docs/ideas/lightweight-toolkit.md` §3.
 */
export interface DialogHost {
    DialogComponent?: DialogComponentType;
    DialogProps: Record<string, unknown> | undefined;
    queueDialog<T extends DialogComponentType>(callback: (doneCallback: () => void) => [T, React.ComponentProps<T>]): void;
}
/** everything a session offers that costs nothing app-shaped to name */
export interface SessionServices extends RpcHost, PaletteHost, NotificationSink, DialogHost {
}
/**
 * The one runtime test behind both this and `isSessionModel`: they differ only
 * in how much of the thing they let the caller see.
 */
export declare function isSessionServices(thing: unknown): thing is SessionServices;
