import type { BlobLocation as MUBlobLocation, FileHandleLocation as MUFileHandleLocation, Region as MUIRegion, LocalPathLocation as MULocalPathLocation, NoAssemblyRegion as MUNoAssemblyRegion, UriLocation as MUUriLocation } from './mst.ts';
import type { SnapshotIn } from '@jbrowse/mobx-state-tree';
export interface NoAssemblyRegion extends SnapshotIn<typeof MUNoAssemblyRegion> {
}
/**
 * a description of a specific genomic region. assemblyName, refName, start,
 * end, and reversed
 */
export interface Region extends SnapshotIn<typeof MUIRegion> {
}
export interface AugmentedRegion extends Region {
    originalRefName?: string;
}
export interface LocalPathLocation extends SnapshotIn<typeof MULocalPathLocation> {
}
export interface UriLocation extends SnapshotIn<typeof MUUriLocation> {
}
export interface BlobLocation extends SnapshotIn<typeof MUBlobLocation> {
}
export interface FileHandleLocation extends SnapshotIn<typeof MUFileHandleLocation> {
}
export type FileLocation = LocalPathLocation | UriLocation | BlobLocation | FileHandleLocation;
export declare function isUriLocation(location: unknown): location is UriLocation;
export declare function isLocalPathLocation(location: unknown): location is LocalPathLocation;
export declare function isBlobLocation(location: unknown): location is BlobLocation;
export declare function isFileHandleLocation(location: unknown): location is FileHandleLocation;
export interface PreUriLocation {
    uri: string;
}
export interface PreLocalPathLocation {
    localPath: string;
}
export interface PreBlobLocation {
    blob: File;
}
export interface PreFileHandleLocation {
    handle: FileSystemFileHandle;
}
export type PreFileLocation = PreUriLocation | PreLocalPathLocation | PreBlobLocation | PreFileHandleLocation;
export declare class AuthNeededError extends Error {
    url: string;
    constructor(message: string, url: string);
}
export declare function isAuthNeededException(exception: unknown): exception is AuthNeededError;
export interface BasePlugin {
    version?: string;
    name: string;
    url?: string;
}
export interface JBrowsePluginVersion {
    pluginVersion: string;
    jbrowseRange: string;
    url?: string;
    umdUrl?: string;
    esmUrl?: string;
    cjsUrl?: string;
    integrity?: string;
}
export interface JBrowsePlugin {
    name: string;
    packageName?: string;
    authors: string[];
    description: string;
    location: string;
    url?: string;
    umdUrl?: string;
    esmUrl?: string;
    cjsUrl?: string;
    integrity?: string;
    versions?: JBrowsePluginVersion[];
    latestUrl?: string;
    license: string;
    image?: string;
    tags?: string[];
}
