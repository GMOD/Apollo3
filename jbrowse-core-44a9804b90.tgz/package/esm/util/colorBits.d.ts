import type { Color } from './color-bits/index.ts';
import type { Feature } from './simpleFeature.ts';
export { alpha, blend, darken, formatHEX, formatHEXA, formatRGBA, getAlpha, getBlue, getGreen, getLuminance, getRed, lighten, newColor, parse, toHSLA, toRGBA, } from './color-bits/index.ts';
export type { Color } from './color-bits/index.ts';
/**
 * One raw attribute value as a usable BED color, or undefined when it isn't
 * one. Deliberately strict: this feeds an *automatic* coloring path, so a value
 * is only claimed when it is unambiguously an in-range BED triple. Anything
 * else — a hex string, a `reserved` column holding something that isn't a color
 * at all — reads as absent and leaves the configured default alone, rather than
 * rendering as the magenta invalid-color sentinel. Takes the raw value so it
 * stays dependency-free and directly testable.
 */
export declare function featureItemRgb(raw: unknown): string | undefined;
/**
 * The BED color a feature declares for itself, under either column name, or
 * undefined if it declares none.
 */
export declare function featureBedColor(feature: Feature): string | undefined;
export declare function parseCssColorOr(color: string, fallback: Color): Color;
export declare function parseCssColor(color: string | undefined | null): number;
export declare function cssColorToNormalizedRgb(color: string): [number, number, number];
export declare function cssColorToRgb(color: string): [number, number, number];
export declare function cssColorToRgba(color: string): [number, number, number, number];
export declare function packAbgr(r: number, g: number, b: number, a: number): number;
export declare function cssColorToABGR(color: string): number;
export declare function withAbgrAlpha(c: number, a: number): number;
export declare function normalizedRgbToABGR(r: number, g: number, b: number): number;
export declare function normalizedRgbToCss(c: readonly [number, number, number]): string;
export declare function normalizedRgbToCssRgba(c: readonly [number, number, number], alpha: number): string;
export declare function setAbgrFill(ctx: {
    fillStyle: string | CanvasGradient | CanvasPattern;
}, c: number): void;
export declare function abgrRed(c: number): number;
export declare function abgrGreen(c: number): number;
export declare function abgrBlue(c: number): number;
export declare function abgrAlpha(c: number): number;
export declare function abgrToCssRgba(c: number): string;
export declare function cssColorToNormalizedRgba(color: string): [number, number, number, number];
