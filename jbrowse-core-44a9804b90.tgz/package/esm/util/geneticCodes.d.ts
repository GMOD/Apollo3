export interface NcbiGeneticCode {
    id: number;
    name: string;
    ncbieaa: string;
    sncbieaa: string;
}
export declare const ncbiGeneticCodes: NcbiGeneticCode[];
export interface GeneticCode {
    id: number;
    name: string;
    codonTable: Record<string, string>;
    starts: string[];
}
export declare function parseTranslTable(value: unknown): number | undefined;
export interface TranslExcept {
    start: number;
    end: number;
    aa: string;
}
export declare function parseTranslExcept(value: unknown): TranslExcept[];
export declare function relativizeTranslExcept({ raw, featureStart, featureLength, strand, }: {
    raw: unknown;
    featureStart: number;
    featureLength: number;
    strand?: number;
}): TranslExcept[];
/**
 * Expand an uppercase codon -> amino acid map so every case combination of a
 * triplet ('atg', 'Atg', 'aTG', ...) resolves, which is what callers reading
 * raw sequence need.
 */
export declare function generateCodonTable(table: Record<string, string>): Record<string, string>;
export declare function getGeneticCode(id?: number): GeneticCode;
/**
 * The standard genetic code's codon map, case-expanded. Callers that translate
 * without knowing (or caring about) a `transl_table` use this; anything reading
 * a feature's declared table should call {@link getGeneticCode} instead.
 *
 * Derived from NCBI table 1 rather than kept as its own literal: the two were
 * duplicated, and a hand-maintained 64-entry map is exactly the kind of thing
 * that drifts silently. Living here (rather than in `seqUtils`, where it used
 * to) is also what keeps the dependency one-way — `geneticCodes` needed
 * `generateCodonTable` from `seqUtils`, so defining this the other way round
 * made the two modules mutually dependent and the const load-order sensitive.
 */
export declare const codonTable: Record<string, string>;
/**
 * The standard genetic code as a raw uppercase map, i.e. the input
 * {@link generateCodonTable} case-expands into {@link codonTable}. Nothing in
 * this repo needs it — it stays exported because the `@jbrowse/core/util` barrel
 * is the runtime ABI external plugins link against, and jbrowse-plugin-protein3d
 * calls `generateCodonTable(defaultCodonTable)` itself. Dropping it turned that
 * into `Object.keys(undefined)` inside the published plugin, which surfaced as
 * "Could not launch protein view: TypeError".
 */
export declare const defaultCodonTable: Record<string, string>;
