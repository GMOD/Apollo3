export { unzip } from '@gmod/bgzf-filehandle';
