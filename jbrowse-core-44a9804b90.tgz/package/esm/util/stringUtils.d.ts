export declare function shorten(name: string, max?: number, short?: number): string;
export declare function shorten2(name: string, max?: number): string;
export declare function truncateMiddle(str: string, maxLen?: number): string;
export declare function pluralize(count: number, noun: string, plural?: string): string;
export declare function capitalizeFirst(s: string): string;
