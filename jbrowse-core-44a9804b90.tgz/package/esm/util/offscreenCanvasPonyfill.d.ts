/**
 * Paint a worker-produced image onto a 2d context: either a real
 * ImageBitmap/canvas, or the serialized canvas-sequencer command list a worker
 * without OffscreenCanvas sends instead.
 */
export declare function drawImageOntoCanvasContext(imageData: any, context: CanvasRenderingContext2D): void;
