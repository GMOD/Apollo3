import type { BpOffset } from './Base1DUtils.ts';
import type { Region as IRegion } from './types/data.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel Base1DView
 * #category general
 * used in non-lgv view representations of a 1d view e.g. the two axes of the
 * dotplot use this. categorized General rather than View because it is not a
 * pluggable view type, which the name-suffix heuristic would otherwise assume
 */
declare const Base1DView: import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    displayedRegions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<IRegion[], IRegion[], IRegion[]>, [undefined]>;
    bpPerPx: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    offsetPx: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    minimumBlockWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
}, {
    volatileWidth: number;
} & {
    /**
     * #action
     */
    setDisplayedRegions(regions: IRegion[]): void;
    /**
     * #action
     */
    setBpPerPx(val: number): void;
    /**
     * #action
     */
    setVolatileWidth(width: number): void;
} & {
    /**
     * #getter
     */
    readonly width: number;
    /**
     * #getter
     * zoom-in floor; overridden by extensions (e.g. the dotplot axes)
     */
    readonly minBpPerPx: number;
    /**
     * #getter
     * zoom-out ceiling; overridden by extensions (e.g. the dotplot axes)
     */
    readonly maxBpPerPx: number;
    /**
     * #getter
     */
    readonly assemblyNames: string[];
    /**
     * #getter
     */
    readonly displayedRegionsTotalPx: number;
    /**
     * #getter
     */
    readonly maxOffset: number;
    /**
     * #getter
     */
    readonly minOffset: number;
    /**
     * #getter
     */
    readonly totalBp: number;
} & {
    /**
     * #getter
     */
    readonly dynamicBlocks: import("./blockTypes.ts").BlockSet;
    /**
     * #getter
     */
    readonly staticBlocks: import("./blockTypes.ts").BlockSet;
    /**
     * #getter
     */
    readonly currBp: number;
} & {
    /**
     * #method
     */
    pxToBp(px: number): import("./Base1DUtils.ts").PxToBpResult;
    /**
     * #method
     */
    bpToPx(args: {
        refName: string;
        coord: number;
        displayedRegionIndex?: number;
    }): number | undefined;
} & {
    /**
     * #action
     * this makes a zoomed out view that shows all displayedRegions that makes
     * the overview bar square with the scale bar
     */
    showAllRegions(): void;
    /**
     * #action
     */
    zoomOut(): void;
    /**
     * #action
     */
    zoomIn(): void;
    /**
     * #action
     */
    zoomTo(bpPerPx: number, offset?: any): number;
    /**
     * #action
     */
    scrollTo(offsetPx: number): number;
    /**
     * #action
     */
    centerAt(coord: number, refName: string | undefined, displayedRegionIndex: number): void;
    /**
     * #action
     * note: the scroll is clamped to keep the view on the main screen
     */
    scroll(distance: number): number;
} & {
    /**
     * #action
     * offset is the base-pair-offset in the displayed region, index is the
     * index of the displayed region in the linear genome view
     *
     * @param start - object as `{start, end, offset, index}`
     * @param end - object as `{start, end, offset, index}`
     */
    moveTo(start?: BpOffset, end?: BpOffset): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type Base1DViewStateModel = typeof Base1DView;
export type Base1DViewModel = Instance<Base1DViewStateModel>;
export default Base1DView;
