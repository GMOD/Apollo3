import type { AnyConfigurationModel } from '../configuration/index.ts';
declare global {
    interface Window {
        ga?: (...args: unknown[]) => void;
    }
}
type TrackConfig = AnyConfigurationModel & {
    type: string;
};
interface AnalyticsRootModel {
    jbrowse: {
        tracks: TrackConfig[];
        assemblies: unknown[];
        plugins?: {
            name?: string;
        }[];
    };
    session?: {
        sessionTracks: TrackConfig[];
        views: unknown[];
    };
    version: string;
}
type AnalyticsRootModelWithConfig = AnalyticsRootModel & {
    jbrowse: {
        configuration: AnyConfigurationModel;
    };
};
export declare function writeAWSAnalytics(rootModel: AnalyticsRootModel, initialTimestamp: number, sessionQuery?: string | null): Promise<void>;
export declare function writeGAAnalytics(rootModel: AnalyticsRootModel, initialTimestamp: number): Promise<void>;
export declare function doAnalytics(rootModel: AnalyticsRootModelWithConfig | undefined, initialTimestamp: number, initialSessionQuery: string | null | undefined): void;
export {};
