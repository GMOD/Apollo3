interface BlockData {
    key: string;
    offsetPx: number;
    widthPx: number;
    assemblyName?: string;
    refName?: string;
    start?: number;
    end?: number;
    reversed?: boolean;
    displayedRegionIndex?: number;
    isLeftEndOfDisplayedRegion?: boolean;
    isRightEndOfDisplayedRegion?: boolean;
    variant?: 'boundary';
}
export interface ContentBlock extends BlockData {
    type: 'ContentBlock';
    assemblyName: string;
    refName: string;
    start: number;
    end: number;
}
export interface ElidedBlock extends BlockData {
    type: 'ElidedBlock';
}
export interface InterRegionPaddingBlock extends BlockData {
    type: 'InterRegionPaddingBlock';
}
export type BaseBlock = ContentBlock | ElidedBlock | InterRegionPaddingBlock;
/**
 * A content block as a region that addresses whole bases.
 *
 * `calculateDynamicBlocks` says in its own docstring that start/end may be
 * FRACTIONAL — a block is a span of screen, and the view is only at a whole
 * base when the pan and the zoom both happen to land there. Anything naming
 * bases rather than pixels needs this: a sequence fetch, a bookmark, and above
 * all a locString, since `BP_QUANTITY_SOURCE` rejects a bare fractional
 * coordinate on purpose ("a bare '1.5' as a coordinate is a mistake").
 *
 * `reversed` is dropped with the pixels. It orients a projection, and a region
 * that has left the screen is not being projected; carrying it only reached
 * `assembleLocString`, which spells it `[rev]` in a field the user is about to
 * read.
 */
export declare function wholeBaseRegion(block: ContentBlock): {
    assemblyName: string;
    refName: string;
    start: number;
    end: number;
};
export declare function wholeBaseRegions(blocks: ContentBlock[]): {
    assemblyName: string;
    refName: string;
    start: number;
    end: number;
}[];
type Func<T> = (value: BaseBlock, index: number, array: BaseBlock[]) => T;
export declare class BlockSet {
    blocks: BaseBlock[];
    constructor(blocks?: BaseBlock[]);
    push(block: BaseBlock): void;
    /**
     * Widen a trailing elided run by widthPx, reporting whether there was one to
     * widen. `push` keeps nothing but the width off an ElidedBlock it merges, so
     * a caller holding the width can skip building the block that would have
     * carried it — which at whole-genome zoom is nearly every region, see
     * calculateDynamicBlocks.
     */
    growElidedRun(widthPx: number): boolean;
    map<T, U = this>(func: Func<T>, thisarg?: U): T[];
    forEach<T, U = this>(func: Func<T>, thisarg?: U): void;
    get length(): number;
    get totalWidthPx(): number;
    get totalWidthPxWithoutBorders(): number;
    get offsetPx(): number;
    get contentBlocks(): ContentBlock[];
    get totalBp(): number;
}
export {};
