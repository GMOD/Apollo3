import React from 'react';
export declare function renderToStaticMarkup(node: React.ReactElement): string;
