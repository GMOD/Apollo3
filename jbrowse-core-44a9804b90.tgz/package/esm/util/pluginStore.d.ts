import type { PluginDefinition } from '../pluginDefinitions.ts';
import type { JBrowsePlugin } from './types/data.ts';
/**
 * The store entries a product can install at all, before any user filter. Both
 * surfaces that list the store go through this — the in-session plugin store
 * widget and Desktop's global plugins dialog — because an entry one of them
 * offers and the loader behind the other drops is a silent install: the button
 * says Installed (or stays live, and every click appends another dead entry) and
 * nothing about the running app changes.
 *
 * Two independent reasons to hide an entry:
 *
 * - **No build this product can load.** Web runs ESM/UMD; a CJS-only entry needs
 *   Node's `require`, so only Desktop can install it. Asked of every build the
 *   entry publishes rather than only the top-level urls — an entry that pins urls
 *   per version, which `resolvePlugin`'s fallback exists to accommodate, used to
 *   vanish from Web's list with no diagnostic. An entry whose *resolved* build is
 *   the CJS-only one is still shown, since that is a fact about this JBrowse
 *   version rather than about the product, and PluginStoreCard already has a
 *   place to say so.
 * - **Already vendored into this product's core bundle**, where installing does
 *   nothing because `dropVendoredPlugins` drops the definition at load. Desktop's
 *   half of that list counts too, and is the half both surfaces were missing.
 */
export declare function installablePlugins(plugins: JBrowsePlugin[], isElectron: boolean): JBrowsePlugin[];
export interface ResolvedPlugin {
    compatible: boolean;
    pluginVersion?: string;
    supportedRanges: string[];
    definition: PluginDefinition | undefined;
}
export interface PluginUpdate {
    pluginVersion: string;
    name: string;
    definition: PluginDefinition;
}
export declare function resolvePlugin(plugin: JBrowsePlugin, jbrowseVersion: string): ResolvedPlugin;
export declare function installedVersionFromUrl(url: string | undefined, packageName: string | undefined): string | undefined;
/**
 * Whether a store entry is already among `installed`.
 *
 * Matched by packageName rather than by the resolved url wherever the store
 * publishes one: once a newer compatible version appears the resolved url
 * changes, and a url match would report "not installed" and let the user add a
 * second copy of the same plugin (same UMD global name) alongside the one
 * already there, which then fails to load with duplicate pluggable-element
 * registrations. Moving to a newer version is a separate, explicit action.
 */
export declare function isPluginInstalled(plugin: JBrowsePlugin, resolved: ResolvedPlugin, installed: PluginDefinition[]): boolean;
export declare function getPluginUpdate(plugin: JBrowsePlugin, jbrowseVersion: string, installedVersion: string | undefined): PluginUpdate | undefined;
/**
 * A definition whose store ref could not be turned into something loadable,
 * with the reason.
 *
 * Structurally identical to `PluginLoader`'s `PluginLoadFailure`, and
 * deliberately re-declared rather than imported: that module pulls in ReExports
 * — effectively all of core — which is the whole reason inspecting a definition
 * lives apart from running one. Matching the shape lets a product report a
 * plugin that could not be resolved and one that could not be loaded through a
 * single path, which is what its user sees anyway.
 */
export interface StorePluginFailure {
    definition: PluginDefinition;
    error: unknown;
}
export interface StorePluginResolution {
    definitions: PluginDefinition[];
    failures: StorePluginFailure[];
}
/**
 * Replaces every store ref in `defs` with the concrete definition the store
 * publishes for this JBrowse version, and passes everything else through
 * untouched.
 *
 * A ref names the store's `name`, not the npm package — the store owns the
 * former and can repoint it at a different package without breaking a config
 * that named it years ago (jbrowse-plugin-list ADR 0008). `packageName` stays
 * the key on the install side, where pinning is the point.
 *
 * `storePlugins` is `undefined` when the manifest could not be read at all.
 * That is a different situation from a name the manifest does not list, but it
 * gets the same answer, and the split that matters is elsewhere:
 *
 * - **No answer from the store** — unreachable, or the name is not listed
 *   (retired, renamed, never published). A ref that also carries a url falls
 *   back to it: that url is what a JBrowse without ref support loads from the
 *   same config today, so falling back is exactly no worse than not having
 *   tried. A ref with no url has nothing to fall back on and fails.
 * - **An answer of "not for this JBrowse"** — the package is listed and no
 *   published version's `jbrowseRange` covers the running version. This does
 *   NOT fall back. The store has an opinion and the opinion is that the bundle
 *   does not work here; loading the url anyway is the hole ADR 0007 describes,
 *   where narrowing a range hid a broken plugin from careful clients and left
 *   it armed for everyone else.
 *
 * The resolved definition keeps `storePlugin`. It is the only one of the three
 * identity keys that survives resolution, so it is what lets `samePlugin` match
 * a config's resolved entry against a session's still-unresolved ref for the
 * same plugin. It ends up equal to the definition's `name`, because the store's
 * `name` is what both are.
 */
export declare function resolveStoreRefs(defs: PluginDefinition[], storePlugins: JBrowsePlugin[] | undefined, jbrowseVersion: string): StorePluginResolution;
/**
 * `resolveStoreRefs` with the manifest fetched for it — the form a product
 * calls, immediately before it drops vendored plugins and loads what is left.
 *
 * Fetches nothing when no definition is a ref, which is every config that
 * predates them and every session a user assembled by hand. The store is on the
 * boot path only for the configs that opted in.
 */
export declare function resolveStorePluginRefs(defs: PluginDefinition[], jbrowseVersion: string, fetchStore?: () => Promise<{
    plugins: JBrowsePlugin[];
}>): Promise<StorePluginResolution>;
