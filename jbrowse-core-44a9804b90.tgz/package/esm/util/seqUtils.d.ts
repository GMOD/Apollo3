export declare const complementTable: Record<string, string>;
export declare function revcom(str: string): string;
export declare function reverse(str: string): string;
export declare function complement(str: string): string;
export type Frame = 1 | 2 | 3 | -1 | -2 | -3;
export declare function getFrame(start: number, end: number, strand: 1 | -1, phase: 0 | 1 | 2): Frame;
/**
 * The start codon the sequence track highlights. Deliberately NOT
 * `getGeneticCode(1).starts`, which is `['TTG','CTG','ATG']` — NCBI marks the
 * alternative initiators, but highlighting every TTG and CTG in a reference
 * sequence would be noise. This is a display convention, not the genetic code.
 */
export declare const defaultStarts: string[];
export declare function stitch(subfeats: {
    start: number;
    end: number;
}[], sequence: string): string;
