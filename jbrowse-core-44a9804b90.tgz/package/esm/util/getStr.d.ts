/**
 * A value rendered as a display string: a UriLocation as its resolved href, any
 * other object as JSON, everything else via String(). Shared by the DataGrid
 * column-width heuristic and the feature-detail panels.
 */
export declare function getStr(obj: unknown): string;
