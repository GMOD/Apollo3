import type { Color } from './core.ts';
/**
 * Modifies color alpha channel.
 * @param color - Color
 * @param value - Value in the range [0, 1]
 */
export declare function alpha(color: Color, value: number): Color;
/**
 * Darkens a color.
 * @param color - Color
 * @param coefficient - Multiplier in the range [0, 1]
 */
export declare function darken(color: Color, coefficient: number): Color;
/**
 * Lighten a color.
 * @param color - Color
 * @param coefficient - Multiplier in the range [0, 1]
 */
export declare function lighten(color: Color, coefficient: number): Color;
/**
 * Blend (aka mix) two colors together.
 * @param background The background color
 * @param overlay The overlay color that is affected by @opacity
 * @param opacity Opacity (alpha) for @overlay
 * @param [gamma=1.0] Gamma correction coefficient. `1.0` to match browser behavior, `2.2` for gamma-corrected blending.
 */
export declare function blend(background: Color, overlay: Color, opacity: number, gamma?: number): number;
/**
 * The relative brightness of any point in a color space, normalized to 0 for
 * darkest black and 1 for lightest white.
 * @returns The relative brightness of the color in the range 0 - 1, with 3 digits precision
 */
export declare function getLuminance(color: Color): number;
