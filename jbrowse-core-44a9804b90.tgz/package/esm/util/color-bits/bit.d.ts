export declare function cast(n: number): number;
export declare function get(n: number, offset: number): number;
export declare function set(n: number, offset: number, byte: number): number;
export declare function clampByte(n: number): number;
