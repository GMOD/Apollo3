export type Color = number;
export declare const OFFSET_R = 24;
export declare const OFFSET_G = 16;
export declare const OFFSET_B = 8;
export declare const OFFSET_A = 0;
/**
 * Creates a new color from the given RGBA components.
 * Every component should be in the [0, 255] range.
 */
export declare function newColor(r: number, g: number, b: number, a: number): number;
/**
 * Creates a new color from a number in the canonical `0xRRGGBBAA` layout —
 * alpha in the LOW byte, which is what `newColor` composes and what
 * `getRed`/`getAlpha` read.
 *
 * A 24-bit CSS hex is therefore not one of these, and this used to say it was:
 * `from(0x599eff)` is `0x00599eff`, so it reads R=0x00, G=0x59, B=0x9e and
 * A=0xff — every intended channel one byte down, with the blue arriving as the
 * alpha. Spell the alpha (`from(0x599effff)`), or use `newColor(r, g, b, a)`.
 */
export declare function from(color: number): number;
/**
 * Turns the color into its equivalent number representation.
 * This is essentially a cast from int32 to uint32.
 */
export declare function toNumber(color: Color): number;
export declare function getRed(c: Color): number;
export declare function getGreen(c: Color): number;
export declare function getBlue(c: Color): number;
export declare function getAlpha(c: Color): number;
export declare function setRed(c: Color, value: number): number;
export declare function setGreen(c: Color, value: number): number;
export declare function setBlue(c: Color, value: number): number;
export declare function setAlpha(c: Color, value: number): number;
