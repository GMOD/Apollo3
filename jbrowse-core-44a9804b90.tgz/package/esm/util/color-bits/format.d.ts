import type { Color } from './core.ts';
/** Format to a #RRGGBBAA string */
export declare const format: typeof formatHEXA;
/** Format to a #RRGGBBAA string */
export declare function formatHEXA(color: Color): string;
export declare function formatHEX(color: Color): string;
export declare function formatRGBA(color: Color): string;
export declare function toRGBA(color: Color): {
    r: number;
    g: number;
    b: number;
    a: number;
};
export declare function formatHSLA(color: Color): string;
export declare function toHSLA(color: Color): {
    h: number;
    s: number;
    l: number;
    a: number;
};
/**
 * Returns [r, g, b] as floats in 0-1 range, suitable for GPU shader uniforms.
 */
export declare function toGLrgb(color: Color): [number, number, number];
