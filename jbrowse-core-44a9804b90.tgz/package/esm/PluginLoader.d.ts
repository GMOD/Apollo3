import type { PluginConstructor } from './Plugin.ts';
import type { CJSPluginDefinition, ESMPluginDefinition, LegacyUMDPluginDefinition, PluginDefinition, UMDPluginDefinition } from './pluginDefinitions.ts';
export interface PluginRecord {
    plugin: PluginConstructor;
    definition: PluginDefinition;
}
export interface LoadedPlugin {
    default: PluginConstructor;
}
/** A definition that could not be loaded, kept with the reason it failed */
export interface PluginLoadFailure {
    definition: PluginDefinition;
    error: unknown;
}
export default class PluginLoader {
    definitions: PluginDefinition[];
    fetchESM?: (url: string) => Promise<LoadedPlugin>;
    fetchCJS?: (url: string) => Promise<LoadedPlugin>;
    constructor(defs?: PluginDefinition[], args?: {
        fetchESM?: (url: string) => Promise<LoadedPlugin>;
        fetchCJS?: (url: string) => Promise<LoadedPlugin>;
    });
    loadCJSPlugin(def: CJSPluginDefinition, baseUri?: string): Promise<LoadedPlugin>;
    loadESMPlugin(def: ESMPluginDefinition, baseUri?: string): Promise<LoadedPlugin>;
    loadUMDPlugin(def: UMDPluginDefinition | LegacyUMDPluginDefinition, baseUri?: string): Promise<{
        default: PluginConstructor;
    }>;
    loadPlugin(def: PluginDefinition, baseUri?: string): Promise<PluginConstructor>;
    private reExportTarget;
    /**
     * Ask for the runtime ABI (`JBrowseExports`) to be published on `target`
     * before any plugin bundle is evaluated. Records the target; the registry
     * itself is fetched in `loadSettled` below.
     *
     * The split is the point. Every product calls this at startup, synchronously,
     * whether or not the config names a plugin — so importing the registry here
     * put it in every host's first paint. It is a ~126 KB gzipped module (see
     * `ReExports/registry.ts` for why it cannot shrink) that only a runtime plugin
     * can use, and loading one is async anyway.
     */
    installGlobalReExports(target: WindowOrWorkerGlobalScope): this;
    private publishReExports;
    /**
     * Loads every definition and separates the ones that worked from the ones
     * that didn't, instead of failing the batch on the first error.
     *
     * A remote config names its plugins at urls nobody re-checks — a store path
     * that stops being republished, a bundle that needs a newer host than the one
     * reading the config — and `load`'s all-or-nothing contract turns any of that
     * into a dead app rather than a missing feature. That is the widest blast
     * radius left in config loading: an unknown track/adapter/display type is
     * already tolerated (the track is simply not usable), so the plugin url was
     * the only field in a config that could still take a whole session down.
     *
     * Callers that can degrade (the apps) use this and report the failures;
     * callers that cannot (the RPC worker, where a half-loaded plugin set would
     * fail renders with a much worse message) keep using `load`.
     */
    loadSettled(baseUri?: string): Promise<{
        records: PluginRecord[];
        failures: PluginLoadFailure[];
    }>;
    load(baseUri?: string): Promise<PluginRecord[]>;
}
