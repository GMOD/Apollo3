/**
 * Make an SVG id safe to both carry in an `id` attribute and point at with
 * `url(#...)`.
 *
 * Injective but NOT idempotent — escaping the marker is what buys injectivity,
 * so a second pass re-escapes the `~`s the first one wrote. Apply it exactly
 * once, at the place that emits both the id and the reference to it
 * (`SvgClipRect` and `SvgGradientLegend` already do; a hand-rolled `<clipPath>`
 * must). Double-applying is harmless to correctness — the id and its `url()`
 * still agree, since both are derived from one call — but it produces noisy ids
 * for no reason.
 */
export declare function svgSafeId(id: string): string;
/**
 * The id to build a view's or display's SVG ids out of. It has to be two things
 * at once, and each rules out the obvious answer to the other.
 *
 * **Unique within the document.** The configured `displayId` is not: a synteny
 * or breakpoint split view exports several LGVs into one file, and a track
 * shown in more than one of them instantiates a display from the *same* config
 * in each, so both emitted the identical
 * `alignments-clip-volvox_inv_indels-LGVSyntenyDisplay`. A duplicate id is
 * silent — `url(#id)` resolves to the first match, so the second display simply
 * renders unclipped and paints over its neighbours. `assertNoDuplicateSvgIds`
 * in the web tests catches it.
 *
 * **Stable across session loads.** `model.id` is not: it is a `nanoid(10)`
 * minted when the MST node is created, so two exports of the same unchanged
 * view differ in every clip-path id. That is why the checked-in export
 * snapshots churned on `wiggle-clip-5GfQp_z8Ji` → `-FePoZy7IhS` without a
 * pixel moving, and why diffing two saved SVGs shows changes that aren't real.
 *
 * The state tree path is both. It is unique by construction — two nodes cannot
 * occupy one path — and it is a function of where the node sits in the session
 * rather than of when it was created, so the same session exports to the same
 * bytes. Only the numeric indices are kept (`/views/0/tracks/2/displays/0` →
 * `0-2-0`), since the property names in between are fixed by the schema and
 * just make the id long.
 */
export declare function svgNodeId(model: {
    id: string;
}): string;
