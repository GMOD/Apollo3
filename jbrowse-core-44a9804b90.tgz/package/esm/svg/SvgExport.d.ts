export declare function SVGBackground({ width, height, }: {
    width: number;
    height: number;
}): import("react").JSX.Element;
export declare function SVGExportRoot({ width, height, margin, fontFamily, children, }: {
    width: number;
    height: number;
    margin?: number;
    fontFamily?: string;
    children: React.ReactNode;
}): import("react").JSX.Element;
export declare function SVGMessageBox({ message, width, height, }: {
    message: string;
    width: number;
    height: number;
}): import("react").JSX.Element;
export declare function SvgChrome({ regionTooLarge, width, height, children, }: {
    regionTooLarge?: boolean;
    width: number;
    height: number;
    children: React.ReactNode;
}): import("react").JSX.Element;
export declare function SvgClipRect({ id, x, y, width, height, children, }: {
    id: string;
    x?: number;
    y?: number;
    width: number;
    height: number;
    children: React.ReactNode;
}): import("react").JSX.Element;
