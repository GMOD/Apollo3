import type PluginManager from '../PluginManager.ts';
import type { SimpleFeatureSerialized } from '../util/index.ts';
import type { SequenceHoverPosition } from './SequenceFeatureDetails/model.ts';
import type { Descriptors, MaybeSerializedFeat } from './types.tsx';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel BaseFeatureWidget
 * displays data about features, allowing configuration callbacks to modify the
 * contents of what is displayed
 *
 * see: formatDetails-\>feature,formatDetails-\>subfeatures
 */
export declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ILiteralType<"BaseFeatureWidget">;
    /**
     * #property
     */
    featureData: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<MaybeSerializedFeat, MaybeSerializedFeat, MaybeSerializedFeat>, [undefined]>;
    /**
     * #property
     */
    unformattedFeatureData: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<MaybeSerializedFeat, MaybeSerializedFeat, MaybeSerializedFeat>, [undefined]>;
    /**
     * #property
     */
    view: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    /**
     * #property
     */
    track: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    /**
     * #property
     */
    trackId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    /**
     * #property
     */
    trackType: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    /**
     * #property
     */
    maxDepth: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<number>>;
    /**
     * #property
     */
    sequenceFeatureDetails: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{}, {
        showCoordinatesSetting: import("./index.ts").ShowCoordinatesMode;
        intronBp: number;
        upDownBp: number;
        upperCaseCDS: boolean;
        charactersPerRow: number;
    } & {
        setUpDownBp(f: number): void;
        setIntronBp(f: number): void;
        setUpperCaseCDS(f: boolean): void;
        setCharactersPerRow(f: number): void;
        setShowCoordinates(f: import("./index.ts").ShowCoordinatesMode): void;
    } & {
        readonly showCoordinates: boolean;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    /**
     * #property
     */
    descriptions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Descriptors | undefined, Descriptors | undefined, Descriptors | undefined>, [undefined]>;
}, {
    error: unknown;
    sequenceHoverPosition: SequenceHoverPosition | undefined;
} & {
    /**
     * #action
     */
    setSequenceHoverPosition(pos: SequenceHoverPosition | undefined): void;
    /**
     * #action
     */
    setFeatureData(featureData: SimpleFeatureSerialized): void;
    /**
     * #action
     */
    clearFeatureData(): void;
    /**
     * #action
     */
    setFormattedData(feat: SimpleFeatureSerialized): void;
    /**
     * #action
     */
    setTrackInfo(type?: string, trackId?: string): void;
    /**
     * #action
     */
    setMaxDepth(maxDepth?: number): void;
    /**
     * #action
     */
    setError(e: unknown): void;
} & {
    afterCreate(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, {
    id: string;
    type: "BaseFeatureWidget";
    view: import("@jbrowse/mobx-state-tree").ReferenceIdentifier | undefined;
    track: import("@jbrowse/mobx-state-tree").ReferenceIdentifier | undefined;
    trackId: string | undefined;
    trackType: string | undefined;
    maxDepth: number | undefined;
    sequenceFeatureDetails: import("@jbrowse/mobx-state-tree").ModelSnapshotType<{}>;
    descriptions: Descriptors | undefined;
    finalizedFeatureData: any;
}>;
export type BaseFeatureWidgetStateModel = ReturnType<typeof stateModelFactory>;
export type BaseFeatureWidgetModel = Instance<BaseFeatureWidgetStateModel>;
