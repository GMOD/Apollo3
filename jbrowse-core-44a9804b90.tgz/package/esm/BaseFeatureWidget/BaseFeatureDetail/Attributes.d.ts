import type { Descriptors, FeatureFormatter } from '../types.tsx';
export default function Attributes(props: {
    attributes: {
        [key: string]: unknown;
        __jbrowsefmt?: Record<string, unknown>;
    };
    omit?: string[];
    omitSingleLevel?: string[];
    formatter?: FeatureFormatter;
    descriptions?: Descriptors;
    prefix?: string[];
    hideUris?: boolean;
    /**
     * The label column's width, measured once for the whole card and threaded
     * down the recursion. Set by `Attributes` itself; a caller leaves it alone.
     */
    labelWidth?: number;
}): import("react").JSX.Element;
