import type { FeatureFormatter } from '../types.tsx';
/**
 * An array of objects renders each element as its own `Attributes` block and
 * draws no label row at this level; anything else is one labelled row like any
 * other field, and so takes its place in the card's shared label column.
 * Exported because `Attributes` measures that column before rendering and has
 * to make the same call.
 */
export declare function isObjectArray(value: unknown[]): value is Record<string, unknown>[];
export default function ArrayValue({ name, value, description, formatter, prefix, width, }: {
    description?: React.ReactNode;
    name: string;
    value: unknown[];
    formatter?: FeatureFormatter;
    prefix?: string[];
    width?: number;
}): import("react").JSX.Element;
