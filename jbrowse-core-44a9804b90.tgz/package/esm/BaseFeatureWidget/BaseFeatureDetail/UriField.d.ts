export default function UriField({ value, prefix, name, width, }: {
    value: {
        uri: string;
        baseUri?: string;
    };
    name: string;
    prefix: string[];
    width?: number;
}): import("react").JSX.Element;
