/**
 * A one-shot tint over a feature-details panel, played when the panel swaps to
 * a different feature.
 *
 * Every feature widget is a singleton the drawer reuses -- one id per widget
 * type, rendered without a key -- so clicking a second feature remounts
 * nothing. The drawer keeps its scroll offset with it, and on a dense panel the
 * content can change entirely below the fold with nothing on screen saying it
 * did. The cue covers the whole panel rather than its title for that reason:
 * a title is off-screen for exactly the reader who cannot tell it updated.
 *
 * **Mount this outside anything keyed on the feature.** Some widgets key their
 * body on `uniqueId` to reset per-feature UI state (variants does, for its
 * sample grid); inside such a key this remounts on every swap and its counter
 * never leaves zero, so it silently never plays.
 */
export default function FeatureWash({ uniqueId, children, }: {
    uniqueId: string | undefined;
    children: React.ReactNode;
}): import("react").JSX.Element;
