import type { RpcStatus, SimpleFeatureSerialized } from '../../util/index.ts';
import type { ErrorState, SeqState } from '../util.tsx';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel, SequenceHoverTarget } from './model.ts';
import type { RefObject } from 'react';
export default function SequenceBody({ error, sequence, status, feature, seqPanelRef, model, mode, revcomp, assemblyGeneticCodeId, assemblyName, hoverTarget, onForceLoad, }: {
    error: unknown;
    sequence: SeqState | ErrorState | undefined;
    status?: RpcStatus;
    feature: SimpleFeatureSerialized;
    seqPanelRef: RefObject<HTMLDivElement | null>;
    model: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    revcomp: boolean;
    assemblyGeneticCodeId?: number;
    assemblyName?: string;
    hoverTarget?: SequenceHoverTarget;
    onForceLoad: () => void;
}): import("react").JSX.Element;
