import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const PlainSequence: ({ str, color, highlight, model, }: {
    str: string;
    color: string;
    highlight?: (index: number) => string | undefined;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default PlainSequence;
