import type { MenuItem } from '../../../ui/index.ts';
import type { AbstractSessionModel } from '../../../util/index.ts';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from '../model.ts';
import type { RefObject } from 'react';
interface Props {
    model: SequenceFeatureDetailsModel;
    session: Pick<AbstractSessionModel, 'notify' | 'notifyError'>;
    ref: RefObject<HTMLDivElement | null>;
    mode: SequenceDisplayMode;
    revcomp: boolean;
    setRevcomp: (arg: boolean) => void;
    extraItems?: MenuItem[];
}
declare const SequenceFeatureMenu: ({ model, session, ref, mode, revcomp, setRevcomp, extraItems, }: Props) => import("react").JSX.Element;
export default SequenceFeatureMenu;
