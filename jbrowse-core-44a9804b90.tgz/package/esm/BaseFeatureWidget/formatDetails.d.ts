import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { SimpleFeatureSerialized } from '../util/index.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Anything carrying a `formatDetails` sub-schema: the session (whose
 * `configuration.formatDetails` applies to every track) and the clicked
 * feature's track. The track is absent when the widget was opened without one,
 * or outlived the one it had -- it is a `safeReference` -- and the session-wide
 * tier still has to run in that case.
 */
export interface FormatDetailsHolder extends IStateTreeNode {
    configuration: AnyConfigurationModel;
}
export interface FormatDetailsTiers {
    session: FormatDetailsHolder;
    track?: FormatDetailsHolder;
}
/**
 * `depth` or `maxDepth`: the track's value when the track sets one, else the
 * session's, else unset.
 *
 * These override rather than merge, unlike the callback objects. That is only
 * expressible because both are `maybeNumber` slots with no `defaultValue` --
 * given a schema default the track reported a value whether or not anyone set
 * one, so the session-wide tier could never apply to a track, and every real
 * config has a track.
 */
export declare function formatDetailsNumber(tiers: FormatDetailsTiers, slot: string): number | undefined;
/**
 * A copy of the feature with each tier's callback output merged onto it (and
 * onto its subfeatures, down to `depth`) as `__jbrowsefmt`, which the detail
 * components spread over the raw fields at render.
 *
 * `__jbrowsefmt` is attached only where a callback produced something, so a
 * config with no `formatDetails` at all leaves the feature exactly as it came
 * in rather than stamping empty objects through the persisted snapshot.
 */
export declare function applyFormatDetails(tiers: FormatDetailsTiers, featureData: SimpleFeatureSerialized): SimpleFeatureSerialized;
