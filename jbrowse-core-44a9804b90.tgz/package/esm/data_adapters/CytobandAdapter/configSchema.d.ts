/**
 * #config CytobandAdapter
 *
 * #example
 * Goes on an ASSEMBLY, under `cytobands` — not on a track. It draws the
 * ideogram banding in the linear genome view's overview bar:
 * ```js
 * {
 *   name: 'hg38',
 *   sequence: {
 *     type: 'ReferenceSequenceTrack',
 *     trackId: 'hg38-ReferenceSequenceTrack',
 *     adapter: {
 *       type: 'BgzipFastaAdapter',
 *       uri: 'https://example.com/hg38.fa.gz',
 *     },
 *   },
 *   cytobands: {
 *     adapter: {
 *       type: 'CytobandAdapter',
 *       uri: 'https://example.com/hg38.cytoBand.txt.gz',
 *     },
 *   },
 * }
 * ```
 */
declare const configSchema: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     * location of a UCSC-style `cytoBand.txt` (`chrom start end name
     * gieStain`), which draws the ideogram banding in the view's overview bar.
     * May be gzipped. Configured on an assembly, not on a track.
     */
    readonly cytobandLocation: {
        readonly type: "fileLocation";
        readonly defaultValue: {
            readonly uri: "/path/to/cytoband.txt.gz";
        };
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default configSchema;
