import type PluginManager from '../PluginManager.ts';
import type { BaseFeatureDataAdapter } from './BaseAdapter/index.ts';
export interface GetFeatureAdapterArgs {
    pluginManager: PluginManager;
    sessionId: string;
    adapterConfig: Record<string, unknown>;
    sequenceAdapter?: Record<string, unknown>;
}
/**
 * Resolve a feature data adapter and prime its reference-sequence adapter
 * config in one step — the single resolution path for every RPC that reads
 * features. Returns undefined when the config resolves to a non-feature
 * adapter, so callers that can degrade (e.g. getRefNames → []) decide how; use
 * {@link getFeatureAdapterOrThrow} when a feature adapter is required.
 */
export declare function getFeatureAdapter({ pluginManager, sessionId, adapterConfig, sequenceAdapter, }: GetFeatureAdapterArgs): Promise<BaseFeatureDataAdapter | undefined>;
/**
 * {@link getFeatureAdapter} for the common case where the RPC cannot proceed
 * without a feature adapter: throws a clear error instead of returning
 * undefined, so callers get a definite type and no cast.
 */
export declare function getFeatureAdapterOrThrow(args: GetFeatureAdapterArgs): Promise<BaseFeatureDataAdapter>;
