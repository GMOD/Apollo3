import { BaseFeatureDataAdapter } from './BaseFeatureDataAdapter.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { NoAssemblyRegion } from '../../util/index.ts';
import type { RegionsAdapter } from '../BaseAdapter/index.ts';
import type { BaseOptions } from './types.ts';
/** #adapterBase BaseSequenceAdapter | a region list plus the sequence for a queried region; extends the feature adapter */
export declare abstract class BaseSequenceAdapter<CONF extends AnyConfigurationModel = AnyConfigurationModel> extends BaseFeatureDataAdapter<CONF> implements RegionsAdapter {
    /**
     * Fetches a list of 'regions' with refName, start, and extends
     */
    abstract getRegions(opts: BaseOptions): Promise<NoAssemblyRegion[]>;
    /**
     * Fetches the sequence string for a given region
     * @param region - Region to fetch sequence for
     * @param opts - Adapter options
     * @returns The sequence string for the region
     */
    getSequence(region: NoAssemblyRegion, opts?: BaseOptions): Promise<string | undefined>;
}
