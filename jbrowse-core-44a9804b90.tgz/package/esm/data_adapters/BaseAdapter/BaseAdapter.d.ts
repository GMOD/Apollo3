import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationModel, ConfigurationSchemaForModel, ConfigurationSlotName, ConfigurationSlotValue } from '../../configuration/index.ts';
import type { getSubAdapterType } from '../dataAdapterCache.ts';
export declare class BaseAdapter<CONF extends AnyConfigurationModel = AnyConfigurationModel> {
    id: string;
    config: CONF;
    getSubAdapter?: getSubAdapterType;
    pluginManager?: PluginManager;
    sequenceAdapterConfig?: Record<string, unknown>;
    static capabilities: string[];
    constructor(config?: CONF, getSubAdapter?: getSubAdapterType, pluginManager?: PluginManager);
    /**
     * Stashes the reference-sequence adapter config for adapters that decode
     * against the reference (e.g. BAM/CRAM). Set once and never cleared: the
     * adapter is cached per adapterConfig (dataAdapterCache), so a given instance
     * maps to a single, stable sequence adapter, and an `undefined` from a later
     * caller must not wipe a config an earlier one already primed. One `??=` does
     * both; callers don't need to guard.
     *
     * **Instance state rather than a per-call argument, and that is forced.**
     * `CramAdapter` binds its `seqFetch` into the `IndexedCramFile` at
     * construction, and @gmod/cram invokes it later with `(seqId, start, end)` and
     * nothing else — there is no call to thread a config through. Threading it per
     * call is the recurring proposal here and it dies at CRAM, which is the
     * adapter that needs the reference most.
     */
    setSequenceAdapterConfig(config: Record<string, unknown> | undefined): void;
    /** shorthand for `readConfObject(this.config, arg)` */
    getConf<SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONF>> | string[] = ConfigurationSlotName<ConfigurationSchemaForModel<CONF>>>(arg: SLOT, args?: Record<string, unknown>): SLOT extends string ? ConfigurationSlotValue<ConfigurationSchemaForModel<CONF>, SLOT> : any;
}
