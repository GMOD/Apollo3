import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyDataAdapter } from './BaseAdapter/index.ts';
import type { SnapshotIn } from '@jbrowse/mobx-state-tree';
type ConfigSnap = SnapshotIn<AnyConfigurationSchemaType>;
export declare function adapterConfigCacheKey(conf?: Record<string, unknown>): string;
interface AdapterCacheEntry {
    dataAdapter: AnyDataAdapter;
    sessionIds: Set<string>;
}
/** instantiate a data adapter, or return a cached one with the same config */
export declare function getAdapter(pluginManager: PluginManager, sessionId: string, adapterConfigSnapshot: SnapshotIn<AnyConfigurationSchemaType>): Promise<AdapterCacheEntry>;
/**
 * this is a callback that is passed to adapters that allows them to get any
 * sub-adapters that they need internally, staying with the same worker session
 * ID
 */
export type getSubAdapterType = (adapterConfigSnap: ConfigSnap) => ReturnType<typeof getAdapter>;
/**
 * Drop this session's claim on every cached adapter, and evict the ones no
 * other session still claims. Reached from the CoreFreeResources RPC when the
 * last track using an adapter config closes.
 *
 * Deleting the key is the whole reclamation: the cache is the only strong
 * reference to an adapter, so once it goes the instance and everything it holds
 * — a whole parsed GFF3, a BAM chunk cache — become unreachable and are
 * collected normally. There is nothing to free by hand.
 *
 * "Collected normally" is not the same as "collected now", and for the indexed
 * adapters it is not even soon. @gmod/bam, @gmod/cram and @gmod/tabix each hold
 * their parsed chunks in a SharedReadCache that sweeps itself on a setInterval,
 * and a pending timer is a GC root — so the instance stays reachable through its
 * own sweep timer until that sweep empties the cache and stops itself, three
 * minutes later. Measured: closing a panned alignments track reclaims nothing at
 * the time it happens, and the worker falls from 296 MB to 7 MB four minutes on.
 * Deleting the key is still the only thing to do here; just don't read a heap
 * immediately after a close and conclude this did nothing.
 *
 * The refcount is what makes this safe to call on any track close: an adapter
 * pulled in as a sub-adapter carries its parent's sessionId (getSubAdapter
 * passes it straight through), so a sequence adapter shared by two alignments
 * tracks survives either one of them closing.
 */
export declare function freeAdapterResources(args: {
    sessionId?: string;
}): Promise<void>;
export declare function clearAdapterCache(): void;
export {};
