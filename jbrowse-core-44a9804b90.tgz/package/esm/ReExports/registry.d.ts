export declare function setReExportRegistry(libs: Record<string, unknown>): void;
export declare function getReExportRegistry(): Record<string, unknown>;
