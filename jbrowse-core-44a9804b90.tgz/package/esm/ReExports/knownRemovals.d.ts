export interface RemovalGroup {
    /** How the announcement and the reference doc name this group. */
    summary: string;
    /** `module#name` to the reason, which is this file's own audience. */
    names: Record<string, string>;
}
export declare const REMOVAL_GROUPS: RemovalGroup[];
export declare const KNOWN_REMOVALS: Record<string, string>;
export interface SurfaceRemovalGroup {
    /** Where a plugin reaches these. Published verbatim. */
    surface: string;
    /** Absent now, to what a v4 plugin gets instead. Published verbatim. */
    gone: Record<string, string>;
    /**
     * Still there, with a signature a v4 caller does not satisfy. Kept apart from
     * `gone` because the failure is the opposite shape: a deleted member throws at
     * the call, where a changed signature answers with a plausible wrong value and
     * logs nothing. "The signature is as public as the name" is the rule on the
     * reference page; this is where the ones that broke it are written down.
     */
    changed: Record<string, string>;
}
export declare const SESSION_AND_PLUGIN_REMOVALS: SurfaceRemovalGroup[];
export interface SubpathRemovalGroup {
    /** How the upgrade guide and the reference doc name this group. */
    summary: string;
    /** The `exports` key, to what a v4 plugin importing it gets now. */
    subpaths: Record<string, string>;
}
export declare const SUBPATH_REMOVALS: SubpathRemovalGroup[];
export declare const KNOWN_SUBPATH_REMOVALS: Record<string, string>;
