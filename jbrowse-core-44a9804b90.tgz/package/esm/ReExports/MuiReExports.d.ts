import type { MuiComponentName } from './muiComponentNames.ts';
import type { ComponentType } from 'react';
export declare const Entries: Record<MuiComponentName, ComponentType<any>>;
