/**
 * Every MUI component name the host re-exports to plugins.
 *
 * Its own module, with **no MUI imports**, because the two things that need it
 * cannot both reach the other: `MuiReExports.ts` holds the components
 * themselves, and `list.ts` must stay importable by bundler configs and
 * esbuild scripts without pulling MUI in behind it (see that file's header).
 * The names were therefore written out twice — 112 of them — and kept in
 * agreement by a load-time throw in `modules.ts`.
 *
 * Declaring them here instead makes `Entries` a `Record` over this union, so a
 * name with no component and a component with no name are both compile errors,
 * and `list.ts` derives its subpaths by mapping. The runtime check in
 * `modules.ts` stays: it still covers the framework and `@jbrowse/core` entries,
 * which are not this list.
 */
export declare const MUI_COMPONENT_NAMES: readonly ['Accordion', 'AccordionActions', 'AccordionDetails', 'AccordionSummary', 'Alert', 'AlertTitle', 'Autocomplete', 'Avatar', 'AvatarGroup', 'Backdrop', 'Badge', 'Box', 'Breadcrumbs', 'Button', 'ButtonGroup', 'Card', 'CardActions', 'CardActionArea', 'CardContent', 'CardHeader', 'CardMedia', 'Chip', 'CircularProgress', 'Collapse', 'ClickAwayListener', 'Checkbox', 'Container', 'Dialog', 'DialogActions', 'DialogTitle', 'DialogContent', 'DialogContentText', 'Divider', 'Drawer', 'Fab', 'Fade', 'FilledInput', 'FormLabel', 'FormControl', 'FormControlLabel', 'FormHelperText', 'FormGroup', 'Grid', 'Grid2', 'Grow', 'Icon', 'IconButton', 'Input', 'InputBase', 'InputLabel', 'InputAdornment', 'Link', 'LinearProgress', 'List', 'ListItem', 'ListItemAvatar', 'ListItemButton', 'ListItemSecondaryAction', 'ListItemIcon', 'ListSubheader', 'ListItemText', 'Menu', 'MenuItem', 'MenuList', 'Modal', 'NativeSelect', 'OutlinedInput', 'Pagination', 'PaginationItem', 'Paper', 'Popover', 'Popper', 'Portal', 'Radio', 'RadioGroup', 'Rating', 'ScopedCssBaseline', 'Select', 'Skeleton', 'Slider', 'Snackbar', 'SnackbarContent', 'SpeedDial', 'SpeedDialAction', 'SpeedDialIcon', 'Stack', 'Step', 'StepButton', 'StepConnector', 'StepLabel', 'StepIcon', 'Stepper', 'SvgIcon', 'Switch', 'Tab', 'Table', 'TableBody', 'TableCell', 'TableContainer', 'TableFooter', 'TableHead', 'TablePagination', 'TableRow', 'TableSortLabel', 'Tabs', 'TextField', 'TextareaAutosize', 'ToggleButton', 'ToggleButtonGroup', 'Toolbar', 'Tooltip', 'Typography'];
export type MuiComponentName = (typeof MUI_COMPONENT_NAMES)[number];
