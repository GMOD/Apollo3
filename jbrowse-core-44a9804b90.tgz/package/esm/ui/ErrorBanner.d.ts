import type { ReactNode } from 'react';
declare function ErrorBanner({ error, onReset, extraAction, }: {
    error: unknown;
    onReset?: () => void;
    extraAction?: ReactNode;
}): import("react").JSX.Element;
export default ErrorBanner;
