import type { ReactNode } from 'react';
export default function LabeledCheckbox({ checked, onChange, label, className, disabled, size, }: {
    checked: boolean;
    onChange: (checked: boolean) => void;
    label: ReactNode;
    className?: string;
    disabled?: boolean;
    size?: 'small' | 'medium';
}): import("react").JSX.Element;
