import type { MenuItem } from './Menu.tsx';
import type { MenuItemClickHandler } from './MenuTypes.ts';
declare const DropDownMenu: ({ menuTitle, menuItems, onMenuItemClick, }: {
    menuTitle: string;
    menuItems: MenuItem[] | (() => MenuItem[]);
    onMenuItemClick?: (callback: MenuItemClickHandler) => void;
}) => import("react").JSX.Element;
export default DropDownMenu;
