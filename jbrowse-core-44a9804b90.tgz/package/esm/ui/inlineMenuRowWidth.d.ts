export declare const INLINE_MENU_ROW_WIDTH = 220;
