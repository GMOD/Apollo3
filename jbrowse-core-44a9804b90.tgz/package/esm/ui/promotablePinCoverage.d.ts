import type { ResolvableDisplay } from '../configuration/promotableResolve.ts';
import type { MenuItem } from './MenuTypes.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
/**
 * The registered display types whose config schema declares a promotable slot,
 * sorted — the set a pin-coverage check has to reach, answered off the
 * `DisplayType`s themselves before anything is opened.
 *
 * The other half of the same gap `promotableSlotsWithoutPin` covers, and the
 * half that has no symptom at all: that function reports on a display it was
 * *given*, so a display type no fixture ever opens is not checked and does not
 * say so. Six display types declaring `showLegend` sat outside the check's
 * reach with nothing recording it.
 *
 * Takes the display types rather than a `PluginManager`, so core doesn't have
 * to name a plugin registry to answer a question about config schemas.
 */
export declare function displayTypesWithPromotableSlots(displayTypes: readonly {
    name: string;
    configSchema: IAnyType;
}[]): string[];
/**
 * Every promotable slot some row of `items` carries a pin for, submenus
 * included.
 *
 * Reads `pin.control.slot` and nothing else. A raw `endAdornment` is
 * deliberately not counted: it is an arbitrary element (synteny's colour
 * swatch), so it cannot say which slot it promotes, and a pin built by hand
 * rather than through `promotableToggleItem`/`promotableRadioItem` is a thing to
 * find, not to accept.
 */
export declare function pinnedSlots(items: MenuItem[]): Set<string>;
/**
 * A display's promotable slots that its own track menu offers no pin for,
 * sorted. Empty is the healthy answer.
 *
 * Takes the built menu rather than calling `trackMenuItems()` itself, because
 * what a menu contains depends on the display's current state — a row can be
 * gated on a rendering type (wiggle line width), on a parent toggle (the sashimi
 * options), or on data having arrived. A caller that wants the whole surface has
 * to drive the display into the states that reveal it, and that is a decision
 * this function should not make silently.
 */
export declare function promotableSlotsWithoutPin(display: ResolvableDisplay, menuItems: MenuItem[]): string[];
