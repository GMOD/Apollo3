import type { MouseTracker } from './useMouseTracking.ts';
export declare const OverlayPointerProvider: import("react").Provider<MouseTracker | undefined>;
/**
 * The stripe a band occupies: an x span across a full-height band, a y span
 * across a full-width one. The other axis is the whole overlay, which is why it
 * isn't here.
 */
export type HighlightStripe = {
    left: number;
    width: number;
} | {
    top: number;
    height: number;
};
/**
 * Whether a band should be drawing its chip, and the `setOpen` that keeps it
 * drawn while its menu is up.
 *
 * A band reveals its chip while the pointer is in its stripe, so the highlight's
 * menu is reachable where the highlight is rather than only from the view menu,
 * and a view full of bands is not also a view full of link icons. `persistent`
 * is the `showHighlightChips` pin, which a screenshot needs because nothing
 * hovers in one.
 *
 * The menu is the reason this owns state at all: it is portalled out of the
 * band, so opening it moves the pointer off the stripe that revealed it, and
 * unmounting the chip under an open menu takes the menu's own anchor with it.
 */
export declare function useHighlightChip(stripe: HighlightStripe | undefined, persistent: boolean): {
    chipVisible: boolean;
    setMenuOpen: import("react").Dispatch<import("react").SetStateAction<boolean>>;
};
