export type TooltipPlacement = 'top' | 'top-start' | 'top-end' | 'right' | 'right-start' | 'right-end' | 'bottom' | 'bottom-start' | 'bottom-end' | 'left' | 'left-start' | 'left-end';
export default function BaseTooltip({ clientPoint: clientPointCoords, anchor, id, children, placement, }: {
    placement?: TooltipPlacement;
    /** Follow the pointer. The cursor-anchored mode, and the older of the two. */
    clientPoint?: {
        x: number;
        y: number;
    };
    /**
     * Hang off an element instead — what a control's hover label wants, where
     * following the cursor across a button reads as a stray box. Mutually
     * exclusive with `clientPoint`; `@jbrowse/display-ui`'s `useTooltip` is what
     * drives this arm.
     */
    anchor?: HTMLElement;
    /** For a trigger pointing at this with `aria-describedby`. */
    id?: string;
    children: React.ReactNode;
}): import("react").ReactPortal | null;
