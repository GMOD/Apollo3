import type { Props as DialogComponentProps } from './Dialog.tsx';
import type { SubmitFormProps } from './SubmitForm.tsx';
export interface SubmitDialogProps extends Omit<DialogComponentProps, 'onSubmit' | 'onReset'>, Omit<SubmitFormProps, 'children'> {
}
declare const SubmitDialog: (props: SubmitDialogProps) => import("react").JSX.Element;
export default SubmitDialog;
