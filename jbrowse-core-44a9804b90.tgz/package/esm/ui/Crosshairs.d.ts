declare const Crosshairs: ({ width, height, mouseX, mouseY, top, zIndex, minLeft, }: {
    width: number;
    height: number;
    mouseX: number;
    mouseY?: number;
    top?: number;
    zIndex?: number;
    minLeft?: number;
}) => import("react").JSX.Element;
export default Crosshairs;
