export declare function MenuItemEndDecoration({ type, checked, }: {
    type: 'checkbox' | 'radio';
    checked: boolean;
}): import("react").JSX.Element;
