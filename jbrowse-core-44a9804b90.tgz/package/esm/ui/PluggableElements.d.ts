import type PluginManager from '../PluginManager.ts';
import type { ExtensionPointProps } from '../PluginManager.ts';
import type { ElementExtensionPointName } from './addExtensionElement.tsx';
/**
 * Render every element contributed to an accumulating point — the overlay
 * points, whose entries are `ReactNode`s put there by `addExtensionElement`.
 *
 * The list sibling of {@link PluggableComponent}, which renders the single
 * component a `single` point resolves to. Which one a point takes is decided by
 * its registry entry, not by the call site: `ElementExtensionPointName` accepts
 * only the points whose `args` are `ReactNode[]`, so asking for a slot point
 * here is a compile error rather than a component that renders nothing.
 *
 * observer for the same reason PluggableComponent is one: a contributor may
 * scope itself on an observable, and the fold runs here rather than in the
 * producer, so the read has to be tracked by this component's own reaction.
 */
declare const PluggableElements: <N extends ElementExtensionPointName>({ pluginManager, name, props, }: {
    pluginManager: PluginManager;
    name: N;
    props: ExtensionPointProps<N>;
}) => import("react").JSX.Element;
export default PluggableElements;
