/**
 * Which tracks a contribution is for. Every track-scoped extension point fires
 * for every track, so a contribution with no selector applies to all of them.
 * {@link matchesTrackSelector} is what applies one.
 */
export interface TrackSelector {
    /** track type, e.g. `'VariantTrack'`, usually what "for my tracks" means */
    trackType?: string | string[];
    /** track id; a plain string also matches the user's copies of that track */
    trackId?: string | RegExp | (string | RegExp)[];
    /** widget model type, e.g. `'AlignmentsFeatureWidget'`, for the slot points */
    widgetType?: string | string[];
}
/** the model fields a declarative selector can match on */
export interface SelectableModel {
    type?: string;
    trackId?: string;
    trackType?: string;
}
/**
 * What a track-scoped extension point contribution is for: whether the widget
 * model or track config in `subject` satisfies every field of `select`. Every
 * field given must match, and an empty selector matches everything.
 *
 * Every one of those points fires for every track, so a contribution that does
 * not call this applies to all of them. Hand-writing `config.trackId === 'x'`
 * instead is what silently stops applying the first time a user copies the
 * track: `copyTrackSnapshot` suffixes the id, and this knows that.
 *
 * Not to be confused with {@link matchTrackId}, which tests an id against
 * patterns you supply and so leaves that normalization to you.
 */
export declare function matchesTrackSelector(select: TrackSelector | undefined, subject: {
    /** a widget model, if the point's props carry one */
    model?: SelectableModel;
    /** a track config, if they carry that instead — `type` is the track type */
    config?: Record<string, unknown>;
}): boolean;
