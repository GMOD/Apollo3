export { INLINE_MENU_ROW_WIDTH } from './inlineMenuRowWidth.ts';
export declare function ResetToDefaultButton({ disabled, title, onClick, }: {
    disabled: boolean;
    title?: string;
    onClick: () => void;
}): import("react").JSX.Element;
