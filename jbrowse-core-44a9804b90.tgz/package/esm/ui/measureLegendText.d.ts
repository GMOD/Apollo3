export declare function measureLegendText(str: string, fontSize: number): number;
