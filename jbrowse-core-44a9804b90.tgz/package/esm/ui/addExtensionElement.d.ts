import type PluginManager from '../PluginManager.ts';
import type { ExtensionPointProps, PointsOfKind } from '../PluginManager.ts';
import type { ComponentType } from 'react';
/**
 * The extension points that accumulate an array of rendered elements — every
 * point declared `ElementList`, the LGV and dotplot overlays.
 * {@link PluggableElements} is the producer side.
 */
export type ElementExtensionPointName = PointsOfKind<'elementList'>;
/**
 * Render `component` into an overlay extension point, passing it the point's
 * props.
 *
 * Prefer this to contributing the element yourself: it fixes the React `key` at
 * registration time, and forgetting that one produces a warning pointing at
 * framework code rather than at the plugin.
 */
export declare function addExtensionElement<N extends ElementExtensionPointName>(pluginManager: PluginManager, name: N, component: ComponentType<ExtensionPointProps<N>>): void;
