import type PluginManager from '../PluginManager.ts';
import type { AbstractSessionModel } from '../util/types/index.ts';
import type { MenuItem } from './MenuTypes.ts';
export interface MultiTrackMenuItemsProps {
    session: AbstractSessionModel;
}
/** Return the items to add, or nothing when the selection isn't yours. */
export type MultiTrackMenuItemsCallback = (props: MultiTrackMenuItemsProps) => MenuItem | MenuItem[] | undefined;
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'TrackSelector-multiTrackMenuItems': {
            args: MenuItem[];
            result: MenuItem[];
            props: MultiTrackMenuItemsProps;
        };
    }
}
export declare function addMultiTrackMenuItems(pluginManager: PluginManager, callback: MultiTrackMenuItemsCallback): void;
export declare function buildMultiTrackMenuItems(pluginManager: PluginManager, props: MultiTrackMenuItemsProps): MenuItem[];
