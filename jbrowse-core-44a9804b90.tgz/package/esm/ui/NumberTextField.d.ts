import type { TextFieldProps } from '@mui/material';
interface OwnProps {
    /** Initial numeric value; undefined renders as empty input. */
    defaultValue?: number;
    /**
     * Fires on every keystroke with the parsed number, or undefined when
     * the input is empty or invalid (NaN / out of bounds). The parent
     * decides whether to gate submission on undefined.
     */
    onValueChange: (value: number | undefined) => void;
    /** Optional inclusive lower bound. */
    min?: number;
    /** Optional inclusive upper bound. */
    max?: number;
    /** Shown under the input when the value is non-empty and invalid. */
    errorText?: string;
}
type Props = Omit<TextFieldProps, 'value' | 'onChange' | 'type' | 'error'> & OwnProps & {
    helperText?: TextFieldProps['helperText'];
};
/**
 * Uncontrolled-style numeric TextField. Owns the input *text* internally;
 * emits the parsed *number* (or undefined) to the parent on every change.
 *
 * Use over `<TextField type="number" />` — the browser number input has
 * known UX problems (scroll-to-change, locale issues, browser-specific
 * spinners). This component keeps a plain text input and validates with
 * `Number.isFinite` + optional min/max.
 */
export default function NumberTextField(props: Props): import("react").JSX.Element;
export {};
