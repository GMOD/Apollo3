import type { ResolvableDisplay } from '../configuration/promotableResolve.ts';
import type { AnyConfigurationModel, ConfigurationSchemaForModel, ConfigurationSlotName } from '../configuration/types.ts';
import type { MenuItem } from './MenuTypes.ts';
import type { SliderScale } from './sliderScale.ts';
interface SizeMenuOptions {
    label: string;
    title: string;
    help?: string;
    getValue: () => number;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    scale?: SliderScale;
    format?: (n: number) => string;
    commitOnRelease?: boolean;
    onChange: (n: number) => void;
    onReset: () => void;
}
export declare function makeSizeMenu(opts: SizeMenuOptions & {
    isDefault: boolean;
}): MenuItem;
export declare function makeSizeSubMenu(opts: SizeMenuOptions & {
    isDefault: boolean;
}): MenuItem;
export declare function makePromotableSizeMenu<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(opts: SizeMenuOptions & {
    display: ResolvableDisplay<CONFMODEL>;
    slot: SLOT;
}): MenuItem;
export {};
