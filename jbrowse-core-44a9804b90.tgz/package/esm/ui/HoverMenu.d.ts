import type { PopoverOrigin } from '@mui/material';
declare function HoverMenu({ open, anchorEl, onClose, onMouseEnter, paperRef, anchorOrigin, transformOrigin, zIndex, children, }: {
    open: boolean;
    anchorEl: HTMLElement | null;
    onClose: () => void;
    onMouseEnter?: () => void;
    paperRef?: React.Ref<HTMLElement>;
    anchorOrigin: PopoverOrigin;
    transformOrigin: PopoverOrigin;
    zIndex?: React.CSSProperties['zIndex'];
    children: React.ReactNode;
}): import("react").JSX.Element;
export default HoverMenu;
