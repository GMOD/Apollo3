/**
 * The "there is more content this way" edge shadow for a display that scrolls
 * its content virtually — the same displays that mount `VerticalScrollbar`,
 * drawn from the same three numbers.
 *
 * It answers a question the scrollbar technically also answers and in practice
 * does not: **is this track showing me all of its features?** A 6px thumb on a
 * dense track is missed even by someone looking for it — GMOD/jbrowse-components#5589,
 * and the figure review that read `k562_bcr_abl_split` past a scrolled-away
 * pileup twice.
 *
 * Two properties are what keep it from being noise, and both are worth keeping
 * if this is ever restyled:
 *
 * - **It costs nothing when nothing is hidden.** No content past an edge, no
 *   fade at that edge; a track that fits draws neither. So it is a readout of
 *   state, not a decoration — which a recoloured bottom border could not be
 *   (and which would also need `showTrackOutlines`, an option the user can turn
 *   off, to have a border to recolour).
 * - **It says which way.** Scrolled to the bottom, the bottom fade goes and the
 *   top one appears, so "am I at the end" is answerable without scrolling.
 *
 * Shadowing with ink rather than dissolving the content into the track's own
 * background is a decision, not the obvious default, and the reason is the
 * sparse case: a dissolve over empty background is background-over-background,
 * so a track whose last visible strip happens to be blank — with rows below it —
 * is marked by nothing at all. Ink marks the edge whatever is under it. The cost
 * is that the dark theme's white ink brightens the last row of a dense pileup
 * rather than darkening it; both were drawn and compared, and covering the
 * sparse case won.
 *
 * The actionable half lives in the bottom-right corner (`TrackHeightIndicator`
 * — autogrow/fit, and the truncation warning for features that were dropped
 * rather than merely scrolled away). This says *that*; that says *what to do*.
 */
export default function ScrollEdgeShadow({ scrollTop, viewportHeight, contentHeight, top, }: {
    scrollTop: number;
    /** the visible viewport height */
    viewportHeight: number;
    /** the full scrollable content height */
    contentHeight: number;
    /** viewport offset from the top, for a display with a sticky band above it */
    top?: number;
}): import("react").JSX.Element | null;
