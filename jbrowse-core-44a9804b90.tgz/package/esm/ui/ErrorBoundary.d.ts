import { Component } from 'react';
import type { ErrorInfo } from 'react';
export interface FallbackProps {
    error: unknown;
    componentStack?: string;
    /** clear the caught error, remounting the children that threw */
    resetErrorBoundary: () => void;
}
interface Props {
    children: React.ReactNode;
    FallbackComponent: React.FC<FallbackProps>;
    /**
     * clear the caught error when any of these changes, compared with `Object.is`
     * element by element. For the cause a caller can name — the display was
     * swapped, the view was replaced — so a banner does not outlive it.
     */
    resetKeys?: unknown[];
    /** runs before the error clears, on either reset path */
    onReset?: () => void;
    /**
     * runs when an error is caught, BEFORE the fallback renders. For a caller
     * that has to record something durable about the failure — jbrowse-web marks
     * the session it was showing, so the next boot does not restore straight back
     * into the crash. An effect inside the fallback would be a render later and
     * one more thing that has to run correctly on the way down.
     */
    onError?: (error: unknown) => void;
}
interface State {
    error: unknown;
    componentStack?: string;
    keysAtError?: unknown[];
}
declare class ErrorBoundary extends Component<Props, State> {
    constructor(props: Props);
    componentDidCatch(error: Error, errorInfo: ErrorInfo): void;
    componentDidUpdate(): void;
    resetErrorBoundary: () => void;
    render(): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | Iterable<import("react").ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | null | undefined;
}
export { ErrorBoundary };
