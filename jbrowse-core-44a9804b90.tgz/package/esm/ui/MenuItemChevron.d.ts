export declare function MenuItemChevron({ hidden }: {
    hidden?: boolean;
}): import("react").JSX.Element;
