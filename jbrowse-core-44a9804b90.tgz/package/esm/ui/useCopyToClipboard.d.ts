/**
 * Copy to the clipboard and briefly flash a "copied" confirmation. Returns the
 * flag to render that confirmation from and the copy function to call from a
 * click handler.
 *
 * The timer is what this exists for: it has to be reset on each copy, so a
 * second click doesn't revert the label early, and cleared on unmount, so a
 * panel closed mid-flash leaves nothing pending. `CopyToClipboardButton` and the
 * feature-details `Formatter` had each grown a version of it, one of them
 * without the unmount cleanup.
 */
export declare function useCopyToClipboard(durationMs?: number): {
    copied: boolean;
    copy: (text: string) => Promise<void>;
};
