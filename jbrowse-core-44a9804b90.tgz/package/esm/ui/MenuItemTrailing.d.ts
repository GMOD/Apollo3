import type { ClickableMenuItem, SubMenuItem } from './MenuTypes.ts';
export type DecoratedMenuItem = ClickableMenuItem | SubMenuItem;
export interface MenuColumnFlags {
    hasCheckboxOrRadioWithHelp: boolean;
    hasEndAdornment: boolean;
    hasSubmenuWithHelp: boolean;
    sharedActionColumn: boolean;
}
export declare function MenuItemTrailing({ item, columns: { hasCheckboxOrRadioWithHelp, hasEndAdornment, hasSubmenuWithHelp, sharedActionColumn, }, }: {
    item: DecoratedMenuItem;
    columns: MenuColumnFlags;
}): import("react").JSX.Element;
