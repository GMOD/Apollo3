/**
 * What a view reads and writes to offer scroll-to-zoom. Duck-typed rather than
 * a model, like the rest of the wheel-zoom layer — every view here delegates
 * both to the session, which is where the preference lives.
 */
export interface ScrollZoomToggleModel {
    scrollZoom: boolean;
    setScrollZoom: (flag: boolean) => void;
}
/**
 * The persistent control for scroll-to-zoom, shared by every view that has one.
 *
 * **Carries its own label.** Scroll-to-zoom is off by default, so a wheel over
 * the tracks does nothing until someone finds this — and the words in the header
 * are the whole of how they find it. An icon alone is not findable, whichever
 * icon: the glyph says "zoom" at best and nothing at all about the wheel. The
 * tooltip is where ctrl/⌘+scroll, which zooms whatever the preference says, is
 * named.
 *
 * **And it pulses when the preference changes.** The other ways to write it are
 * somewhere else on the screen — a view menu, the Preferences dialog — so the
 * moment the setting is learned is also the moment this button is not being
 * looked at. The ring is what connects the two: it says the thing you just
 * turned on lives *here*, which is what a user who wants it back off has to
 * know. Its own click pulses too — the answer to "where is this" should not
 * depend on which of the several places wrote it, and the other views' copies
 * of this button pulse with it, which is the preference being session-wide made
 * visible.
 *
 * `iconOnly` is for a header where this sits inside a run of icon buttons (the
 * comparative views), where a single labelled button reads as a mistake rather
 * than as emphasis. The tooltip carries the same words either way.
 */
declare const ScrollZoomToggle: ({ model, iconOnly, }: {
    model: ScrollZoomToggleModel;
    iconOnly?: boolean;
}) => import("react").JSX.Element;
export default ScrollZoomToggle;
