import type { AbstractViewContainer, AbstractViewModel } from '../util/types/index.ts';
import type { SubmitFormProps } from './SubmitForm.tsx';
/**
 * The two destinations a launch dialog offers, as `SubmitDialog` props: Submit
 * opens the launched view in a new one, and a second button puts it in the slot
 * the launching view occupies.
 *
 * Every launcher anchored on what a view is already showing — the synteny
 * launches, "read vs ref", the derivative reconstruction — wants exactly this
 * pair, and each had written the same four lines around
 * {@link ReplaceCurrentViewButton}: the guard, the button, its disabled state,
 * and the renaming of Submit that only makes sense once there are two buttons.
 * The guard is the part worth having in one place; see {@link canReplaceView}
 * for the case each copy got wrong.
 *
 * Spread it into the dialog *before* any explicit props, so a caller that words
 * its own Submit differently still can:
 *
 * ```tsx
 * <SubmitDialog
 *   {...replaceViewAction({ session, sourceView, disabled, onReplace: launch })}
 *   submitText="Open in new view"
 * />
 * ```
 */
export declare function replaceViewAction({ session, sourceView, disabled, onReplace, }: {
    session: AbstractViewContainer;
    sourceView: AbstractViewModel | undefined;
    disabled?: boolean;
    onReplace: (replacing: AbstractViewModel) => void;
}): Pick<SubmitFormProps, 'submitText' | 'actions'>;
