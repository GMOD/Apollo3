import type { ReactNode } from 'react';
export default function ShareLinkField({ value, label, action, }: {
    value: string;
    label?: string;
    action?: ReactNode;
}): import("react").JSX.Element;
