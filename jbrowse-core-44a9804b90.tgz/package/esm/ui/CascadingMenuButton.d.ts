import type { MenuItemsGetter } from './CascadingMenu.tsx';
import type { MenuItemClickHandler } from './MenuTypes.ts';
import type { PopoverOrigin } from '@mui/material';
declare function CascadingMenuButton({ children, menuItems, closeAfterItemClick, stopPropagation, disabled, setOpen, ButtonComponent, onClick: onClickExtra, onMenuItemClick, anchorOrigin, transformOrigin, tooltip, ...rest }: {
    children?: React.ReactNode;
    menuItems: MenuItemsGetter;
    closeAfterItemClick?: boolean;
    stopPropagation?: boolean;
    disabled?: boolean;
    onClick?: (event: React.MouseEvent<HTMLButtonElement>) => void;
    onMenuItemClick?: (callback: MenuItemClickHandler) => void;
    setOpen?: (arg: boolean) => void;
    ButtonComponent?: React.FC<{
        onClick: (e: React.MouseEvent<HTMLButtonElement>) => void;
        disabled?: boolean;
        children?: React.ReactNode;
        'aria-label'?: string;
    }>;
    anchorOrigin?: PopoverOrigin;
    transformOrigin?: PopoverOrigin;
    tooltip?: string;
    [key: string]: unknown;
}): import("react").JSX.Element;
export default CascadingMenuButton;
