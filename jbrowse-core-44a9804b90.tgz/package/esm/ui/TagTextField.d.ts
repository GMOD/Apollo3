import type { TextFieldProps } from '@mui/material';
/** A quick-pick shortcut: the two-character tag plus a human label. */
export interface TagQuickPick {
    tag: string;
    label?: string;
}
interface OwnProps {
    /** Initial tag; undefined or '' renders as empty input. */
    defaultValue?: string;
    /**
     * Fires on every keystroke with the tag when it is a valid 2-character SAM
     * tag, or undefined otherwise. The parent gates submission on undefined.
     */
    onValueChange: (value: string | undefined) => void;
    /**
     * Optional hint shown under the input. Off by default — the field is capped at
     * two characters and the quick-pick chips already teach the common tags, so a
     * persistent hint just adds a line that misaligns the field against its
     * siblings. The invalid-tag error still shows regardless.
     */
    helperText?: TextFieldProps['helperText'];
    /** data-testid forwarded to the inner <input> (used by screenshot specs). */
    inputTestId?: string;
    /**
     * One-click shortcuts for common tags (e.g. HP, RG) shown as chips above the
     * field, so users don't have to know and type the two-letter code. Clicking a
     * chip fills the field and emits the value exactly as typing it would.
     */
    quickPicks?: TagQuickPick[];
}
type Props = Omit<TextFieldProps, 'value' | 'onChange' | 'error' | 'helperText' | 'slotProps'> & OwnProps;
/**
 * Uncontrolled-style TextField for a two-character SAM tag (e.g. HP, RG, XS).
 * Owns the input text internally; emits the tag string when valid (or
 * undefined) to the parent. Caps input at two characters and shows an inline
 * error once two invalid characters are entered. Optional `quickPicks` render a
 * chip row of common tags that fill the field on click.
 */
export default function TagTextField(props: Props): import("react").JSX.Element;
export {};
