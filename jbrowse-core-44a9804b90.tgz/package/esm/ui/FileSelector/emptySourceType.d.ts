export declare const EmptySourceTypeProvider: import("react").Provider<string | undefined>;
export declare function useEmptySourceType(): string | undefined;
