import type { AssemblyHost } from '../util/index.ts';
declare const AssemblySelector: ({ session, onChange, label, selected, fullWidth, helperText, }: {
    session: AssemblyHost;
    label?: string;
    helperText?: string;
    onChange: (arg: string) => void;
    selected?: string;
    fullWidth?: boolean;
}) => import("react").JSX.Element;
export default AssemblySelector;
