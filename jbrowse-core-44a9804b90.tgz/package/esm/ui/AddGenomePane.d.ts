import type { FormState } from '../util/assemblyConfigUtils.ts';
declare const AddGenomePane: ({ form, setForm, loading, onStageAnother, }: {
    form: FormState;
    setForm: (update: (prev: FormState) => FormState) => void;
    loading?: string;
    onStageAnother?: () => Promise<boolean>;
}) => import("react").JSX.Element;
export default AddGenomePane;
