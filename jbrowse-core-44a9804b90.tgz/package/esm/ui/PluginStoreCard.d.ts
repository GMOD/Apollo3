import type { PluginDefinition } from '../pluginDefinitions.ts';
import type { ResolvedPlugin } from '../util/pluginStore.ts';
import type { JBrowsePlugin } from '../util/types/index.ts';
/**
 * One plugin-store entry. Presentational, and shared by every surface that
 * installs from the store (the in-session plugin store widget, Desktop's global
 * plugins dialog) so all of them install the version `resolvePlugin` picked —
 * version-pinned, integrity-carrying, and refused when no published version
 * supports this JBrowse.
 */
export default function PluginStoreCard({ plugin, resolved, installed, disabled, onInstall, }: {
    plugin: JBrowsePlugin;
    resolved: ResolvedPlugin;
    installed: boolean;
    disabled?: boolean;
    onInstall: (definition: PluginDefinition) => void;
}): import("react").JSX.Element;
