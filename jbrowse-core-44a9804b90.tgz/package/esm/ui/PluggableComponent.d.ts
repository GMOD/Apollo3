import type PluginManager from '../PluginManager';
import type { ExtensionPointName, ExtensionPointProps } from '../PluginManager';
import type React from 'react';
declare const PluggableComponent: <N extends ExtensionPointName, P extends object>({ pluginManager, name, component: DefaultComponent, props, }: {
    pluginManager: PluginManager;
    name: N;
    component: React.ComponentType<P> | React.LazyExoticComponent<React.ComponentType<P>>;
    props: P & ExtensionPointProps<N>;
}) => React.JSX.Element;
export default PluggableComponent;
