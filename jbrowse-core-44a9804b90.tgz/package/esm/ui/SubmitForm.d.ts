import type { ButtonProps } from '@mui/material';
import type { ReactNode } from 'react';
export interface SubmitFormProps {
    onCancel: () => void;
    onSubmit: () => void;
    cancelText?: string;
    submitText?: string;
    submitDisabled?: boolean;
    submitColor?: ButtonProps['color'];
    submitStartIcon?: ReactNode;
    onReset?: () => void;
    resetText?: string;
    actions?: ReactNode;
    contentClassName?: string;
    children?: ReactNode;
}
/**
 * Content plus a Cancel/Submit footer, wrapped in a form so Enter submits.
 * SubmitDialog is this with a Dialog around it; a dialog whose Dialog (and
 * outer chrome) is shared across several tab panes uses this directly, so the
 * panes get the same keyboard behavior without each owning a Dialog.
 */
export default function SubmitForm({ onSubmit, onCancel, cancelText, submitText, submitDisabled, submitColor, submitStartIcon, onReset, resetText, actions, contentClassName, children, }: SubmitFormProps): import("react").JSX.Element;
