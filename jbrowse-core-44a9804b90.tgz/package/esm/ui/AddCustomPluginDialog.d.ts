import type { PluginDefinition } from '../pluginDefinitions.ts';
/**
 * The "add a plugin by url" form, shared by every place a plugin can be
 * installed from outside the store — the in-session plugin store widget and
 * Desktop's global plugins dialog — so both mint the same definition shapes
 * from the same fields.
 *
 * `onAdd` returns false to reject the definition and keep the dialog open (the
 * plugin store rejects a name already installed).
 */
export default function AddCustomPluginDialog({ onClose, onAdd, }: {
    onClose: () => void;
    onAdd: (definition: PluginDefinition) => boolean;
}): import("react").JSX.Element;
