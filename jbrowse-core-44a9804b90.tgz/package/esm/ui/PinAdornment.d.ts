import type { MenuItemPin } from './MenuTypes.ts';
export declare function PinAdornment({ pin, disabled, }: {
    pin: MenuItemPin;
    disabled?: boolean;
}): import("react").JSX.Element;
