declare const category10: string[];
declare const set1: string[];
export declare const paletteColors: {
    category10: string[];
    dark2: string[];
    ggplot2Colors3: string[];
    ggplot2Colors4: string[];
    ggplot2Colors5: string[];
    ggplot2Colors6: string[];
    set1: string[];
    set2: string[];
    tableau10: string[];
};
/**
 * The wide qualitative palette: every scheme above, in order, deduped and with
 * the neutrals dropped. ~40 entries.
 *
 * One list, because "give each row a distinct color" is one question this repo
 * answers in two places — the multi-row painter handing colors out by row
 * index, and the arrangement dialog's palette-by-attribute — and two lists
 * would mean a track's automatic colors and the colors it takes when a user
 * palettes it by hand were different palettes for no reason a reader could see.
 *
 * `tableau10` leads because its hues are the most evenly separated, so a track
 * with a handful of rows spends only that. The tail is what makes the 26
 * 1000-Genomes population codes, or a repeat painting's classes, all get a
 * curated color instead of falling out to `randomColor`.
 *
 * Past the end is the caller's problem, and the two callers answer differently
 * on purpose: an attribute palette-by hashes the VALUE (stable across
 * re-palettes), while a by-position painter has no value to hash and wraps.
 */
export declare const categoricalPalette: string[];
/**
 * Deterministic non-negative 32-bit hash of a string.
 */
export declare function hashString(str: string): number;
/**
 * Stable category10 color for a sequence name, via `hashString`.
 *
 * Kept as a published export; in-tree, prefer {@link refNameColor}, which hands
 * the palette out by position where the caller knows the assembly's chromosome
 * order and only hashes where it does not.
 */
export declare function getQueryColor(queryName: string): string;
/** The palette color for a chromosome at `position` in its assembly. */
export declare function refNamePaletteColorAt(position: number): string;
/**
 * The color a refName paints, BY POSITION IN THE ASSEMBLY where the caller
 * knows its chromosome order.
 *
 * Handing the palette out rather than hashing into it is what stops a genome
 * painting two of its own chromosomes the same color: nine slots means ten or
 * more chromosomes re-use one, and by the birthday bound long before that. On
 * hg38 the hash puts chr1, chr12, chr21 and chrY on one color.
 *
 * `position` is undefined for the case the order genuinely is not available —
 * an assembly still loading, or a refName the assembly does not list (a
 * scaffold under an alias). There a stable arbitrary color beats no color, so
 * it falls back to the hash.
 */
export declare function refNameColor(name: string, position: number | undefined): string;
export { category10, set1 };
