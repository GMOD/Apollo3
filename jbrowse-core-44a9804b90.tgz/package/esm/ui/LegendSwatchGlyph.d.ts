import type { LegendSwatch } from './legendSpec.ts';
export declare function LegendSwatchGlyph({ swatch, size, x, y, }: {
    swatch: LegendSwatch;
    size: number;
    x?: number;
    y?: number;
}): import("react").JSX.Element;
