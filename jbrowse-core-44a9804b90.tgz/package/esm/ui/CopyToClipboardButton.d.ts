import type { ButtonProps } from '@mui/material';
/**
 * A Button that copies `value` to the clipboard and briefly swaps its label to
 * `copiedLabel` as feedback. `value` may be a function so callers can defer
 * computing large strings (e.g. JSON.stringify) until the click happens.
 */
export default function CopyToClipboardButton({ value, children, copiedLabel, ...rest }: {
    value: string | (() => string);
    copiedLabel?: string;
} & Omit<ButtonProps, 'value'>): import("react").JSX.Element;
