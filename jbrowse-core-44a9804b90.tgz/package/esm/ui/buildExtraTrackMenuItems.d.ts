import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { AbstractSessionModel, TrackActionView } from '../util/types/index.ts';
import type { MenuItem } from './MenuTypes.ts';
export interface ExtraTrackMenuItemsProps {
    session: AbstractSessionModel;
    config: AnyConfigurationModel;
    view?: TrackActionView;
}
/** Return the items to add, or nothing when the track isn't yours. */
export type ExtraTrackMenuItemsCallback = (props: ExtraTrackMenuItemsProps) => MenuItem | MenuItem[] | undefined;
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-extraTrackMenuItems': {
            args: MenuItem[];
            result: MenuItem[];
            props: ExtraTrackMenuItemsProps;
        };
    }
}
export declare function addExtraTrackMenuItems(pluginManager: PluginManager, callback: ExtraTrackMenuItemsCallback): void;
export declare function buildExtraTrackMenuItems(pluginManager: PluginManager, props: ExtraTrackMenuItemsProps): MenuItem[];
