export declare const indeterminateSweep: {
    name: string;
    styles: string;
    anim: 1;
    toString: () => string;
} & string;
