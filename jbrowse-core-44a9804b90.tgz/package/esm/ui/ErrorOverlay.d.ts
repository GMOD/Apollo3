import type { ReactNode } from 'react';
export default function ErrorOverlay({ error, onRetry, width, height, extraAction, }: {
    error: unknown;
    onRetry: () => void;
    width: number | string;
    height: number | string;
    extraAction?: ReactNode;
}): import("react").JSX.Element;
