import type { BaseExportSvgOptions } from './BaseExportSvgDialog.tsx';
export default function ExportSvgDialog({ model, handleClose, }: {
    model: {
        exportSvg(opts: BaseExportSvgOptions): Promise<void>;
    };
    handleClose: () => void;
}): import("react").JSX.Element;
