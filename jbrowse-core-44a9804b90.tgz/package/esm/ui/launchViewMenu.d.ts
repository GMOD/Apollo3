import type { MenuItem } from './MenuTypes.ts';
export declare const LAUNCH_LABEL = "Launch";
export declare function pushIntoSubMenu(items: MenuItem[], label: string, item: MenuItem): void;
export declare function pushLaunchViewMenuItem(items: MenuItem[], item: MenuItem): void;
