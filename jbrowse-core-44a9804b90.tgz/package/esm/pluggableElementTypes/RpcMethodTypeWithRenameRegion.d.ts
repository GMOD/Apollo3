import RpcMethodType from './RpcMethodType.ts';
import type { RenameRegionArgs } from './RpcMethodType.ts';
export default abstract class RpcMethodTypeWithRenameRegion<MethodName extends string = string> extends RpcMethodType<MethodName> {
    serializeArguments<T extends RenameRegionArgs>(args: T): Promise<Record<string, unknown>>;
}
