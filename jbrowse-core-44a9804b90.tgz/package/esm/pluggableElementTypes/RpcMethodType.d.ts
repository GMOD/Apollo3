import PluggableElementBase from './PluggableElementBase.ts';
import type PluginManager from '../PluginManager.ts';
import type { RpcCallContext, RpcCallReturn, RpcExecuteArgs, RpcSession, RpcWireReturn } from '../rpc/RpcRegistry.ts';
import type { Region } from '../util/index.ts';
import type { UriLocation } from '../util/types/index.ts';
export type RpcMethodConstructor = new (pm: PluginManager) => RpcMethodType;
export type RenameRegionsArgs = RpcCallContext & {
    assemblyName?: string;
    regions?: Region[];
    adapterConfig: Record<string, unknown>;
};
export type RenameRegionArgs = RpcSession & {
    region: Region;
    adapterConfig: Record<string, unknown>;
};
export declare function convertFileHandleLocations(obj: unknown, blobMap: Record<string, File>): void;
/**
 * Base for an RPC method. Parameterize with the method's own registry name —
 * `class CoreGetRegions extends RpcMethodType<'CoreGetRegions'>` — and `execute`
 * is then checked against that entry's declared `return` (bare or wrapped in
 * rpcResult), so the registry stays an assertion about the worker rather than a
 * hand-maintained guess. Left unparameterized, `execute` resolves to `unknown`
 * as before; that's the escape hatch, and it should be rare.
 *
 * The name is checked twice over, because parameterizing used to be a claim
 * rather than a fact: it must be a key of the registry (a miss lands on
 * {@link NotInRpcRegistry} instead of quietly on `unknown`), and it must be the
 * key this class sets as its {@link name}. Both are compile errors, so the
 * escape hatch is the only way to end up unchecked, and taking it is visible.
 *
 * A method whose worker sends something other than the registry `return` — a
 * result wrapped in `rpcResult` to hand its buffers to postMessage, or one
 * `deserializeReturn` rebuilds — says so in the registry entry, beside the
 * `return` it has to be read against. There is deliberately no second type
 * parameter for it. As one it was a copy of the registry rather than a
 * reference to it, and fifteen classes kept the copy in step by hand.
 *
 * The name is the ONLY parameter, and that is what makes this shape uniform:
 * a second one survives only where a base is still GENERIC over its name, since
 * `RpcWireReturn<MethodName>` is then a conditional TypeScript will not resolve
 * and the shared body has nothing to check against. Such a base has to pin the
 * wire return by hand and constrain `MethodName` to keep the pin honest — which
 * is a mechanism, and the last one that needed it was sharing a three-line
 * delegation two subclasses could each just write (see `runDiagonalize` in
 * @jbrowse/synteny-core). Share an RPC body as a FUNCTION, not as a base
 * generic over the key.
 *
 * The way back is {@link deserializeReturn}, checked against the same entry's
 * `return`.
 */
export default abstract class RpcMethodType<MethodName extends string = string> extends PluggableElementBase {
    /**
     * The key this method is registered under, and the same one the class is
     * parameterized with — `pluginManager.getRpcMethodType` looks it up by this
     * string, so it is what a caller's `rpcManager.call` names.
     *
     * Narrowed to `MethodName` because the parameter was otherwise a claim about
     * a method that nothing checked was this one: `RpcMethodType<'A'>` with
     * `name = 'B'` type-checked, and then `execute` was checked against B's
     * registry entry while the worker ran it for A. Not hypothetical here —
     * `GetPileupFeatureDetails` and `GetCanvasFeatureDetails` are two registry
     * keys held by two same-bodied classes both called `GetFeatureDetails`.
     *
     * A class field initializer is not contextually typed by the base property,
     * so a parameterized subclass writes `name = 'CoreGetRegions' as const`.
     * Omitting the `as const` is a compile error on `name`, which is the point:
     * the tie is either made or reported, never silently absent. Unparameterized
     * subclasses keep plain `string` and need nothing.
     */
    name: MethodName;
    pluginManager: PluginManager;
    constructor(pluginManager: PluginManager);
    serializeArguments(args: object): Promise<Record<string, unknown>>;
    protected renameRegions<T extends RenameRegionsArgs>(args: T): Promise<T>;
    /**
     * The root model to resolve internet accounts against, but only while it is
     * still attached to its tree. An RPC's promise can settle after the session it
     * belongs to is gone — jbrowse-web loading a new session, or a headless
     * renderer (jbrowse-img) destroying its model once the SVG is out — and
     * reading `internetAccounts` off a destroyed node logs an MST dead-node
     * warning for work whose result is already discarded. A torn-down root has no
     * accounts to consult, so it reads as "none" rather than as an error.
     */
    private get authRootModel();
    serializeNewAuthArguments(loc: UriLocation): Promise<UriLocation>;
    /**
     * What both drivers call: deserialize, then `execute`.
     *
     * Each `execute` used to open with the deserialize call itself, and eleven
     * methods across seven plugins had silently drifted off it. `RpcExecuteArgs`
     * describes the DESERIALIZED shape — an entry declares `filters?:
     * SerializableFilterChain` where the wire carries a `string[]` — so skipping
     * it made the declared type false rather than erroring. Here it is true by
     * construction.
     */
    invoke(serializedArgs: RpcExecuteArgs<MethodName>): Promise<RpcWireReturn<MethodName>>;
    /**
     * The far side of `serializeArguments`; {@link invoke} calls it. Override to
     * add to the step, not to call it — and **an override must tolerate running
     * twice on the same object**, since an external plugin written against the
     * older contract still calls it from its own `execute`.
     */
    deserializeArguments<T>(args: T): Promise<T>;
    /**
     * The args are {@link RpcExecuteArgs} rather than `unknown` so that a method
     * parameterized with its own name has BOTH ends checked against the registry.
     * The return has been checked for a while; the args were hand-written in each
     * of 45 subclasses, which is the asymmetry that let them drift — and the drift
     * is not cosmetic, because the two handles every method receives are the two
     * an author who did not write them down never forwards.
     *
     * `CoreGetExportData` is the worked example: the stop token and status
     * callback arrived on every call and its `execute` destructured neither, so
     * the Save-track-data dialog's cancel did nothing and its progress never moved
     * on the adapter-export branch. Nothing was mistyped — the fields simply were
     * not in a signature anyone read.
     */
    abstract execute(serializedArgs: RpcExecuteArgs<MethodName>): Promise<RpcWireReturn<MethodName>>;
    /**
     * The wire shape, rebuilt into what the caller of `rpcManager.call` holds —
     * the registry entry's `return`. Overridden by the three methods whose two
     * differ (features travel serialized and arrive as `SimpleFeature`s); for
     * everyone else the whole job is taking off the `rpcResult` envelope, which
     * MainThreadRpcDriver needs because nothing stripped it on that path.
     *
     * The registry `return` is checked against `execute` on the way in (through
     * {@link RpcWireReturn}) and this is what checks it on the way back out. It
     * checks covariantly, so unlike the arguments it cannot be widened past.
     *
     * An override calls {@link unwrapRpcResult} rather than `super`, because the
     * envelope is all it wants and `super` now promises the rebuilt value it is
     * the one rebuilding. The cast below is the claim that stands for every
     * method that does NOT override: unwrapped wire is the declared `return`.
     * True by construction for a `transferables: true` or bare entry, since both
     * derive their wire from that `return`; an explicit `wire:` restates, so it
     * is the one that has to override or agree.
     */
    deserializeReturn(serializedReturn: RpcWireReturn<MethodName>, _args: unknown): Promise<RpcCallReturn<MethodName>>;
    private augmentLocationObjects;
}
