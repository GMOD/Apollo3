import type { AbstractSessionModel, Feature, StatusCallback, StopToken } from '../../../util/index.ts';
export declare function formatFeatWithSubfeatures({ feature, minPos, geneName, }: {
    feature: Feature;
    minPos: number;
    geneName?: string;
}): string;
export declare function stringifyGBK({ features, assemblyName, session, stopToken, statusCallback, }: {
    assemblyName: string;
    session: AbstractSessionModel;
    features: Feature[];
    stopToken?: StopToken;
    statusCallback?: StatusCallback;
}): Promise<string>;
