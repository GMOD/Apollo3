import type { AnyConfigurationModel } from '../../../configuration/index.ts';
import type { Region } from '../../../util/index.ts';
import type { StatusCallback } from '../../../util/progress.ts';
import type { StopToken } from '../../../util/stopToken.ts';
import type { FileTypeExporter } from '../saveTrackFileTypes/types.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * What the export needs off the track, duck-typed rather than imported: this
 * module is behind `BaseTrackModel`'s lazy dialog import, so naming that model
 * type here would close the circle. `exportsDataViaAdapter` and
 * `exportByteLimit` are its getters.
 */
export interface ExportableTrack extends IStateTreeNode {
    configuration: AnyConfigurationModel;
    exportsDataViaAdapter: boolean;
    exportByteLimit: number;
    saveTrackFileFormatOptions: () => Record<string, FileTypeExporter>;
}
/**
 * The four fields a region fetch needs, with the fractional bounds a view hands
 * out widened to whole bases. Narrowed rather than spread whole: an LGV's
 * `visibleRegions` blocks also carry screen geometry and a `reversed` flag, and
 * `reversed` is what put a stray "[rev]" on the region the dialog says it is
 * exporting — the export itself is in reference order either way.
 */
export declare function roundRegions(regions: Region[]): Region[];
export interface TrackDataResult {
    str: string;
    usedAdapterExport: boolean;
    /**
     * Set, with an empty `str` and nothing downloaded, when the pre-flight
     * estimate came back over budget and the caller had not passed `force`.
     */
    tooLarge?: {
        bytes: number;
        limit: number;
    };
}
/**
 * The data behind the "Save track data" dialog, in the selected format.
 *
 * This reads every feature in the visible region, which on a deep track is the
 * same work the display itself does — worth cancelling when the dialog closes,
 * and worth naming while it runs, hence the stop token and status callback.
 */
export declare function fetchTrackData({ model, regions, type, options, force, stopToken, statusCallback, }: {
    model: ExportableTrack;
    regions: Region[];
    type: string;
    options: Record<string, FileTypeExporter>;
    /** skip the size pre-flight — the user has seen the estimate and said yes */
    force?: boolean;
    stopToken?: StopToken;
    statusCallback?: StatusCallback;
}): Promise<TrackDataResult>;
