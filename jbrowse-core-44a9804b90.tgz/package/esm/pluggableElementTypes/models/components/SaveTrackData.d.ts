import type { ExportableTrack } from './fetchTrackData.ts';
declare const SaveTrackDataDialog: ({ model, handleClose, }: {
    model: ExportableTrack;
    handleClose: () => void;
}) => import("react").JSX.Element;
export default SaveTrackDataDialog;
