import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { MenuItem } from '../../ui/index.ts';
import type { RpcStatus } from '../../util/progress.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type React from 'react';
export declare const BaseDisplay: import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, {
    error: unknown;
    statusMessage: string | undefined;
    /**
     * #volatile
     * determinate progress fraction [0,1] for the current status, or
     * undefined when the in-flight phase is indeterminate. Set alongside
     * `statusMessage` by `setStatusMessage`; a display that never shows a
     * bar simply leaves it undefined.
     */
    statusProgress: number | undefined;
} & {
    /**
     * #getter
     */
    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
} & {
    /**
     * #getter
     */
    readonly RenderingComponent: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        onHorizontalScroll?: (distance: number) => void;
        blockState?: Record<string, unknown>;
    }>;
    /**
     * #getter
     */
    readonly DisplayBlurb: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }> | null;
    /**
     * #getter
     */
    readonly adapterConfig: Record<string, unknown>;
    /**
     * #getter
     * Returns true if the parent track is minimized. Used to skip
     * expensive operations like autoruns when track is not visible.
     */
    readonly isMinimized: boolean;
    /**
     * #getter
     * Overridable hook (default `undefined`): what the pointer is currently
     * over, for readers **outside** the display. `LinearGenomeViewContainer`
     * publishes it to `session.hovered`, the view-wide "what is the user
     * pointing at" channel a plugin can subscribe to.
     *
     * Declared here because a cross-display consumer can only read a name the
     * base declares — the same reason `SyntenyFetchStateMixin.fetchInert` is a
     * hook rather than a getter each display invents. The container used to
     * read `featureUnderMouse`, which only the wiggle, alignments and
     * Manhattan families spelled that way — canvas said `hoveredFeature`,
     * variants `hoveredGenotype` — so the channel carried a hover from a third
     * of the display types and nothing said which. It also asked only
     * `displays[0]` of each track.
     *
     * `unknown` because the payload genuinely differs — a read, a wiggle bin,
     * a SNP, a genotype cell — and `session.hovered` is typed to match ("can
     * be anything; code that wants to deal with this should examine it").
     * Narrow it in the override.
     */
    readonly hoveredFeature: unknown;
    /**
     * #getter
     * Overridable hook (default `'feature'`): the SINGULAR word for one of
     * the things this display draws, as a menu row or a chip says it —
     * "Hide this read", "Showing 3 variants".
     *
     * Declared here for the same reason as `hoveredFeature` above: it is read
     * across the display boundary, by chrome that has no idea which display
     * it is drawing for (`SoloSelectionChip`, alignments' group-label
     * overlay), and a name only the base declares is a name every such
     * consumer can rely on. Two displays declared it independently and one of
     * those declarations WAS this default.
     *
     * **A control keeps the generic word; content takes this one.** "Variant
     * height" reads as a different setting from "Feature height" when it is
     * the same one, so the shared menus stay on "feature" however the display
     * answers here, and the noun varies where it names what the user is
     * looking at — "Showing 3 variants", "Hide this read". A display drawing
     * something the generic word already fits is right to leave this alone.
     *
     * Distinct from the per-hit noun a context menu takes off the clicked
     * item's own `type` ("mRNA", "gene"); that names one annotation, this
     * names what the track holds. The hit noun falls back to this.
     */
    readonly featureNoun: string;
    /**
     * #getter
     * Overridable hook: which widget `openFeatureWidget` opens for one of
     * this display's features. The default is the generic one, which is what
     * a display drawing plain features wants and what the canvas base spelled
     * out by hand.
     *
     * An override is a display whose features have a vocabulary of their own —
     * a read, a variant, a synteny block — and the `id` is deliberately part
     * of it: two displays naming one id share the drawer panel, which is the
     * behaviour when the two are showing the same kind of thing.
     */
    readonly featureWidgetType: {
        type: string;
        id: string;
    };
} & {
    /**
     * #method
     * props passed to the renderer's React "Rendering" component.
     * these are client-side only and never sent to the worker.
     * includes displayModel and callbacks
     */
    renderingProps(): {
        displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
        } & {
            /**
             * #getter
             */
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            /**
             * #getter
             */
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            /**
             * #getter
             */
            readonly adapterConfig: Record<string, unknown>;
            /**
             * #getter
             * Returns true if the parent track is minimized. Used to skip
             * expensive operations like autoruns when track is not visible.
             */
            readonly isMinimized: boolean;
            /**
             * #getter
             * Overridable hook (default `undefined`): what the pointer is currently
             * over, for readers **outside** the display. `LinearGenomeViewContainer`
             * publishes it to `session.hovered`, the view-wide "what is the user
             * pointing at" channel a plugin can subscribe to.
             *
             * Declared here because a cross-display consumer can only read a name the
             * base declares — the same reason `SyntenyFetchStateMixin.fetchInert` is a
             * hook rather than a getter each display invents. The container used to
             * read `featureUnderMouse`, which only the wiggle, alignments and
             * Manhattan families spelled that way — canvas said `hoveredFeature`,
             * variants `hoveredGenotype` — so the channel carried a hover from a third
             * of the display types and nothing said which. It also asked only
             * `displays[0]` of each track.
             *
             * `unknown` because the payload genuinely differs — a read, a wiggle bin,
             * a SNP, a genotype cell — and `session.hovered` is typed to match ("can
             * be anything; code that wants to deal with this should examine it").
             * Narrow it in the override.
             */
            readonly hoveredFeature: unknown;
            /**
             * #getter
             * Overridable hook (default `'feature'`): the SINGULAR word for one of
             * the things this display draws, as a menu row or a chip says it —
             * "Hide this read", "Showing 3 variants".
             *
             * Declared here for the same reason as `hoveredFeature` above: it is read
             * across the display boundary, by chrome that has no idea which display
             * it is drawing for (`SoloSelectionChip`, alignments' group-label
             * overlay), and a name only the base declares is a name every such
             * consumer can rely on. Two displays declared it independently and one of
             * those declarations WAS this default.
             *
             * **A control keeps the generic word; content takes this one.** "Variant
             * height" reads as a different setting from "Feature height" when it is
             * the same one, so the shared menus stay on "feature" however the display
             * answers here, and the noun varies where it names what the user is
             * looking at — "Showing 3 variants", "Hide this read". A display drawing
             * something the generic word already fits is right to leave this alone.
             *
             * Distinct from the per-hit noun a context menu takes off the clicked
             * item's own `type` ("mRNA", "gene"); that names one annotation, this
             * names what the track holds. The hit noun falls back to this.
             */
            readonly featureNoun: string;
            /**
             * #getter
             * Overridable hook: which widget `openFeatureWidget` opens for one of
             * this display's features. The default is the generic one, which is what
             * a display drawing plain features wants and what the canvas base spelled
             * out by hand.
             *
             * An override is a display whose features have a vocabulary of their own —
             * a read, a variant, a synteny block — and the `id` is deliberately part
             * of it: two displays naming one id share the drawer panel, which is the
             * behaviour when the two are showing the same kind of thing.
             */
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
        } & {
            /**
             * #getter
             */
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            /**
             * #getter
             */
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            /**
             * #getter
             */
            readonly adapterConfig: Record<string, unknown>;
            /**
             * #getter
             * Returns true if the parent track is minimized. Used to skip
             * expensive operations like autoruns when track is not visible.
             */
            readonly isMinimized: boolean;
            /**
             * #getter
             * Overridable hook (default `undefined`): what the pointer is currently
             * over, for readers **outside** the display. `LinearGenomeViewContainer`
             * publishes it to `session.hovered`, the view-wide "what is the user
             * pointing at" channel a plugin can subscribe to.
             *
             * Declared here because a cross-display consumer can only read a name the
             * base declares — the same reason `SyntenyFetchStateMixin.fetchInert` is a
             * hook rather than a getter each display invents. The container used to
             * read `featureUnderMouse`, which only the wiggle, alignments and
             * Manhattan families spelled that way — canvas said `hoveredFeature`,
             * variants `hoveredGenotype` — so the channel carried a hover from a third
             * of the display types and nothing said which. It also asked only
             * `displays[0]` of each track.
             *
             * `unknown` because the payload genuinely differs — a read, a wiggle bin,
             * a SNP, a genotype cell — and `session.hovered` is typed to match ("can
             * be anything; code that wants to deal with this should examine it").
             * Narrow it in the override.
             */
            readonly hoveredFeature: unknown;
            /**
             * #getter
             * Overridable hook (default `'feature'`): the SINGULAR word for one of
             * the things this display draws, as a menu row or a chip says it —
             * "Hide this read", "Showing 3 variants".
             *
             * Declared here for the same reason as `hoveredFeature` above: it is read
             * across the display boundary, by chrome that has no idea which display
             * it is drawing for (`SoloSelectionChip`, alignments' group-label
             * overlay), and a name only the base declares is a name every such
             * consumer can rely on. Two displays declared it independently and one of
             * those declarations WAS this default.
             *
             * **A control keeps the generic word; content takes this one.** "Variant
             * height" reads as a different setting from "Feature height" when it is
             * the same one, so the shared menus stay on "feature" however the display
             * answers here, and the noun varies where it names what the user is
             * looking at — "Showing 3 variants", "Hide this read". A display drawing
             * something the generic word already fits is right to leave this alone.
             *
             * Distinct from the per-hit noun a context menu takes off the clicked
             * item's own `type` ("mRNA", "gene"); that names one annotation, this
             * names what the track holds. The hit noun falls back to this.
             */
            readonly featureNoun: string;
            /**
             * #getter
             * Overridable hook: which widget `openFeatureWidget` opens for one of
             * this display's features. The default is the generic one, which is what
             * a display drawing plain features wants and what the canvas base spelled
             * out by hand.
             *
             * An override is a display whose features have a vocabulary of their own —
             * a read, a variant, a synteny block — and the `id` is deliberately part
             * of it: two displays naming one id share the drawer panel, which is the
             * behaviour when the two are showing the same kind of thing.
             */
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    /**
     * #method
     */
    trackMenuItems(): MenuItem[];
} & {
    /**
     * #action
     */
    setStatusMessage(status?: RpcStatus): void;
    /**
     * #action
     */
    setError(error?: unknown): void;
    /**
     * #action
     * Overridable hook (default no-op): drop whatever `hoveredFeature`
     * reports. The writing twin of that getter, and what
     * `installClearHoverOnViewportChange` calls.
     *
     * A display that STORES its hover owes an override; one that derives it
     * from the live pointer (MAF, Hi-C, LD) owes nothing, and the default
     * costs it nothing. Declared here so the clear can be installed for every
     * display rather than remembered per display — forgetting it is the
     * failure ARCHITECTURE.md's stored-hover section is about, and it used to
     * be six closures at six call sites, which is six chances to omit one.
     */
    clearHoveredFeature(): void;
    /**
     * #action
     * base display reload does nothing, see specialized displays for details
     */
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseDisplayStateModel = typeof BaseDisplay;
export type BaseDisplayModel = Instance<BaseDisplayStateModel>;
/**
 * The shape every display instance held in a track's `displays` array
 * satisfies: the composed `BaseDisplay` state model (RenderingComponent,
 * DisplayBlurb, trackMenuItems, ...) plus the `configuration`
 * reference every display gains at instantiation. `getPortableSettings` is
 * optional — only display types that support switching type via the track menu
 * implement it. This is the concrete element type behind
 * `BaseTrackModel.displays`, which the runtime plugin union erases to `any`.
 */
export interface DisplayModel extends BaseDisplayModel {
    configuration: AnyConfigurationModel & {
        displayId: string;
    };
    getPortableSettings?: (newDisplayId?: string) => Record<string, unknown> | undefined;
}
