/**
 * #config BaseInternetAccount
 * the "base" internet account type
 */
export declare const BaseInternetAccountConfig: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     */
    readonly name: {
        readonly description: "descriptive name of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly description: {
        readonly description: "a description of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly authHeader: {
        readonly description: "request header for credentials";
        readonly type: "string";
        readonly defaultValue: "Authorization";
    };
    /**
     * #slot
     */
    readonly tokenType: {
        readonly description: "a custom name for a token to include in the header";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly domains: {
        readonly description: "array of valid domains the url can contain to use this account";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>;
