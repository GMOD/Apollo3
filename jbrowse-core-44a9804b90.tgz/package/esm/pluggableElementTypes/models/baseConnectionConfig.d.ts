import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #config BaseConnection
 * #gotcha A connection config is only a pointer: the hub's track list is
 * fetched when the connection loads and held in memory, and is **not** written
 * into a saved or shared session. Only a track you actually open is stored
 * (under `connectionTrackConfigs`, keyed by `trackId`), which is what keeps a
 * shared session small even against a very large hub.
 */
declare const BaseConnectionConfig: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     */
    readonly name: {
        readonly type: "string";
        readonly defaultValue: "nameOfConnection";
        readonly description: "a unique name for this connection";
    };
    /**
     * #slot
     */
    readonly assemblyNames: {
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
        readonly description: "optional list of names of assemblies in this connection";
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "connectionId">>;
export default BaseConnectionConfig;
export type BaseConnectionConfigSchema = typeof BaseConnectionConfig;
export type BaseConnectionConfigModel = Instance<BaseConnectionConfigSchema>;
