import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyReactComponentType } from '../util/index.ts';
import type { IAnyModelType } from '@jbrowse/mobx-state-tree';
export default class DisplayType extends PluggableElementBase {
    stateModel: IAnyModelType;
    configSchema: AnyConfigurationSchemaType;
    ReactComponent: AnyReactComponentType;
    /**
     * The track type the display is associated with
     */
    trackType: string;
    subDisplay?: {
        type: string;
        [key: string]: unknown;
    };
    /**
     * The view type the display is associated with
     */
    viewType: string;
    /**
     * Help text describing the display type
     */
    helpText?: string;
    /**
     * Older display type names that should be remapped to this one when loading
     * sessions/configs. Each entry is the legacy `type` value previously used.
     * Per-display `preProcessSnapshot` hooks then handle any property migrations
     * within the renamed type. For migrations that rewrite the value of an
     * existing constrained slot (enum rename, type narrow), use
     * `addDisplayConfigMigration` instead — see that helper for why.
     */
    aliases?: string[];
    constructor(stuff: {
        name: string;
        stateModel: IAnyModelType;
        trackType: string;
        viewType: string;
        displayName?: string;
        subDisplay?: {
            type: string;
            [key: string]: unknown;
        };
        configSchema: AnyConfigurationSchemaType;
        ReactComponent: AnyReactComponentType;
        helpText?: string;
        aliases?: string[];
    });
}
