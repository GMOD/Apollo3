import type PluginManager from '../PluginManager.ts';
/**
 * Fill in an assembly `sequence.adapter`'s `type` from its `uri` when the type
 * is omitted, so `sequence: { adapter: { uri: 'genome.fa.gz' } }` resolves to a
 * `BgzipFastaAdapter` (and `.fa` → indexed, `.2bit` → `TwoBitAdapter`). Uses the
 * same `Core-guessAdapterForLocation` extension point the "Add track" flow uses,
 * so every host describes a custom genome with just a URL and lets jbrowse-core
 * pick the adapter — no adapter-type table in the Python/R/JS bindings.
 *
 * The guesser also derives the index locations (`.fai`/`.gzi`) from the uri;
 * explicit adapter fields (e.g. a non-sibling `faiLocation`) are spread on top
 * so they win. A `uri` matching no sequence adapter is left untouched, so a
 * genuinely bad config still surfaces its own downstream error. Returns the same
 * object reference when there is nothing to expand, so callers can cheaply skip
 * a rebuild.
 */
/**
 * Expand an assembly snapshot's own shorthands into the `sequence` an assembly
 * config declares: the flat `{ name, uri: 'genome.fa.gz' }` form, the
 * `sequence: { adapter: { uri } }` form, and the omitted
 * `sequence.type`/`trackId`.
 *
 * This is the assembly config schema's `preProcessSnapshot`, lifted out so a
 * caller that has to see canonical locations *before* MST builds the tree can
 * run it too. `localFiles` is that caller: it rewrites `{ uri: <a registered
 * name> }` location nodes into blobs, and until this has run the only `uri` in
 * a shorthand assembly is on the assembly itself, where it is not a location
 * node and must not be rewritten as one. Idempotent — the flat `uri` is
 * consumed, so the schema's own later pass finds nothing to do.
 */
export declare function expandAssemblyShorthand<T>(snap: T, pluginManager: PluginManager): T;
export declare function expandAssemblySequenceAdapter(sequence: unknown, pluginManager: PluginManager): unknown;
