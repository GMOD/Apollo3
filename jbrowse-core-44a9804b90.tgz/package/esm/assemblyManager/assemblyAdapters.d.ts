import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
interface AdapterArgs {
    config: AnyConfigurationModel;
    pluginManager: PluginManager;
    opts?: BaseOptions;
}
export declare function getRefNameAliases({ config, pluginManager, opts, }: AdapterArgs): Promise<import("../data_adapters/BaseAdapter/BaseRefNameAliasAdapter.ts").Alias[]>;
export declare function getCytobands({ config, pluginManager, opts, }: AdapterArgs): Promise<import("../util/simpleFeature.ts").Feature[]>;
export declare function getAssemblyRegions({ config, pluginManager, opts, }: AdapterArgs): Promise<import("../util/index.ts").NoAssemblyRegion[]>;
export {};
