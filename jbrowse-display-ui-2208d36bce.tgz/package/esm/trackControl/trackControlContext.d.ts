import type { TrackControlComponent } from './types.ts';
export declare const TrackControlProvider: import("react").Provider<TrackControlComponent | undefined>;
/**
 * The component a provider installed, or `undefined` for "nobody asked". The
 * caller supplies the default, which is what keeps this module free of one.
 */
export declare function useTrackControlOverride(): TrackControlComponent | undefined;
