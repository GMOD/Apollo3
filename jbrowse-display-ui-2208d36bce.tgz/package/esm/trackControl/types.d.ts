import type { ComponentType } from 'react';
/**
 * Icons are *named* rather than passed in as elements, which is the whole
 * mechanism: an element would have to come from somewhere, and every call site
 * would end up importing `@mui/icons-material` whatever the renderer was. A name
 * lets each implementation draw it its own way.
 *
 * A closed set on purpose — a display wanting a new one adds it here and to both
 * implementations, which is the moment to check the plain set still has an
 * answer.
 */
export type TrackControlIcon = 'height' | 'isoform' | 'filter';
/** One row of the control's menu. Rendered as a radio group. */
export interface TrackControlOption {
    label: string;
    selected: boolean;
    onSelect: () => void;
}
export interface TrackControlProps {
    icon: TrackControlIcon;
    /**
     * Always required: it is the only place the control explains itself, and
     * these controls are deliberately small and wordless.
     */
    tooltip: string;
    /**
     * Present: a text chip, for a state the user should notice without looking
     * (the isoform notice, the show-only count). Absent: a quiet icon button, for
     * a control that is always there and should not shout.
     */
    label?: string;
    /**
     * Pressing opens these as a radio list. Mutually exclusive with `onClick`.
     * A labelled control with options draws a ▾ after its label — the one thing
     * telling a chip that opens a menu from one that acts (`onClick`), since the
     * two are otherwise drawn alike.
     */
    options?: TrackControlOption[];
    /** Pressing does this. Mutually exclusive with `options`. */
    onClick?: () => void;
    /**
     * The `options` menu closed, by any route — a pick, Escape, a press outside.
     * A notice that wants opening the menu to count as having been read hangs
     * its acknowledgement here rather than on a (×) of its own. On close and not
     * on open: a chip that shrinks while its menu is still up takes the menu's
     * anchor with it.
     */
    onMenuClose?: () => void;
    /** Adds a (×). What it means is the caller's business — dismiss, clear, undo. */
    onDelete?: () => void;
    /**
     * Something is wrong and a tooltip nobody opens is not a disclosure — today
     * this is features the layout dropped outright. Renders in an alert tone
     * rather than the quiet default.
     */
    warning?: boolean;
}
export type TrackControlComponent = ComponentType<TrackControlProps>;
