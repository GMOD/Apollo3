import type { TooltipPlacement } from '@jbrowse/core/ui/BaseTooltip';
import type { ReactNode, Ref } from 'react';
export interface TooltipTrigger {
    /** Whether the bubble is up, for a caller that wants to style the trigger. */
    open: boolean;
    /**
     * Spread onto the control the tooltip describes. `aria-describedby`, not
     * `aria-label`: the tooltip is a visual affordance, and a name pointing at a
     * node that exists only during a hover leaves the control unnamed the rest of
     * the time. **The control still needs its own accessible name.**
     */
    triggerProps: {
        ref: Ref<HTMLElement>;
        'aria-describedby': string | undefined;
        onPointerEnter: (event: React.PointerEvent<HTMLElement>) => void;
        onPointerLeave: () => void;
        onPointerDown: () => void;
        onFocus: () => void;
        onBlur: () => void;
    };
    /** Render this. It is `null` until the bubble is up, and portals itself. */
    tooltip: ReactNode;
}
/**
 * #api
 * A hover/focus label for one control, as props to spread — the headless half
 * of {@link Tooltip}, for a host writing its own chrome rather than restyling
 * ours. Same relationship `useTrackControlMenu` has to `plainTrackControl`.
 *
 * ```tsx
 * const { triggerProps, tooltip } = useTooltip('Hide legend')
 * return (
 *   <>
 *     <button {...triggerProps} aria-label="Hide legend" onClick={onDismiss}>
 *       ×
 *     </button>
 *     {tooltip}
 *   </>
 * )
 * ```
 *
 * `triggerProps` carries no `onClick`, so a control's own handler does not
 * collide with it. Any other handler on this list has to compose rather than
 * replace — spread first, then call `triggerProps.onFocus` from yours.
 */
export declare function useTooltip(
/** What the bubble says. It stays down while this is empty. */
title: ReactNode, { placement }?: {
    placement?: TooltipPlacement;
}): TooltipTrigger;
