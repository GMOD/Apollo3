/**
 * #api
 * Which axis tripped (empty when the display gates without a reason), then the
 * way out.
 *
 * `zoomCanRelease` decides whether "zoom in" is offered, and it has to be asked
 * because the advice is not always true. It was, once: the `AUTO_FORCE_LOAD_BP`
 * floor turned the byte gate off below 20kb, so zooming far enough always
 * worked. The byte gate no longer stops at any floor, and an index quotes whole
 * blocks — so for a file whose blocks are large the same bytes come down however
 * far the user goes, and telling them to keep zooming into a fetch whose cost
 * cannot fall is the one thing the banner must not do. `zoomCanReleaseGate`
 * answers it from two consecutive measurements rather than from a threshold; see
 * `ByteEstimate.zoomIneffective`.
 */
export declare function tooLargeBannerText(regionTooLargeReason: string, { zoomCanRelease }?: {
    zoomCanRelease?: boolean;
}): string;
