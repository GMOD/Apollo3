import type { DisplayChromeOverlays } from './chromeOverlays.ts';
export declare const DisplayChromeOverlayProvider: import("react").Provider<DisplayChromeOverlays | undefined>;
/**
 * The set a provider installed, or `undefined` for "nobody asked". The caller
 * supplies the default, which is what keeps this module free of one.
 */
export declare function useChromeOverlayOverride(): DisplayChromeOverlays | undefined;
