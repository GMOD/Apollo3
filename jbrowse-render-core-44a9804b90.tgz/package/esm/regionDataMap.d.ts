import type { ObservableMap } from 'mobx';
export declare function isCheckedAtTheStore(map: ReadonlyMap<unknown, unknown>): boolean;
/**
 * The volatile a display keys its per-region payloads by
 * (`displayedRegionIndex` → result). Every one of them in tree is built with
 * this, so "how is per-region data represented" has one answer — see
 * ADR-060.
 *
 * **Shallow, and that follows from an invariant the codebase already states**:
 * per-region values are freshly constructed and never mutated (agent-docs
 * CLAUDE.md; backends diff by reference identity). Nothing inside an entry can
 * therefore change, so the deep enhancer's field-level atoms can never fire —
 * they are unreachable reactivity, not a safety margin. What they do cost is
 * paid on every insert and every read:
 *
 * - **Insert.** `deepEnhancer` recursively rebuilds each payload as an
 *   observable object graph — the stored value is not the object the worker
 *   produced. A multi-wiggle region is one atom per field per source, so a
 *   thousand-sample track pays ~18k on every pan; MAF pays the whole set again
 *   for every cached region on every row reorder, since `placeFetchedRows`
 *   re-places them all.
 * - **Read.** Each field access goes through `getObservablePropValue_`. Hot
 *   loops that hoist their typed arrays are fine, but the ones that don't were
 *   paying it per iteration.
 *
 * Typed arrays and class instances (Flatbush) pass through the deep enhancer
 * untouched, so the arrays were never the cost — the objects holding them were.
 *
 * Coarser tracking is the only behavioral difference, and it is unobservable
 * here: an entry is only ever replaced whole, so the keys atom and the entry's
 * own atom fire on exactly the same `.set`/`.delete`/`.clear`.
 *
 * Not for maps of primitives (`groupMaxHeightOverrides`,
 * `detectedModifications`), where the enhancer is a no-op, nor for UI state
 * whose values are mutated in place.
 *
 * **Dev-only, every entry is checked on the way in.** A fetch RPC answers a
 * payload or a `regionTooLarge` refusal, and every reader of this map is
 * written for the payload — so a value that is not one is a fetch that did not
 * happen, stored as though it had. There is no type to catch it: `onResult`
 * receives whatever the RPC resolved, typed as the payload it was supposed to
 * be, and the mock in the display harness resolved `undefined` for every
 * un-stubbed method for as long as the harness existed. Six reactions across
 * four packages then threw `Cannot read properties of undefined` on every run,
 * inside autoruns MobX catches and logs — invisible until the reaction gate
 * went in.
 *
 * Checked HERE because this is the one constructor all of them share, so the
 * store is one place while the readers are hundreds, and because a payload
 * caught at the `set` names the region and the display instead of surfacing as
 * a TypeError in whichever getter happened to read it first.
 *
 * **`T extends object` is the same statement as the check, in the one place a
 * type can make it.** The runtime predicate is "a non-null object", and
 * `object` is that predicate spelled as a constraint — so a map cannot be
 * *declared* as holding something the check would then report, which is the
 * only way the two could come apart. It costs nothing: every payload in tree is
 * an interface, an array, an intersection or a class.
 */
export declare function regionDataMap<T extends object>(name: string): ObservableMap<number, T>;
