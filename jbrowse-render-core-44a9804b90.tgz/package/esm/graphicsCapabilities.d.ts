export interface GraphicsCapabilities {
    webgpu: boolean;
    /**
     * `undefined` when the WebGL2 probe was skipped, which is what
     * `getGraphicsCapabilities` does whenever WebGPU answered first — see there.
     */
    webgl2?: boolean;
    gpuVendor?: string;
    gpuArchitecture?: string;
    /**
     * `UNMASKED_RENDERER_WEBGL` from the WebGL2 probe — the real driver string
     * ("SwiftShader Device", "Mesa Intel(R) UHD Graphics 630"), not the masked
     * one, which is a fixed placeholder. Present only when the probe ran (no
     * WebGPU) and the browser exposes `WEBGL_debug_renderer_info`; Firefox with
     * `privacy.resistFingerprinting` does not. It identifies hardware far more
     * precisely than `gpuVendor`/`gpuArchitecture` do, so like them it stays
     * local — the stack-trace dialog the user chooses to copy — and never goes to
     * analytics. `softwareWebgl` is the coarse bit that does.
     */
    glRenderer?: string;
    /**
     * Whether that driver string names a software rasterizer. `undefined` means
     * unknown (no probe, or no extension), which is deliberately not `false`: the
     * distinction is the whole value of the field.
     */
    softwareWebgl?: boolean;
}
/**
 * The rungs of the rendering ladder, as the names a person reads — the About
 * widget's "Graphics:" line, the stack-trace dialog, the analytics field.
 *
 * Deliberately *not* the {@link GpuOverride} vocabulary, which is what a user
 * types into `?renderer=` and therefore carries lowercase spellings and the
 * `webgl`/`canvas` aliases. One is an input to parse, the other an answer to
 * display, and collapsing them would mean either showing "canvas2d" in the UI
 * or accepting "Canvas2D" in a URL.
 */
export type RendererName = 'WebGPU' | 'WebGL2' | 'Canvas2D';
/**
 * Whether a `UNMASKED_RENDERER_WEBGL` string names a software rasterizer, where
 * WebGL costs ~25x Canvas2D on the main thread for the same session (measured;
 * on real hardware the ordering reverses at ~2x). Exported for its test — the
 * marker list is the part that can be wrong.
 */
export declare function isSoftwareRenderer(glRenderer: string): boolean;
/**
 * What this machine can do, memoized for the page: capabilities cannot change
 * within a session, and every call that probed again was another WebGL2 context
 * (each reopening of the About widget or the stack-trace dialog made one).
 *
 * **The WebGL2 probe is skipped when WebGPU is available**, leaving `webgl2`
 * undefined, because it is the rung below and nothing reads it:
 * {@link effectiveRenderer} returns WebGPU regardless. So a WebGPU machine
 * creates no WebGL2 context at all.
 *
 * Nothing needs the skipped rung resolved, and a "probe everything" variant was
 * deleted for it: {@link effectiveRenderer} already encodes the whole capability
 * vector, since `Canvas2D` means neither rung exists and `WebGL2` means WebGPU
 * is missing. The only bit a full probe adds is whether a WebGPU machine *also*
 * has WebGL2 — which no shipping browser answers no to, and which nothing would
 * do anything with. Report the effective renderer instead of a list.
 *
 * This is capabilities alone. What will actually draw is
 * {@link effectiveRenderer}, which is this plus the page-wide pin.
 */
export declare function getGraphicsCapabilities(): Promise<GraphicsCapabilities>;
/**
 * Which rung will actually draw — the ladder in `createGpuHal`, read as an
 * answer rather than run. This is the question every consumer asks (the About
 * widget's "Graphics:" line, the stack-trace dialog's environment block, the
 * analytics field), and answering it needs both halves: what the machine can do
 * *and* the page-wide pin from `?renderer=` or the GPU-error banner's "disable
 * GPU" button.
 *
 * The pin is checked first and wins outright, because **a pin never falls
 * through to the next rung** — `createGpuHal` throws instead, on the reasoning
 * that a pinned renderer which silently substitutes another makes any
 * comparison against it wrong. So the pinned rung *is* the answer, and a pin
 * that cannot be honored surfaces as a `renderError` rather than as a different
 * string here. That is what makes this exact rather than a guess: the one case
 * it cannot resolve from capabilities alone (`?renderer=webgl` on a WebGPU
 * machine, where the WebGL2 probe was skipped) is also the case where the pin
 * decides on its own.
 *
 * **`softwareWebgl` skips the WebGL2 rung here because it skips it there**, and
 * only where the ladder skips it — unpinned. Leaving it out is not a rounding
 * error on a rare machine: the VM, the locked-down laptop and the remote desktop
 * are exactly the population the rung-skip exists for, so the one group that
 * newly falls back was the one group still reported as WebGL2, in the About box,
 * in the stack traces users paste into bug reports, and in the analytics field
 * whose stated purpose is counting that fallback.
 *
 * Keeping this beside `gpuDevice` is the point of the module living in
 * render-core: it was previously in `@jbrowse/core`, which cannot see the
 * override, so every consumer reported the capability answer and a user who had
 * clicked "Use Canvas2D" was still reported as WebGL2.
 */
export declare function effectiveRenderer(c: GraphicsCapabilities): RendererName;
