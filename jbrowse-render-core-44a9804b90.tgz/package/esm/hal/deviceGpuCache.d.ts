import type { PipelineDescriptor, SampleCount } from './types.ts';
/**
 * The two pipeline layouts every pass is built against. Both are created
 * eagerly now — the textured pair used to be lazy so that a display drawing no
 * textured pass paid nothing, which was worth two objects per *display* and is
 * not worth the null-bundling for two objects per *device*.
 */
export interface DeviceLayouts {
    uniformOnlyBindGroupLayout: GPUBindGroupLayout;
    uniformOnlyPipelineLayout: GPUPipelineLayout;
    texturedBindGroupLayout: GPUBindGroupLayout;
    texturedPipelineLayout: GPUPipelineLayout;
}
/**
 * The bind group and pipeline layouts for `device`, built once per device.
 *
 * A device that is lost drops out of the map with itself — `gpuDevice.ts`
 * releases its reference in the `.lost` handler and the next acquisition is a
 * new object, so the layouts and pipelines built against the dead one are
 * unreachable and there is no cache to invalidate by hand.
 */
export declare function getDeviceLayouts(device: GPUDevice): DeviceLayouts;
/**
 * The pipeline for `desc` at `sampleCount` on `device`, building it through
 * `build` on the first ask and handing every later one the same promise.
 *
 * `build` receives the sample count rather than closing over one, so the key
 * and the pipeline stored under it cannot disagree.
 */
export declare function getOrBuildPipeline(device: GPUDevice, desc: PipelineDescriptor, sampleCount: SampleCount, build: (layouts: DeviceLayouts, sampleCount: SampleCount) => Promise<GPURenderPipeline>): Promise<GPURenderPipeline>;
/**
 * Drop every device's entry. Tests only — nothing in the app invalidates this
 * cache, because losing the device is what invalidates it (see
 * {@link getDeviceLayouts}).
 */
export declare function resetDeviceGpuCacheForTests(device: GPUDevice): void;
