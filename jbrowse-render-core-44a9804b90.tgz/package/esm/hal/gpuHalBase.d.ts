import { OomReporter } from './oomReporter.ts';
import { RegionRegistry } from './regionRegistry.ts';
import type { PipelineDescriptor, TextureBinding } from './types.ts';
/**
 * The device ceilings the shared upload shells refuse past. WebGPU asks the
 * device, WebGL2 has no such parameter for buffers and carries its own constant
 * (see `MAX_VERTEX_BUFFER_BYTES`), and `MockHal` has none at all.
 */
export interface HalLimits {
    maxBufferBytes: number;
    maxTextureDimensionPx: number;
}
/**
 * The half of a HAL that is not per-backend: the descriptor map, the
 * `(region, pass)` buffer registry and the upload/delete semantics over it, the
 * over-limit refusals and their wording, and the once-only `dispose` guard.
 *
 * `packages/render-core/CLAUDE.md` states HAL parity as a rule ("a behavior
 * change to one HAL lands in the other and in `MockHal`"); this class is the
 * structural half of it. What stays in the leaves is what genuinely differs —
 * the frame bracket, uniform ring vs UBO, scissor Y-flip, MSAA, lazy vs eager
 * pipeline build, and WebGPU's deferred destroy, which the `destroyBuffer` hook
 * keeps WebGPU's alone.
 *
 * A backend's `Buf` carries its own leaf handle plus the instance `count` every
 * caller reads through `getBufferCount`.
 */
export declare abstract class GpuHalBase<Buf extends {
    count: number;
}> {
    protected descriptors: Map<string, PipelineDescriptor>;
    protected regions: RegionRegistry<Buf>;
    protected oom: OomReporter;
    protected disposed: boolean;
    constructor(descriptors: PipelineDescriptor[], halName: string);
    protected abstract limits(): HalLimits;
    protected abstract createBuffer(data: ArrayBuffer | ArrayBufferView, count: number): Buf;
    protected abstract destroyBuffer(buf: Buf): void;
    /**
     * Replace the texture bound to `passId`, releasing whatever was there. Only
     * reached for a pass that declares a binding, and only within
     * `maxTextureDimensionPx`.
     */
    protected abstract createTexture(passId: string, binding: TextureBinding, data: Uint8Array, width: number, height: number): void;
    /** Release this HAL's own GPU objects. Runs exactly once, from `dispose`. */
    protected abstract releaseResources(): void;
    setErrorHandler(handler: (error: Error) => void): void;
    uploadBuffer(regionKey: number, passId: string, data: ArrayBuffer | ArrayBufferView, count: number): void;
    getBufferCount(regionKey: number, passId: string): number;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    pruneRegions(active: Iterable<number>): void;
    uploadTexture(passId: string, data: Uint8Array, width: number, height: number): void;
    dispose(): void;
}
