import { GpuHalBase } from './gpuHalBase.ts';
import type { GpuHal, PipelineDescriptor, TextureBinding } from './types.ts';
interface RegionPassBuffer {
    vbo: WebGLBuffer;
    count: number;
}
export declare class WebGL2Hal extends GpuHalBase<RegionPassBuffer> implements GpuHal {
    private gl;
    private canvas;
    private passes;
    private ubo;
    private maxTextureDim;
    private debug;
    private instanceId;
    private firstDrawSeen;
    private contextWasLost;
    private contextLostListener;
    private contextRestoredListener;
    private checkGlError;
    constructor(canvas: HTMLCanvasElement, descriptors: PipelineDescriptor[], uniformByteSize: number);
    protected limits(): {
        maxBufferBytes: number;
        maxTextureDimensionPx: number;
    };
    protected createBuffer(data: ArrayBuffer | ArrayBufferView, count: number): {
        vbo: WebGLBuffer;
        count: number;
    };
    protected destroyBuffer(buf: RegionPassBuffer): void;
    private compilePass;
    private getPass;
    resize(width: number, height: number): import("./types.ts").CanvasScale;
    protected createTexture(passId: string, binding: TextureBinding, data: Uint8Array, width: number, height: number): void;
    writeUniforms(data: ArrayBuffer): void;
    beginFrame(clearR: number, clearG: number, clearB: number, clearA?: number): void;
    setScissor(x: number, y: number, w: number, h: number): void;
    clearScissor(): void;
    setViewport(x: number, y: number, w: number, h: number): void;
    clearViewport(): void;
    drawPass(passId: string, regionKey: number, bufferPassId?: string): void;
    endFrame(): void;
    protected releaseResources(): void;
    private applyBlendState;
    private bindTextures;
    private bindAttributes;
}
export {};
