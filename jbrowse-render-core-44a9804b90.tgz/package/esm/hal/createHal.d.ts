import type { GpuHal, PipelineDescriptor, SampleCount } from './types.ts';
export interface GpuHalOptions {
    passes: PipelineDescriptor[];
    uniformByteSize: number;
    /**
     * Reaches the WebGPU rung only. The WebGL2 rung draws to the default
     * framebuffer with `antialias: true`, so its multisampling is the browser's
     * own and there is nothing here to thread into it.
     */
    sampleCount: SampleCount;
    /**
     * Out-parameter collecting why each rung declined, in ladder order. Falling
     * through a rung is normal (no WebGPU on this machine) and stays a
     * `console.warn` — but when the *last* rung fails too, the reasons the earlier
     * ones gave are the diagnosis, and they used to exist only in a console the
     * user reporting the bug never opens. `createRenderingBackend` attaches this
     * to the error it throws, and the error UI's stack-trace dialog already walks
     * `AggregateError.errors` (core's `formatErrorStack`), so they arrive with it.
     */
    failures?: unknown[];
}
export declare function createGpuHal(canvas: HTMLCanvasElement, { passes, uniformByteSize, sampleCount, failures }: GpuHalOptions): Promise<GpuHal | null>;
