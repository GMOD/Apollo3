import type { CanvasScale } from './canvas2dUtils.ts';
import type { BpRegionBounds } from './renderBlock.ts';
export declare function splitPositionWithFrac(value: number): [number, number];
export interface BlockClipResult {
    scissorX: number;
    scissorW: number;
    pxX: number;
    pxW: number;
    pxH: number;
    /**
     * The vertical scale the backing store ACTUALLY got — `hal.resize`'s answer,
     * not `getDpr()`. Carried through so a renderer scissoring bands out of one
     * canvas (`devicePxBand`) has the ratio the clip was built with rather than
     * reconstructing it as `pxH / canvasHeight`, which is a division by a height
     * that can be 0.
     */
    scaleY: number;
    bpStartHi: number;
    bpStartLo: number;
    bpEndHi: number;
    bpEndLo: number;
    clippedLengthBp: number;
    bpPerPx: number;
}
export declare function bpRangeXTuple(clip: BlockClipResult, reversed: boolean): [number, number, number];
export declare function writeBpRangeUniforms(uniformF32: Float32Array, offsetF32: number, clip: BlockClipResult, reversed: boolean): void;
export declare function clipBlock(block: BpRegionBounds, canvasWidth: number, canvasHeight: number, scale: CanvasScale): BlockClipResult | null;
