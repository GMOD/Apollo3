export declare function crispSquareTopLeftPx(centerPx: number, diameterPx: number): number;
