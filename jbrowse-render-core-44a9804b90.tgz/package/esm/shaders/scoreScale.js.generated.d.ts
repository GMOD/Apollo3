export declare function normalizeScore(score: number, domainMin: number, domainMax: number, scaleType: number, symlogConstant: number): number;
