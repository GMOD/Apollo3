export declare const SMALL_POINT_MAX_DIAMETER = 3;
export declare const AA_PAD_PX = 1;
