export declare const TRIANGLE_HW = 3.5;
export declare const TRIANGLE_H = 4.5;
