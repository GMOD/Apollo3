export declare function drawnRowHeightPx(rowHeight: number, rowProportion: number): number;
export declare function rowBandOffsetPx(rowHeight: number, rowProportion: number): number;
