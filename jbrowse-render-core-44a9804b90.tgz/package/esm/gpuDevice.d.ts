interface GpuDeviceCell {
    device: GPUDevice | null;
    /** Serializes concurrent calls during async init and after recovery. */
    devicePromise: Promise<GPUDevice | null> | null;
    /**
     * Proof that this machine's WebGPU works, set the first time a device is
     * acquired. It is what makes a failed acquisition readable, because the two
     * causes are indistinguishable at the call site and want opposite handling:
     *
     *  - Before it, failure means "no WebGPU here" — the ordinary path on most
     *    hardware. Cache it, so every later backend skips the rung for free.
     *  - After it, failure means the GPU stack has not come back up yet. The
     *    re-init that follows `device.lost` asks for an adapter within a frame of
     *    the loss, and on a sleep/wake or a driver reset that is exactly when
     *    `requestAdapter` still declines. So this is not a rare race — it is the
     *    expected timing of the one path that re-acquires.
     *
     * Caching the second kind is what `createGpuHal` then reads as "no WebGPU on
     * this machine" (its own words), silently pinning the whole page to WebGL2
     * until a reload. So past this flag a failure is retried and never cached.
     */
    hadDevice: boolean;
    deviceLostListeners: Set<() => void>;
    /**
     * Stays `string | null` rather than {@link GpuOverride} because the cell is
     * shared with other copies of this module, including older ones whose
     * `setGpuOverride` took any string without checking. Everything that reads it
     * treats an unrecognized value as no pin.
     *
     * @see setGpuOverride
     */
    gpuOverride: string | null;
}
declare global {
    var __jbrowseRenderCoreGpuDeviceV1: GpuDeviceCell | undefined;
}
export declare function onDeviceLost(listener: () => void): () => void;
/**
 * The renderers `?renderer=` can pin the page to. `canvas` is a spelling of
 * `canvas2d` kept because it is in the wild.
 *
 * A pin means *only* that rung — `createGpuHal` does not fall past it. That is
 * the whole point of the flag: it exists to compare backends, and a comparison
 * whose subject silently substitutes itself is worse than no comparison. The
 * failure is visible instead, as a `renderError` carrying the pin that could
 * not be honored, with the banner's "disable GPU" as the way out.
 */
export declare const GPU_OVERRIDES: readonly ['webgpu', 'webgl', 'canvas2d', 'canvas'];
export type GpuOverride = (typeof GPU_OVERRIDES)[number];
/**
 * Pin the page to a renderer, or clear the pin with `null`. Page-wide by
 * design and shared across every copy of this module — see {@link GpuDeviceCell}.
 *
 * Takes a bare `string` because both callers hand it one straight off a URL
 * (`?renderer=` in jbrowse-web's `InitialLoad`, the same param fed by desktop's
 * `--renderer` flag), so validating here is validating once at the only place
 * an unchecked value enters. An unrecognized one clears the pin and says so:
 * before this, `?renderer=WebGL` or a typo was indistinguishable from passing
 * nothing at all, which is the one outcome a person debugging a renderer must
 * not silently get.
 */
export declare function setGpuOverride(value: string | null): void;
export declare function getGpuOverride(): string | null;
/**
 * Whether the GPU is off for the whole page — either pinned by `?renderer=` at
 * startup or switched off from a display's GPU-error banner after an
 * unrecoverable WebGL context loss. `createGpuHal` returns null in that case, so
 * every backend built from then on is the Canvas2D one.
 *
 * Note this is narrower than "a pin is in force": `webgl` and `webgpu` are pins
 * too, and both leave GPU rendering on. The banner reads this to decide whether
 * to offer its escape, so it must stay the Canvas2D question specifically.
 */
export declare function isGpuRenderingDisabled(): boolean;
/**
 * Reset the shared singleton state. For use in tests only — clears `device` and
 * `devicePromise` so the next `getGpuDevice()` call starts fresh rather than
 * returning the cached (possibly null) promise from a previous test.
 *
 * It drops references and deliberately does not destroy the device, so this is
 * not the half of a pair that a `destroyGpuDevice()` completes. See the comment
 * above `onDeviceLost` for what destroying one costs.
 *
 * Resets the cell's fields rather than replacing the cell, so a second copy of
 * this module that captured it still sees the reset. `gpuOverride` is left
 * alone: it is set by the host and by individual tests, and clearing it here
 * would make the reset mean two different things.
 */
export declare function resetGpuDeviceForTests(): void;
export declare function getGpuDevice(): Promise<GPUDevice | null>;
export {};
