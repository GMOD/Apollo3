export declare const MAX_RECOVERIES = 2;
export declare const RECOVERY_WINDOW_MS = 60000;
export type RecoveryVerdict = 'recover' | 'give-up';
/**
 * The recovery budget a display spends re-initializing its rendering backend
 * after a lost WebGL context or a lost WebGPU device.
 *
 * The budget is **windowed, not lifetime**. A context that resolves and then
 * immediately re-loses has to keep climbing toward the cap — that is the flap
 * the cap exists for, and it happens within seconds. But two unrelated losses
 * an hour apart are not a flap, and a lifetime counter cannot tell them apart:
 * it spends the second loss's budget on the first one's and leaves a
 * long-running session permanently unable to auto-recover. Counting over a
 * window separates the two without needing to know which kind of loss it saw.
 *
 * `now` is passed in rather than read, so the caller owns the clock and this
 * stays testable without fake timers.
 */
export declare class RecoveryBudget {
    private count;
    private lastAt;
    private readonly max;
    private readonly windowMs;
    constructor(max?: number, windowMs?: number);
    /**
     * Record a loss and say whether to recover from it. Call this **only when
     * about to act** on the answer — it is a mutation, and calling it
     * speculatively (this hook's recovery effect runs on every render) would
     * refresh the window forever and the count would never lapse.
     */
    record(now: number): RecoveryVerdict;
    /** Which attempt the loss just recorded is — drives the backoff exponent. */
    get attempt(): number;
    /**
     * Back to a clean slate, for the two events that mean the trouble is over: a
     * genuine `webglcontextrestored` and a manual Retry. A successful re-init is
     * deliberately NOT one of them — every flap contains one.
     */
    reset(): void;
}
