import type { BlendState, VertexAttributeLayout, PipelineDescriptor, ShaderBinding, TextureBinding } from './hal';
export interface ShaderModule {
    WGSL_SOURCE: string;
    GLSL_VERTEX: string;
    GLSL_FRAGMENT: string;
    INSTANCE_STRIDE_BYTES: number;
    VERTEX_ATTRIBUTES: readonly VertexAttributeLayout[];
    VERTS_PER_INSTANCE?: number;
    TOPOLOGY?: PipelineDescriptor['topology'];
    BLEND_STATE?: BlendState;
    TEXTURES?: readonly [TextureBinding, ...TextureBinding[]];
    BINDINGS?: readonly ShaderBinding[];
}
/**
 * What a pass is, over and above its shader: an identity, and the handful of
 * choices that are genuinely the *consumer's* rather than the shader's.
 *
 * Every remaining field is an override of something the module already carries,
 * and each one earns its place by a case in the tree where one shader is drawn
 * by two passes that disagree:
 *
 * - `verticesPerInstance` — the canvas chevron pass, whose count is the
 *   shader's `CHEVRON_VERTS` times a cap the *renderer* chooses.
 * - `blendState` / `topology` — wiggle's step line and center line share
 *   `wiggleLine.slang` and blend differently (src-over against max), so that
 *   shader declares no `//! blend:` and each pass says which it wants.
 * - `blend: false` — nothing disables blending today, which is why there is no
 *   `//! blend: none` to inherit it from.
 *
 * There is deliberately no `bufferStride` / `bufferAttributes` pair. Two passes
 * sharing one instance buffer (`drawPass(id, region, bufferPassId)`) must
 * declare the same instance struct — canvas's chevron and line both take
 * `LineInstance` from `lineInstance.slang` — so both modules reflect the same
 * stride and the same `VERTEX_ATTRIBUTES`, and copying one pass's layout onto
 * the other was restating that rather than establishing it. Worse, it *hid* the
 * case it looked like it was handling: had the two structs drifted apart, the
 * override would have made the borrowing pass read line's bytes through
 * chevron's shader without complaint. Share the `.slang` struct instead.
 */
export interface SlangPassOpts {
    id: string;
    mod: ShaderModule;
    verticesPerInstance?: number;
    topology?: PipelineDescriptor['topology'];
    blend?: boolean;
    blendState?: BlendState;
    textures?: [TextureBinding, ...TextureBinding[]];
}
export declare function slangPass(opts: SlangPassOpts): PipelineDescriptor;
