import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { IAutorunOptions } from 'mobx';
/**
 * Dev-only. Records a named reaction against the node it belongs to, so a test
 * can ask for its dependency set by name. Every autorun installer in the tree
 * calls this; a display's afterAttach discards the disposer, and this is the
 * one place it can still be found.
 */
export declare function recordNamedReaction(self: object, name: string, disposer: () => void): void;
/**
 * An autorun that is disposed with `self` and answerable by name.
 *
 * The two halves belong together: `reactionDependencies` can only see a
 * reaction that was recorded, so an installer that calls `autorun` and
 * `addDisposer` directly silently opts its dependency set out of the tests that
 * are supposed to pin it — and nothing fails, which is the same shape of
 * quiet-hole the mechanism exists to close. Every installer goes through here
 * so there is no second spelling to forget.
 */
export declare function namedAutorun(self: IAnyStateTreeNode, body: () => void, options: IAutorunOptions & {
    name: string;
}): import("mobx").IReactionDisposer;
/**
 * The observables a named reaction currently subscribes to, as sorted leaf
 * names (`Model.prop`), computeds flattened to what they read. This is the
 * dependency set MobX rebuilt on the reaction's last run, so it answers, for
 * that state, the question no pure function can: which reads are tracked.
 */
export declare function reactionDependencies(self: object, name: string): string[];
