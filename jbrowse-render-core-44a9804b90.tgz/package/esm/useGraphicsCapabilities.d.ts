import type { GraphicsCapabilities } from './graphicsCapabilities.ts';
/**
 * The memoized capability probe, as React state — `null` until it resolves,
 * which is one microtask on a machine with no WebGPU and one adapter request on
 * one that has it.
 *
 * Hand-rolled rather than `@jbrowse/core`'s `useFetch`, and that is forced
 * rather than preferred: render-core must not depend on core (ADR-030 keeps it
 * a leaf so a third-party display can bundle it), so every hook here is its own
 * — `useRenderingBackend` and `useTabVisibilityRerender` are the same shape.
 *
 * It is also all this needs. `useFetch` carries keys, stop tokens, error state
 * and `mutate` for sources that change; capabilities are fixed for the life of
 * the page and already memoized in the module, so there is one value, fetched
 * once, that never invalidates. The effect exists only to deliver it.
 */
export declare function useGraphicsCapabilities(): GraphicsCapabilities | null;
