/**
 * The prompt raised when a wheel over the view did nothing at all — see
 * `useScrollZoomHint` for when that is and why it's the only moment worth
 * interrupting.
 *
 * It says what would have worked *and* offers the setting, because the point is
 * to spend the user's attention once: they came here wanting to zoom, so the
 * useful reply is a way to zoom, not the name of a preference they now have to
 * go and find. The modifier it names is the one that platform's users reach for
 * — see ZOOM_MODIFIER.
 *
 * Portalled to the body and positioned in viewport coordinates, which is not
 * fussiness: this fires most often when the user has scrolled to the bottom of
 * a view, so anything positioned inside the view is off-screen at the one
 * moment it matters — and `contain`/`transform` on the containers between here
 * and the body would capture a plain `position: fixed` anyway.
 *
 * Takes an `onEnable` rather than a view: nothing here reads model state, and
 * scroll-to-zoom is a session preference every wheel-zoom view shares, so the
 * card is the same card whichever one raised it.
 */
declare function ScrollZoomHint({ show, at, onEnable, onHeldChange, }: {
    show: boolean;
    at: {
        x: number;
        y: number;
    };
    onEnable: () => void;
    onHeldChange: (held: boolean) => void;
}): import("react").ReactPortal;
export default ScrollZoomHint;
