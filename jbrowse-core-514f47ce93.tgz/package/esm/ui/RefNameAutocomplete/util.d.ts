import BaseResult from '../../TextSearch/BaseResults.ts';
import type { RefNameMatchSource } from '../../util/selectNamedRegions.ts';
export declare const ADORNMENT_RESERVE_PX = 70;
export declare const HELP_BUTTON_RESERVE_PX = 30;
export declare const MAX_OPTIONS = 100;
export interface Option {
    isLimit?: boolean;
    result: BaseResult;
}
export declare function cap(options: Option[]): Option[];
/**
 * The browse/pre-fetch fallback list, shown while a typed query is in flight and
 * when it comes back empty (typed queries otherwise resolve through
 * fetchResults).
 *
 * The matching itself is `matchRefNames`, in core beside the glob semantics,
 * because Enter answers for the same typed text and the two must not each grow
 * their own reading of it. What is left here is presentation: how many rows to
 * materialize, and the bulk row.
 *
 * A glob may gather up to MAX_GLOB_REGIONS for that bulk row; a plain query
 * never needs more than the visible list, so it keeps the tighter bound and the
 * cost it always had. Collecting one past MAX_OPTIONS is what lets `cap` render
 * its "keep typing" hint.
 */
export declare function getRefNameOptions(assembly: RefNameMatchSource | undefined, inputValue: string): Option[];
export declare function getDeduplicatedResult(results: BaseResult[]): Option[];
export declare function coerceToResult(option: string | Option): BaseResult;
export declare function getOptionLabel(option: string | Option): string;
export declare function getInputWidth(value: string, minWidth: number, maxWidth: number, adornmentWidth?: number): number;
