import type { LegendSwatch } from './legendSpec.ts';
import type { ReactNode } from 'react';
export interface ColorLegendEntry {
    key: string;
    label: string;
    color?: string;
    swatches?: LegendSwatch[];
    hidden?: boolean;
    marker?: ReactNode;
}
export declare const LEGEND_ROW_HEIGHT = 14;
export declare const LEGEND_SWATCH = 10;
export default function SvgColorLegend({ entries, canvasWidth, maxHeight, onDismiss, children, testid, }: {
    entries: ColorLegendEntry[];
    canvasWidth: number;
    maxHeight?: number;
    onDismiss?: () => void;
    children?: ReactNode;
    testid?: string;
}): import("react").JSX.Element | null;
