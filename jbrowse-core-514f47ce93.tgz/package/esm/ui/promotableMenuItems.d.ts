import type { Pin } from '../configuration/promotableDefaults.ts';
import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
import type { RadioOption, SettingRowOptions } from './toggleMenuItems.ts';
/** #menuBuilder promotableToggleItem | `checkboxItem` plus a promote-to-default pin */
export declare function promotableToggleItem({ label, checked, onToggle, pin, ...opts }: {
    label: string;
    checked: boolean;
    onToggle: () => void;
    pin: Pin;
} & SettingRowOptions): CheckboxMenuItem;
/** #menuBuilder promotableRadioItem | `radioItem` plus a promote-to-default pin */
export declare function promotableRadioItem({ label, checked, onClick, pin, ...opts }: {
    label: string;
    checked: boolean;
    onClick: () => void;
    pin?: Pin;
} & SettingRowOptions): RadioMenuItem;
/** #menuBuilder promotableRadioItems | `radioItems` plus a pin per option, from a factory over the value */
export declare function promotableRadioItems<T extends string>(options: readonly RadioOption<T>[], current: T | undefined, setMode: (m: T) => void, pin: (value: T) => Pin): RadioMenuItem[];
