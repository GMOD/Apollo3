import type { BaseInternetAccountModel } from '../../pluggableElementTypes/index.ts';
import type { FileLocation } from '../../util/index.ts';
export declare const MAX_LABEL_LENGTH = 5;
export declare function isAdminMode(): boolean;
export declare function truncateLabel(str: string): string;
export declare function getAccountLabel(account: BaseInternetAccountModel): string | number | bigint | true | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | Iterable<import("react").ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
export declare function getInitialSourceType(location?: FileLocation, emptyDefault?: string): string;
/**
 * The toggle `location` needs in order to be visible, or undefined when the one
 * already showing can render it.
 *
 * `getInitialSourceType` answers this once, at mount, when a form's slot is
 * usually still empty. This is the same question asked of a location that
 * arrived later — the index a form found sitting beside the main file, say,
 * which on desktop is a local path and would render as a blank URL box.
 *
 * Undefined for an empty slot (spelled as a UriLocation with no uri) as well as
 * for a match: an emptied field says nothing about how the user wants to work,
 * and switching the toggle out from under them as they clear a box is worse than
 * leaving it.
 */
export declare function sourceTypeForLocation(location: FileLocation | undefined, current: string): string | undefined;
/**
 * The directory containing `filePath`, for remembering where the user last
 * picked a file. Undefined when there is no directory to remember.
 *
 * String surgery rather than `node:path` because this is renderer code that
 * also builds for the web, and it has to read a Windows path from Electron
 * either way. Which means keeping the separator: `idx` is the index of the last
 * one, so slicing *before* it drops it, and `C:\reads.bam` — a file at the root
 * of a data drive, which is where an external disk mounts — yielded `"C:"`.
 * That is not the root; to Windows a drive letter with no separator means the
 * current directory on that drive, so the dialog reopened wherever the process
 * happened to be. Keep the separator when dropping it would leave a bare root
 * (`C:\`, and `/` on POSIX).
 */
export declare function dirFromPath(filePath: string): string | undefined;
/**
 * Stamps the selected account onto a URL location — and, given no account,
 * *unstamps* whichever one was there. The second half is the one that matters:
 * picking Dropbox and then going back to plain URL used to leave the stamp
 * behind, so the file kept being fetched through Dropbox with nothing in the
 * form saying so.
 *
 * Returns the location itself when there is nothing to change, so a caller can
 * tell a real edit from a no-op by identity.
 */
export declare function addAccountToLocation(location: FileLocation, account?: BaseInternetAccountModel): FileLocation;
