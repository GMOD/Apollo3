import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
export interface SettingRowOptions {
    helpText?: string;
    subLabel?: string;
    disabled?: boolean;
    disabledHelpText?: string;
    keepMenuOpen?: boolean;
}
/** #menuBuilder checkboxItem | one checkbox setting row */
export declare function checkboxItem(label: string, checked: boolean, onToggle: () => void, opts?: SettingRowOptions): CheckboxMenuItem;
/**
 * #menuBuilder toggleItem | a checkbox row whose setter takes the new value
 *
 * `checkboxItem` where the callback is handed the value rather than left to
 * derive it. Prefer this: the derivation is `!` applied to the same expression
 * the row is `checked` by, and writing it out per row is 38 chances to negate
 * the wrong thing — which fails as a checkbox that ticks and does nothing, with
 * nothing thrown.
 *
 * It is also the shape `radioItems` already takes (`setMode: (m: T) => void`),
 * so the two group builders now agree about who computes the new value.
 *
 * MAF had this as a local wrapper, and it had already lost three of
 * `SettingRowOptions`' five fields to a hand-narrowed `{ subLabel? }` — the
 * exact drift the comment on that interface warns about.
 */
export declare function toggleItem(label: string, value: boolean, setValue: (value: boolean) => void, opts?: SettingRowOptions): CheckboxMenuItem;
/** #menuBuilder radioItem | one radio setting row; the singular of `radioItems` */
export declare function radioItem(label: string, checked: boolean, onClick: () => void, opts?: SettingRowOptions): RadioMenuItem;
export interface RadioOption<T extends string> {
    value: T;
    label: string;
    subLabel?: string;
    helpText?: string;
}
/** #menuBuilder radioItems | a radio group, one row per option */
export declare function radioItems<T extends string>(options: readonly RadioOption<T>[], current: T | undefined, setMode: (m: T) => void): RadioMenuItem[];
