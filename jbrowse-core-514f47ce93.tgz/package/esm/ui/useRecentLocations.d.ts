/**
 * A recorded row: what the menu shows, and what reopening it actually opens.
 *
 * The two are not the same string. A text-search hit's display string is built
 * for reading — a snippet ellipsized to fit, or `name (matched attribute)` when
 * the query hit something other than the name — and feeding it back to the
 * search finds nothing, because those characters were never in the index. So a
 * row that had a location carries it, and reopening parses that instead.
 *
 * `loc` is absent for a query the user typed and submitted freehand, which has
 * no resolved location to record. That label _is_ searchable (it is what the
 * user typed), so those rows are replayed through search as before.
 */
export interface RecentLocation {
    label: string;
    loc?: string;
}
/**
 * Remembers the locations recently opened from the header search box or an
 * import form, most-recent first and deduplicated, scoped per assembly (and per
 * host/path/config like the remembered assembly). Without an assembly there is
 * nothing to scope the key to, so the list stays in memory only.
 */
export declare function useRecentLocations(assemblyName?: string): {
    recentLocations: RecentLocation[];
    addRecentLocation: (entry: RecentLocation) => void;
    clearRecentLocations: () => void;
};
