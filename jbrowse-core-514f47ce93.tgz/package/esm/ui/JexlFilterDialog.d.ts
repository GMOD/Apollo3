import type { JexlFilterModel } from '../util/jexlFilters.ts';
/**
 * Editor for a list of jexl feature filters (one per line), for any display
 * implementing the two-tier {@link JexlFilterModel} contract.
 *
 * It takes the display node rather than a filter list and a setter because the
 * three plugins offering this row each wrote their own 30-line adapter to
 * supply exactly that pair, and the adapters had drifted: one seeded the dialog
 * from the *resolved* filters (so config-declared ones showed up and were
 * editable) and the others from the raw override (so they did not), and only one
 * of them normalized an emptied list. Both are policy this dialog can state
 * once — the dialog is where "the box is empty" becomes a value.
 */
declare const JexlFilterDialog: ({ model, handleClose, }: {
    model: JexlFilterModel;
    handleClose: () => void;
}) => import("react").JSX.Element;
export default JexlFilterDialog;
