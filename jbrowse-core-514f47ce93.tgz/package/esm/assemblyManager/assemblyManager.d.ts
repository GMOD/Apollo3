import type PluginManager from '../PluginManager.ts';
import type RpcManager from '../rpc/RpcManager.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { StopToken } from '../util/stopToken.ts';
import type { Assembly } from './assembly.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
type AdapterConf = Record<string, unknown>;
export interface AssemblyBaseOpts {
    stopToken?: StopToken;
    sessionId: string;
    statusCallback?: StatusCallback;
}
/**
 * #stateModel AssemblyManager
 */
declare function assemblyManagerFactory(conf: IAnyType, pm: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     * this is automatically managed by an autorun which looks in the parent
     * session.assemblies, session.sessionAssemblies, and
     * session.temporaryAssemblies
     */
    assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {
    /**
     * #volatile
     * rate limiter for `get`'s `Core-handleUnrecognizedAssembly` reports, so
     * each unknown name reaches the extension point once per session
     */
    unrecognizedReports: {
        /**
         * Report `name` via `fire`, once per session, and keep what came back.
         * `handlerCount` separates "every handler declined" from "nobody
         * listening": the folded result is the same either way, and only the first
         * is worth waiting out.
         */
        report(session: unknown, name: string, handlerCount: number, fire: () => unknown): void;
        /** what `report` recorded for `name` under `session`, if anything */
        reportFor(session: unknown, name: string): {
            handled: boolean;
            claim?: Promise<void>;
        } | undefined;
    };
} & {
    /**
     * #getter
     */
    readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
} & {
    /**
     * #method
     */
    getCanonicalAssemblyName(asmName: string): string | undefined;
    /**
     * #method
     */
    getDisplayName(asmName: string): string;
    /**
     * #method
     * The assembly `asmName` names, or undefined. Reports a name it doesn't
     * know to `Core-handleUnrecognizedAssembly` so a plugin can go supply it,
     * which is a side effect: a caller only asking *whether* the session has
     * the assembly wants {@link has} instead. Each name is reported at most
     * once per session, since a handler resolves it out of band and the
     * assembly turning up is itself the reactive signal.
     */
    get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #method
     * Whether the session knows this assembly. Use this, not `get`, to ask
     * only whether the assembly is present: `!has(name)` is exactly the
     * condition under which `get` reports `name` to
     * `Core-handleUnrecognizedAssembly`, so probing with `get` tells every
     * installed plugin to go resolve a name that a caller supplying the
     * assembly itself (a hub connection, MAF row navigation) is about to
     * create.
     */
    has(asmName: string): boolean;
    /**
     * #method
     * The first of `asmNames` that hasn't finished loading — the one a view
     * blocked on them is waiting for, and whose `statusMessage` /
     * `statusProgress` its spinner should show. Returns the assembly itself
     * (a stable reference, so a consuming getter doesn't invalidate on every
     * read) or undefined once they are all loaded.
     */
    loadingAssembly(asmNames: string[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #getter
     * read via readConfObject, matching how the afterAttach autorun names the
     * assemblies it creates: get() treats a name found here as "a config
     * exists, its model is just not built yet", so the two must agree
     */
    readonly assemblyNamesList: string[];
    /**
     * #getter
     * Every name the *configs* answer to — each assembly's `name` and its
     * `aliases`. What {@link has} knows before the models exist.
     *
     * Separate from assemblyNamesList rather than widening it: `get` treats a
     * name found in that list as "a config exists, its model is just not built
     * yet", which has to stay the canonical name the autorun will create the
     * assembly under. A Set because `has` is called per name by per-render
     * scans over every track in the session.
     */
    readonly configuredAssemblyNames: Set<string>;
    /**
     * #getter
     * combined jbrowse.assemblies, session.sessionAssemblies, and
     * session.temporaryAssemblies
     */
    readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
    readonly rpcManager: RpcManager;
} & {
    /**
     * #method
     * Wait out whatever might still be about to supply `assemblyName`, and
     * resolve once nothing is.
     *
     * Resolution is a chain of events, not a duration: a handler probes and
     * adds a connection, the connection fetches a config, the config's
     * assemblies land in the session. Each link is observable, so each is
     * waited on rather than guessed at.
     *
     * - the handler's own promise, if it returned one, covers the part before
     *   the session gains anything to watch (the hubs plugin's HEAD probe)
     * - any connection still fetching could be carrying the assembly, so its
     *   `loading` flag going false is the next event. Every loading
     *   connection counts, not just one naming this assembly: a connection
     *   config need not declare what it will turn out to provide, and waiting
     *   for one connection too many costs a moment while missing one returns
     *   the wrong answer.
     *
     * A handler that returned nothing gets {@link UNDECLARED_HANDLER_GRACE_MS}
     * instead, because it left nothing to wait on.
     */
    settleAssemblyResolution(assemblyName: string): Promise<void>;
} & {
    /**
     * #method
     * use this method instead of assemblyManager.get(assemblyName) to get an
     * assembly with regions loaded
     */
    waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
    /**
     * #method
     * {@link waitForAssembly}, but a name that cannot be resolved is an error
     * rather than an `undefined` for the caller to interpret.
     *
     * For callers whose result is silently *wrong* without the assembly, not
     * merely absent: a refName map is the obvious one, since an empty map
     * means an adapter gets queried with un-renamed refNames, finds nothing,
     * and the track draws blank with nothing to say why. Failing here instead
     * puts the name in front of the user, who is the only one who can add the
     * assembly or fix the track.
     *
     * Worth using only because the wait is causal now. It used to give up
     * after a fixed ten seconds, where "not resolved" could equally mean "not
     * resolved yet" and throwing would have been a race; today it returns
     * only once every handler and connection that could supply the name has
     * finished, so there is a real answer to report.
     */
    requireAssembly(assemblyName: string): Promise<import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        refNameMismatches: Map<string, import("./refNameMismatch.ts").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("./refNameMismatch.ts").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("./assembly.ts").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("./refNameMismatch.ts").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
    /**
     * #method
     * The refName map for an adapter under `assemblyName`. Throws if the
     * assembly cannot be resolved — see {@link requireAssembly}. No
     * `assemblyName` at all is not a failure, just nothing to rename.
     */
    getRefNameMapForAdapter(adapterConf: AdapterConf, assemblyName: string | undefined, opts: AssemblyBaseOpts): Promise<import("./refNameMaps.ts").RefNameAliases>;
    /**
     * #method
     */
    isValidRefName(refName: string, assemblyName: string): boolean;
} & {
    afterAttach(): void;
    /**
     * #action
     * private: you would generally want to add to manipulate
     * jbrowse.assemblies, session.sessionAssemblies, or
     * session.temporaryAssemblies instead of using this directly
     */
    removeAssembly(asm: Assembly): void;
    /**
     * #action
     * private: you would generally want to add to manipulate
     * jbrowse.assemblies, session.sessionAssemblies, or
     * session.temporaryAssemblies instead of using this directly
     *
     * this can take an active instance of an assembly, in which case it is
     * referred to, or it can take an identifier e.g. assembly name, which is
     * used as a reference. snapshots cannot be used
     */
    addAssembly(configuration: any): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default assemblyManagerFactory;
