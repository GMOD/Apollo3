import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type BaseRpcDriver from './BaseRpcDriver.ts';
import type { RpcCallArgs, RpcCallReturn } from './RpcRegistry.ts';
export type RpcDriverFactory = (config: AnyConfigurationModel, pluginManager: PluginManager) => BaseRpcDriver;
export interface RpcManagerOptions {
    makeWorkerInstance?: () => Worker;
    defaultDriverName?: string;
}
export default class RpcManager {
    static configSchema: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly defaultDriver: {
            readonly type: "string";
            readonly description: "the RPC driver to run data fetching on: MainThreadRpcDriver or WebWorkerRpcDriver. Leave empty to use the default for this application";
            readonly defaultValue: "";
            readonly advanced: true;
        };
        readonly workerCount: {
            readonly type: "number";
            readonly description: "The number of workers to use. If 0 (the default) JBrowse will decide how many workers to use.";
            readonly defaultValue: 0;
            readonly advanced: true;
        };
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    pluginManager: PluginManager;
    mainConfiguration: AnyConfigurationModel;
    defaultDriverName: string;
    driverObjects: Map<string, BaseRpcDriver>;
    driverFactories: Map<string, RpcDriverFactory>;
    constructor(pluginManager: PluginManager, mainConfiguration: AnyConfigurationModel, { makeWorkerInstance, defaultDriverName, }?: RpcManagerOptions);
    registerDriverFactory(name: string, factory: RpcDriverFactory): void;
    getDriver(backendName: string): BaseRpcDriver;
    /**
     * The driver every call in this session runs on: the config's `defaultDriver`
     * if set, otherwise the host application's default.
     *
     * There is no per-call, per-track or per-display override. One existed, and
     * one call site in the app ever passed it — a tag-value scan in the alignments
     * plugin — so a track pinned to the main thread had its tag scan run there and
     * every one of its data fetches go to the worker pool anyway. Routing a single
     * call somewhere else is only meaningful with a backend that differs in what it
     * can do, which is the tabled server-side-driver idea; add it back with that,
     * not before.
     */
    private getDriverForCall;
    /**
     * `args` carries the method's data and the caller's handles on the operation —
     * the stop token and the status callback. Both handles are always accepted,
     * for every method, because {@link RpcHandles} is part of `RpcCallArgs` rather
     * than of any registry entry.
     *
     * There is deliberately no second position for either. The handles were
     * accepted in an `opts` parameter as well, and the two disagreed:
     * `WorkerPoolRpcDriver` honored a `statusCallback` there and
     * `MainThreadRpcDriver` ignored `opts` entirely, so the same call had a
     * working progress bar under a worker and a silent one under the driver every
     * embedded component defaults to. One position.
     *
     * The cast on the way out is at the driver boundary, where the method is an
     * unparameterized {@link RpcMethodType} and `deserializeReturn` is therefore
     * `unknown`. It is not the only thing holding the return type up: the same
     * type is what that hook is declared to produce, checked against the registry
     * at each method that overrides it.
     */
    call<M extends string>(sessionId: string, functionName: M, args: RpcCallArgs<M>): Promise<RpcCallReturn<M>>;
    /**
     * Run an RPC thunk, and if it fails because a location needs auth, set up
     * credentials for the origin and run it exactly once more. The single retry
     * is structural — there is no loop — so a persistent auth failure surfaces
     * the error instead of spinning. The retry re-runs serializeArguments, which
     * now finds the new account and injects pre-authorization (prompting the
     * user). If auth can't be set up, the original error is rethrown unchanged.
     */
    private withAuthRetry;
    /**
     * Ensure an ephemeral HTTP-basic internet account exists for a location's
     * origin so a retried RPC call can authenticate. The account id is derived
     * from the origin and reused if already present: when a track first loads,
     * many block RPC calls fail auth near-simultaneously, and a single shared
     * account collapses them into one credential prompt (BaseInternetAccountModel
     * memoizes the token via a per-account promise). Returns false when the root
     * model can't hold accounts or no HTTPBasicInternetAccount type is registered
     * (authentication plugin not loaded), signaling the caller not to retry.
     */
    private ensureAuthForOrigin;
    /**
     * Drop a session's sticky worker assignment on every driver so the
     * workerAssignments map doesn't grow unboundedly as sessions are freed.
     */
    private freeSessionOnAllDrivers;
    /**
     * Terminate every driver's worker threads. Call when discarding the owning
     * root model (e.g. switching sessions or reloading after a plugin change) so
     * orphaned workers don't accumulate across a desktop run.
     */
    destroy(): void;
}
