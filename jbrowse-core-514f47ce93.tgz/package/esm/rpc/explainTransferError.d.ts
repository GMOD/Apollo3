/**
 * Every payload field each transferred buffer is reachable by.
 *
 * Several fields can name one buffer, so this collects all of them rather than
 * the first: subarrays of a shared allocation are exactly how a duplicate entry
 * gets into a hand-built list, and naming both ends is what makes that
 * actionable.
 */
export declare function bufferPaths(value: unknown): Map<ArrayBufferLike, string[]>;
/**
 * The error to send when `postMessage` rejects a reply, with the transfer-list
 * entry it blamed named by field.
 *
 * Returns the original error untouched when the message addresses no index: an
 * unserializable payload ("() => {} could not be cloned") reports that way and
 * has nothing to do with the transfer list, so a report about transfers would
 * point at the wrong thing entirely.
 */
export declare function explainTransferError(error: unknown, value: unknown, transferables: readonly Transferable[], method?: string): unknown;
