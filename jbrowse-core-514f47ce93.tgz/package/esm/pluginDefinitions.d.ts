/**
 * What a plugin definition is, and everything that can be answered by looking
 * at one — its url, its name, whether two describe the same plugin.
 *
 * Kept apart from PluginLoader, which pulls in ReExports (effectively all of
 * core) to be able to run a plugin. Inspecting a definition must not cost that:
 * the plugin store resolves definitions and would otherwise import core's
 * config layer back into itself.
 */
export interface UMDLocPluginDefinition {
    umdLoc: {
        uri: string;
        baseUri?: string;
    };
    name: string;
    integrity?: string;
}
export interface UMDUrlPluginDefinition {
    umdUrl: string;
    name: string;
    integrity?: string;
}
export interface LegacyUMDPluginDefinition {
    url: string;
    name: string;
    integrity?: string;
}
export type UMDPluginDefinition = UMDLocPluginDefinition | UMDUrlPluginDefinition;
export interface ESMLocPluginDefinition {
    esmLoc: {
        uri: string;
        baseUri?: string;
    };
    name?: string;
}
export interface ESMUrlPluginDefinition {
    esmUrl: string;
    name?: string;
}
export type ESMPluginDefinition = ESMLocPluginDefinition | ESMUrlPluginDefinition;
export interface CJSPluginDefinition {
    cjsUrl: string;
    name?: string;
}
export type PluginDefinition = UMDUrlPluginDefinition | UMDLocPluginDefinition | LegacyUMDPluginDefinition | ESMLocPluginDefinition | ESMUrlPluginDefinition | CJSPluginDefinition;
export declare function isUMDPluginDefinition(def: PluginDefinition): def is UMDPluginDefinition | LegacyUMDPluginDefinition;
export declare function isESMPluginDefinition(def: PluginDefinition): def is ESMPluginDefinition;
export declare function isCJSPluginDefinition(def: PluginDefinition): def is CJSPluginDefinition;
export declare const vendoredPluginNames: Set<string>;
/**
 * Desktop's half of the same list — a plugin one product bundles and another does
 * not, which the shared set above cannot express.
 *
 * Blat is in Desktop's corePlugins but deliberately not Web's: Web is where
 * cold-load bundle size is paid, and BLAT is niche. So Desktop's bundled copy is
 * the only one that ships. It is what gives BLAT on a genome the user opened
 * from their own disk, where no config names any plugin, and it is the copy that
 * reaches UCSC through the main-process `blatFetch` bridge and the CAPTCHA-solve
 * window. Web has to load the external entry to have BLAT at all.
 *
 * Naming it drops a config's `plugins[]` entry for Blat before Desktop's loader
 * sees it, so a config that carries one does not install a second copy beside
 * the bundled one and append its Tools menu items twice. Nothing carries one
 * today: jb2hubs stamps `sequence.metadata.blatDb`, which names the UCSC db an
 * assembly is searchable under and says nothing about loading a plugin. The
 * entry is a guard for the UMD build (`plugins/blat/scripts/build-umd.ts`),
 * which a config can name and which is how Web would pick BLAT up.
 *
 * It lives here beside the shared set rather than in jbrowse-desktop because the
 * two are read together — a surface consulting one and not the other offers an
 * install the loader then drops, which is what Desktop's plugin store and global
 * plugins dialog both did.
 */
export declare const desktopVendoredPluginNames: string[];
export declare function dropVendoredPlugins(defs: PluginDefinition[], alsoVendored?: Iterable<string>): PluginDefinition[];
export declare function pluginDescriptionString(d: PluginDefinition): string;
/**
 * The url a definition loads from, or undefined when it names no loader at all.
 * Comparisons between definitions go through this rather than `pluginUrl`, whose
 * 'unknown url' placeholder is display text: two unloadable definitions are not
 * the same plugin just because neither has a url.
 */
export declare function maybePluginUrl(d: PluginDefinition): string | undefined;
export declare function pluginUrl(d: PluginDefinition): string;
/**
 * Whether a definition loads from exactly `url` — the question behind "which
 * definition is this loaded plugin", "is this one in the session's list", "which
 * entry does an uninstall remove".
 *
 * The two undefined guards are the whole point, and both were live as
 * `pluginUrl(d) === url` comparisons. A definition naming no loader reads back as
 * the literal `'unknown url'`, so any two of them compared equal: approving one
 * marked every other unloadable definition trusted, and removing one filtered
 * every other unloadable one out of the config. And the url side is absent for a
 * core or global plugin (no install url was recorded), which must match no
 * definition rather than the first url-less one.
 */
export declare function isPluginUrl(d: PluginDefinition, url: string | undefined): boolean;
export declare function pluginName(definition: PluginDefinition): string | undefined;
export declare function pluginDefinitionMetadata(definition: PluginDefinition): {
    name: string | undefined;
    url: string;
};
export declare function pluginLabel(definition: PluginDefinition): string;
/**
 * Whether two definitions describe the same plugin. They can without being
 * identical — a UMD name+url in a config, an esmUrl in the global list — so
 * either a shared name or a shared url is enough. Both are optional (an ESM
 * definition carries no name, an unloadable one no url), and a missing field
 * never matches: two definitions are not the same plugin just because neither
 * names one.
 *
 * This is the single answer to "is this plugin already installed" — dedupe
 * across plugin sources, the plugin store's installed-check — so those cannot
 * drift apart and disagree about what is a duplicate.
 */
export declare function samePlugin(a: PluginDefinition, b: PluginDefinition): boolean;
/**
 * The candidates no definition in `existing` already describes — `dedupePlugins`
 * across two lists whose first one is already settled, for a source loaded after
 * another rather than merged with it.
 */
export declare function pluginsNotIn(candidates: PluginDefinition[], existing: PluginDefinition[]): PluginDefinition[];
/**
 * Drops later definitions that name a plugin an earlier one already did, so the
 * first source listed wins: a config's own (version-pinned) entry takes
 * precedence over the same plugin from the user's global list.
 */
export declare function dedupePlugins(plugins: PluginDefinition[]): PluginDefinition[];
