import type { FileLocation } from '../util/types/index.ts';
import type { ConfigurationSchemaOptions, ConfigurationSchemaType } from './configurationSchema.ts';
import type { BuiltinSlotTypeName } from './configurationSlot.ts';
import type { ISimpleType, IStateTreeNode, Instance, SnapshotOut } from '@jbrowse/mobx-state-tree';
export type GetOptions<SCHEMA> = SCHEMA extends ConfigurationSchemaType<any, infer OPTIONS> ? OPTIONS : never;
export type GetBase<SCHEMA> = SCHEMA extends undefined ? never : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<undefined, any> ? undefined : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<infer BASE extends AnyConfigurationSchemaType, any> ? BASE : never;
export type GetExplicitIdentifier<SCHEMA> = GetOptions<SCHEMA> extends ConfigurationSchemaOptions<any, infer EXPLICIT_IDENTIFIER extends string> ? EXPLICIT_IDENTIFIER : never;
/**
 * The identifier prop a schema declares **or inherits** — `trackId`,
 * `displayId`, or whatever `explicitIdentifier` names. Recursive because most
 * display schemas never declare it themselves: they pick up `displayId` from
 * `baseConfiguration: baseLinearDisplayConfigSchema`, whose options
 * `preprocessConfigurationSchemaArguments` merges in at runtime, leaving the
 * subclass's own `EXPLICIT_IDENTIFIER` param `undefined`. Same walk
 * `ConfigurationSlotName` does for inherited slot names.
 */
export type GetInheritedIdentifier<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<any, any> ? GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? GetInheritedIdentifier<GetBase<SCHEMA>> : never) : never;
export type ConfigurationSchemaForModel<MODEL> = MODEL extends IStateTreeNode<infer SCHEMA extends AnyConfigurationSchemaType> ? SCHEMA : never;
export type ConfigurationSlotName<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<infer D, any> ? (keyof D & string) | GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotName<GetBase<SCHEMA>> : never) : never;
/**
 * The names a config snapshot for `SCHEMA` may use — its own slots, its
 * sub-schemas recursively, its identifier and everything it inherits — with
 * every value left `unknown`.
 *
 * Names are the whole point of it. A slot value can be its own type, a `jexl:`
 * callback string, or (for a promotable slot) absent, and nothing here tries to
 * check that; a *name* the schema does not declare is dropped on the way in
 * without a word, so `preferance` is a setting that reads as applied and never
 * applies. Against an object literal — which is how an embedder writes one —
 * TypeScript's excess-property check turns that into a compile error.
 */
export type ConfigurationSnapshot<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<infer D, any> ? {
    [K in keyof D]?: D[K] extends ConfigurationSchemaType<any, any> ? ConfigurationSnapshot<D[K]> : unknown;
} & {
    [K in GetExplicitIdentifier<SCHEMA>]?: string;
} & (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSnapshot<GetBase<SCHEMA>> : unknown) : unknown;
type SlotValueResolvedFromDef<DEF> = DEF extends {
    promotedBase: undefined;
} ? SlotValueRawFromDef<DEF> : DEF extends {
    promotedBase: unknown;
} ? Exclude<SlotValueRawFromDef<DEF>, undefined> : SlotValueRawFromDef<DEF>;
/**
 * The value each builtin slot `type` reads as — the type-level twin of
 * `slotTypes` in `configurationSlot.ts`, which is the same list as MST models.
 * A table rather than the fourteen-deep conditional staircase this used to be:
 * adding a slot type is now one row here and one there, and the two tables sit
 * side by side where a name present in one and missing from the other is
 * visible. Missing a row is not silent either — it drops the slot to the
 * `defaultValue` fallback below, which is what `SlotValueRawFromDef` documents.
 *
 * `stringEnum`/`maybeStringEnum` are deliberately absent: their value type comes
 * from the author's own `types.enumeration`, read off `model` before this table
 * is consulted.
 */
interface SlotValueByType {
    stringArray: string[];
    stringArrayMap: Record<string, string[]>;
    numberMap: Record<string, number>;
    fileLocation: FileLocation;
    maybeNumber: number | undefined;
    maybeBoolean: boolean | undefined;
    maybeColor: string | undefined;
    /**
     * `frozen` and its `maybe*` form are `any` deliberately — arbitrary dynamic
     * JSON whose shape the caller asserts at the read boundary. `unknown` would
     * only add cast ceremony on values that are legitimately dynamic.
     *
     * Stated here rather than left to the `defaultValue` fallback, which reaches
     * `any` for these only by accident: it lands there because no `frozen` slot in
     * the repo happens to default to a scalar, and a promotable slot's default is
     * always the `undefined` sentinel.
     */
    frozen: any;
    maybeFrozen: any;
    number: number;
    integer: number;
    boolean: boolean;
    string: string;
    text: string;
    color: string;
}
/**
 * The two tables name the same builtin slot types, checked rather than
 * remembered.
 *
 * A row present in one and missing from the other is otherwise **not** an
 * error: the slot drops through to `SlotValueRawFromDef`'s `defaultValue`
 * fallback, which re-widens a scalar default but reaches `any` for everything
 * else — so a new `stringArray`-shaped type would silently read as `any` at
 * every call site. The "every builtin slot type reads as its declared value
 * type" case in `configTypeNarrowing.test.ts` lists the rows by hand, so it
 * only catches the drift if whoever adds the type also edits the test; this
 * catches it either way.
 */
type MutuallyExtends<A, B> = [A] extends [B] ? [B] extends [A] ? true : false : false;
type Assert<T extends true> = T;
export type SlotValueTableCoversBuiltinSlotTypes = Assert<MutuallyExtends<BuiltinSlotTypeName, keyof SlotValueByType>>;
type SlotValueRawFromDef<DEF> = DEF extends AnyConfigurationSchemaType ? AnyConfigurationSnapshot : DEF extends {
    model: ISimpleType<infer T extends string>;
} ? DEF extends {
    type: 'maybeStringEnum';
} ? T | undefined : T : DEF extends {
    type: infer T extends keyof SlotValueByType;
} ? SlotValueByType[T] : DEF extends {
    defaultValue: infer V;
} ? [V] extends [boolean] ? boolean : [V] extends [string] ? string : [V] extends [number] ? number : any : any;
/** what a raw read (`getConf` / `readConfObject`) of this slot yields */
export type ConfigurationSlotValue<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueRawFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValue<GetBase<SCHEMA>, K> : any : any;
/**
 * what `resolveConf` yields: the same, minus the inherit sentinel on a
 * promotable slot — the cascade always produces a real value.
 */
export type ConfigurationSlotValueResolved<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueResolvedFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValueResolved<GetBase<SCHEMA>, K> : any : any;
/**
 * Naming convention for config types, paired per schema:
 * - `XConfigSchema` is the MST IType (the schema itself). Use it for
 *   `getConf`, `ConfigurationReference`, and factory params — anywhere a schema
 *   is expected.
 * - `XConfigModel` is `Instance<XConfigSchema>` (a resolved config node). Use it
 *   for `readConfObject` results, model fields, and values read off a session.
 *
 * Prefer a named `XConfigModel` alias over inlining `Instance<XConfigSchema>` at
 * call sites. Two historical names predate this convention and stay as-is:
 * `BaseTrackConfig` (the track instance type) and `AnyConfiguration` (a
 * model-or-snapshot union, not a plain instance).
 */
export type AnyConfigurationSchemaType = ConfigurationSchemaType<any, any>;
export type AnyConfigurationModel = Instance<AnyConfigurationSchemaType>;
/** a plain-object snapshot of a configuration model (not a live MST node) */
export type AnyConfigurationSnapshot = SnapshotOut<AnyConfigurationModel>;
/**
 * A value readable as configuration: either a live configuration model or a
 * plain snapshot of one. `session.tracks` legitimately holds a mix (live
 * `sessionTracks` nodes, plus plain frozen/merged base entries that hydrate to
 * MST only on first reference access), and `readConfObject` reads both — so this
 * is the honest type at those boundaries. Reserve `AnyConfigurationModel` for
 * values that must be live (actions, identity, reference resolution).
 */
export type AnyConfiguration = AnyConfigurationModel | AnyConfigurationSnapshot;
export {};
