import type { RefObject } from 'react';
export declare function useFocusOnInteraction(ref: RefObject<HTMLElement | null>, onInteract: () => void): void;
export declare function useDebounce<T>(value: T, delay: number): T;
export declare function useWidthSetter(view: {
    setWidth: (arg: number) => void;
    id?: string;
}): RefObject<HTMLDivElement | null>;
/**
 * Build a value exactly once per mount — including under React StrictMode,
 * which `useState(() => build())` does not.
 *
 * StrictMode double-invokes a state initializer in development and throws the
 * SECOND result away. For an ordinary value that is the intended lint: it
 * surfaces impure initializers and costs nothing. For anything that owns
 * something — an MST tree, a worker pool, a subscription — it stands up a second
 * one and then drops the only reference to it, so nothing can ever tear it down,
 * and it is invisible because the one React kept behaves perfectly.
 *
 * A ref is written once and survives the double render; this is React's own
 * "avoiding recreating the ref contents" pattern.
 */
export declare function useCreateOnce<T>(create: () => T): T;
/**
 * Run `cleanup` when the component *really* unmounts.
 *
 * "Really" is the whole difficulty, because React does not distinguish a final
 * unmount from a simulated one. The obvious spelling —
 * `useEffect(() => () => cleanup(), [])` — is wrong in exactly the environment
 * most hosts develop in, jbrowse-web included: StrictMode runs
 * setup → cleanup → setup on a live component, so a cleanup that destroys
 * something leaves the component holding the destroyed thing for the rest of its
 * life, with the second setup having nothing to rebuild from. For an MST tree
 * that is not a quiet degradation — the next read throws `[mobx-state-tree] …
 * [dead]`.
 *
 * So the teardown is deferred by a microtask and cancelled if setup runs again.
 * StrictMode's cleanup and re-setup are one synchronous block, so the cancel
 * always wins there; a real unmount never runs setup again, so the microtask
 * fires.
 *
 * This owns a *component's* teardown, not a per-value one: `cleanup` always sees
 * the latest render's closure, and swapping the thing being torn down mid-life
 * is not supported. Pair it with {@link useCreateOnce}, which is the shape that
 * makes that true.
 *
 * Deliberately not covered: a subtree hidden with `<Activity>`, which destroys
 * effects and re-creates them a TASK later rather than synchronously, so the
 * cancel below cannot reach it. Measured, not assumed — `useFinalUnmount.test.tsx`
 * pins that hiding tears the value down and showing does not rebuild it, since
 * `useCreateOnce`'s ref survives the hide. A host that needs a view to survive
 * being hidden owns the engine itself and keeps it outside the hidden tree.
 */
export declare function useFinalUnmount(cleanup: () => void): void;
/**
 * `useState` backed by a localStorage key.
 *
 * Originally https://usehooks.com/useLocalStorage/, which is per-instance: two
 * components on the same key each kept their own copy of it, so toggling a
 * setting in one BreakpointSplitView header left a second one open beside it
 * showing the old value until it remounted. Instances on a key now subscribe to
 * each other's writes, and to other tabs' — `subscribeToLocalStorageKey`, which
 * the grid-bookmark widget shares from its state model.
 *
 * The store is read on every notify rather than cached, so nothing here can go
 * stale against a `localStorage.clear()`. Which also means a functional update
 * resolves against what is actually stored: two `setValue(v => …)` calls in one
 * handler used to keep only the second, because both resolved against the value
 * captured by the render that produced the setter.
 *
 * `enabled: false` keeps the value in component state only: nothing is read,
 * written or shared. Callers use it for a key that isn't meaningful yet (no
 * assembly chosen, so nothing to scope the key to). A page with no usable store
 * at all — an RPC worker, SSR, a cross-origin iframe with third-party storage
 * blocked, which is the embedded products on someone else's page — runs in that
 * same mode, because reading a key back through a store that dropped the write
 * answers the default and would report it as the stored value: the control
 * would revert the instant the user moved it.
 */
export declare function useLocalStorage<T>(key: string, initialValue: T, enabled?: boolean): readonly [T, (value: T | ((val: T) => T)) => void];
