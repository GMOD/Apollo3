interface BlockData {
    key: string;
    offsetPx: number;
    widthPx: number;
    assemblyName?: string;
    refName?: string;
    start?: number;
    end?: number;
    reversed?: boolean;
    displayedRegionIndex?: number;
    isLeftEndOfDisplayedRegion?: boolean;
    isRightEndOfDisplayedRegion?: boolean;
    variant?: 'boundary';
}
export interface ContentBlock extends BlockData {
    type: 'ContentBlock';
    assemblyName: string;
    refName: string;
    start: number;
    end: number;
}
export interface ElidedBlock extends BlockData {
    type: 'ElidedBlock';
}
export interface InterRegionPaddingBlock extends BlockData {
    type: 'InterRegionPaddingBlock';
}
export type BaseBlock = ContentBlock | ElidedBlock | InterRegionPaddingBlock;
type Func<T> = (value: BaseBlock, index: number, array: BaseBlock[]) => T;
export declare class BlockSet {
    blocks: BaseBlock[];
    constructor(blocks?: BaseBlock[]);
    push(block: BaseBlock): void;
    /**
     * Widen a trailing elided run by widthPx, reporting whether there was one to
     * widen. `push` keeps nothing but the width off an ElidedBlock it merges, so
     * a caller holding the width can skip building the block that would have
     * carried it — which at whole-genome zoom is nearly every region, see
     * calculateDynamicBlocks.
     */
    growElidedRun(widthPx: number): boolean;
    map<T, U = this>(func: Func<T>, thisarg?: U): T[];
    forEach<T, U = this>(func: Func<T>, thisarg?: U): void;
    get length(): number;
    get totalWidthPx(): number;
    get totalWidthPxWithoutBorders(): number;
    get offsetPx(): number;
    get contentBlocks(): ContentBlock[];
    get totalBp(): number;
}
export {};
