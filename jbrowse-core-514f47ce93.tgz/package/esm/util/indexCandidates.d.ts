import type { FileLocation } from './types/index.ts';
/**
 * Every conventional spelling of an index file, for the docs that describe this
 * behavior. Kept beside {@link indexCandidateNames}, which is the list actually
 * probed, so the two are edited together.
 */
export declare const indexSpellings: {
    name: string;
    writtenBy: string;
}[];
/**
 * The index filenames worth looking for beside `fileName`, best guess first.
 *
 * One data file has several names its index might carry, and picking only the
 * first left everyone else with a missing-file error naming a path they never
 * wrote:
 *
 * - `<file>.bai` / `.crai` / `.tbi` is what samtools and tabix write
 * - `<file>.csi` is what htslib writes for a reference over 512 Mb, and on
 *   request at any size
 * - `reads.bai` beside `reads.bam` is what Picard and GATK write, in place of
 *   samtools' `reads.bam.bai`
 *
 * Empty for a file type that carries no sibling index (BigWig, BigBed, hic),
 * which is how a caller knows not to go looking.
 *
 * `jbrowse-cli` answers the same question in `siblingSidecar`
 * (`commands/add-track-utils/adapter-utils.ts`) rather than calling this: it
 * carries no `@jbrowse/core` dependency, so `npm i -g @jbrowse/cli` stays a CLI
 * rather than a copy of the app. Change one, change the other.
 */
export declare function indexCandidateNames(fileName: string): string[];
/**
 * `location` with its filename replaced, i.e. the sibling of a data file.
 *
 * Only a URI and a local path have a sibling at all. A Blob or a FileHandle is
 * whatever the user picked out of a file dialog and there is no directory
 * around it to look in, so those get `undefined` — the honest answer, and the
 * reason index detection cannot work from a browser file picker.
 */
export declare function siblingLocation(location: FileLocation, fileName: string): FileLocation | undefined;
/**
 * The index sitting beside `location`, or undefined when none of the
 * conventional spellings is there.
 *
 * `exists` is injected rather than reached for, because what "exists" costs is
 * the caller's business and differs by host: a local path is a stat, a URL is a
 * request, and a Blob cannot be asked at all.
 */
export declare function detectIndexLocation(location: FileLocation, exists: (location: FileLocation) => Promise<boolean>): Promise<FileLocation | undefined>;
