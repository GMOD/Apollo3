import type { RpcStatus } from './progress.ts';
import type { StopToken } from './stopToken.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
export interface StatusReporter {
    setStatusMessage: (status?: RpcStatus) => void;
    /**
     * `FetchMixin`'s model-wide guarded sink, present on any display composing
     * the LGV fetch mixins. When it is, the rotation reports through it rather
     * than opening a SECOND throttle window on the same status field — which is
     * the thing one-window-per-owner exists to prevent, and which the
     * multi-sample-variant sources fetch had done to a display whose region
     * fetches were already thinning through the mixin's window.
     *
     * Optional because the displays this helper was written for (dotplot,
     * synteny) compose no fetch mixin and have only the window below.
     */
    makeStatusCallback?: (isCurrent: () => boolean) => (status: RpcStatus) => void;
    /**
     * `FetchMixin`'s `throttle.runNow` — the hand-written clear at a fetch
     * boundary, so it lands on the same window `makeStatusCallback` reports
     * through instead of racing it. Not a path the guarded sink uses; ADR-071.
     */
    flushStatus?: (apply: () => void) => void;
}
/**
 * A {@link StatusReporter} a model can hold in **one** volatile, for something
 * that has one operation to narrate and no reason to grow a status vocabulary
 * of its own.
 *
 * The alternative is what every display does: two volatiles and an action that
 * calls {@link statusMessageText} and {@link statusFraction}. That is the right
 * shape where the fields are part of the model's own surface — `BaseDisplay`
 * and `FetchMixin` declare them because half the display API reads them, and
 * ADR-041 is why those two keep their own copies rather than sharing a mixin.
 * It is a lot of declaration for a view that wants a corner chip while one
 * fetch runs.
 *
 * A plain function rather than a mixin, for the reason ADR-041 gives: a compose
 * layer is what the model chains here cannot afford. Holding it costs one
 * `.volatile` line, and `ProgressChip` takes `message`/`fraction` straight off
 * it.
 */
export interface StatusChannel extends StatusReporter {
    readonly message: string | undefined;
    readonly fraction: number | undefined;
}
export declare function createStatusChannel(): StatusChannel;
export interface ActiveFetch {
    /** stop token to forward to the RPC call */
    stopToken: StopToken;
    /**
     * True only while this is still the most recent fetch AND `self` is alive.
     * Gate every post-await write — result commit, error set — on it so a
     * superseded or torn-down fetch never writes back.
     */
    isCurrent: () => boolean;
    /**
     * RPC `statusCallback` pre-gated by `isCurrent`: forwards progress to
     * `setStatusMessage` only while this is still the latest fetch, so a
     * superseded fetch's late status update can't flicker the overlay, and
     * throttled to the same leading edge as `FetchMixin`'s callbacks. Pass it
     * straight as the RPC `statusCallback` arg.
     */
    statusCallback: (status: RpcStatus) => void;
    /**
     * Call in the `finally` of the run that owns this fetch: closes
     * `isCurrent`, drops the write queued behind the throttle, and clears the
     * status field.
     *
     * All three, because a caller doing it by hand got some subset. `isCurrent`
     * is `token === current && isAlive`, and a run that *completes* never rotates
     * its own token — so the guard stays open after the work ends and a trailing
     * write lands on top of a hand-written `setStatusMessage(undefined)` up to a
     * window later. That is the shape `installComparativeFetchAutorun` had; the
     * multi-sample-variant sources fetch had no clear at all and pinned a
     * progress chip on any failure its worker didn't clear for it.
     */
    end: () => void;
}
/**
 * Latest-wins stop-token rotation for a fetch that runs in a bare `autorun`
 * rather than through `FetchMixin.runFetch` (which welds the same mechanics to
 * `fetchGeneration`, so it's only for viewport-driven LGV fetches). Each
 * `begin()` aborts the prior fetch's token and returns a fresh one plus an
 * `isCurrent()` guard that captures this run's token — gate every post-await
 * write on it and a superseded or torn-down fetch can never clobber fresher
 * data. The guard is the return value, so a caller can't forget to compare a
 * token by hand.
 *
 * `end()` in the run's `finally` is the other half, and for the same reason:
 * ending a fetch means three things (close the guard, drop the throttle's
 * queued write, clear the status field) and a caller writing them out got a
 * subset. Both callers did — one cleared without dropping the queued write,
 * the other never cleared at all.
 *
 * Owns the token mechanics and the status channel; the caller keeps its own
 * loading/error/commit side-effects in its autorun. Used by any bare-autorun
 * fetch: the comparative-view displays (dotplot, synteny, through
 * `installComparativeFetchAutorun`, which wraps this with their shared
 * debounce/flags/commit skeleton), the multi-sample-variant sources fetch, and
 * the breakpoint split view's overlay-feature fetch.
 *
 * `report` is passed rather than read off `self`, so where the status lands is
 * the caller's decision and not a shape this imposes. A display passes itself —
 * its status fields are part of its own API, and one composing `FetchMixin`
 * passes the model-wide window along with them (see `makeStatusCallback`).
 * Anything with one operation to narrate and no status vocabulary of its own
 * passes a {@link createStatusChannel}, which is one volatile instead of two
 * fields and an action.
 */
export declare function createStopTokenRotation(self: IStateTreeNode, report: StatusReporter): {
    begin(): ActiveFetch;
    dispose(): void;
};
