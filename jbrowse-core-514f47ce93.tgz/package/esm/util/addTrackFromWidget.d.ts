import type { AbstractSessionModel, SessionWithAddTracks, TrackContainer } from './types/index.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Whether the target track list currently displays any of the track's
 * assemblies, i.e. the track can be shown there after adding it.
 */
export declare function containerDisplaysAssembly(container: {
    assemblyNames?: readonly string[];
} | undefined, assemblyNames: readonly (string | undefined)[] | undefined): boolean;
/** the slice of the add-track widget every workflow's submit path writes to */
export interface AddTrackWidgetSelf extends IStateTreeNode {
    /**
     * Where a submitted track opens: the view, or one track list within it when
     * the widget was opened from a synteny level's track selector. Not the same
     * as `view` — a workflow reaching past this for `view` adds the track to the
     * wrong list.
     */
    trackContainer: TrackContainer | undefined;
    clearData: () => void;
}
/**
 * Reset the form and dismiss the widget after a successful add.
 *
 * Only ever on an add that landed something: finishing throws away what the
 * user assembled, so doing it when every config was rejected buries the
 * snackbars explaining why behind an empty form with nothing to retry from.
 */
export declare function finishAddTrack(model: AddTrackWidgetSelf, session: AbstractSessionModel): void;
/**
 * Add one track config from an add-track workflow, reveal it, and dismiss the
 * widget — the tail every workflow shares, so all of them decide "show vs.
 * warn vs. dismiss" the same way.
 *
 * Three things a workflow doing this by hand has got wrong:
 *
 * - It shows the track in `model.view`, which is the wrong list when the widget
 *   was opened from a synteny level's track selector. `trackContainer` is the
 *   target.
 * - It shows a track whose assembly the container doesn't display, which is
 *   silently nothing on screen. Say so instead.
 * - It dismisses the widget even when `addTrackConf` rejected the config,
 *   wiping the form behind the error snackbar.
 *
 * Returns the added config, or undefined when `addTrackConf` rejected it — it
 * has already surfaced its own error, and a second, vaguer snackbar on top of
 * that helps nobody.
 */
export declare function addTrackFromWidget({ model, session, conf, }: {
    model: AddTrackWidgetSelf;
    session: AbstractSessionModel;
    conf: Parameters<SessionWithAddTracks['addTrackConf']>[0] & {
        trackId: string;
        name?: string;
        assemblyNames?: (string | undefined)[];
    };
}): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
} & IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>) | undefined;
