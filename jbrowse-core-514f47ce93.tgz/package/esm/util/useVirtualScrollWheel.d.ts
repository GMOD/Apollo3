export interface VirtualScrollOpts {
    scrollTop: number;
    viewportHeight: number;
    scrollableHeight: number;
}
export type ApplyVirtualScroll = (e: WheelEvent, opts: VirtualScrollOpts, commit: (scrollTop: number) => void) => void;
export declare function useVirtualScrollWheel(canvas: HTMLElement | null, onWheel: (e: WheelEvent, applyScroll: ApplyVirtualScroll, el: HTMLElement) => void): void;
