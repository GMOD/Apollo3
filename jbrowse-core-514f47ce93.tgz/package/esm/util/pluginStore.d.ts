import type { PluginDefinition } from '../pluginDefinitions.ts';
import type { JBrowsePlugin } from './types/index.ts';
/**
 * The store entries a product can install at all, before any user filter. Both
 * surfaces that list the store go through this — the in-session plugin store
 * widget and Desktop's global plugins dialog — because an entry one of them
 * offers and the loader behind the other drops is a silent install: the button
 * says Installed (or stays live, and every click appends another dead entry) and
 * nothing about the running app changes.
 *
 * Two independent reasons to hide an entry:
 *
 * - **No build this product can load.** Web runs ESM/UMD; a CJS-only entry needs
 *   Node's `require`, so only Desktop can install it. Asked of every build the
 *   entry publishes rather than only the top-level urls — an entry that pins urls
 *   per version, which `resolvePlugin`'s fallback exists to accommodate, used to
 *   vanish from Web's list with no diagnostic. An entry whose *resolved* build is
 *   the CJS-only one is still shown, since that is a fact about this JBrowse
 *   version rather than about the product, and PluginStoreCard already has a
 *   place to say so.
 * - **Already vendored into this product's core bundle**, where installing does
 *   nothing because `dropVendoredPlugins` drops the definition at load. Desktop's
 *   half of that list counts too, and is the half both surfaces were missing.
 */
export declare function installablePlugins(plugins: JBrowsePlugin[], isElectron: boolean): JBrowsePlugin[];
export interface ResolvedPlugin {
    compatible: boolean;
    pluginVersion?: string;
    supportedRanges: string[];
    definition: PluginDefinition | undefined;
}
export interface PluginUpdate {
    pluginVersion: string;
    name: string;
    definition: PluginDefinition;
}
export declare function resolvePlugin(plugin: JBrowsePlugin, jbrowseVersion: string): ResolvedPlugin;
export declare function installedVersionFromUrl(url: string | undefined, packageName: string | undefined): string | undefined;
/**
 * Whether a store entry is already among `installed`.
 *
 * Matched by packageName rather than by the resolved url wherever the store
 * publishes one: once a newer compatible version appears the resolved url
 * changes, and a url match would report "not installed" and let the user add a
 * second copy of the same plugin (same UMD global name) alongside the one
 * already there, which then fails to load with duplicate pluggable-element
 * registrations. Moving to a newer version is a separate, explicit action.
 */
export declare function isPluginInstalled(plugin: JBrowsePlugin, resolved: ResolvedPlugin, installed: PluginDefinition[]): boolean;
export declare function getPluginUpdate(plugin: JBrowsePlugin, jbrowseVersion: string, installedVersion: string | undefined): PluginUpdate | undefined;
