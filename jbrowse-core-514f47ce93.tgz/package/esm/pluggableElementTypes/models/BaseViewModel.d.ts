import type { MenuItem } from '../../ui/index.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel BaseViewModel
 * #category view
 */
declare const BaseViewModel: import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     * displayName is displayed in the header of the view, or assembly names
     * being used if none is specified
     */
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    /**
     * #property
     * collapse the view to its header bar, keeping it in the session rather
     * than closing it
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    width: number;
} & {
    /**
     * #method
     */
    menuItems(): MenuItem[];
} & {
    /**
     * #action
     */
    setDisplayName(name: string): void;
    /**
     * #action
     * width is an important attribute of the view model, when it becomes set,
     * it often indicates when the app can start drawing to it. certain views
     * like lgv are strict about this because if it tries to draw before it
     * knows the width it should draw to, it may start fetching data for
     * regions it doesn't need to
     *
     * setWidth is updated by a ResizeObserver generally, the views often need
     * to know how wide they are to properly draw genomic regions
     */
    setWidth(newWidth: number): void;
    /**
     * #action
     */
    setMinimized(flag: boolean): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default BaseViewModel;
export type IBaseViewModel = Instance<typeof BaseViewModel> & {
    type: string;
    assemblyNames?: string[];
};
export declare const BaseViewModelWithDisplayedRegions: import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     * displayName is displayed in the header of the view, or assembly names
     * being used if none is specified
     */
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    /**
     * #property
     * collapse the view to its header bar, keeping it in the session rather
     * than closing it
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "displayedRegions"> & {
    displayedRegions: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<Omit<{
        refName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        start: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
        end: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
        reversed: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    }, "assemblyName"> & {
        assemblyName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }, {
        setRefName(newRefName: string): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {
    width: number;
} & {
    /**
     * #method
     */
    menuItems(): MenuItem[];
} & {
    /**
     * #action
     */
    setDisplayName(name: string): void;
    /**
     * #action
     * width is an important attribute of the view model, when it becomes set,
     * it often indicates when the app can start drawing to it. certain views
     * like lgv are strict about this because if it tries to draw before it
     * knows the width it should draw to, it may start fetching data for
     * regions it doesn't need to
     *
     * setWidth is updated by a ResizeObserver generally, the views often need
     * to know how wide they are to properly draw genomic regions
     */
    setWidth(newWidth: number): void;
    /**
     * #action
     */
    setMinimized(flag: boolean): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type IBaseViewModelWithDisplayedRegions = Instance<typeof BaseViewModelWithDisplayedRegions>;
