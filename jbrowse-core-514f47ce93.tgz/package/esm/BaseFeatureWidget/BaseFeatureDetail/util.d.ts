export declare function isEmpty(obj: Record<string, unknown>): boolean;
export declare function applyFeatureFormatting<T extends {
    __jbrowsefmt?: Record<string, unknown>;
}>(feature: T): T & {
    [x: string]: unknown;
};
export declare function isFormattedField(feature: {
    __jbrowsefmt?: Record<string, unknown>;
}, key: string): boolean;
export declare function generateTitle(name: unknown, id: unknown, type: unknown): string;
export declare function accessNested(arr: string[], obj?: Record<string, unknown>): string | undefined;
