import type { AbstractSessionModel, SimpleFeatureSerialized } from '../../util/index.ts';
export declare function useSequenceFetch({ session, assemblyName, feature, upDownBp, }: {
    session: AbstractSessionModel;
    assemblyName: string | undefined;
    feature: SimpleFeatureSerialized;
    upDownBp: number;
}): {
    sequence: {
        error: string;
        seq?: undefined;
        upstream?: undefined;
        downstream?: undefined;
    } | {
        error?: undefined;
        seq: string;
        upstream: string;
        downstream: string;
    } | undefined;
    error: unknown;
    status: import("../../util/progress.ts").RpcStatus | undefined;
    assemblyGeneticCodeId: number | undefined;
    onForceLoad: () => void;
};
