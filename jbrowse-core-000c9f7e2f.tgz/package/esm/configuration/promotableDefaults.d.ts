import type { TrackConfigChange } from '../util/trackConfigDelta.ts';
import type { PromotedDefaultStore, ResolvableDisplay } from './promotableResolve.ts';
import type { AnyConfigurationModel, ConfigurationSchemaForModel, ConfigurationSlotName, ConfigurationSlotValueResolved } from './types.ts';
/**
 * #api core/configuration
 * Whether this track has customized the slot (holds a non-default value of its
 * own) rather than following the display type's default. The correct "reset to
 * default" predicate for a promotable slot: comparing the resolved value to the
 * base instead reads as at-default for a track merely *following* a non-base
 * promoted default, so the reset control lights up on a no-op.
 *
 * `SLOT` is constrained the way `getConf`'s is. A pin or a reset over a slot
 * name the schema does not declare is inert and silent — `resolveSlot` answers
 * about nothing, so the control draws outline forever — and a widened `self`
 * switches the check off (`HostChecksSlotNames`).
 */
export declare function isSlotCustomized<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(self: ResolvableDisplay<CONFMODEL>, slot: SLOT): boolean;
/**
 * #api core/configuration
 * The display's full config snapshot with every `promotable`
 * slot overwritten by its resolved value in place. For building a worker payload:
 * a promotable slot serializes as its raw inherit sentinel (`undefined`, since
 * they're all `maybe*` types), which the worker can't interpret — it has no
 * session to resolve against. This hands it concrete values instead, with no per-slot
 * bookkeeping, so adding a promotable worker-consumed slot needs no rpcProps
 * change and can't silently ship a sentinel. Main-thread only (the cascade
 * consults the session). Display-only promotable slots the worker never reads
 * (e.g. displayMode) are still excluded by the caller — resolving them here is a
 * harmless no-op since they're dropped anyway.
 */
export declare function getConfigSnapshotWithPromotables(self: ResolvableDisplay): Record<string, unknown>;
/**
 * #api core/configuration
 * A track config snapshot with every display's `promotable` slots resolved, plus
 * the list of values that came from a session-wide default rather than from the
 * config itself.
 *
 * For handing a track's config to somewhere that leaves the cascade for good —
 * the About dialog's "Copy config", whose output a user pastes into a
 * `config.json`. A raw `getSnapshot` records a slot a track merely *follows* as
 * absent (`stripDefault` collapsed it), so the copied config renders differently
 * from the track it was copied from. This is `getComputedStyle` at that
 * boundary, and `fromDisplayTypeDefaults` is what lets the UI say so rather than
 * silently materializing a session preference into a track config.
 *
 * Resolves from the display *config* alone, whether or not the track is open.
 * Everything the cascade takes is on the config node: it is the same node an
 * open display's `configuration` points at (the hydration cache makes it
 * stable), its `type` is the display type the session-wide tier is keyed on
 * (every display schema is `explicitlyTyped` under the display type's own name),
 * and the session is passed in. So an unopened track — which has no display
 * state at all — still has an answer to "what would this render as", by the same
 * code path.
 *
 * **Writes every promotable slot, including the ones sitting at `promotedBase`,
 * and that is the decision — don't "align" it with the share bake.** A pasted
 * `config.json` is read by a mechanism with no cascade in it at all, so writing
 * only the inherited values would leave every other slot to pick up whatever the
 * reader has promoted in their own browser. Pinned by
 * `products/jbrowse-web/src/tests/CopyConfigPromotedDefaults.test.ts`.
 */
export interface TrackConfigWithPromotables {
    config: Record<string, unknown>;
    /** `<displayType>.<slot>`, one per value inherited from a promoted default */
    fromDisplayTypeDefaults: string[];
}
/**
 * #api core/configuration
 * See {@link TrackConfigWithPromotables}.
 */
export declare function getTrackConfigWithPromotables(session: PromotedDefaultStore, trackConfig: AnyConfigurationModel): TrackConfigWithPromotables;
/**
 * #api core/configuration
 * The "make this the default for all tracks of this type" affordance on a menu
 * row — the trailing `PushPin`, bundled so the row consumes it as one prop.
 * Built by {@link makePin}.
 *
 * `active` = this value is currently the session default (a filled pin);
 * `toggle` sets it as the default or clears it, touching no track's own value
 * (see `applyDefaultToggle`). On set it raises a snackbar with an "Override N
 * customized tracks" action for every open track not already showing this value
 * — that action is the only thing in the subsystem that rewrites a track.
 *
 * **`toggle` rather than a `promote`/`clear` pair**, which was tried and dropped:
 * the sole renderer is a MUI `ToggleButton` whose `onChange` means exactly
 * "flip", so splitting it adds a member *and* a branch at the one call site that
 * never needed one. `active` is already public for a caller that wants to state a
 * direction. (The house preference for explicit setters over toggles is about MST
 * actions, where a toggle destroys the ability to set a known state; nothing here
 * stores a value.) ADR-048's requirement is that the flip be *symmetric* —
 * pin-then-unpin discards nothing — not that it be two functions.
 */
export interface Pin {
    /**
     * The promotable slot this pin promotes a value of. Nothing in the UI reads
     * it — a pin renders from `active`, `onValue` and the toggle. It is here so a
     * *built menu* can be asked which promotable slots it offers a pin for, which
     * is the only way that question has an answer: declaring `promotedBase` is a
     * schema fact and the pin is a menu fact, and a display that inherits the slot
     * but never builds a row has a slot nothing can ever promote, silently
     * (`promotableSlotsWithoutPin`, guarded by
     * `products/jbrowse-web/src/tests/PromotablePinCoverage.test.ts`).
     */
    slot: string;
    /**
     * The value `toggle` promotes — the on-value {@link makePin} was given, or the
     * track's current resolved value for the value-omitted form.
     *
     * `PinAdornment` words itself from this, and has to: a **boolean** on-value
     * promotes a *state*, so a row whose label names the setting rather than a
     * value ("Show legend") gets a pin that promotes hiding the legend as often as
     * showing it. Every other on-value IS what the row's label says — a radio
     * option, a slider's current size — so those keep the value-shaped copy.
     *
     * Required, like `slot`: a pin that cannot say what it promotes is what let
     * that copy state the opposite of what the click does.
     */
    onValue: unknown;
    active: boolean;
    toggle: () => void;
}
/**
 * Unset each display's own value on `slot`, so it follows the display type's
 * default instead of baking in a value that wouldn't track a later default
 * change. Backs the snackbar's "apply to open tracks" action. Displays already
 * unset are skipped. Takes the display set explicitly so it's unit-testable.
 *
 * Clearing the slot is the whole of it — this is the subsystem's only write to a
 * display, and it goes through the config.
 *
 * Skips dead displays, since the caller supplies the list and MST throws on any
 * read or write to a destroyed node.
 */
export declare function resetSlotToInherit(displays: ResolvableDisplay[], slot: string): void;
/**
 * Whether `value` is the current session default for `slot`. The live state the
 * pin's filled/outline reflects — a session-wide fact, so it reads the raw
 * promoted default rather than what this display resolves to (a customized track
 * can be showing something else entirely). Module-internal (exercised by
 * promotableDefaults.test.ts); not part of the public barrel.
 */
export declare function isPromotableDefault(self: ResolvableDisplay, slot: string, value: unknown): boolean;
/**
 * Open tracks (across all views) whose resolved value for `slot` differs from
 * `value` — the ones "Override N customized tracks" would visibly change by
 * clearing their own values. Drives that action's count. Module-internal
 * (exercised by promotableDefaults.test.ts); not part of the public barrel.
 *
 * Reads the **resolved** value, which is what makes this the *override* set
 * rather than the *apply* set: a track merely following the promoted default
 * already resolves to `value` and so is absent here, correctly — it needs no
 * clearing. {@link applySlotToOpenTracks} wants the opposite question and asks
 * it of the stored value.
 */
export declare function tracksDifferingFrom(self: ResolvableDisplay, slot: string, value: unknown): ResolvableDisplay[];
/**
 * Write `value` into each display's own config for `slot`, so the track *holds*
 * it rather than resolving it through the cascade. The additive mirror of
 * {@link resetSlotToInherit}, and the write behind the snackbar's "apply to N
 * open tracks instead" — those tracks keep the value once the promoted default
 * that offered it is gone.
 *
 * **A track already showing `value` still has to be written**, which is why this
 * compares the *stored* value and not the resolved one. A follower stores
 * nothing and resolves `value` only through the promoted default, so skipping it
 * and then clearing that default would strand it at base — the exact opposite of
 * what the user asked for. Comparing the stored value is also what lets a
 * `jexl:` value answer "is this already what we would write?" without being
 * evaluated, the reason `resetSlotToInherit` reads the same field.
 *
 * Skips dead displays, since the caller supplies the list and MST throws on any
 * read or write to a destroyed node.
 */
export declare function applySlotToOpenTracks(displays: ResolvableDisplay[], slot: string, value: unknown): void;
/**
 * #api core/configuration
 * The pin for one promotable slot: "make this value the default for every track
 * of this display type".
 *
 * `value` chooses between the subsystem's two meanings, which are otherwise
 * identical:
 *
 * - **Give it** for a per-value pin — "make *arcs* the default" — independent of
 *   what the track currently shows. Use on an always-visible pin so it can never
 *   promote a meaningless value, and so two rows sharing one slot (arcs `'arc'`
 *   vs read cloud `'cloud'`; sashimi `'down'` vs `'auto'`) stay independent.
 * - **Omit it** for "whatever I'm showing", resolved through the cascade. Use for
 *   a symmetric or continuous setting where no fixed on-value makes sense
 *   (wiggle point size, arc line width, `mismatchAlpha`).
 *
 * One function with an optional argument, rather than the two exported builders
 * it replaces — a per-value one and a `…CurrentValue…` one, the second of which
 * was exactly the first applied to `resolveSlot(self, slot).value`. The pair was
 * one function plus a doc section explaining which name to reach for; omitting
 * the argument now says what the longer name said.
 */
export declare function makePin<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(self: ResolvableDisplay<CONFMODEL>, slot: SLOT, ...value: [] | [
    ConfigurationSlotValueResolved<ConfigurationSchemaForModel<CONFMODEL>, SLOT>
]): Pin;
/**
 * #api core/configuration
 * Effective differences a track following the default inherits from session-wide
 * defaults, one per promotable slot whose inherited value differs from its schema
 * default. Drives the track-selector "affected by a session default" badge.
 */
export declare function getDisplayTypeDefaultChanges(self: ResolvableDisplay): TrackConfigChange[];
/**
 * #api core/configuration
 * Clear the named promoted defaults for this display type, so every track
 * following one reverts to its own config value. Backs the badge's "clear
 * session default" action, which passes the slots it actually listed
 * (`getDisplayTypeDefaultChanges`).
 *
 * **`slots` is required, and an all-slots default is not the convenience it
 * looks like.** It reaches further than any list a dialog can have shown: a
 * promoted default the track *customized* over, or one promoted to a value
 * equal to `promotedBase`, is `inherited: false` and so appears in no row, yet
 * still governs sibling tracks — so clearing it from a dialog that never showed
 * it moves tracks other than the one whose badge was clicked. Clearing every
 * promoted default at once is a preferences-scope action, and Preferences →
 * "Reset to defaults" is where it lives (`clearPreferenceOverrides`).
 */
export declare function clearPromotedDefaults(self: ResolvableDisplay, slots: Iterable<string>): void;
