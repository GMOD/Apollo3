import type { AbstractSessionModel, SessionWithPublishTrackConf, TrackContainer } from './types/index.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Whether the target track list currently displays any of the track's
 * assemblies, i.e. the track can be shown there after adding it.
 */
export declare function containerDisplaysAssembly(container: {
    assemblyNames?: readonly string[];
} | undefined, assemblyNames: readonly (string | undefined)[] | undefined): boolean;
/** the slice of the add-track widget every workflow's submit path writes to */
export interface AddTrackWidgetSelf extends IStateTreeNode {
    /**
     * Where a submitted track opens: the view, or one track list within it when
     * the widget was opened from a synteny level's track selector. Not the same
     * as `view` — a workflow reaching past this for `view` adds the track to the
     * wrong list.
     */
    trackContainer: TrackContainer | undefined;
    clearData: () => void;
}
/**
 * The slice of the add-track widget a whole workflow gets: the submit path
 * above plus the assembly it writes into. Structural rather than the widget's
 * own model type, so a plugin contributing a workflow doesn't take a package
 * dependency on the plugin that owns the widget.
 */
export interface AddTrackWorkflowModel extends AddTrackWidgetSelf {
    assembly: string | undefined;
    setAssembly: (arg: string) => void;
}
/**
 * Reset the form and dismiss the widget after a successful add.
 *
 * Only ever on an add that landed something: finishing throws away what the
 * user assembled, so doing it when every config was rejected buries the
 * snackbars explaining why behind an empty form with nothing to retry from.
 */
export declare function finishAddTrack(model: AddTrackWidgetSelf, session: AbstractSessionModel): void;
/**
 * Add one track config from an add-track workflow, reveal it, and dismiss the
 * widget — the tail every workflow shares, so all of them decide "show vs.
 * warn vs. dismiss" the same way.
 *
 * Three things a workflow doing this by hand has got wrong:
 *
 * - It shows the track in `model.view`, which is the wrong list when the widget
 *   was opened from a synteny level's track selector. `trackContainer` is the
 *   target.
 * - It shows a track whose assembly the container doesn't display, which is
 *   silently nothing on screen. Say so instead.
 * - It dismisses the widget even when `publishTrackConf` rejected the config,
 *   wiping the form behind the error snackbar.
 *
 * **A track on an assembly the view synthesized takes neither destination.** The
 * widget reads its assembly off the containing view and offers no choice of one
 * outside it (`setAssembly` lists `session.assemblyNames`, which excludes the
 * temporary ones), so a user opening a file in a read-vs-ref panel arrives here
 * naming an assembly that goes back when that view closes — and a session list
 * would keep the config, once per file, in the snapshot they save and share.
 * That is ADR-084's leak reached through the widget rather than through a
 * launcher, so it takes ADR-084's answer: the config rides on the track as
 * `showTrack`'s `inlineConf`, works for the life of the view, and goes out with
 * it. The container is the one this assembly came from, so it displays it.
 *
 * Returns the added config, or undefined when `publishTrackConf` rejected it — it
 * has already surfaced its own error, and a second, vaguer snackbar on top of
 * that helps nobody.
 */
export declare function addTrackFromWidget({ model, session, conf, }: {
    model: AddTrackWidgetSelf;
    session: AbstractSessionModel;
    conf: Parameters<SessionWithPublishTrackConf['publishTrackConf']>[0] & {
        trackId: string;
        name?: string;
        assemblyNames?: (string | undefined)[];
    };
}): (import("@jbrowse/mobx-state-tree").$EmptyObjectBrand & Partial<{
    [x: string]: any;
}> & {
    trackId: string;
    name?: string;
    assemblyNames?: (string | undefined)[];
}) | (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
} & IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>) | undefined;
