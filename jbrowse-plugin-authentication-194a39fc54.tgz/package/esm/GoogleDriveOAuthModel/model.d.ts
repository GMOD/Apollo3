import { GoogleDriveFile } from './GoogleDriveFilehandle.ts';
import type { GoogleDriveOAuthInternetAccountConfigModel } from './configSchema.ts';
import type { UriLocation } from '@jbrowse/core/util/types';
import type { Instance } from '@jbrowse/mobx-state-tree';
export interface RequestInitWithMetadata extends RequestInit {
    metadataOnly?: boolean;
}
/**
 * #stateModel GoogleDriveOAuthInternetAccount
 */
export default function stateModelFactory(configSchema: GoogleDriveOAuthInternetAccountConfigModel): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
}, "configuration" | "type"> & {
    type: import("@jbrowse/mobx-state-tree").ISimpleType<"OAuthInternetAccount">;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "Bearer";
        };
        readonly authEndpoint: {
            readonly description: "the authorization code endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly tokenEndpoint: {
            readonly description: "the token endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly needsPKCE: {
            readonly description: "boolean to indicate if the endpoint needs a PKCE code";
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        readonly clientId: {
            readonly description: "id for the OAuth application";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly scopes: {
            readonly description: "optional scopes for the authorization call";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly state: {
            readonly description: "optional state for the authorization call";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly responseType: {
            readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
            readonly type: "string";
            readonly defaultValue: "code";
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>>;
}, "configuration" | "type"> & {
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<"GoogleDriveOAuthInternetAccount">;
    /**
     * #property
     */
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly authEndpoint: {
            readonly description: "the authorization code endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "https://accounts.google.com/o/oauth2/v2/auth";
        };
        readonly scopes: {
            readonly description: "optional scopes for the authorization call";
            readonly type: "string";
            readonly defaultValue: "https://www.googleapis.com/auth/drive.readonly";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly ["drive.google.com"];
        };
        readonly responseType: {
            readonly description: "the type of response from the authorization endpoint";
            readonly type: "string";
            readonly defaultValue: "token";
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "Bearer";
        };
        readonly authEndpoint: {
            readonly description: "the authorization code endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly tokenEndpoint: {
            readonly description: "the token endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly needsPKCE: {
            readonly description: "boolean to indicate if the endpoint needs a PKCE code";
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        readonly clientId: {
            readonly description: "id for the OAuth application";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly scopes: {
            readonly description: "optional scopes for the authorization call";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly state: {
            readonly description: "optional state for the authorization call";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly responseType: {
            readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
            readonly type: "string";
            readonly defaultValue: "code";
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>, undefined>>>;
}, {
    readonly name: string;
    readonly description: string;
    readonly internetAccountId: string;
    readonly authHeader: string;
    readonly tokenType: string;
    readonly domains: string[];
    readonly toggleContents: React.ReactNode;
    readonly selectorLabel: string | undefined;
    readonly showInFileSelector: boolean;
} & {
    handlesLocation(location: UriLocation): boolean;
    readonly tokenKey: string;
} & {
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    storeToken(token: string): void;
    retrieveToken(): string | undefined;
    validateToken(token: string, _loc: UriLocation): Promise<string>;
} & {
    removeToken(): void;
    getToken(location?: UriLocation): Promise<string>;
} & {
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    fetchWithToken(loc: UriLocation | undefined, run: (token: string) => Promise<Response>): Promise<Response>;
    getPreAuthorizationInformation(location: UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        };
    }>;
} & {
    getFetcher(loc?: UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    openLocation(location: UriLocation): import("@gmod/range-cache-filehandle").RemoteFileWithRangeCache;
} & {
    readonly conf: import("../OAuthModel/configSchema.ts").OAuthInternetAccountConfig;
} & {
    readonly codeVerifierPKCE: string;
} & {
    readonly authEndpoint: string;
    readonly tokenEndpoint: string;
    readonly needsPKCE: boolean;
    readonly clientId: string;
    readonly scopes: string;
    readonly state: string;
    readonly responseType: 'token' | 'code';
    readonly refreshTokenKey: string;
    readonly authFlowParams: Record<string, string>;
} & {
    storeRefreshToken(refreshToken: string): void;
    removeRefreshToken(): void;
    retrieveRefreshToken(): string | undefined;
} & {
    postTokenGrant(grant: Record<string, string>, describeError: (response: Response) => Promise<string>): Promise<string>;
} & {
    exchangeAuthorizationForAccessToken(code: string, redirectUri: string): Promise<string>;
    exchangeRefreshForAccessToken(refreshToken: string): Promise<string>;
} & {
    validateTokenWithProbe(token: string, probe: (token: string) => Promise<Response>, describeError: (response: Response, reason?: string) => Promise<string>): Promise<string>;
    getTokenViaAuthFlow(): Promise<string>;
} & {
    getTokenFromUser(resolve: (token: string) => void, reject: (error: Error) => void): Promise<void>;
    validateToken(token: string, location: UriLocation): Promise<string>;
} & {
    /**
     * #getter
     * The FileSelector icon for Google drive
     */
    readonly toggleContents: import("react").JSX.Element;
    /**
     * #getter
     */
    readonly selectorLabel: string;
} & {
    /**
     * #method
     */
    getFetcher(location?: UriLocation): (input: RequestInfo, init?: RequestInitWithMetadata) => Promise<Response>;
    /**
     * #action
     */
    validateToken(token: string, location: UriLocation): Promise<string>;
} & {
    /**
     * #method
     */
    openLocation(location: UriLocation): GoogleDriveFile;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GoogleDriveOAuthStateModel = ReturnType<typeof stateModelFactory>;
export type GoogleDriveOAuthModel = Instance<GoogleDriveOAuthStateModel>;
