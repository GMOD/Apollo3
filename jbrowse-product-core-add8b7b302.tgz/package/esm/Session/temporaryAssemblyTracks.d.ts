import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
/**
 * Checks that a track config being written into a session or config list is one
 * something can still draw tomorrow.
 *
 * A config naming nothing but a temporary assembly is dead the moment its view
 * closes, and no list outside that view has anyone to sweep it — which is the
 * whole of ADR-084. A track only one view can draw carries its config on the
 * track instead (`showTrackGeneric`'s `inlineConf`), so reaching a session list
 * with one is the mistake, not the cleanup afterwards.
 *
 * **This reports a write, not a click.** The two flows a user can drive into it
 * are answered before they get here — the track menu greys its copy actions, and
 * `addTrackFromWidget` opens the track inline instead of adding it — so what
 * survives to report is a caller that had `inlineConf` available and did not
 * take it. That is the reading the message is written for.
 *
 * `console.error` and never `throw`, matching `assertDisplayContract`: these
 * writes happen inside launchers and menu handlers where an exception is caught
 * and reported as a failed track, which would hide the violation. The jest gate
 * (`config/jest/contractGate.js`) is what listens in tree; out of tree
 * `contractReports` does, once a host arms it.
 */
export declare function assertTrackConfOutlivesItsAssemblies(session: unknown, trackConf: AnyConfigurationModel | Record<string, unknown>, destination: string): void;
