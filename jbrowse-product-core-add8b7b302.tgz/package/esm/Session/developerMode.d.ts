import type { NotificationSink } from '@jbrowse/core/util/types';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
interface DeveloperModeHost extends IStateTreeNode, Pick<NotificationSink, 'notify'> {
    getPreference: (key: string) => unknown;
}
export declare function applyDeveloperMode(self: DeveloperModeHost): void;
export {};
