import type { AbstractSessionModel } from '@jbrowse/core/util';
export declare function formatRows(rows: [string, string[]][]): string;
export declare function alignRows(rows: [string, string[]][]): string;
declare const RefNameAliasesDialog: ({ assemblyName, session, onClose, }: {
    assemblyName: string;
    session: AbstractSessionModel;
    onClose: () => void;
}) => import("react").JSX.Element;
export default RefNameAliasesDialog;
