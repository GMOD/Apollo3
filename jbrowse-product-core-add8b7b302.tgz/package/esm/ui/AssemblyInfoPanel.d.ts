import type { AboutPanelProps } from './util.ts';
declare const AssemblyInfoPanel: ({ config, session, hideUris, }: AboutPanelProps & {
    hideUris?: boolean;
}) => import("react").JSX.Element | null;
export default AssemblyInfoPanel;
