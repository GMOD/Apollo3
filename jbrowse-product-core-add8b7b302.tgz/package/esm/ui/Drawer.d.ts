import type { DrawerPosition } from '@jbrowse/core/util';
/**
 * All the chrome needs of a session, narrowed the way
 * `PreferencesDialogSession` is: the drawer is the one widget surface an
 * embedder can mount against a session of their own shape.
 */
export interface DrawerChromeSession {
    drawerPosition: DrawerPosition;
    resizeDrawer: (distance: number, availableWidth?: number) => number;
}
/**
 * The drawer's chrome: the paper it sits on and the handle that resizes it.
 * Focus tracking is left to the caller through `ref`, since only the app shell
 * has a focused-view concept to wire it to.
 */
declare const Drawer: ({ session, children, ref, }: {
    session: DrawerChromeSession;
    children: React.ReactNode;
    ref?: React.Ref<HTMLDivElement>;
}) => import("react").JSX.Element;
export default Drawer;
