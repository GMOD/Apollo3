import type PluginManager from '@jbrowse/core/PluginManager';
import type { PluggableElementTypeGroup } from '@jbrowse/core/PluginManager';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
/**
 * A session snapshot that arrives from somewhere else — a share link, a desktop
 * "export to web" URL, a session.json — can name a pluggable type this build has
 * no plugin for. Every such collection is `types.map`/`types.array` over a bare
 * `pluggableMstType` union with no dispatcher, so one entry the union cannot
 * match throws `No type is applicable for the union` out of the `cast` in
 * `setSession` — outside the try that `filterSessionInPlace` sits in. The whole
 * session is lost, and jbrowse-web's fallback then advises the recipient to ask
 * for a link made with the Share button, which is often exactly what they were
 * sent.
 *
 * Two routes reach it and neither is exotic. A desktop export carries session
 * state built from desktop's own core plugins — `blat` registers
 * `UcscResultsWidget`, and every BLAT or in-silico PCR search leaves one in the
 * drawer — which jbrowse-web does not have (see
 * `scripts/check-core-plugin-sets.ts` for the exact relation between the
 * products' lists). And a runtime plugin that fails to load is already
 * tolerated: `notifyPluginLoadFailures` says the session opens without it, which
 * was untrue for any session actually using its types.
 *
 * So the node comes out of the tree and the session opens. `dropped` is what the
 * caller tells the user, which is the only part of this a person can act on.
 *
 * **The node is held, not discarded.** Taking it out of the tree is only half
 * the job: jbrowse-web autosaves `getSnapshot(session)` on a 400ms debounce
 * (`rootModel/persistence.ts`), so a recipient who merely opens a shared link
 * without the plugin writes the reduced session back over the stored row — and
 * reshares it that way. The removed nodes ride along under
 * `heldForMissingPlugins` instead, and a build that has the plugin puts them
 * back. Installing the plugin and reloading is then enough to get the session
 * whole again, which is what makes a plugin removable at all.
 *
 * **The session schema is read off the session MST type, not written down here.**
 * One walk descends `(type, snapshot)` in lockstep: at any `types.array` or
 * `types.map` whose element type is one of the `pluggableMstType` unions it
 * admits, holds or restores each entry, and everywhere else it recurses
 * structurally. That is what reaches a synteny view's `levels[].tracks` and the
 * session's `connectionInstances`, which a hand-written list of `views` /
 * `tracks` / `displays` / `widgets` did not, and what will reach the next
 * container someone adds without anyone editing this file.
 *
 * **A node is held only when all three tests fail**: its `type` names no
 * registered element, no element declares it as an `alias`, and
 * the real MST union refuses the snapshot. The last two are what keep a renamed
 * type alive — an element can declare `aliases`, and a model's own
 * `preProcessSnapshot` can rewrite the type literal
 * (`LinearMultiSampleVariantDisplay` does both for the old
 * `MultiLinearVariantDisplay`), neither of which the registry's names show. The
 * first is what keeps this from quietly swallowing a *malformed* snapshot of a
 * type this build does have: that still throws, exactly as before, because
 * holding it would hide a real bug behind a message about plugins.
 */
type Group = PluggableElementTypeGroup;
export interface UnbuildableNode {
    group: Group;
    type: string;
    cascade?: true;
}
/**
 * One node taken out of the tree, with the anchor that puts it back.
 *
 * The anchor is a parent **id** plus a position, never a path: paths are
 * index-based and every edit the recipient makes shifts them, while a view id
 * and a track id are stable for as long as the container exists. A held node
 * whose parent the recipient has since deleted is not restorable and is not
 * meant to be — the container going is the user saying so.
 */
export interface HeldNode {
    group: Group;
    /** map key, for a node that came out of a `types.map` */
    key?: string;
    /**
     * id of the nearest enclosing node that has one — the view a track came out
     * of, the track a display came out of, the synteny level a level's track came
     * out of. Absent for a container on the session itself.
     */
    parent?: string;
    /**
     * position in the list it came out of, so a restore lands where it was.
     * Absent for a map entry, which `key` places instead.
     */
    index?: number;
    snapshot: Record<string, unknown>;
}
/**
 * Takes the session-snapshot nodes whose pluggable type this plugin manager
 * cannot build out of the tree and holds them under `heldForMissingPlugins`,
 * and puts back the ones already held that it now can build — in one walk of
 * the session type, so the two can never disagree about where a node lives.
 * Returns the snapshot unchanged (by identity) when there is nothing to do
 * either way, which is every session this build produced itself.
 */
export declare function pruneUnbuildableNodes(snapshot: Record<string, unknown>, pluginManager: PluginManager, sessionModelType: IAnyType): {
    snapshot: Record<string, unknown>;
    dropped: UnbuildableNode[];
};
/**
 * The user-facing summary of one prune, or undefined when nothing was dropped.
 * Names the missing types rather than counting nodes: the plugin a person has to
 * install is the actionable half, and one missing display type can take several
 * nodes with it. Says what a person can do about it, because the nodes are not
 * gone — they ride along under `heldForMissingPlugins` and come back the moment
 * a build that has the plugin opens the session.
 */
export declare function describeUnbuildableNodes(dropped: UnbuildableNode[]): string | undefined;
export {};
