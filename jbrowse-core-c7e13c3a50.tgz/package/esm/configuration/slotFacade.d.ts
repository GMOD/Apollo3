import type PluginManager from '../PluginManager.ts';
import type { ConfigSlotDefinition, ConfigSlotType } from './configurationSlot.ts';
import type { AnyConfigurationModel } from './types.ts';
/**
 * Whether `slotName` on a config node is a slot (vs a nested sub-schema or a
 * string/number constant).
 */
export declare function isConfigurationSlot(node: AnyConfigurationModel, slotName: string): boolean;
/**
 * Run `node`'s own schema `preProcessSnapshot` over a partial bag of slot
 * values headed for that config.
 *
 * A config.json snapshot gets this for free on `create`, but the session/URL
 * path writes slots one `setSlot` at a time onto an already-created config, so
 * without this a schema's shorthand expansions and legacy-key migrations apply
 * to `config.json` and silently no-op in a session spec, share link, or embed —
 * the surfaces that are supposed to speak the same vocabulary. The hooks are
 * written to normalize whatever subset of keys they're handed, so a partial bag
 * is the same shape they already tolerate.
 */
export declare function preProcessSlotValues(node: AnyConfigurationModel, values: Record<string, unknown>): Record<string, unknown>;
/**
 * The duck-typed object the config editor's leaf components consume. They never
 * touch MST internals — only this shape (see ColorEditor.test.tsx, which passes
 * a plain object). It is built from `(parentNode, slotName)` + the schema
 * metadata table. Collection editors edit immutably via `set` (build a new
 * array/map and assign it).
 */
export interface SlotFacade {
    name: string;
    description: string;
    type: ConfigSlotType;
    contextVariable: string[];
    defaultValue: unknown;
    /**
     * For a `promotable` slot, the value its unset state resolves to when nothing
     * is promoted (see `promotableResolve.ts`). Undefined on a plain slot, whose
     * `defaultValue` is already the concrete value.
     *
     * Here because a promotable slot's `defaultValue` is always the `undefined`
     * inherit sentinel, so an editor rendering `defaultValue` for an unset slot
     * shows nothing at all — for a `maybeBoolean` that reads as a concrete
     * `false`, which is wrong for every slot whose base is `true`. The editor
     * still cannot see the *session* tier of the cascade (its target is often a
     * detached config node), so this is the honest answer it can give: what unset
     * means with nothing promoted.
     */
    promotedBase?: unknown;
    /** enum choices, present only for `stringEnum`/`maybeStringEnum` slots */
    choices?: string[];
    pluginManager: PluginManager;
    readonly value: unknown;
    /**
     * Whether the slot holds a non-default value. Each slot is `stripDefault`-
     * wrapped, so an at-default slot is omitted from the config snapshot — the
     * same signal the persistence/delta layer uses (robust for map/array slots
     * where a live-value `deepEqual` against the plain default would misfire). For
     * a promotable slot, "non-default" means customized rather than inheriting.
     */
    readonly modified: boolean;
    set: (val: unknown) => void;
}
/**
 * Look up a slot's metadata (type/description/defaultValue/contextVariable/
 * model) from the schema-type table stashed by ConfigurationSchema. Includes
 * slots inherited via `baseConfiguration`, which are merged into the table at
 * schema construction.
 */
export declare function getSlotDefinition(node: AnyConfigurationModel, slotName: string): ConfigSlotDefinition;
export declare function makeSlotFacade(node: AnyConfigurationModel, slotName: string): SlotFacade;
