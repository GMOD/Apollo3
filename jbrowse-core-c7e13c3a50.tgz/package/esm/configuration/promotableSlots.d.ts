import type { AnyConfigurationModel } from './types.ts';
export declare function promotableSlotNames(config: AnyConfigurationModel): ReadonlySet<string>;
