import type { PluginDefinition } from './pluginDefinitions.ts';
import type { JBrowsePlugin } from './util/types/index.ts';
export declare const TRUSTED_PLUGIN_URL_PREFIXES: string[];
export declare function fetchPlugins(): Promise<{
    plugins: JBrowsePlugin[];
}>;
export declare function checkPluginsAgainstStore(pluginsToCheck: PluginDefinition[], storePlugins: {
    plugins: JBrowsePlugin[];
}): boolean;
export declare function checkPlugins(pluginsToCheck: PluginDefinition[]): Promise<boolean>;
