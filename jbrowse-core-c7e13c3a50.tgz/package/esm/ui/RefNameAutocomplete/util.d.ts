import BaseResult from '../../TextSearch/BaseResults.ts';
export declare const ADORNMENT_RESERVE_PX = 70;
export declare const HELP_BUTTON_RESERVE_PX = 30;
export declare const MAX_OPTIONS = 100;
export interface Option {
    isLimit?: boolean;
    result: BaseResult;
}
export declare function cap(options: Option[]): Option[];
export declare function getRefNameOptions(regions: readonly {
    refName: string;
}[], inputValue: string): Option[];
export declare function getDeduplicatedResult(results: BaseResult[]): Option[];
export declare function coerceToResult(option: string | Option): BaseResult;
export declare function getOptionLabel(option: string | Option): string;
export declare function getInputWidth(value: string, minWidth: number, maxWidth: number, adornmentWidth?: number): number;
