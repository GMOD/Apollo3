import type { MenuItemsGetter } from './MenuTypes.ts';
import type { PopoverOrigin } from '@mui/material';
export type { MenuItemsGetter } from './MenuTypes.ts';
interface CascadingMenuProps {
    onMenuItemClick: (callback: () => void) => void;
    closeAfterItemClick?: boolean;
    menuItems: MenuItemsGetter;
    open: boolean;
    onClose: () => void;
    anchorEl?: Element | null;
    anchorOrigin?: PopoverOrigin;
    transformOrigin?: PopoverOrigin;
    anchorReference?: 'anchorEl' | 'anchorPosition' | 'none';
    anchorPosition?: {
        top: number;
        left: number;
    };
    style?: React.CSSProperties;
}
declare const CascadingMenu: ({ onMenuItemClick, closeAfterItemClick, menuItems, open, onClose, anchorEl, anchorOrigin, transformOrigin, anchorReference, anchorPosition, style, }: CascadingMenuProps) => import("react").JSX.Element;
export default CascadingMenu;
