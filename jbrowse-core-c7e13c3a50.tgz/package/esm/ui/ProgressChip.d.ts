/**
 * Bottom-right progress chip for work running while usable content is already on
 * screen: a refetch over stale geometry (dotplot, linear synteny), or a
 * background job that is not a fetch at all (clustering, via `DisplayChrome`).
 * It stays small and out of the way instead of masking the canvas the way the
 * full loading overlay would, and surfaces the statusCallback message plus a
 * determinate bar when the phase reports progress.
 *
 * Pure presentation — the caller owns the gate (its own `refetching` getter, or
 * the chrome's "a status is set while the phase is ready") and the containing
 * element owns the positioning context.
 */
declare const ProgressChip: ({ statusMessage, statusProgress, }: {
    statusMessage?: string;
    statusProgress?: number;
}) => import("react").JSX.Element;
export default ProgressChip;
