import type { Pin } from '../configuration/promotableDefaults.ts';
import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
export declare function promotableToggleItem({ label, helpText, checked, onToggle, pin, keepMenuOpen, }: {
    label: string;
    helpText?: string;
    checked: boolean;
    onToggle: () => void;
    pin: Pin;
    keepMenuOpen?: boolean;
}): CheckboxMenuItem;
export declare function promotableRadioItem({ label, subLabel, helpText, checked, onClick, pin, keepMenuOpen, }: {
    label: string;
    subLabel?: string;
    helpText?: string;
    checked: boolean;
    onClick: () => void;
    pin?: Pin;
    keepMenuOpen?: boolean;
}): RadioMenuItem;
