import type { JBrowsePalette, ThemeInput } from './palette.ts';
/**
 * JBrowse's grid unit, in px. Half Material's 8, because a genome browser packs
 * far more controls into a toolbar than a Material layout expects.
 */
export declare const DEFAULT_SPACING = 4;
/** Base font size, in px. Material's default is 14; JBrowse's chrome is denser. */
export declare const DEFAULT_FONT_SIZE = 12;
/** What `pxToRem` assumes the `<html>` font size is. */
export declare const HTML_FONT_SIZE = 16;
export declare const DEFAULT_FONT_FAMILY = "\"Roboto\", \"Helvetica\", \"Arial\", sans-serif";
export declare const DEFAULT_BORDER_RADIUS = 4;
/**
 * One entry of the type scale. `letterSpacing` is absent for a non-Roboto
 * family rather than reset to `normal`, which is what MUI does and what lets a
 * host's own tracking through.
 */
export interface TypeVariant {
    fontFamily: string;
    fontWeight: number | string;
    fontSize: string;
    lineHeight: number;
    letterSpacing?: string;
}
export interface JBrowseTypography {
    fontFamily: string;
    fontSize: number;
    htmlFontSize: number;
    fontWeightLight: number | string;
    fontWeightRegular: number | string;
    fontWeightMedium: number | string;
    fontWeightBold: number | string;
    pxToRem: (size: number) => string;
    body1: TypeVariant;
    body2: TypeVariant;
}
/**
 * What a `makeStyles` block is handed.
 *
 * Deliberately a subset of Material UI's `Theme` rather than a copy of it: it
 * carries what the 268 call sites read and nothing else, so anything reaching
 * further is a compile error naming the file rather than a silent dependency on
 * a component library. `transitions`, `zIndex` and `shadows` are the three that
 * used to be reached for; a literal reads better at each of those five sites,
 * and `ui/zIndexes.ts` already owns the layering that matters.
 */
export interface JBrowseStyleTheme {
    palette: JBrowsePalette;
    spacing: (...args: number[]) => string;
    shape: {
        borderRadius: number;
    };
    typography: JBrowseTypography;
}
export interface TypographyInput {
    fontFamily?: string;
    fontSize?: number;
    htmlFontSize?: number;
    fontWeightLight?: number | string;
    fontWeightRegular?: number | string;
    fontWeightMedium?: number | string;
    fontWeightBold?: number | string;
}
/**
 * The non-color half of what a theme may declare — `spacing` and `typography`,
 * the two documented in the theming guide's "Sizing".
 *
 * Both admit a function arm, and that is not overbuilding: the config `theme`
 * slot is typed as MUI's `ThemeOptions`, which has one, so this has to accept
 * it for a caller to hand `themeOptions` straight in. Neither survives JSON, so
 * neither reaches here from a config; `resolveStyleTheme` falls back to the
 * defaults if one somehow does, rather than calling it.
 */
export interface SizingInput {
    spacing?: number | string | readonly (number | string)[] | ((abs: never) => unknown);
    typography?: TypographyInput | ((palette: never) => unknown);
}
/**
 * A number is a grid unit and an array is a lookup table indexed by the
 * argument, which is Material's contract and what a JSON config slot can
 * express. An array entry that is already a string carries its own unit.
 */
export declare function createSpacing(input: SizingInput['spacing']): (...args: number[]) => string;
export declare function createTypography(input?: TypographyInput): {
    fontFamily: string;
    fontSize: number;
    htmlFontSize: number;
    fontWeightLight: string | number;
    fontWeightRegular: string | number;
    fontWeightMedium: string | number;
    fontWeightBold: string | number;
    pxToRem: (size: number) => string;
    body1: TypeVariant;
    body2: TypeVariant;
};
/** A theme, as far as the style theme is concerned: colors plus sizing. */
export interface StyleThemeInput extends ThemeInput, SizingInput {
}
/** What `resolveStyleTheme` reads — `resolvePalette`'s arguments, plus sizing. */
export interface StyleThemeArgs {
    configTheme?: StyleThemeInput;
    themeName?: string;
    extraThemes?: Record<string, StyleThemeInput>;
}
/**
 * Build the style theme for a set of theme args.
 *
 * The colors come from `resolvePalette`, so this and the MUI theme cannot
 * disagree about them by construction. Sizing follows the same rule the palette
 * does: only the `default` theme draws from the config, since the named presets
 * are fixed.
 */
export declare function resolveStyleTheme(args?: StyleThemeArgs): JBrowseStyleTheme;
/**
 * The style theme a component gets with no provider above it, resolved once
 * rather than per call — a fresh object each render would defeat the
 * memoization every `makeStyles` hook depends on.
 */
export declare const defaultStyleTheme: JBrowseStyleTheme;
