import type { Pin } from '../configuration/promotableDefaults.ts';
import type { SliderScale } from './sliderScale.ts';
export declare const SizeSliderRow: ({ title, getValue, min, max, step, scale, format, isDefault, commitOnRelease, onChange, onReset, pin, }: {
    title: string;
    getValue: () => number;
    min: number;
    max: number;
    step: number;
    scale: SliderScale;
    format: (n: number) => string;
    isDefault: boolean;
    commitOnRelease?: boolean;
    onChange: (n: number) => void;
    onReset: () => void;
    pin?: Pin;
}) => import("react").JSX.Element;
