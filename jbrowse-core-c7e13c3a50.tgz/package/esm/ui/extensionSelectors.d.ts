/**
 * The track-scoping fields every extension point selector shares. Both points
 * they scope (`Core-replaceWidget`, `Core-extraFeaturePanel`) fire for every
 * track, so without a selector a contribution applies to all of them.
 */
export interface TrackSelectorFields {
    /** track type, e.g. `'VariantTrack'`, usually what "for my tracks" means */
    trackType?: string | string[];
    /** track id; a plain string also matches the user's copies of that track */
    trackId?: string | RegExp | (string | RegExp)[];
}
/** the model fields a declarative selector can match on */
export interface SelectableModel {
    type?: string;
    trackId?: string;
    trackType?: string;
}
/**
 * Whether `model` satisfies every declarative field of `select`. A selector's
 * `where` predicate is applied by its own helper, which knows the props type it
 * receives.
 */
export declare function selectorMatchesModel(select: (TrackSelectorFields & {
    widgetType?: string | string[];
}) | undefined, model: SelectableModel): boolean;
