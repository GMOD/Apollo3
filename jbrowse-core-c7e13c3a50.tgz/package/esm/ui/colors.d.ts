declare const category10: string[];
declare const set1: string[];
export declare const paletteColors: {
    category10: string[];
    dark2: string[];
    ggplot2Colors3: string[];
    ggplot2Colors4: string[];
    ggplot2Colors5: string[];
    ggplot2Colors6: string[];
    set1: string[];
    set2: string[];
    tableau10: string[];
};
/**
 * Deterministic non-negative 32-bit hash of a string.
 */
export declare function hashString(str: string): number;
/**
 * Stable category10 color for a sequence name, via `hashString`. Lives here
 * rather than in a view-specific package because several unrelated displays
 * paint by refName — the synteny/dotplot views and the alignments display's
 * mateRefName scheme — and a contig must get the same color in all of them.
 */
export declare function getQueryColor(queryName: string): string;
export { category10, set1 };
