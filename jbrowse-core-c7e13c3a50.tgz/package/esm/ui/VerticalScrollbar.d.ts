import type React from 'react';
/**
 * How much of a display's right edge this occupies while it is drawn.
 *
 * Exported because the things that have to *clear* it are drawn by the displays
 * that mount it, not by this file: the bottom-right indicator row and the
 * alignments coverage axis label. Both kept a private copy of the number (and
 * the alignments indicator row kept none at all, so its chips were drawn over
 * the thumb), which is a copy that can only be checked by looking at two files
 * at once.
 */
export declare const VERTICAL_SCROLLBAR_WIDTH = 12;
/**
 * Draggable vertical scrollbar overlay for canvas-backed displays that scroll
 * their content via a `scrollTop` value (alignments pileup, variant matrix).
 * Renders nothing when the content fits the viewport. The thumb geometry and
 * the drag-to-scroll mapping live here so the consumers don't each re-derive
 * them; the wheel handling stays per-display (their gesture semantics differ).
 *
 * Deliberately NOT a keyboard tab stop: the surrounding views have no working
 * keyboard navigation to reach the scrolled content anyway, so a per-track
 * `tabIndex` would only add noise to the tab order. The `role="scrollbar"` +
 * `aria-value*` semantics are kept — they cost nothing and expose scroll
 * position to pointer/voice assistive tech.
 */
export default function VerticalScrollbar({ scrollTop, setScrollTop, viewportHeight, contentHeight, controlsId, top, }: {
    scrollTop: number;
    setScrollTop: (n: number) => void;
    viewportHeight: number;
    contentHeight: number;
    /** `id` of the scrolled viewport element, for `aria-controls`. */
    controlsId: string;
    /** Track offset from the top, for displays with a sticky band above it. */
    top?: number;
}): React.JSX.Element | null;
