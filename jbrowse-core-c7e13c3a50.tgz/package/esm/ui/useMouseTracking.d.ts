export interface MouseState {
    x: number;
    y: number;
    clientX: number;
    clientY: number;
}
/**
 * The pointer position, as something to read rather than something you hold.
 *
 * `useMouseTracking` hands this back instead of the position itself, and that
 * indirection is the entire point — see there.
 */
export interface MouseTracker {
    subscribe: (onStoreChange: () => void) => () => void;
    getSnapshot: () => MouseState | undefined;
}
/**
 * Container-relative mouse position for the overlays that follow the pointer
 * (`Crosshairs`, tooltips), coalesced to one update per frame.
 *
 * The position is measured against the box of whatever element the handlers are
 * bound to, which is what the overlays are positioned in — off `currentTarget`,
 * so there is no ref to pass and no way to bind the two to different elements.
 * A display that also hit-tests takes `onMove`, so its hit and its guides come
 * off one measurement in one frame instead of two pointer paths that have to
 * agree.
 *
 * **It returns a `mouseTracker` rather than the position, and that is the
 * load-bearing part.** Its one caller is `DisplayChromeBase`, which owns the
 * container the handlers bind to — so if the position were state here, every
 * mouse move would re-render the chrome itself (re-running
 * `useRenderingBackend`), the status container with a fresh inline `style`
 * object, all three overlays, and only then the body that actually wanted the
 * coordinate. That is a whole display's chrome repainting because the cursor
 * moved a pixel over it; it cost a full document `Layout` plus three `Paint`s
 * per mousemove on the wiggle displays, back when each display called this hook
 * itself and every one of them had it.
 *
 * So the position is published instead, and whoever wants it calls
 * `useMouseState(mouseTracker)` — from inside the chrome's body, where the
 * overlays live. Re-rendering then starts at the component that reads it.
 * Passing the tracker down a prop is free; passing `mouseState` down is the bug.
 */
export declare function useMouseTracking(onMove?: (state?: MouseState) => void): {
    mouseTracker: MouseTracker;
    handleMouseMove: (event: React.MouseEvent) => void;
    handleMouseLeave: () => void;
};
/**
 * Read the tracked pointer position. Call this in the component that draws the
 * cursor-following thing, not in the one that bound the handlers — see
 * `useMouseTracking`.
 */
export declare function useMouseState(tracker: MouseTracker): MouseState | undefined;
