import type { AbstractSessionModel } from '../util/index.ts';
export declare function instanceScopedKey(prefix: string, suffix: string): string;
/**
 * Tracks the assembly chosen in an import form and resolves the outcomes the
 * form renders from: `assemblyError` (failed, or nothing configured), `regions`
 * (ready), or neither (still loading). The user's choice is stored as an
 * override and re-resolved against the live assembly list every render, so it
 * always names a currently-configured assembly even as assemblies load in, get
 * removed, or when a remembered choice is no longer valid. Passing a
 * `localStorageKey` persists the choice across reloads. Shared by the LGV and
 * circular-view import forms.
 */
export declare function useAssemblySelection(session: AbstractSessionModel, localStorageKey?: string): {
    selectedAssemblyName: string | undefined;
    setSelectedAssemblyName: (value: string | ((val: string | undefined) => string | undefined) | undefined) => void;
    assembly: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("../assemblyManager/refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("../assemblyManager/assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("../assemblyManager/refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("../assemblyManager/refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("../assemblyManager/refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("../assemblyManager/assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("../rpc/RpcManager.ts").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("../assemblyManager/refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("../assemblyManager/refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("../assemblyManager/assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("../assemblyManager/refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("../assemblyManager/refNameMaps.ts").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("../util/progress.ts").RpcStatus): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("../assemblyManager/refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("../assemblyManager/assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("../rpc/RpcManager.ts").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("../assemblyManager/refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    assemblyError: unknown;
    regions: import("../assemblyManager/assembly.ts").BasicRegion[] | undefined;
};
