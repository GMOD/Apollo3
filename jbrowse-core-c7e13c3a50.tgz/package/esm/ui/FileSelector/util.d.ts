import type { BaseInternetAccountModel } from '../../pluggableElementTypes/index.ts';
import type { FileLocation } from '../../util/index.ts';
export declare const MAX_LABEL_LENGTH = 5;
export declare function isAdminMode(): boolean;
export declare function truncateLabel(str: string): string;
export declare function getAccountLabel(account: BaseInternetAccountModel): string | number | bigint | true | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | Iterable<import("react").ReactNode> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | import("react").ReactPortal | null | undefined> | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>>;
export declare function getInitialSourceType(location?: FileLocation): string;
export declare function dirFromPath(filePath: string): string | undefined;
export declare function addAccountToLocation(location: FileLocation, account?: BaseInternetAccountModel): FileLocation;
