/** Material UI's `zIndex.drawer`: above the app bar (1100), below a modal (1300). */
export declare const DRAWER_Z_INDEX = 1200;
/**
 * Material UI's `zIndex.tooltip`, for chrome that must clear every Material
 * surface without leaving that scale — the coordinate guide label, which is
 * fixed-position and follows the cursor across the whole app.
 */
export declare const MUI_TOOLTIP_Z_INDEX = 1500;
/**
 * Hover tooltips (see BaseTooltip). Above the app chrome so a tooltip near a
 * track edge isn't clipped by the drawer or the view's own overlays.
 */
export declare const TOOLTIP_Z_INDEX = 100000;
/**
 * Right-click menus (see ContextMenu). One above the tooltip: the menu is
 * something the user just asked for, so nothing may cover it. Handlers still
 * drop the hover when opening a menu — this is what keeps a tooltip that
 * outlives that clear (a neighbouring display's, say) from landing on top.
 */
export declare const CONTEXT_MENU_Z_INDEX: number;
