import type { MenuItemPin } from './MenuTypes.ts';
export declare function PinAdornment({ pin }: {
    pin: MenuItemPin;
}): import("react").JSX.Element;
