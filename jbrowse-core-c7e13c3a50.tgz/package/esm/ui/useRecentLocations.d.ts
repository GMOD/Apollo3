/**
 * Remembers the locations recently opened from an import form, most-recent
 * first and deduplicated, scoped per assembly (and per host/path/config like
 * the remembered assembly). Without an assembly there is nothing to scope the
 * key to, so the list stays in memory only.
 */
export declare function useRecentLocations(assemblyName?: string): {
    recentLocations: string[];
    addRecentLocation: (loc: string) => void;
    clearRecentLocations: () => void;
};
