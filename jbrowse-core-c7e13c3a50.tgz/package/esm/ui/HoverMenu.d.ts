import type { PopoverOrigin } from '@mui/material';
declare function HoverMenu({ open, anchorEl, onClose, anchorOrigin, transformOrigin, children, }: {
    open: boolean;
    anchorEl: HTMLElement | null;
    onClose: () => void;
    anchorOrigin: PopoverOrigin;
    transformOrigin: PopoverOrigin;
    children: React.ReactNode;
}): import("react").JSX.Element;
export default HoverMenu;
