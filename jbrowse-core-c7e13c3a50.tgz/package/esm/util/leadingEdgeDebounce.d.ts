export declare function leadingEdgeDebounce(delay: number): {
    scheduler: (run: () => void) => void;
    prime(): void;
};
