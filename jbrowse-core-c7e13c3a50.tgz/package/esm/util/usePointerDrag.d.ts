import type React from 'react';
/**
 * Pointer-capture drag lifecycle shared by draggable UI (resize handles,
 * scrollbars, rubberbands, pan). On pointerdown it captures the pointer on the
 * event's element, so the returned `onPointerMove`/`onPointerUp` fire on that
 * same element even when the pointer leaves it — no window/document listeners,
 * and the capture auto-releases if the element unmounts mid-drag.
 *
 * `onDrag` gets the live React pointer event. React nulls `event.currentTarget`
 * after the handler returns, so snapshot `clientX`/`clientY` (and any target
 * geometry) into locals synchronously before deferring work into a
 * requestAnimationFrame.
 */
export declare function usePointerDrag({ onDragStart, onDrag, onDragEnd, }: {
    onDragStart?: (event: React.PointerEvent) => void;
    onDrag: (event: React.PointerEvent) => void;
    onDragEnd?: (event: React.PointerEvent) => void;
}): {
    onPointerDown: (event: React.PointerEvent) => void;
    onPointerMove: (event: React.PointerEvent) => void;
    onPointerUp: (event: React.PointerEvent) => void;
    onPointerCancel: (event: React.PointerEvent) => void;
};
