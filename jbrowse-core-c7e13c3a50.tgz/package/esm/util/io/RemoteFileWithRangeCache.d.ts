import { RemoteFile } from 'generic-filehandle2';
/**
 * Drop every chunk no read has touched for {@link CACHE_IDLE_TIMEOUT_MS}.
 *
 * Safe to call at any moment, including mid-fetch, and that is not an accident:
 * `getCachedRange` holds a strong local reference to every chunk it will
 * assemble from before its first await, precisely so that eviction underneath it
 * is harmless. A chunk dropped here that somebody still wants is re-fetched.
 *
 * Deliberately narrower than {@link clearCache}: it touches neither `inFlight`
 * nor `queue`, whose entries are by definition active, and it keeps `sizeCache`,
 * which is one number per URL and costs a round trip to re-derive.
 *
 * Exported so a caller can reclaim on its own schedule — a tab going hidden,
 * say — rather than only on the interval. The interval is what makes this work
 * for the case it exists for, though: an idle consumer is calling nothing, so a
 * lazy check inside `getCached` would never fire for exactly the reader who has
 * walked away.
 */
export declare function sweepIdleCache(): void;
export declare function clearCache(): void;
export declare class RemoteFileWithRangeCache extends RemoteFile {
    stat(): Promise<{
        size: number;
    }>;
    private fetchRange;
    /**
     * Fetch one contiguous run of missing chunks as a single range request, and
     * publish a promise for each of its chunks. Publication is synchronous —
     * before the request is awaited — so a read planned while this is in flight
     * awaits these chunks instead of asking for the same bytes again.
     */
    private fetchRun;
    /**
     * Register a reader's interest in a run, so its request survives until that
     * reader has given up too.
     *
     * A reader with **no signal cannot give up**, so it pins the run: there is no
     * longer any set of aborts that should stop it. That is the honest reading of
     * a caller that never asked to be cancellable, and it means one signal-free
     * read makes that request uncancellable for everyone sharing it.
     */
    private joinRun;
    /**
     * Await a chunk fetch another read already had in flight.
     *
     * Sharing one fetch between reads is what makes a row of adjacent genomic
     * blocks cheap. It used to mean another reader's `AbortSignal` could reject a
     * chunk this read still needed, which was handled by re-issuing the fetch —
     * correct, but it threw away a 256 KiB request that was already in flight and
     * that somebody still wanted. Joining the run's reference count instead means
     * the request is simply not cancelled while anyone is still waiting on it, so
     * there is nothing to re-issue. `@gmod/bam` and `@gmod/cram` do the same at
     * their own cache layers.
     */
    private joinChunk;
    private getCachedRange;
    fetch(url: string | RequestInfo, init?: RequestInit): Promise<Response>;
}
