export type Color = number;
export declare const OFFSET_R = 24;
export declare const OFFSET_G = 16;
export declare const OFFSET_B = 8;
export declare const OFFSET_A = 0;
/**
 * Creates a new color from the given RGBA components.
 * Every component should be in the [0, 255] range.
 */
export declare function newColor(r: number, g: number, b: number, a: number): number;
/**
 * Creates a new color from the given number value, e.g. 0x599eff.
 */
export declare function from(color: number): number;
/**
 * Turns the color into its equivalent number representation.
 * This is essentially a cast from int32 to uint32.
 */
export declare function toNumber(color: Color): number;
export declare function getRed(c: Color): number;
export declare function getGreen(c: Color): number;
export declare function getBlue(c: Color): number;
export declare function getAlpha(c: Color): number;
export declare function setRed(c: Color, value: number): number;
export declare function setGreen(c: Color, value: number): number;
export declare function setBlue(c: Color, value: number): number;
export declare function setAlpha(c: Color, value: number): number;
