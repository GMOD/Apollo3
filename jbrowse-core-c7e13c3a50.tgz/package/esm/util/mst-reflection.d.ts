import type { IAnyType, IModelReflectionPropertiesData, ISimpleType, UnionStringArray } from '@jbrowse/mobx-state-tree';
export interface ILiteralType<T> extends ISimpleType<T> {
    value: T;
}
/**
 * get the inner type of an MST optional, refinement, array, map, or late type
 */
export declare function getSubType(type: IAnyType): IAnyType;
/**
 * get the array of the subtypes in a union (drills through optional/refinement/
 * late wrappers that inherit the union flag)
 */
/**
 * get the type of one of the properties of the given MST model type
 */
export declare function getPropertyType(type: IModelReflectionPropertiesData, propertyName: string): IAnyType;
/**
 * get the default value out of an MST optional type
 */
export declare function getDefaultValue(type: IAnyType): any;
export type IEnumerationType<T extends string> = ISimpleType<UnionStringArray<T[]>>;
/** get the string values of an MST enumeration type */
export declare function getEnumerationValues(type: IAnyType): string[];
export declare function resolveLateType(maybeLate: IAnyType): IAnyType;
export { getUnionSubtypes as getUnionSubTypes } from '@jbrowse/mobx-state-tree';
