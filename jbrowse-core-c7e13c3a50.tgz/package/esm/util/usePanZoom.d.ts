import type { WheelZoomView } from './wheelZoom.ts';
import type React from 'react';
/**
 * What the gestures need off a view: `bpPerPx`/`zoomTo`/`horizontalScroll` from
 * WheelZoomView, plus the scroll-to-zoom preference.
 *
 * Duck-typed rather than taking a model, like the rest of the wheel-zoom layer.
 *
 * **`scrollZoom` belongs to the view, not to a piece of React state of your
 * own.** Displays that scroll vertically inside themselves — an alignments
 * pileup is the one you hit first — consult the same flag to decide whether the
 * plain wheel is already spoken for, so a private copy that disagrees gets you
 * both at once: the pileup scrolls its reads *and* the view zooms under the
 * cursor. It is read at event time, so flipping it takes effect on the next
 * wheel event with nothing rebound.
 */
export interface PanZoomView extends WheelZoomView {
    scrollZoom?: boolean;
}
/**
 * Wheel zoom and side-scroll, bound to `ref` for as long as the component
 * lives.
 *
 * The listener is registered on the element directly and non-passively, which
 * is not a style preference: React registers `wheel` at the root as a *passive*
 * listener, so a handler installed through the `onWheel` prop cannot
 * `preventDefault`, and the gesture would drive the page out from under you at
 * the same time as it drove the view.
 *
 * `onModifierNeeded` is the controller's `onUnhandled` — the user wheeled
 * expecting a zoom and got nothing, because scroll-to-zoom is off and no
 * modifier was held. That mode's well-known failure is that it is
 * undiscoverable, and this is the hook for the prompt that fixes it
 * (`useScrollZoomHint` builds one on top). Nothing else can see the moment:
 * doing nothing leaves no trace on the view. It is handed the event because a
 * prompt worth showing is shown where the user is looking, and the wheel is the
 * only thing that knows where that is.
 */
export declare function useWheelZoom(ref: React.RefObject<HTMLElement | null>, view: PanZoomView, onModifierNeeded?: (event: WheelEvent) => void): void;
/**
 * Binds the view's wheel gestures and, when a wheel plainly meant "zoom" and
 * did nothing, raises the prompt that says so — the discoverability half of
 * scroll-to-zoom being off by default.
 *
 * The signal is the controller's `onUnhandled`: a vertical wheel over the view,
 * scroll-to-zoom off, no modifier, and nothing inside the view having already
 * claimed the gesture. That is a statement of intent rather than a guess about
 * one, which is why the prompt can be gated on it instead of shown to everyone
 * on first visit — nobody who wasn't reaching for zoom ever sees it.
 *
 * Then gated a second time on whether the page actually scrolled. If it did,
 * nothing was lost and there is nothing to say — that is the case
 * scroll-to-zoom being off is *for*, and the prompt has no business arguing with
 * it. Only a wheel that moved nothing at all raises it.
 *
 * The gate is deliberately "did it scroll", not "could it scroll". They sound
 * interchangeable and are not: jbrowse-web's view container overflows its
 * viewport by a couple of hundred pixels with a *single* alignments track open,
 * so a can-it-scroll test is true on nearly every page and the prompt would
 * never appear. Did-it-scroll also lands the behavior in the right place on its
 * own — someone on a long page scrolls freely and sees nothing, and is offered
 * the zoom once scrolling has run out of page to give.
 *
 * And it is asked per wheel rather than per gesture, which matters for the exact
 * case this exists to catch: scrolling to the bottom of a view and continuing to
 * push is one unbroken run of wheel events, and judging the run as a whole lets
 * its scrolling first half acquit its dead second half.
 *
 * How often it may fire is the caller's to decide, through `enabled`/`onShow`.
 * That policy is deliberately not here: the budget worth enforcing is
 * session-wide (JBrowse spends one across every view — see the session's
 * `canShowScrollZoomHint`), and this hook is duck-typed on the view, like the
 * rest of the wheel-zoom layer, so it can't see a session and shouldn't learn
 * to.
 *
 * This is the state machine on its own, for a caller that binds the wheel some
 * other way — the synteny ribbon band drives one controller across a whole
 * stack of views, so it hands `noteDeadWheel` to `createWheelZoomController`'s
 * `onUnhandled` directly. A caller with a plain element and one view wants
 * `useScrollZoomHint` below, which binds the gestures too.
 */
export declare function useScrollZoomHintState({ lingerMs, enabled, onShow, }?: {
    lingerMs?: number;
    /** false to stop raising it at all — a spent budget, usually */
    enabled?: boolean;
    /** one raise, for the caller to charge against whatever budget it keeps */
    onShow?: () => void;
}): {
    /**
     * The user wheeled expecting a zoom, scroll-to-zoom was off, and nothing
     * scrolled either — so the gesture did nothing at all. Draw the prompt; it
     * clears itself.
     */
    showZoomHint: boolean;
    /** viewport point to draw it at — see `at` */
    zoomHintAt: {
        x: number;
        y: number;
    };
    /** whether the prompt has ever been raised — see `mounted` */
    zoomHintMounted: boolean;
    dismissZoomHint: () => void;
    /**
     * Hold the prompt open while the pointer is on it, and start it expiring
     * again on the way out.
     */
    setZoomHintHeld: (value: boolean) => void;
    /**
     * A wheel that did nothing, from whatever bound the gesture — the
     * controller's `onUnhandled`. Every gate above runs from here.
     */
    noteDeadWheel: (event: WheelEvent) => void;
};
/**
 * `useScrollZoomHintState` plus the gestures, for the usual case: one element,
 * one view. Binds what `useWheelZoom` binds — call this *or* that, never both.
 *
 * `usePanZoom` and JBrowse's own LinearGenomeView both come through here, so
 * the two prompts differ only in what they draw: a caption for the embedder, a
 * portalled card with the setting on it for the app.
 */
export declare function useScrollZoomHint(ref: React.RefObject<HTMLElement | null>, view: PanZoomView, opts?: Parameters<typeof useScrollZoomHintState>[0]): {
    /**
     * The user wheeled expecting a zoom, scroll-to-zoom was off, and nothing
     * scrolled either — so the gesture did nothing at all. Draw the prompt; it
     * clears itself.
     */
    showZoomHint: boolean;
    /** viewport point to draw it at — see `at` */
    zoomHintAt: {
        x: number;
        y: number;
    };
    /** whether the prompt has ever been raised — see `mounted` */
    zoomHintMounted: boolean;
    dismissZoomHint: () => void;
    /**
     * Hold the prompt open while the pointer is on it, and start it expiring
     * again on the way out.
     */
    setZoomHintHeld: (value: boolean) => void;
    /**
     * A wheel that did nothing, from whatever bound the gesture — the
     * controller's `onUnhandled`. Every gate above runs from here.
     */
    noteDeadWheel: (event: WheelEvent) => void;
};
/**
 * Every navigation gesture for a view, on one element: wheel zoom, side-scroll,
 * and click-drag panning.
 *
 * ```tsx
 * const ref = useWidthSetter(view)
 * const { containerProps, showZoomHint } = usePanZoom(ref, view)
 * return (
 *   <div ref={ref} {...containerProps} style={{ touchAction: 'none' }}>
 *     …tracks…
 *   </div>
 * )
 * ```
 *
 * `touchAction: 'none'` is the host's half of the deal — without it the browser
 * claims a touch-drag as a page scroll and the pointer stream never arrives.
 *
 * JBrowse's own view splits these across two elements (the wheel on the whole
 * view, the drag on the tracks area, so a drag over the header does nothing) and
 * so binds `useScrollZoomHint` plus its own `useSideScroll`. One element is the
 * normal case for an embedder, and this is it.
 */
export declare function usePanZoom(ref: React.RefObject<HTMLElement | null>, view: PanZoomView): {
    /**
     * The user wheeled, scroll-to-zoom was off and no modifier was held, and
     * the page did not scroll either — so the gesture did nothing at all. Draw
     * a prompt saying what it would have taken; it clears itself. See
     * `useScrollZoomHint` for why the page-scrolled case is deliberately
     * excluded, and for the richer state a prompt with a control on it needs.
     */
    showZoomHint: boolean;
    containerProps: {
        onPointerDown(event: React.PointerEvent<HTMLElement>): void;
        onPointerMove(event: React.PointerEvent<HTMLElement>): void;
        onPointerUp: (event: React.PointerEvent<HTMLElement>) => void;
        onPointerCancel: (event: React.PointerEvent<HTMLElement>) => void;
    };
};
