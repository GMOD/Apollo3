import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { Theme } from '@mui/material';
export interface HighlightType {
    start: number;
    end: number;
    assemblyName?: string;
    refName: string;
    color?: string;
    label?: string;
}
export declare function revealHighlightsOnGrowth(node: IAnyStateTreeNode, count: () => number): void;
export declare function highlightKey(h: {
    assemblyName?: string;
    refName: string;
    start: number;
    end: number;
}, i: number): string;
export declare function getHighlightColor(highlight: {
    color?: string;
}, theme: Theme, alpha?: number): import("./colord.ts").Colord;
export declare function coerceHighlight(h: string | HighlightType, defaultAssembly: string, isValidRefName: (refName: string) => boolean): HighlightType | undefined;
