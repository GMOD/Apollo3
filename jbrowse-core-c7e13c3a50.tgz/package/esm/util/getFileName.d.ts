import type { FileLocation } from './types/index.ts';
/**
 * The bare filename a location refers to, for every location type — a Blob and
 * a FileHandle carry their name directly, a URI and a local path carry it as the
 * last path segment.
 *
 * Its own module rather than living in `tracks.ts` because the assembly form
 * helpers need it too, and `tracks.ts` pulls in MST and the configuration
 * system. Re-exported from `tracks.ts`, which is the import path plugins use.
 */
export declare function getFileName(location: FileLocation): string;
