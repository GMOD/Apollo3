/**
 * Darken or lighten a color, depending on its luminance.
 * Light colors are darkened, dark colors are lightened.
 *
 * @param color - CSS color, i.e. one of: #nnn, #nnnnnn, rgb(), rgba(),
 * hsl(), hsla(), or named color
 * @param coefficient - multiplier in the range 0 - 1, defaults to 0.15
 * @returns A CSS color string. Hex input values are returned as rgb
 */
export declare function emphasize(color: string, coefficient?: number): string;
/**
 * Push `foreground` away from `background` until it clears `minContrastRatio`,
 * returning the closest it got when that ratio is unreachable.
 *
 * `minContrastRatio` genuinely cannot be met against a mid-luminance
 * background: lighten/darken clamp their coefficient at 1, so the candidate
 * pins at white/black, and against a `#b0b0b0` paper the best ratio any color
 * reaches is about 2.2. This used to be a `while (ratio < min)` loop with an
 * unbounded coefficient, which froze the render thread outright for 38 of the 40
 * default refName colors.
 */
export declare function makeContrasting(foreground: string, background?: string, minContrastRatio?: number): string;
export { isNamedColor, namedColorToHex } from './cssColorsLevel4.ts';
/**
 * #api
 * Move a color's OKLCH lightness by `lightnessShift` and scale its chroma,
 * holding its hue.
 *
 * For extending a categorical palette past its length. Cycling a nine-color
 * list over a 24-chromosome karyotype repeats the color outright; cycling it
 * with a lightness shift per lap gives the hue back as a variant still told
 * apart from the original — tab20's construction, which pairs a light and a
 * dark of each hue.
 *
 * SHIFT rather than a fixed lightness, and SCALE rather than a fixed chroma,
 * because a categorical palette is uneven on purpose: category10's brown and
 * its red are 5 degrees apart in hue and are told apart by chroma alone, so
 * re-lighting both to one (lightness, chroma) makes them the same color.
 * Keeping each color's own relative chroma keeps brown reading as brown.
 *
 * In OKLCH rather than through `lighten`/`darken`, which work in sRGB, where
 * the same coefficient moves a yellow and a blue by visibly different amounts:
 * a lap has to read as one tone across the whole palette or it reads as noise.
 *
 * @param color - CSS color to transform
 * @param lightnessShift - added to its OKLCH lightness (which is 0 - 1)
 * @param chromaScale - multiplies its OKLCH chroma; the result is reduced at
 *  constant hue if that lands out of gamut
 * @returns A CSS hex color string
 */
export declare function relight(color: string, lightnessShift: number, chromaScale?: number): string;
/**
 * Generate a consistent random color for a given string.
 * The same string will always generate the same color, with no shared palette
 * state — so the same value (e.g. a gene symbol used as an ortholog id) gets the
 * same color across independent tracks/panels.
 *
 * Statelessness is why this hashes into a color space rather than indexing a
 * fixed palette of N: with no allocator there is no "next unused color", so an
 * N-color palette collides by the birthday problem — six values into a
 * twenty-color palette collide more often than not — while a hue circle does
 * not repeat until 360 values. What a curated palette actually buys is
 * perceptual evenness, and that comes from the space, not the list: hues are
 * placed in OKLCH at a fixed lightness and chroma, so every value is equally
 * light and equally colorful. HSL, which this used to use, is neither — its
 * hue wheel spends a quarter of itself on greens that look identical and a
 * sliver on yellow, and at one lightness its yellows glare while its blues go
 * murky. That unevenness is what reads as "random RGB".
 *
 * @param str - The string to generate a color from
 * @returns A CSS hex color string
 */
export declare function randomColor(str: string): string;
