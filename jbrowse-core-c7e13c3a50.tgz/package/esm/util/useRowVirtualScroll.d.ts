interface RowScrollTarget {
    effectiveRowHeight: number;
    scrollTop: number;
    nrow: number;
    scrollableHeight: number;
    setRowHeight: (n: number) => void;
    setScrollTop: (n: number) => void;
}
/**
 * Wheel gestures over a **row-stack** panel — the multi-sample variant displays
 * and MAF: `shift`+wheel resizes the rows (a vertical-zoom that keeps the row
 * under the cursor put), a plain wheel scrolls them, and anything the panel
 * can't consume is left to bubble to the view.
 *
 * These panels paint a fixed-size canvas at `-scrollTop` rather than living in a
 * DOM overflow container, so nothing scrolls them without this.
 *
 * ADR-027 keeps wheel-*intent* dispatch per handler, because the four panels do
 * not agree on what a gesture means — and that still holds. This is the one rule
 * two of them genuinely share, which the ADR states outright ("same rule as the
 * variant displays, and deliberately so: same sample-row shape, same coupled
 * row-height axis"). It is unified for exactly that reason, and no further: the
 * pileup / canvas-basic rule (`shift` scrolls, nothing resizes) stays where it
 * is. `scrollZoom` and `viewportHeight` are inputs rather than reads off the
 * model, so core needs no view typing and each display keeps naming its own
 * rows-area height.
 */
export declare function useRowVirtualScroll(el: HTMLElement | null, model: RowScrollTarget, { viewportHeight, scrollZoom, }: {
    viewportHeight: number;
    scrollZoom: boolean;
}): void;
export {};
