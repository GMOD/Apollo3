import type PluginManager from '../PluginManager.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { ComponentType } from 'react';
/**
 * The slice of the add-track widget model an adapter-specific picker gets. It
 * is deliberately narrower than the widget's own model: a picker reads which
 * adapter is selected and contributes config fragments through `mixinData`,
 * which the widget merges into the track config on submit.
 */
export interface AddTrackComponentModel extends IStateTreeNode {
    assembly: string | undefined;
    setAssembly: (arg: string) => void;
    trackAdapterType: string | undefined;
    mixinData: Record<string, unknown>;
    setMixinData: (data: Record<string, unknown>) => void;
}
export interface AddTrackComponentProps {
    model: AddTrackComponentModel;
}
declare module '../PluginManager.ts' {
    interface ExtensionPointRegistry {
        'Core-addTrackComponent': {
            args: ComponentType<AddTrackComponentProps>;
            result: ComponentType<AddTrackComponentProps>;
            props: AddTrackComponentProps;
        };
    }
}
/**
 * Show `component` in the add-track widget whenever the selected adapter is one
 * of `adapterTypes`. Wraps `Core-addTrackComponent` so a plugin states only
 * which adapters it claims, instead of restating the "match or pass the
 * accumulated component through" fold.
 */
export declare function addAddTrackComponent(pluginManager: PluginManager, { adapterTypes, component, }: {
    adapterTypes: readonly string[];
    component: ComponentType<AddTrackComponentProps>;
}): void;
