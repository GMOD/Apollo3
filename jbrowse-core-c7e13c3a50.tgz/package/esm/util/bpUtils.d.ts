import type { Region } from './types/index.ts';
export interface MinimalRegion {
    start: number;
    end: number;
    reversed?: boolean;
}
export declare function bpToPx(bp: number, { reversed, end, start, }: {
    start?: number;
    end?: number;
    reversed?: boolean;
}, bpPerPx: number): number;
export declare function bpSpanPx(leftBp: number, rightBp: number, region: MinimalRegion, bpPerPx: number): readonly [number, number];
export declare function featureSpanPx(feature: {
    get: (key: string) => number;
}, region: MinimalRegion, bpPerPx: number): readonly [number, number];
export declare function getBpDisplayStr(total: number): string;
/**
 * The grammar of a single base-pair quantity, as a regex source fragment so
 * that callers matching it in a larger pattern (a locString coordinate range,
 * say) stay in step with {@link parseBpString}. Match case-insensitively.
 *
 * A decimal point is allowed only on the unit-suffixed alternative. That is
 * deliberate: "1.5Mb" is a number a user means, whereas a bare "1.5" as a
 * coordinate is a mistake, and it should stay an error rather than silently
 * yielding a fractional coordinate.
 */
export declare const BP_QUANTITY_SOURCE: string;
/**
 * Parse a base-pair count written the way people type one: plain digits, with
 * optional thousand separators, and with an optional metric unit suffix. So
 * "150", "1,500", "1.5kb", "1.5k", "34Mb" and "2G" are all accepted.
 *
 * The unit's tail is loose because both "kb" and "k" are in common use, and
 * because everything {@link getBpDisplayStr} prints has to come back in. The
 * app shows a window size as "1.5Mbp" in the zoom slider tooltip and over a
 * rubberband selection, so a user who reads one off the screen and types it
 * into a bp field has typed a string this must accept.
 *
 * Returns undefined, rather than NaN or a throw, when the string is not a bp
 * quantity, so that callers validating a text field can test it directly.
 */
export declare function parseBpString(str: string): number | undefined;
export declare function getTickDisplayStr(totalBp: number, bpPerPx: number): string;
interface VirtualOffset {
    blockPosition: number;
    dataPosition?: number;
}
interface Block {
    minv: VirtualOffset;
    maxv: VirtualOffset;
    /**
     * Bytes this block's fetch actually reads. @gmod/tabix and @gmod/bam compute
     * it from an `endPosition` that `clampChunkEnds` has tightened down to the
     * next known BGZF block boundary, so it is materially smaller than the
     * full-block padding the fallback below has to assume.
     */
    fetchedSize?: () => number;
}
/**
 * Index-only estimate of the bytes a fetch of these regions would download.
 *
 * Prefers each block's own `fetchedSize()`. The fallback —
 * `maxv + 65535 - minv` — has to pad by a whole maximum-size BGZF block,
 * because the compressed length of the block at `maxv` is not recorded in the
 * index; it is what this did for every block before the parsers exposed a
 * tightened figure, and it over-estimates.
 *
 * Blocks are also de-duplicated across regions. Two adjacent regions routinely
 * resolve to the same chunk, and it is downloaded once, so counting it twice
 * inflated the estimate for exactly the multi-region queries this gates.
 *
 * Note @gmod/tabix's own `TabixIndexedFile.bytesForRegions` is strictly better
 * still — it runs the chunk merger over the combined set, so it also collapses
 * *overlapping* blocks rather than only identical ones — and every tabix
 * adapter in this repo calls that instead. This remains for other index shapes
 * and for plugins outside the repo, which reach it through `@jbrowse/core/util`.
 */
export declare function bytesForRegions(regions: Region[], index: {
    blocksForRange: (ref: string, start: number, end: number) => Promise<Block[]>;
}): Promise<number>;
export {};
