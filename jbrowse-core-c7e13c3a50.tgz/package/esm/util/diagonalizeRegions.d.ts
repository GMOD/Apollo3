import type { StatusCallback } from './progress.ts';
import type { StopToken } from './stopToken.ts';
import type { Region } from './types/index.ts';
export interface AlignmentData {
    refRefName: string;
    queryRefName: string;
    refStart: number;
    refEnd: number;
    queryStart: number;
    queryEnd: number;
    strand: number;
}
export interface DiagonalizationResult {
    newRegions: Region[];
    stats: {
        regionsReordered: number;
        regionsReversed: number;
    };
}
export declare function diagonalizeRegions(alignments: AlignmentData[], referenceRegions: Region[], currentRegions: Region[], { stopToken, statusCallback, }?: {
    stopToken?: StopToken;
    statusCallback?: StatusCallback;
}): Promise<DiagonalizationResult>;
