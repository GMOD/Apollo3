export declare const isElectron: boolean;
export declare const isNode: boolean;
export declare const rIC: ((cb: () => void) => void) | (((callback: IdleRequestCallback, options?: IdleRequestOptions) => number) & typeof requestIdleCallback);
