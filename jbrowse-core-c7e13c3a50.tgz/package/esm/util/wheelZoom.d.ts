export declare const MAX_ZOOM_RATE_PER_MS: number;
export declare const SCROLL_ZOOM_FACTOR_DIVISOR = 500;
export declare function wheelZoomAccum(normalizedDeltaY: number, isCtrlZoom: boolean): number;
export declare function getZoomNormalizer(deltaY: number): 25 | 75 | 150 | 500;
export declare function normalizeWheelDelta(delta: number, deltaMode: number, pageHeight?: number): number;
export declare function wheelFrameElapsedMs(now: number, lastRafTime: number | null): number;
export declare function accumulateScroll(prev: number, deltaX: number): number;
export declare const ZOOM_ACTIVE_WINDOW_MS = 100;
export declare function isActivelyZooming(now: number, lastZoomTime: number | null): boolean;
export declare function applyZoomAccum(bpPerPx: number, zoomAccum: number, elapsedMs: number): number;
export interface WheelZoomView {
    bpPerPx: number;
    zoomTo: (bpPerPx: number, offset?: number) => void;
    horizontalScroll: (delta: number) => void;
}
export interface WheelZoomTarget {
    views: WheelZoomView[];
    scrollZoom: boolean;
    originElement: () => HTMLElement | undefined;
}
export interface WheelZoomControllerOptions {
    element: HTMLElement;
    resolveTarget: (event: WheelEvent) => WheelZoomTarget | undefined;
    swallowUnhandled?: boolean;
    /**
     * Abandon the gesture once the pointer leaves `element`, rather than following
     * the wheel events the browser keeps latching here (see trackPointerPresence).
     *
     * Only for an element large and stationary enough that "the pointer left" is a
     * real exit. On a small or moving target it isn't: a zoom slides a thin svg
     * ribbon out from under a stationary cursor, the browser fires mouseleave, and
     * the gesture would die halfway through. So this is opt-in, not the default.
     */
    releaseOnPointerLeave?: boolean;
    onEvent?: (event: WheelEvent) => void;
    /**
     * A wheel that meant "zoom" and got nothing: vertical, no ctrl/meta,
     * scroll-to-zoom off, and nothing nested inside having already claimed it.
     * The gesture leaves no trace on any view, so this callback is the only way
     * to see it happened — which is what the scroll-to-zoom prompt is built on
     * (`useScrollZoomHint`).
     *
     * Fires from inside the target branch, so a gesture the controller released
     * (`releaseOnPointerLeave`, or a `resolveTarget` that declined) is not
     * reported: the view did nothing because it was not being asked, which is a
     * different thing from doing nothing when it was.
     *
     * It does *not* say the page scrolled instead. With `swallowUnhandled` it
     * certainly didn't, and without it that is up to the browser — a caller that
     * cares has to watch for the scroll itself.
     */
    onUnhandled?: (event: WheelEvent) => void;
}
/**
 * The one wheel gesture handler for linear views. Its decision matrix:
 *
 *   - ctrl/meta+wheel, or (scrollZoom && |dy| >= |dx|)  → zoom about the cursor
 *   - shift+wheel while scrollZoom is on                → native scroll, we pass
 *   - a horizontal delta, unless one arrives mid-zoom   → pan by dx
 *
 * The listener is non-passive so it can preventDefault to suppress native scroll
 * during a zoom. To pay for that it only accumulates deltas: every model write
 * happens in one requestAnimationFrame, so a burst of events (fast trackpad,
 * inertial scroll) collapses to a single update per frame instead of thrashing
 * the views once per event.
 *
 * Returns its disposer.
 */
export declare function createWheelZoomController({ element, resolveTarget, swallowUnhandled, releaseOnPointerLeave, onEvent, onUnhandled, }: WheelZoomControllerOptions): () => void;
