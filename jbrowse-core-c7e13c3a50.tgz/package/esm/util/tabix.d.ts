import type { StatusCallback } from './progress.ts';
import type { StopToken } from './stopToken.ts';
/**
 * A raw tabix line paired with the metadata the GFF3/GTF adapters need before
 * parsing: `offset` (the tabix byte offset) mints a stable per-feature id that
 * survives redispatch and panning, and start/end/type feed the redispatch
 * calculation (see {@link calculateRedispatchRange}) that runs before any line
 * is parsed.
 *
 * `start`/`end` are interbase, not the raw column values: @gmod/tabix applies
 * the index's coordinate offset (-1 for a 1-based-closed preset such as GFF)
 * before it calls back.
 */
export interface TabixLine {
    line: string;
    offset: number;
    start: number;
    end: number;
    type: string;
}
/**
 * Minimal structural view of `@gmod/tabix`'s `TabixIndexedFile.getLines`, so
 * core needn't depend on `@gmod/tabix`.
 */
interface TabixLineSource {
    getLines(refName: string, start: number | undefined, end: number | undefined, opts: {
        lineCallback: (line: string, offset: number, start: number, end: number) => void;
        onProgress?: (bytesDownloaded: number, totalBytes?: number) => void;
        signal?: AbortSignal;
    }): Promise<void>;
}
/**
 * Fetch the tabix lines for a region under a "Downloading features" progress
 * label, capturing each line's byte offset, indexed start/end, and feature type
 * into a {@link TabixLine}. Shared by the GFF3 and GTF tabix adapters.
 *
 * The stop token becomes the read's `AbortSignal`, so a cancelled fetch drops
 * its block reads at the socket instead of downloading them and discarding the
 * lines. @gmod/tabix aborts a block shared between callers only once every
 * joined caller has aborted (`AggregateAbortController`), so this can't cancel a
 * chunk another region still needs.
 */
export declare function readTabixLines(gff: TabixLineSource, refName: string, start: number, end: number, statusCallback?: StatusCallback, stopToken?: StopToken): Promise<TabixLine[]>;
/**
 * Read a region's tabix lines, then — if any feature found there extends past
 * the query — read once more over the union of the query and those feature
 * bounds, so a parent line's children (a gene's exons, a transcript's CDS)
 * outside the original window are pulled in and the parent/child tree resolves
 * fully. Types in `dontRedispatchSet` are excluded from the bounds, so one
 * chromosome-spanning record can't force a whole-chromosome refetch.
 *
 * Exactly one expansion happens: the second read's own overhang is not chased,
 * which bounds the work at two reads per query.
 *
 * Shared by the GFF3 and GTF tabix adapters, which differ only in how they
 * parse the returned lines.
 */
export declare function readTabixLinesRedispatched(file: TabixLineSource, query: {
    refName: string;
    start: number;
    end: number;
}, dontRedispatchSet: Set<string>, opts?: {
    statusCallback?: StatusCallback;
    stopToken?: StopToken;
}): Promise<TabixLine[]>;
/**
 * Minimal structural view of the `@gmod/tabix` call a header read needs, kept
 * structural for the same reason as {@link TabixLineSource}.
 */
interface TabixHeaderSource {
    getHeaderLines(): Promise<string[]>;
}
/**
 * The header lines of a tabix-indexed file, however that file kept them.
 *
 * `getHeader()` alone is not that: it returns only lines beginning with the
 * index's meta character (`#`). A header that is a plain row — which is what
 * `tabix -S N` exists for, and what PLINK `.ld`, bedGraph and BED deflines
 * routinely are — comes back as the empty string, even though the index records
 * N in `skipLines`.
 *
 * Reading both is not backwards compatibility, and does not become unnecessary
 * once our own files are written with commented headers. A bare header is the
 * shape the data's publisher chose: Pan-UKB's TSVs and PLINK's `.ld` are
 * distributed that way, and `-S N` is the only way to index one without
 * rewriting a file the user did not write. Advice about how to generate a file
 * reaches the files we generate; this reaches the rest.
 *
 * An adapter that stops at `getHeader()` therefore cannot tell "this file has
 * no header" from "this file's header is not commented", and quietly falls back
 * to an assumed column layout. That has cost real information more than once: a
 * PLINK LD file lost its D' column, so `ldMetric: 'dprime'` silently served r²,
 * and a bedGraph loses the names of its value columns. Nothing errors, because
 * the assumed layout parses.
 *
 * That policy now lives in @gmod/tabix 3.5.4 as getHeaderLines, next to the
 * index metadata that decides it, so this is a delegate. Deciding it there also
 * costs one read of the file's leading blocks rather than two: asking for the
 * commented block and then the counted rows used to fetch and decompress the
 * same bytes twice, which every bare-header file did on every call.
 */
export declare function readTabixHeaderLines(file: TabixHeaderSource): Promise<string[]>;
export {};
