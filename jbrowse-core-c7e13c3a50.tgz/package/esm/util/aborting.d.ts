declare class AbortError extends Error {
    code: string | undefined;
}
export declare function makeAbortError(): AbortError | DOMException;
/**
 * check if the given exception was caused by an operation being intentionally aborted
 * @param exception -
 */
export declare function isAbortException(exception: unknown): boolean;
export {};
