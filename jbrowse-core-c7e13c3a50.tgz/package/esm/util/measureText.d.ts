export declare function measureText(str: unknown, fontSize?: number, fontFamily?: string): number;
