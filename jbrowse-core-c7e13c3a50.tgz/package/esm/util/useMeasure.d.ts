/**
 * Element size, via ResizeObserver.
 *
 * `track` names the axes the caller actually uses, and it is a performance knob
 * as much as an API one: the observer fires for a change on *either* axis, so a
 * width-only caller re-rendered every time its content grew taller. That is the
 * common case in a view container, whose height follows its tracks. Naming the
 * axis lets those updates be dropped instead. The unnamed axis is reported as
 * `undefined` rather than a stale number, so nothing can quietly read it.
 */
export default function useMeasure(track?: 'both' | 'width' | 'height'): readonly [import("react").RefObject<HTMLDivElement | null>, {
    width?: number;
    height?: number;
}];
