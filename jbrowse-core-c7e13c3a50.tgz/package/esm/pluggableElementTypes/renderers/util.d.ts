import type { Region } from '../../util/index.ts';
export declare function normalizeRegion(region: Region): Region;
/**
 * Expands a region by a given number of base pairs in both directions.
 * Useful for fetching features that may extend beyond the visible region.
 */
export declare function expandRegion(region: Region, bpExpansion: number): Region;
