import type { HighlightType } from '../../util/highlights.ts';
/**
 * #stateModel HighlightsMixin
 * #category view
 *
 * The `view.highlight` band state shared verbatim by the LinearGenomeView and
 * DotplotView: an array of translucent highlight regions plus the
 * `showHighlightChips` toggle for their interactive chips. Both views compose
 * this so the props and actions stay identical by construction rather than by
 * two hand-kept copies. Visibility across all views is the session-wide
 * `highlightsVisible` flag (on BaseSession), not a prop here.
 */
export default function HighlightsMixin(): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     * translucent highlight bands, seeded from URL params or session JSON and
     * added interactively via the rubber-band menu
     */
    highlight: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IType<HighlightType, HighlightType, HighlightType>>, [undefined]>;
    /**
     * #property
     * controls whether the interactive highlight chip (link icon + context
     * menu) is drawn on each highlight band; off by default
     */
    showHighlightChips: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    /**
     * #action
     */
    addToHighlights(highlight: HighlightType): void;
    /**
     * #action
     */
    setHighlight(highlight?: HighlightType[]): void;
    /**
     * #action
     */
    removeHighlight(highlight: HighlightType): void;
    /**
     * #action
     */
    updateHighlight(old: HighlightType, updates: Partial<HighlightType>): void;
    /**
     * #action
     */
    setShowHighlightChips(arg: boolean): void;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
