import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { MenuItem } from '../../ui/index.ts';
import type { RpcStatus } from '../../util/progress.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type React from 'react';
export declare const BaseDisplay: import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    /**
     * #property
     */
    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
}, {
    error: unknown;
    statusMessage: string | undefined;
    /**
     * #volatile
     * determinate progress fraction [0,1] for the current status, or
     * undefined when the in-flight phase is indeterminate. Set alongside
     * `statusMessage` by `setStatusMessage`; a display that never shows a
     * bar simply leaves it undefined.
     */
    statusProgress: number | undefined;
} & {
    /**
     * #getter
     */
    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
    /**
     * #getter
     * Returns the parent display if this display is nested within another display
     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
     */
    readonly parentDisplay: {
        type?: string;
        effectiveRpcDriverName?: string;
    } | undefined;
} & {
    /**
     * #getter
     */
    readonly RenderingComponent: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            /**
             * #property
             */
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            /**
             * #getter
             * Returns the parent display if this display is nested within another display
             * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
             */
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            /**
             * #property
             */
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            /**
             * #getter
             * Returns the parent display if this display is nested within another display
             * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
             */
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        onHorizontalScroll?: (distance: number) => void;
        blockState?: Record<string, unknown>;
    }>;
    /**
     * #getter
     */
    readonly DisplayBlurb: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            /**
             * #property
             */
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            /**
             * #getter
             * Returns the parent display if this display is nested within another display
             * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
             */
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            /**
             * #property
             */
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            /**
             * #getter
             * Returns the parent display if this display is nested within another display
             * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
             */
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }> | null;
    /**
     * #getter
     */
    readonly adapterConfig: Record<string, unknown>;
    /**
     * #getter
     * Returns true if the parent track is minimized. Used to skip
     * expensive operations like autoruns when track is not visible.
     */
    readonly isMinimized: boolean;
    /**
     * #getter
     * Returns the effective RPC driver name with hierarchical fallback:
     * 1. This display's explicit rpcDriverName
     * 2. Parent display's effectiveRpcDriverName (for nested displays)
     * 3. Track config's rpcDriverName
     */
    readonly effectiveRpcDriverName: any;
} & {
    /**
     * #method
     * props passed to the renderer's React "Rendering" component.
     * these are client-side only and never sent to the worker.
     * includes displayModel and callbacks
     */
    renderingProps(): {
        displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            /**
             * #property
             */
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            /**
             * #getter
             * Returns the parent display if this display is nested within another display
             * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
             */
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & {
            /**
             * #getter
             */
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            /**
             * #getter
             */
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            /**
             * #getter
             */
            readonly adapterConfig: Record<string, unknown>;
            /**
             * #getter
             * Returns true if the parent track is minimized. Used to skip
             * expensive operations like autoruns when track is not visible.
             */
            readonly isMinimized: boolean;
            /**
             * #getter
             * Returns the effective RPC driver name with hierarchical fallback:
             * 1. This display's explicit rpcDriverName
             * 2. Parent display's effectiveRpcDriverName (for nested displays)
             * 3. Track config's rpcDriverName
             */
            readonly effectiveRpcDriverName: any;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            /**
             * #property
             */
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            /**
             * #property
             */
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            /**
             * #property
             */
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            /**
             * #volatile
             * determinate progress fraction [0,1] for the current status, or
             * undefined when the in-flight phase is indeterminate. Set alongside
             * `statusMessage` by `setStatusMessage`; a display that never shows a
             * bar simply leaves it undefined.
             */
            statusProgress: number | undefined;
        } & {
            /**
             * #getter
             */
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            /**
             * #getter
             * Returns the parent display if this display is nested within another display
             * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
             */
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & {
            /**
             * #getter
             */
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            /**
             * #getter
             */
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    /**
                     * #property
                     */
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    /**
                     * #property
                     */
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    /**
                     * #property
                     */
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    /**
                     * #volatile
                     * determinate progress fraction [0,1] for the current status, or
                     * undefined when the in-flight phase is indeterminate. Set alongside
                     * `statusMessage` by `setStatusMessage`; a display that never shows a
                     * bar simply leaves it undefined.
                     */
                    statusProgress: number | undefined;
                } & {
                    /**
                     * #getter
                     */
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    /**
                     * #getter
                     * Returns the parent display if this display is nested within another display
                     * (e.g., PileupDisplay inside LinearAlignmentsDisplay)
                     */
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            /**
             * #getter
             */
            readonly adapterConfig: Record<string, unknown>;
            /**
             * #getter
             * Returns true if the parent track is minimized. Used to skip
             * expensive operations like autoruns when track is not visible.
             */
            readonly isMinimized: boolean;
            /**
             * #getter
             * Returns the effective RPC driver name with hierarchical fallback:
             * 1. This display's explicit rpcDriverName
             * 2. Parent display's effectiveRpcDriverName (for nested displays)
             * 3. Track config's rpcDriverName
             */
            readonly effectiveRpcDriverName: any;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    /**
     * #method
     */
    trackMenuItems(): MenuItem[];
} & {
    /**
     * #action
     */
    setStatusMessage(status?: RpcStatus): void;
    /**
     * #action
     */
    setError(error?: unknown): void;
    /**
     * #action
     */
    setRpcDriverName(rpcDriverName: string): void;
    /**
     * #action
     * base display reload does nothing, see specialized displays for details
     */
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseDisplayStateModel = typeof BaseDisplay;
export type BaseDisplayModel = Instance<BaseDisplayStateModel>;
/**
 * The shape every display instance held in a track's `displays` array
 * satisfies: the composed `BaseDisplay` state model (RenderingComponent,
 * DisplayBlurb, trackMenuItems, ...) plus the `configuration`
 * reference every display gains at instantiation. `getPortableSettings` is
 * optional — only display types that support switching type via the track menu
 * implement it. This is the concrete element type behind
 * `BaseTrackModel.displays`, which the runtime plugin union erases to `any`.
 */
export interface DisplayModel extends BaseDisplayModel {
    configuration: AnyConfigurationModel & {
        displayId: string;
    };
    getPortableSettings?: (newDisplayId?: string) => Record<string, unknown> | undefined;
}
