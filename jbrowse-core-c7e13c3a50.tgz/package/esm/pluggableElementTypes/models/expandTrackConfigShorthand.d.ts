import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../../configuration/index.ts';
export interface DisplaySnapshot {
    type: string;
    displayId?: string;
    [key: string]: unknown;
}
interface DisplayTypeLike {
    name: string;
    configSchema: AnyConfigurationSchemaType;
}
interface TrackTypeLike {
    displayTypes: DisplayTypeLike[];
}
/** display type name → its config slot names, for one track type. */
export declare function trackDisplaySlots(trackType: TrackTypeLike): Map<string, Set<string>>;
/**
 * Pure: route each shorthand `displayDefaults: {...}` setting to the display
 * types that define it. A setting goes to every display type whose config schema
 * has that slot, so slot names disambiguate across displays on their own (e.g.
 * `color` → LinearVariantDisplay, `strokeColor` → ChordVariantDisplay). Keys no
 * display defines are returned as `unknownKeys` for the caller to surface.
 */
export declare function collectDisplayOverrides(displaySettings: Record<string, unknown>, displaySlots: Map<string, Set<string>>): {
    overrides: Map<string, Record<string, unknown>>;
    unknownKeys: string[];
};
/**
 * Pure: fold per-display override props into a `displays` array, creating an
 * entry (with a derived displayId) for any display type not already present.
 * Explicit entries in the existing array win over shorthand on conflict.
 */
export declare function mergeOverridesIntoDisplays(displays: DisplaySnapshot[], overrides: Map<string, Record<string, unknown>>, trackId: string): DisplaySnapshot[];
/**
 * Expands the shorthand `displayDefaults` **object** into the explicit `displays`
 * **array**, so users can set display settings without naming the display type
 * or nesting in `displays:[{type,...}]`. `displayDefaults:{color:'green'}` routes
 * each setting to the display type(s) that define that slot, folding them into
 * whatever `displays` array the track already has (explicit entries win).
 *
 * `displayDefaults` is kept separate from `displays` (rather than overloading
 * `displays` by shape) so a config using it still loads in a JBrowse version
 * that predates the feature — the unknown key is ignored, instead of crashing
 * when the array-typed `displays` slot receives an object.
 *
 * Runs inside `baseTrackConfig.preProcessSnapshot`, before display-stub
 * injection. Takes/returns the loosely-typed snapshot (as `evaluateExtensionPoint`
 * does) — the caller casts the result to its snapshot type for validation.
 */
export declare function expandTrackConfigShorthand(input: unknown, pluginManager: PluginManager): unknown;
export {};
