import RpcMethodType from './RpcMethodType.ts';
import type { RenameRegionsArgs } from './RpcMethodType.ts';
export default abstract class RpcMethodTypeWithRenameRegions<MethodName extends string = string> extends RpcMethodType<MethodName> {
    serializeArguments<T extends RenameRegionsArgs>(args: T, rpcDriverClassName: string): Promise<Record<string, unknown>>;
}
