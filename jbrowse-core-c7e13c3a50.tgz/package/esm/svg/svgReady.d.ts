/**
 * The contract every GPU display's `renderSvg` relies on: a `svgReady` gate
 * (the per-display terminal-state getter — see MultiRegionDisplayMixin /
 * GlobalDataDisplayMixin) and the `error` it fails the export on.
 * Duck-typed `renderSvg` model interfaces extend this so the compiler catches a
 * missing field instead of it surfacing as a runtime hang or a silent blank.
 */
export interface SvgExportable {
    svgReady: boolean;
    error: unknown;
    regionTooLarge: boolean;
}
/**
 * The terminal states that let an export proceed with no current data. Mirrors
 * `DisplayPhaseInputs`: named fields, all required, so adding a state is a
 * compile error at every call site rather than a silently missing branch.
 *
 * `extraTerminal` is the display-specific escape hatch — sequence sets it when
 * zoomed past base resolution, where it renders a static "zoom in" message and
 * fetches nothing, so a data-only gate would never resolve.
 */
export interface SvgReadyTerminals {
    error: unknown;
    regionTooLarge: boolean;
    extraTerminal: boolean;
}
/**
 * Whether an off-screen (SVG) export can read this display's data now: the held
 * data is current for what is on screen, or the fetch reached a terminal state.
 *
 * Single-sourced for the same reason as `computeDisplayPhase`: every display
 * family expresses freshness differently — spatial coverage (per-region),
 * viewport-snapshot compare (global), signature compare (arc / dotplot /
 * synteny) — but the *policy* wrapping it is identical, and each of the five
 * hand-written copies this replaced was one place to forget a terminal and hang
 * the export, or to forget freshness and capture a stale viewport (both have
 * shipped; see agent-docs/reference/SVG_EXPORT.md).
 *
 * `dataCurrent` is a **thunk**, evaluated only after the terminals are ruled
 * out, for the same MobX reason `computeDisplayPhase`'s `loading` is: freshness
 * typically reads the containing view's `visibleRegions` / `loadedRegions`, and
 * the `when()` in `awaitSvgReady` shouldn't subscribe to that churn while a
 * banner is up.
 */
export declare function computeSvgReady({ error, regionTooLarge, extraTerminal }: SvgReadyTerminals, dataCurrent: () => boolean): boolean;
/**
 * Off-screen renderers (SVG export, headless jbrowse-img) must wait until the
 * display reaches a terminal state before reading its data. That whole policy
 * lives in `svgReady`; this is the one shared way to await it, so renderers
 * never re-inline `data != null || error || …`. No time bound: `svgReady` is a
 * terminal state (data loaded, or error / too-large), so it resolves once the
 * fetch it observes settles. If a throwing `svgReady` getter rejects the wait,
 * that error propagates faithfully rather than being masked.
 *
 * It then fails the export if the terminal it settled on was the error
 * (`throwOnExportErrors`, below, for why that is fatal), making this the exact
 * display-level twin of `awaitViewInitialized`: both wait for `settled || error`
 * and both refuse to continue on the error, so the postcondition of each is
 * "there is something to draw". Folded in rather than left to the caller because
 * `svgReady` is *true* on error, so a caller that awaits and stops there gets a
 * display with nothing to draw and no sign of why.
 *
 * Every display uses this one, including the ones with nowhere to draw an error
 * (dotplot, synteny) — a display never has to know whether it owns the surface
 * it paints, because the thing that made that distinction matter, reporting all
 * the failures rather than one, is `awaitSvgRenders`'s job.
 */
export declare function awaitSvgReady(model: Pick<SvgExportable, 'svgReady' | 'error'>): Promise<void>;
/**
 * The view-level counterpart, for the wait every `renderToSvg` opens with.
 * `initialized` folds in the view's assemblies, so an assembly that failed to
 * load leaves it false forever — and a bare `when(() => view.initialized)` then
 * hangs the export with the dialog's spinner up and nothing said, the same
 * failure mode on screen the views cure by falling back to their import form.
 * Every view exposes a resolved `error` beside `initialized`; waiting on both
 * and throwing turns that hang into the dialog's error banner.
 *
 * Only a view that never initialized is fatal *here*. A track error on an
 * initialized view is fatal too, but it is the displays' readiness waits that
 * report it (`throwOnExportErrors`), after this one has let the export start.
 */
export declare function awaitViewInitialized(view: {
    initialized: boolean;
    error: unknown;
}): Promise<void>;
/**
 * How the export answers "a track failed": by failing. A track whose data won't
 * load has its error caught by the fetch layer and stored on the display, so the
 * render itself still returns — with that track blank.
 *
 * An export is a standalone artifact, so a failed track is fatal: the dialog
 * shows its error banner and saves nothing, and a headless caller (jbrowse-img)
 * exits nonzero instead of writing a broken image. Drawing the error into the
 * figure instead costs more than the red rect it leaves in the picture: on a
 * shared surface (dotplot plot rect, synteny band) the box covers the tracks
 * that *did* render, and a snapshot regenerated while a display is broken
 * absorbs the stack trace as expected output — which is how a real crash sat
 * inside two committed goldens without turning anything red.
 *
 * `regionTooLarge` is deliberately not routed here — see `SvgChrome`.
 *
 * The failures are kept on the thrown error so that nesting one `awaitSvgRenders`
 * inside another (synteny: rows of tracks *and* levels of ribbons) still reports
 * every leaf rather than one per group.
 */
export declare function throwOnExportErrors(errors: unknown[]): void;
/**
 * `Promise.all` for the renders a view fans out, differing in the one way an
 * export needs: it fails with **every** failure instead of whichever rejected
 * first. Exporting a session with three broken tracks should not mean finding
 * the second one by fixing the first and exporting again. Nest it freely — an
 * inner fan-out's failures are flattened into the outer one's report.
 *
 * That is also what lets every display await through the plain `awaitSvgReady`.
 * A display on a shared surface (the dotplot's plot rect, a synteny level's
 * band) has nowhere to draw an error and nothing complete to say alone; the
 * alternative is for it to stay silent and let its view read the combined error
 * back *after* the waits, which nothing enforces and every new shared-surface
 * view has to rediscover. Here the display just throws, and being complete is
 * the fan-out's job rather than the display's.
 */
export declare function awaitSvgRenders<T extends readonly unknown[] | []>(renders: T): Promise<{
    -readonly [K in keyof T]: Awaited<T[K]>;
}>;
