/**
 * #config CytobandAdapter
 */
declare const configSchema: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     * location of a UCSC-style `cytoBand.txt` (`chrom start end name
     * gieStain`), which draws the ideogram banding in the view's overview bar.
     * May be gzipped. Configured on an assembly, not on a track.
     */
    readonly cytobandLocation: {
        readonly type: "fileLocation";
        readonly defaultValue: {
            readonly uri: "/path/to/cytoband.txt.gz";
        };
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default configSchema;
