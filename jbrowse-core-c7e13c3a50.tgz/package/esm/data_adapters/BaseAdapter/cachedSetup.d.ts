import type { BaseOptions } from './types.ts';
/** byte-granularity progress reporter to hand an index reader's `onProgress` */
type OnProgress = (current: number, total?: number) => void;
/**
 * Memoize an adapter's one-time setup (open the file, read the header, build a
 * parser) into a loader every method can await.
 *
 * Two behaviors that every hand-rolled copy of this needs and that are easy to
 * get wrong:
 *
 * - a rejected setup clears the memo, so the next call retries instead of
 *   replaying the same rejection forever
 * - `label` is shown only while the *first* attempt is in flight. Re-entry on
 *   pan/zoom (every getFeatures and byte estimate awaits the loader) would
 *   otherwise re-flash "Downloading index" over an index that is already
 *   resident. Omit it for a setup whose progress is reported from the inside,
 *   e.g. a whole-file fetch that drives its own download bar.
 *
 * `setup` receives the opts of whichever call happened to run it first, so its
 * statusCallback/stopToken belong to that caller, plus an `onProgress` to pass
 * to an index reader so the label upgrades to a determinate bar.
 */
export declare function cachedSetup<T>({ setup, label, }: {
    setup: (opts?: BaseOptions, onProgress?: OnProgress) => Promise<T>;
    label?: string;
}): (opts?: BaseOptions) => Promise<T>;
export {};
