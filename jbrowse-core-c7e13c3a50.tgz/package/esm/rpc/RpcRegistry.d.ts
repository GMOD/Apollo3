import type { StatusCallback } from '../util/progress.ts';
import type { Feature } from '../util/simpleFeature.ts';
import type { StopToken } from '../util/stopToken.ts';
import type { NoAssemblyRegion } from '../util/types/index.ts';
import type { RpcResult } from './RpcServer.ts';
export interface RegionLike {
    refName: string;
    start: number;
    end: number;
    assemblyName: string;
}
export interface RpcRegistry {
    CoreGetRefNames: {
        args: {
            adapterConfig: Record<string, unknown>;
            sequenceAdapter?: Record<string, unknown>;
            assemblyName?: string;
            stopToken?: StopToken;
            statusCallback?: StatusCallback;
        };
        return: string[];
    };
    CoreGetRegions: {
        args: {
            adapterConfig: Record<string, unknown>;
        };
        return: NoAssemblyRegion[];
    };
    CoreGetSequence: {
        args: {
            region: RegionLike;
            adapterConfig: Record<string, unknown>;
            stopToken?: StopToken;
        };
        return: string | undefined;
    };
    CoreGetFeatures: {
        args: {
            regions: RegionLike[];
            adapterConfig: Record<string, unknown>;
            sequenceAdapter?: Record<string, unknown>;
            statusCallback?: StatusCallback;
            stopToken?: StopToken;
            opts?: Record<string, unknown>;
        };
        return: Feature[];
    };
    CoreGetRegionByteEstimate: {
        args: {
            adapterConfig: Record<string, unknown>;
            regions: RegionLike[];
            stopToken?: StopToken;
            headers?: Record<string, string>;
            statusCallback?: StatusCallback;
        };
        return: number | undefined;
    };
    CoreGetInfo: {
        args: {
            adapterConfig: Record<string, unknown>;
            stopToken?: StopToken;
        };
        return: unknown;
    };
    CoreGetMetadata: {
        args: {
            adapterConfig: Record<string, unknown>;
            stopToken?: StopToken;
        };
        return: unknown;
    };
    CoreGetExportData: {
        args: {
            regions: RegionLike[];
            adapterConfig: Record<string, unknown>;
            formatType: string;
            opts?: Record<string, unknown>;
        };
        return: string;
    };
    CoreFreeResources: {
        args: Record<string, unknown>;
        return: void;
    };
}
export type RpcMethodName = keyof RpcRegistry;
export type RpcArgs<M extends RpcMethodName> = RpcRegistry[M]['args'];
export type RpcReturn<M extends RpcMethodName> = RpcRegistry[M]['return'];
export type RpcExecuteReturn<M extends string> = M extends RpcMethodName ? RpcReturn<M & RpcMethodName> | RpcResult<RpcReturn<M & RpcMethodName>> : unknown;
