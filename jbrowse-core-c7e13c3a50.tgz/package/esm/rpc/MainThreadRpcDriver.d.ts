import BaseRpcDriver from './BaseRpcDriver.ts';
import type PluginManager from '../PluginManager.ts';
import type RpcMethodType from '../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../util/progress.ts';
/**
 * RPC driver that runs RPC functions in-band on the main thread. It owns no
 * worker pool, so the per-session lifecycle hooks (freeSession/destroy) stay as
 * the BaseRpcDriver no-ops.
 */
export default class MainThreadRpcDriver extends BaseRpcDriver {
    name: string;
    protected transport(_pluginManager: PluginManager, _sessionId: string, rpcMethod: RpcMethodType, serializedArgs: Record<string, unknown>, statusCallback: StatusCallback | undefined): Promise<unknown>;
}
