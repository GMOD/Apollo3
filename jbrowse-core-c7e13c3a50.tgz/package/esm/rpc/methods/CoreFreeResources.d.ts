import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
/**
 * Drop cached data adapters associated with the given session.
 *
 * Reached from `RpcManager.releaseSession` when the last track model holding an
 * rpcSessionId is destroyed — closing a track, closing its view, or switching
 * session. `RpcManager` counts the holders because an rpcSessionId is derived
 * from the adapter config and so is shared by every track configured alike; the
 * cache entry's own `sessionIds` refcount then keeps an adapter alive for any
 * *other* session still using it, which is what makes a shared sub-adapter safe.
 *
 * This does not bound the cache, and is not meant to: an adapter whose track is
 * open stays cached however long that takes.
 */
export default class CoreFreeResources extends RpcMethodType<'CoreFreeResources'> {
    name: string;
    execute(args: {
        sessionId?: string;
    }): Promise<void>;
    serializeArguments(args: Record<string, unknown>, _rpcDriver: string): Promise<Record<string, unknown>>;
}
