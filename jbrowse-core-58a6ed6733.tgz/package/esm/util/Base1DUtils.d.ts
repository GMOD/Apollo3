import type { BaseBlock } from './blockTypes.ts';
export interface BpOffset {
    refName?: string;
    index: number;
    offset: number;
    start?: number;
    end?: number;
}
/**
 * Offset in bp from a displayed region's **left screen edge**, which is its end
 * when the region is reversed. This one reflection is what "reversed" means
 * everywhere in a linear view: `bpToPx` below, the ruler's ticks
 * (`LinearGenomeView/util.ts`), and any display placing a feature against a
 * single block. Reach for it instead of writing `pos - region.start`, which
 * silently lays out forward under a right-to-left ruler.
 */
export declare function bpOffsetInRegion(region: {
    start: number;
    end: number;
    reversed?: boolean;
}, bp: number): number;
interface RegionSnap {
    start: number;
    end: number;
    refName: string;
    reversed?: boolean;
    assemblyName: string;
}
interface MoveSnap {
    displayedRegions: {
        start: number;
        end: number;
    }[];
    width: number;
}
export interface ViewLayout {
    displayedRegions: RegionSnap[];
    bpPerPx: number;
    offsetPx: number;
    width: number;
    minimumBlockWidth: number;
}
export declare function moveTo(self: MoveSnap & {
    zoomTo: (arg: number) => number;
    scrollTo: (arg: number) => void;
}, start?: BpOffset, end?: BpOffset): void;
/**
 * Pure version of moveTo: returns the {bpPerPx, offsetPx} that moveTo would
 * apply, without mutating any model. Assumes no bpPerPx clamping (i.e.
 * Base1DView with no min/maxBpPerPx).
 */
export declare function computeMoveToLayout(self: MoveSnap, start: BpOffset, end: BpOffset): {
    bpPerPx: number;
    offsetPx: number;
};
/**
 * The base **painted** at a pixel. Pair it with `pxToBp`'s `offset` field, and
 * only once you know the pixel is in bounds (`!oob`) — off the end of a region
 * no base is painted and the question has no answer.
 *
 * Use this rather than `coord0` whenever the result indexes per-base data: a
 * sequence string, a coverage bin, a per-base tooltip. Reversed, bp runs
 * leftward, so base b covers offsets (b, b+1] — `coord0`'s floor names b+1 on
 * b's leftmost pixel column, and names `r.end`, outside the region entirely, on
 * the region's first column.
 *
 * This is the same one-base pivot as render-core's `makeCellLeftMapper` /
 * `bpAtPx`, which is what the per-base painters draw with, so this is the
 * readout that agrees with what is on screen. The parity block in
 * `Base1DUtils.test.ts` holds the two together.
 *
 * They stay two spellings because there is no shared call to make, not because
 * of the package graph — core declares `@jbrowse/render-core` and imports it
 * from three modules already. `bpAtPx` takes a screen pixel plus a px/bp
 * projection and is mostly about the float behaviour of that projection; this
 * takes an offset already in bp and has no projection. Feeding `bpAtPx`
 * synthetic bounds to fake one computes `(offsetBp * span) / span`, which is
 * not exactly `offsetBp` at genome scale: over a 3000000-sample sweep of base
 * boundaries the perturbation named the wrong base 6885 times, every one of
 * them on a 248956422 bp region (1.9% of that span's samples) and none on any
 * span at or below 133797422. What is left to share is the two lines below, and
 * only render-core could hold them — it must not import core — which would put
 * a pixel-free function downstream of the renderer and split it from its own
 * forward twin, `bpOffsetInRegion` at the top of this file.
 */
export declare function basePaintedAt(r: {
    start: number;
    end: number;
    reversed?: boolean;
}, offsetBp: number): number;
export interface PxToBpResult extends RegionSnap {
    coord: number;
    coord0: number;
    index: number;
    oob: boolean;
    offset: number;
}
export declare function pxToBp(self: ViewLayout, px: number): PxToBpResult;
export declare function offsetBpToPx(self: ViewLayout, regionIndex: number, regionOffsetBp: number): number;
export declare function bpToPx({ refName, coord, displayedRegionIndex, self, }: {
    refName: string;
    coord: number;
    displayedRegionIndex?: number;
    self: ViewLayout;
}): {
    index: number;
    offsetPx: number;
} | undefined;
/**
 * The {@link BpOffset} a 0-based genomic coord sits at — a region index plus an
 * offset in **bp** from that region's left screen edge, which is the shape
 * `moveTo` and `computeMoveToLayout` take.
 *
 * `bpToPx` above answers the neighbouring question in pixels and returns an
 * `index` too, so `{...bpToPx(...), offset: hit.offsetPx}` type-checks and is
 * wrong: `moveTo` re-adds the bp of every region before `index`, which
 * `offsetPx` has already counted, and divides by a bpPerPx that was never in
 * the units to begin with. Reach for this when the destination is a coordinate
 * rather than a pixel.
 *
 * Undefined when no displayed region holds the coord, same as `bpToPx`; a
 * caller that means "as far as the region goes" clamps before asking.
 */
export declare function bpToOffset({ refName, coord, displayedRegions, }: {
    refName: string;
    coord: number;
    displayedRegions: {
        refName: string;
        start: number;
        end: number;
        reversed?: boolean;
    }[];
}): BpOffset | undefined;
/**
 * Where a 0-based genomic coord sits in the LINEARIZED bp space — the
 * concatenation of `displayedRegions`, which is the space `windowStartBp`
 * indexes and the one a viewport is stored in.
 *
 * `bpToPx`'s answer in those units, and without its rounding, which is the
 * reason to reach for this one: `bpToPx` quantizes to a whole pixel at the
 * CURRENT `bpPerPx`, so a caller computing a destination while the view is
 * mid-zoom — an animated flight planning its next leg — gets a destination
 * that shifts with whatever zoom it happened to ask at.
 *
 * `undefined` when no displayed region holds the coord, exactly as `bpToPx`
 * answers: a refName the view is not showing has no place on its screen.
 */
export declare function bpToLinearBp({ refName, coord, displayedRegions, }: {
    refName: string;
    coord: number;
    displayedRegions: {
        refName: string;
        start: number;
        end: number;
        reversed?: boolean;
    }[];
}): number | undefined;
/**
 * Screen order of two {@link BpOffset}s: negative when `a` is to the left of
 * `b`. `moveTo` takes its arguments left-to-right and computes a negative
 * bpPerPx from a backwards pair, so a caller deriving the two from data that
 * can name them in either order sorts with this first.
 */
export declare function compareBpOffsets(a: BpOffset, b: BpOffset): number;
export declare function layoutBpToPx(layout: ViewLayout, args: {
    refName: string;
    coord: number;
    displayedRegionIndex?: number;
}): number | undefined;
export declare function getLayoutHighlightCoords(layout: ViewLayout, region: {
    refName: string;
    start: number;
    end: number;
}, minWidth?: number): {
    width: number;
    left: number;
} | undefined;
export declare function createOverviewLayout({ displayedRegions, width, minimumBlockWidth, }: {
    displayedRegions: RegionSnap[];
    width: number;
    minimumBlockWidth?: number;
}): ViewLayout;
export interface PxSpan {
    leftPx: number;
    rightPx: number;
}
/** Project a span into another pixel space: each end becomes px * scale + translatePx. */
export declare function transformPxSpan(span: PxSpan, scale: number, translatePx?: number): PxSpan;
/**
 * Absolute pixel extent (measured from the layout origin) of the region blocks
 * — content and elided — but not the blank inter-region padding at the ends.
 * Since dynamic blocks only pad at the ends, the region blocks are contiguous,
 * so the first block's left edge to the last block's right edge is the full
 * extent.
 *
 * Uses block pixel geometry rather than projecting genomic coordinates because
 * coalesced elided blocks have their coordinates zeroed out, so coordinate
 * projection cannot reach them at all — and because pixel geometry is per-copy
 * correct for free, where projecting a refName would land both copies of a
 * twice-displayed region on the first.
 */
export declare function regionBlocksPxExtent(blocks: BaseBlock[]): PxSpan | undefined;
/**
 * The visible regions' pixel extent projected onto an overview layout: the span
 * of the overview scalebar's "you are here" rectangle, and of the top edge of
 * the polygon drawn under it. Both read this one extent so they always describe
 * the same regions, elided ones included.
 *
 * The main view and the overview lay out the same regions from cumulative-bp 0,
 * so a main-view pixel maps to the (more zoomed-out) overview by the bpPerPx
 * ratio.
 */
export declare function getOverviewRegionPxSpan({ overview, bpPerPx, blocks, }: {
    overview: ViewLayout;
    bpPerPx: number;
    blocks: BaseBlock[];
}): PxSpan | undefined;
export {};
