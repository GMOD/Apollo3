import type { TrackControlOption } from './types.ts';
import type { CSSProperties } from 'react';
export interface TrackControlMenu {
    /** Whether the menu is up. The caller renders `menuProps` only when true. */
    open: boolean;
    close: () => void;
    /**
     * Spread onto the button that opens the menu. `data-state` is a styling hook
     * — a host's stylesheet can reach `[data-state='open']` without this having to
     * take a `className` for every part.
     */
    triggerProps: {
        'aria-expanded': boolean;
        'aria-haspopup': 'menu';
        'data-state': 'open' | 'closed';
        onClick: (event: React.MouseEvent<HTMLElement>) => void;
    };
    /** Spread onto the menu container — portal it to `document.body`. */
    menuProps: {
        ref: React.Ref<HTMLDivElement>;
        role: 'menu';
        tabIndex: -1;
        style: CSSProperties;
    };
    /**
     * Spread onto each option. Selecting closes and returns focus to the trigger.
     *
     * `role="menuitemradio"` is also how the arrow keys find their targets — the
     * hook queries the container for it rather than collecting refs, so any markup
     * that spreads these props is navigable without handing anything back.
     */
    getOptionProps: (option: TrackControlOption) => {
        role: 'menuitemradio';
        'aria-checked': boolean;
        onClick: () => void;
    };
}
/**
 * #api
 * The behaviour behind a bottom-right track control's menu, as prop getters to
 * spread — dismissal (Escape, an outside press, an ancestor scrolling), the
 * keyboard (arrows, Home/End), focus, and the anchoring that clears both the
 * display's `contain: strict` box and the window edge.
 *
 * For writing your own control rather than restyling `plainTrackControl`: each
 * of those rules is a bug when missed and none of them shows up in a
 * screenshot. Render `menuProps` only while `open`, and portal it to
 * `document.body` — `createPortal` is the caller's to aim, the maths is here.
 * `menuProps.style` carries position only.
 */
export declare function useTrackControlMenu(): TrackControlMenu;
