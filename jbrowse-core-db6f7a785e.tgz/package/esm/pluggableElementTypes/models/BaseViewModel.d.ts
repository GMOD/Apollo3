import type { MenuItem } from '../../ui/index.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel BaseViewModel
 * #category view
 */
declare const BaseViewModel: import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     * displayName is displayed in the header of the view, or assembly names
     * being used if none is specified
     */
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    /**
     * #property
     * collapse the view to its header bar, keeping it in the session rather
     * than closing it
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    width: number;
    /**
     * Whether the container has this view's body in the DOM.
     *
     * `ViewContainer` mounts a view's body only while an IntersectionObserver
     * says it is on screen, to hold the app under the WebGL2 context ceiling
     * (`reference/GPU_CONTEXT_BUDGET.md`). A view below the fold therefore has
     * no canvas, so nothing ever calls `markCanvasDrawn` and the pre-first-paint
     * term of `displayPhase` pins every display in it at `loading` with nothing
     * left to resolve it — which parks `[data-app-phase="ready"]` for the whole
     * app on a view the user cannot see.
     *
     * Defaults true so the containers that always mount a body — embedded
     * views, workspace panels, and any test rendering a display directly — are
     * unaffected and need not set it.
     */
    bodyMounted: boolean;
} & {
    /**
     * #method
     */
    menuItems(): MenuItem[];
} & {
    /**
     * #action
     */
    setDisplayName(name: string): void;
    /**
     * #action
     * width is an important attribute of the view model, when it becomes set,
     * it often indicates when the app can start drawing to it. certain views
     * like lgv are strict about this because if it tries to draw before it
     * knows the width it should draw to, it may start fetching data for
     * regions it doesn't need to
     *
     * setWidth is updated by a ResizeObserver generally, the views often need
     * to know how wide they are to properly draw genomic regions
     */
    setWidth(newWidth: number): void;
    /**
     * #action
     * See `bodyMounted`. Written by the view's container, which is the only
     * thing that knows whether it rendered the body.
     */
    setBodyMounted(flag: boolean): void;
    /**
     * #action
     */
    setMinimized(flag: boolean): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default BaseViewModel;
export type IBaseViewModel = Instance<typeof BaseViewModel> & {
    type: string;
    assemblyNames?: string[];
};
export declare const BaseViewModelWithDisplayedRegions: import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     * displayName is displayed in the header of the view, or assembly names
     * being used if none is specified
     */
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    /**
     * #property
     * collapse the view to its header bar, keeping it in the session rather
     * than closing it
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "displayedRegions"> & {
    displayedRegions: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<Omit<{
        refName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        start: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
        end: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
        reversed: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    }, "assemblyName"> & {
        assemblyName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }, {
        setRefName(newRefName: string): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {
    width: number;
    /**
     * Whether the container has this view's body in the DOM.
     *
     * `ViewContainer` mounts a view's body only while an IntersectionObserver
     * says it is on screen, to hold the app under the WebGL2 context ceiling
     * (`reference/GPU_CONTEXT_BUDGET.md`). A view below the fold therefore has
     * no canvas, so nothing ever calls `markCanvasDrawn` and the pre-first-paint
     * term of `displayPhase` pins every display in it at `loading` with nothing
     * left to resolve it — which parks `[data-app-phase="ready"]` for the whole
     * app on a view the user cannot see.
     *
     * Defaults true so the containers that always mount a body — embedded
     * views, workspace panels, and any test rendering a display directly — are
     * unaffected and need not set it.
     */
    bodyMounted: boolean;
} & {
    /**
     * #method
     */
    menuItems(): MenuItem[];
} & {
    /**
     * #action
     */
    setDisplayName(name: string): void;
    /**
     * #action
     * width is an important attribute of the view model, when it becomes set,
     * it often indicates when the app can start drawing to it. certain views
     * like lgv are strict about this because if it tries to draw before it
     * knows the width it should draw to, it may start fetching data for
     * regions it doesn't need to
     *
     * setWidth is updated by a ResizeObserver generally, the views often need
     * to know how wide they are to properly draw genomic regions
     */
    setWidth(newWidth: number): void;
    /**
     * #action
     * See `bodyMounted`. Written by the view's container, which is the only
     * thing that knows whether it rendered the body.
     */
    setBodyMounted(flag: boolean): void;
    /**
     * #action
     */
    setMinimized(flag: boolean): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type IBaseViewModelWithDisplayedRegions = Instance<typeof BaseViewModelWithDisplayedRegions>;
