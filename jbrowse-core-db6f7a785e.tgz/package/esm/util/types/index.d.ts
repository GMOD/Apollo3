import type TextSearchManager from '../../TextSearch/TextSearchManager.ts';
import type { AnyConfigurationModel, ResolvableDisplay } from '../../configuration/index.ts';
import type { BaseInternetAccountModel } from '../../pluggableElementTypes/models/index.ts';
import type { PluginDefinition } from '../../pluginDefinitions.ts';
import type RpcManager from '../../rpc/RpcManager.ts';
import type { MenuItem } from '../../ui/index.ts';
import type { Feature } from '../simpleFeature.ts';
import type { TrackConfigChange } from '../trackConfigDelta.ts';
import type { UriLocation } from './data.ts';
import type { RenderingServices } from './renderingServices.ts';
import type { DialogHost, NotificationSink } from './services.ts';
import type { IAnyStateTreeNode, IStateTreeNode, SnapshotIn } from '@jbrowse/mobx-state-tree';
import type { Theme, ThemeOptions } from '@mui/material';
export type { AnyReactComponentType, ClassReturnedBy, InstanceTypeRestrictive, TypeTestedByPredicate, } from './util.ts';
export type { IsAny } from './isAny.ts';
export { isSessionServices } from './services.ts';
export type { DialogComponentType, DialogHost, NotificationLevel, NotificationSink, PaletteHost, RpcCaller, RpcHost, SessionServices, SnackAction, } from './services.ts';
export type { AssemblyHost, AssemblyManager, RenderingServices, } from './renderingServices.ts';
export { AuthNeededError, isAuthNeededException, isBlobLocation, isFileHandleLocation, isLocalPathLocation, isUriLocation, } from './data.ts';
export type { AugmentedRegion, BasePlugin, BlobLocation, FileHandleLocation, FileLocation, JBrowsePlugin, JBrowsePluginVersion, LocalPathLocation, NoAssemblyRegion, PreBlobLocation, PreFileHandleLocation, PreFileLocation, PreLocalPathLocation, PreUriLocation, Region, UriLocation, } from './data.ts';
/** abstract type for a model that contains multiple views */
export interface AbstractViewContainer extends IStateTreeNode {
    views: AbstractViewModel[];
    removeView(view: AbstractViewModel): void;
    addView(typeName: string, initialState?: Record<string, unknown>): AbstractViewModel;
}
export declare function isViewContainer(thing: unknown): thing is AbstractViewContainer;
/**
 * the slice of a view that track-action menu items need: opening a track, and
 * (for views that show tracks) reporting which display is active for a given
 * track so the config editor can expand it and collapse the rest
 */
export interface TrackActionView {
    showTrack: (id: string) => void;
    getActiveDisplayId?: (trackId: string) => string | undefined;
}
/**
 * controls feature-layout animations. 'system' respects the OS
 * prefers-reduced-motion setting, 'enabled' always animates, 'disabled' never
 * animates
 */
export type AnimationMode = 'system' | 'enabled' | 'disabled';
/**
 * The tracks and assemblies a host offers, which is what a track picker, a
 * track-name lookup and a search result read.
 *
 * App-shaped by construction — `AnyConfigurationModel` is the configuration
 * schema machinery — so this lives here beside the session family rather than
 * in `./services.ts`, which is the file that stays cheap to name.
 */
export interface TrackCatalog {
    tracks: AnyConfigurationModel[];
    assemblies: AnyConfigurationModel[];
    connectionInstances?: {
        tracks: AnyConfigurationModel[];
    }[];
    getTrackById: (id: string) => AnyConfigurationModel | undefined;
}
/** minimum interface that all session state models must implement */
export interface AbstractSessionModel extends AbstractViewContainer, RenderingServices, NotificationSink, DialogHost, TrackCatalog {
    /** @deprecated prefer the per-id reactive `getTrackById(id)` */
    getTracksById: () => Record<string, AnyConfigurationModel>;
    jbrowse: IAnyStateTreeNode;
    drawerPosition?: string;
    stickyViewHeaders?: boolean;
    configuration: AnyConfigurationModel;
    rpcManager: RpcManager;
    assemblyNames: string[];
    selection?: unknown;
    focusedViewId?: string;
    themeName?: string;
    theme: Theme;
    animationMode: AnimationMode;
    scrollZoom: boolean;
    highlightsVisible: boolean;
    setHighlightsVisible: (arg: boolean) => void;
    revealHighlights: () => void;
    getPreference: (key: string) => unknown;
    setPreferenceOverride: (key: string, value: unknown) => void;
    clearPreferenceOverrides: () => void;
    setScrollZoom: (flag: boolean) => void;
    getDisplayTypeDefault: (displayType: string, slot: string) => unknown;
    setDisplayTypeDefault: (displayType: string, slot: string, value: unknown) => void;
    hovered: unknown;
    setHovered: (arg: unknown) => void;
    setFocusedViewId?: (id: string) => void;
    allThemes?: () => Record<string, ThemeOptions & {
        name?: string;
    }>;
    getActiveThemeOptions?: (name?: string) => (ThemeOptions & {
        name?: string;
    }) | undefined;
    setSelection: (feature: Feature) => void;
    setSession?: (arg: {
        name: string;
        [key: string]: unknown;
    }) => void;
    clearSelection: () => void;
    duplicateCurrentSession?: () => void;
    version: string;
    gitCommit?: string;
    getTrackActionMenuItems?: (arg: {
        config: AnyConfigurationModel;
        view?: TrackActionView;
    }) => MenuItem[];
    getTrackActions?: (arg: AnyConfigurationModel, view?: TrackActionView) => MenuItem[];
    getTrackListMenuItems?: (arg: AnyConfigurationModel, view?: TrackActionView) => MenuItem[];
    addAssembly?: (conf: Record<string, unknown>) => void;
    addSessionAssembly?: (conf: Record<string, unknown>) => void;
    sessionAssemblies?: AnyConfigurationModel[];
    removeAssembly?: (name: string) => void;
    textSearchManager?: TextSearchManager;
    connections: AnyConfigurationModel[];
    deleteConnection?: (arg: AnyConfigurationModel) => void;
    temporaryAssemblies?: unknown[];
    addTemporaryAssembly?: (arg: Record<string, unknown>) => void;
    removeTemporaryAssembly?: (arg: string) => void;
    sessionConnections?: AnyConfigurationModel[];
    sessionTracks?: AnyConfigurationModel[];
    trackConfigDeltas?: Record<string, {
        trackId: string;
        [key: string]: unknown;
    }>;
    getTrackConfigChanges?: (trackId: string) => TrackConfigChange[];
    resetTrackConfiguration?: (trackId: string) => void;
    connectionInstances?: ConnectionInstance[];
    connectionTrackConfigs?: Record<string, {
        connectionId: string;
        config: Record<string, unknown>;
    }>;
    makeConnection?: (arg: AnyConfigurationModel) => void;
    breakConnection?: (arg: AnyConfigurationModel) => void;
    captureConnectionTrack?: (trackId: string) => void;
    pruneConnectionTrackConfig?: (trackId: string) => void;
    hydrateConnection?: (connectionId: string) => void;
    adminMode: boolean;
    showWidget?: (widget: unknown) => void;
    addWidget?: (typeName: string, id: string, initialState?: Record<string, unknown>, configuration?: {
        type: string;
    }) => Widget;
    name: string;
    id?: string;
}
export declare function isSessionModel(thing: unknown): thing is AbstractSessionModel;
/** abstract interface for a session allows editing configurations */
export interface SessionWithConfigEditing extends AbstractSessionModel {
    editConfiguration(configuration: AnyConfigurationModel, opts?: {
        expandedDisplayId?: string;
    }): void;
    updateTrackConfiguration(trackConf: {
        trackId: string;
        [key: string]: unknown;
    }): void;
}
export declare function isSessionModelWithConfigEditing(t: unknown): t is SessionWithConfigEditing;
/**
 * abstract interface for a session that can swap one of its views for a new one
 * of another type, in the slot the old view occupied.
 *
 * Separate from AbstractViewContainer rather than an optional member on it: the
 * single-view embedded products implement addView by destructively replacing
 * their one view, which is the same words for a different contract — there is
 * no slot and nothing to name. Only a real multi-view container can offer this,
 * and the guard is what a launcher asks before offering it.
 */
export interface SessionWithViewReplacement extends AbstractSessionModel {
    replaceView(view: AbstractViewModel, typeName: string, initialState?: Record<string, unknown>): AbstractViewModel;
}
export declare function isSessionWithViewReplacement(t: unknown): t is SessionWithViewReplacement;
/**
 * Whether `view` is a view a launcher can actually offer to swap out — i.e.
 * whether "Replace current view" would replace anything.
 *
 * Both halves are needed. The session must be able to replace a view at all,
 * and the view must be one of the session's OWN: a launcher resolves its source
 * with `getContainingView`, which inside a LinearSyntenyView (or a dotplot)
 * returns the row's inner LGV, and that view occupies no session slot. Replacing
 * it falls through to `addView`, so the button did what Submit does while saying
 * otherwise — the launched view appended below the untouched source. Asking this
 * instead leaves those cases with the one button that tells the truth.
 */
export declare function canReplaceView(session: AbstractViewContainer, view: AbstractViewModel | undefined): view is AbstractViewModel;
/**
 * Open a launched view, either in the slot `replacing` occupies or appended.
 *
 * The branch every launcher that offers "Replace current view" would otherwise
 * write for itself, kept in one place with the guard it depends on. A session
 * that can't replace a view falls back to appending, so a caller passes the
 * source view unconditionally and never has to ask twice.
 */
export declare function addOrReplaceView({ session, typeName, initialState, replacing, }: {
    session: AbstractViewContainer;
    typeName: string;
    initialState?: Record<string, unknown>;
    replacing?: AbstractViewModel;
}): AbstractViewModel;
/**
 * abstract interface for a session that can publish a track config to the
 * shared catalog on behalf of whoever is looking.
 *
 * The capability the "Add track" workflows need, and nothing else: an admin's
 * track goes into the config.json every visitor is served. A feature standing a
 * track up on the user's behalf wants `SessionWithAddSessionTrack` below —
 * every session has that one, so reaching for this is a statement about the
 * workflow rather than a fallback when the other is missing.
 */
export interface SessionWithPublishTrackConf extends AbstractSessionModel {
    publishTrackConf(configuration: AnyConfigurationModel | SnapshotIn<AnyConfigurationModel>): AnyConfigurationModel | undefined;
}
export declare function isSessionWithPublishTrackConf(t: unknown): t is SessionWithPublishTrackConf;
/**
 * abstract interface for a session that keeps a user's own added/copied tracks
 * separate from the ones the config ships. `AbstractSessionModel` already
 * declares `sessionTracks` optionally; this is the narrowing a caller needs to
 * read it, and it lives here rather than in product-core so a plugin — in-tree
 * or external — can ask the question through the ABI it already depends on.
 */
export interface SessionWithSessionTracks extends AbstractSessionModel {
    sessionTracks: AnyConfigurationModel[];
}
export declare function isSessionWithSessionTracks(t: unknown): t is SessionWithSessionTracks;
/**
 * abstract interface for a session that can be given a track belonging to the
 * session itself.
 *
 * The default, and what a feature standing a track up on the user's behalf
 * wants: an admin opening a VCF in the SV inspector does not thereby mean to
 * publish it to every visitor. Every session mixin defines
 * `addSessionTrackConf`, so a false here means the host turned tracks off
 * (`disableAddTracks`) rather than that this product lacks a session scope —
 * the guard is about permission, not about capability.
 */
export interface SessionWithAddSessionTrack extends AbstractSessionModel {
    addSessionTrackConf(configuration: AnyConfigurationModel | SnapshotIn<AnyConfigurationModel>): AnyConfigurationModel | undefined;
}
export declare function isSessionWithAddSessionTrack(t: unknown): t is SessionWithAddSessionTrack;
/**
 * @deprecated ask `isSessionWithAddSessionTrack` for a track a feature stands
 * up on the user's behalf, or `isSessionWithPublishTrackConf` in an Add-track
 * workflow.
 *
 * Kept because a prebuilt plugin bundle links it by name off
 * `JBrowseExports['@jbrowse/core/util']` and cannot be recompiled:
 * jbrowse-plugin-protein3d 0.8.0 gates its structure-track launch on it
 * (`(0,ll.isSessionWithAddTracks)(e)?e:void 0`), so dropping the export makes
 * the call `undefined is not a function` inside the menu builder rather than
 * failing a build. It answers the session-scoped question now, which is the one
 * that caller wanted — its launch goes on to `session.addTrackConf`, the
 * session-scoped alias. `graphgenomeviewer` does not reference either name.
 *
 * Nothing in tree may call it; `no-restricted-syntax` says so.
 */
export declare const isSessionWithAddTracks: typeof isSessionWithAddSessionTrack;
/** abstract interface for a session that allows adding session assemblies */
export interface SessionWithAddAssembly extends AbstractSessionModel {
    addSessionAssembly(conf: Record<string, unknown>): void;
}
export declare function isSessionWithAddAssembly(t: unknown): t is SessionWithAddAssembly;
/** abstract interface for a session that allows deleting track configs */
export interface SessionWithDeleteTrackConf extends AbstractSessionModel {
    deleteTrackConf(configuration: AnyConfigurationModel): void;
}
export declare function isSessionWithDeleteTrackConf(t: unknown): t is SessionWithDeleteTrackConf;
/** abstract interface for a session allows adding tracks */
export interface SessionWithShareURL extends AbstractSessionModel {
    shareURL: string;
}
export declare function isSessionWithShareURL(thing: unknown): thing is SessionWithShareURL;
export interface Widget {
    type: string;
    id: string;
    view?: {
        id: string;
    };
}
/** Minimal map interface compatible with both native Map and MST IMSTMap */
export interface WidgetMap<K, V> {
    size: number;
    has(key: K): boolean;
    get(key: K): V | undefined;
    keys(): IterableIterator<K>;
    values(): IterableIterator<V>;
    entries(): IterableIterator<[K, V]>;
    forEach(callbackfn: (value: V, key: K) => void): void;
    [Symbol.iterator](): IterableIterator<[K, V]>;
}
/** abstract interface for a session that manages widgets */
export interface SessionWithWidgets extends AbstractSessionModel {
    minimized: boolean;
    visibleWidget?: Widget;
    widgets: WidgetMap<string, Widget>;
    activeWidgets: WidgetMap<string, Widget>;
    hideAllWidgets: () => void;
    addWidget(typeName: string, id: string, initialState?: Record<string, unknown>, configuration?: {
        type: string;
    }): Widget;
    showWidget(widget: unknown): void;
    hideWidget(widget: unknown): void;
}
export interface SessionWithDrawerWidgets extends SessionWithWidgets {
    drawerWidth: number;
    resizeDrawer(arg: number): number;
    minimizeWidgetDrawer(): void;
    showWidgetDrawer: () => void;
    drawerPosition: string;
    setDrawerPosition(arg: string): void;
    /** true while the visible widget is shown in a modal instead of the drawer */
    poppedOut: boolean;
    popoutWidget(): void;
    returnWidgetToDrawer(): void;
}
export declare function isSessionModelWithWidgets(thing: unknown): thing is SessionWithWidgets;
/** a live connection instance held in a session's `connectionInstances` */
export interface ConnectionInstance {
    name: string;
    connectionId: string;
    tracks: AnyConfigurationModel[];
    configuration: AnyConfigurationModel;
    loading: boolean;
}
/** a session that can turn connections on and off */
export interface SessionWithConnections extends AbstractSessionModel {
    connectionInstances: ConnectionInstance[];
    makeConnection: (arg: AnyConfigurationModel) => void;
    breakConnection: (arg: AnyConfigurationModel) => void;
    deleteConnection: (arg: AnyConfigurationModel) => void;
}
export declare function isSessionModelWithConnections(thing: unknown): thing is SessionWithConnections;
/** a session that can also add new connection configs */
export interface SessionWithConnectionEditing extends SessionWithConnections {
    addConnectionConf: (arg: AnyConfigurationModel) => AnyConfigurationModel;
}
export declare function isSessionModelWithConnectionEditing(thing: unknown): thing is SessionWithConnectionEditing;
export interface SessionWithSessionPlugins extends AbstractSessionModel {
    sessionPlugins: (PluginDefinition & {
        name: string;
    })[];
    addSessionPlugin: (plugin: PluginDefinition & {
        name: string;
    }) => void;
    removeSessionPlugin: (plugin: PluginDefinition) => void;
}
export declare function isSessionWithSessionPlugins(thing: unknown): thing is SessionWithSessionPlugins;
/** abstract interface for a session that manages a global selection */
export interface SelectionContainer extends AbstractSessionModel {
    selection?: unknown;
    setSelection(thing: unknown): void;
}
export declare function isSelectionContainer(thing: unknown): thing is SelectionContainer;
/** abstract interface for a session allows applying focus to views and widgets */
export interface SessionWithFocusedViewAndDrawerWidgets extends SessionWithDrawerWidgets {
    focusedViewId: string | undefined;
    setFocusedViewId(id: string): void;
}
/**
 * the slice of a view that the track-selector and add-track widgets write into:
 * a track list, the assemblies it may show tracks for, and the open/close
 * actions. A plain view is its own track container; a view that owns several
 * (the synteny view's per-level track lists) hands them out via
 * `trackContainerFor`.
 */
export interface TrackContainer {
    tracks: {
        configuration: {
            trackId: string;
        };
        displays: ResolvableDisplay[];
    }[];
    assemblyNames?: string[];
    /**
     * The trailing three are `showTrackGeneric`'s, and only the last has a caller
     * here: `addTrackFromWidget` passes a config the session must not keep. A
     * container that implements the one-argument form still satisfies this, and
     * drops the config — `showTrackGeneric` then finds no track by that id and
     * throws "Could not resolve identifier", which is a snackbar rather than a
     * silence.
     */
    showTrack: (trackId: string, initialSnapshot?: object, displayInitialSnapshot?: Record<string, unknown>, inlineConf?: Record<string, unknown>) => unknown;
    hideTrack: (trackId: string) => unknown;
    toggleTrack: (trackId: string) => unknown;
}
/** minimum interface that all view state models must implement */
export interface AbstractViewModel {
    id: string;
    type: string;
    width: number;
    minimized: boolean;
    /**
     * Whether the view's container has its body in the DOM — see
     * `BaseViewModel.bodyMounted`. A display's phase excuses the first paint it
     * will never make while this is false.
     */
    bodyMounted: boolean;
    setWidth(width: number): void;
    setBodyMounted(flag: boolean): void;
    setMinimized(flag: boolean): void;
    displayName: string | undefined;
    setDisplayName: (arg: string) => void;
    menuItems: () => MenuItem[];
    assemblyNames?: string[];
    /**
     * a track container owned by this view, by its id. Only views holding more
     * than one track list implement it; for every other view the widget targets
     * the view itself.
     */
    trackContainerFor?: (id: string) => TrackContainer | undefined;
    /**
     * every track container this view owns INSTEAD of a `tracks` array of its
     * own. The synteny view is the only one: its tracks hang off the levels, one
     * per band, so anything walking `view.tracks` to reach a display finds
     * nothing there and reads a still-fetching synteny view as idle.
     * `trackContainerFor` cannot answer that — a walker has no id to ask with.
     */
    trackContainers?: TrackContainer[];
}
export declare function isViewModel(thing: unknown): thing is AbstractViewModel;
type Display = {
    displayId: string;
} & AnyConfigurationModel;
export interface AbstractTrackModel {
    id: string;
    displays: AbstractDisplayModel[];
    configuration: AnyConfigurationModel & {
        displays: Display[];
    };
    minimized: boolean;
}
export declare function isTrackModel(thing: unknown): thing is AbstractTrackModel;
export interface AbstractDisplayModel {
    id: string;
    parentTrack: AbstractTrackModel;
    renderDelay: number;
    cannotBeRenderedReason?: string;
}
export declare function isDisplayModel(thing: unknown): thing is AbstractDisplayModel;
export interface TrackViewModel extends AbstractViewModel {
    showTrack(trackId: string): void;
    hideTrack(trackId: string): void;
}
export declare function isTrackViewModel(thing: unknown): thing is TrackViewModel;
/** minimum interface for the root MST model of a JBrowse app */
export interface AbstractRootModel {
    jbrowse: IAnyStateTreeNode;
    session?: AbstractSessionModel;
    setSession?(arg: {
        name: string;
        [key: string]: unknown;
    }): void;
    setDefaultSession?(): void;
    adminMode: boolean;
    error?: unknown;
}
/** root model with more included for the heavier JBrowse web and desktop app */
export interface AppRootModel extends AbstractRootModel {
    internetAccounts: BaseInternetAccountModel[];
    findAppropriateInternetAccount(location: UriLocation): BaseInternetAccountModel | undefined;
    createEphemeralInternetAccount(internetAccountId: string, initialSnapshot: Record<string, unknown>, url: string): BaseInternetAccountModel;
}
export declare function isAppRootModel(thing: unknown): thing is AppRootModel;
export interface RootModelWithInternetAccounts extends AbstractRootModel {
    internetAccounts: BaseInternetAccountModel[];
    findAppropriateInternetAccount(location: UriLocation): BaseInternetAccountModel | undefined;
}
export declare function isRootModelWithInternetAccounts(thing: unknown): thing is RootModelWithInternetAccounts;
/**
 * a root model that manages global menus. Every method records a contribution
 * that is applied when the menu opens, so none of them can report where the
 * item landed
 */
export interface AbstractMenuManager {
    appendMenu(menuName: string): void;
    insertMenu(menuName: string, position: number): void;
    insertInMenu(menuName: string, menuItem: MenuItem, position: number): void;
    appendToMenu(menuName: string, menuItem: MenuItem): void;
    appendToSubMenu(menuPath: string[], menuItem: MenuItem): void;
    insertInSubMenu(menuPath: string[], menuItem: MenuItem, position: number): void;
}
export declare function isAbstractMenuManager(thing: unknown): thing is AbstractMenuManager;
