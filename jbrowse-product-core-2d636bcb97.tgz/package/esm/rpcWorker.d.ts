import { RpcServer } from '@jbrowse/core/util/librpc';
import type { PluginConstructor } from '@jbrowse/core/Plugin';
import type { LoadedPlugin } from '@jbrowse/core/PluginLoader';
declare global {
    interface Window {
        rpcServer?: RpcServer;
    }
}
export declare function initializeWorker(corePlugins: PluginConstructor[], opts: {
    fetchESM?: (url: string) => Promise<LoadedPlugin>;
    fetchCJS?: (url: string) => Promise<LoadedPlugin>;
}): Promise<void>;
