export declare function migrateSessionSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
export declare function migrateConfigSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
