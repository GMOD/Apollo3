import type PluginManager from '@jbrowse/core/PluginManager';
import type { IAnyModelType, SnapshotIn, SnapshotOut } from '@jbrowse/mobx-state-tree';
export declare function finalizeSession<T extends IAnyModelType>(pluginManager: PluginManager, sessionModel: T): import("@jbrowse/mobx-state-tree").ISnapshotProcessor<T, Omit<SnapshotIn<T> & {
    connectionInstances?: unknown;
}, "connectionInstances">, Omit<SnapshotOut<T> & {
    connectionInstances?: unknown;
}, "connectionInstances">>;
