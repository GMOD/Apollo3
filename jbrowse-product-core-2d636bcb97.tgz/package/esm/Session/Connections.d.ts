import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { BaseConnectionConfigModel } from '@jbrowse/core/pluggableElementTypes/models/baseConnectionConfig';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
export interface ConnectionTrackConfigEntry {
    connectionId: string;
    config: Record<string, unknown>;
}
export declare function ConnectionManagementSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    connectionInstances: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    connectionTrackConfigs: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Record<string, ConnectionTrackConfigEntry>, Record<string, ConnectionTrackConfigEntry>, Record<string, ConnectionTrackConfigEntry>>, [undefined]>;
}, {
    readonly connections: BaseConnectionConfigModel[];
} & {
    makeConnection(configuration: AnyConfigurationModel, initialSnapshot?: any): any;
    breakConnection(configuration: AnyConfigurationModel): void;
    teardownConnection(configuration: AnyConfigurationModel): void;
    deleteConnection(configuration: AnyConfigurationModel): any;
    addConnectionConf(connectionConf: AnyConfigurationModel): any;
    clearConnections(): void;
    captureConnectionTrack(trackId: string): void;
    updateConnectionTrackConfig(trackConf: Record<string, unknown> & {
        trackId: string;
    }): void;
    setConnectionTrackConfig(trackId: string, connectionId: string, config: Record<string, unknown>): void;
    pruneConnectionTrackConfig(trackId: string): void;
    hydrateConnection(connectionId: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type SessionWithConnectionsType = ReturnType<typeof ConnectionManagementSessionMixin>;
export type SessionWithConnections = Instance<SessionWithConnectionsType>;
export declare function isSessionWithConnections(session: IAnyStateTreeNode): session is SessionWithConnections;
