import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { BaseTrackConfig } from '@jbrowse/core/pluggableElementTypes';
import type { MenuItem } from '@jbrowse/core/ui';
import type { DialogComponentType } from '@jbrowse/core/util';
import type { TrackActionView } from '@jbrowse/core/util/types';
type TrackCopySnapshot = {
    trackId: string;
    name: string;
    category?: unknown;
    displays?: {
        type: string;
        displayId: string;
    }[];
} & Record<string, unknown>;
export declare function copyTrackSnapshot(config: BaseTrackConfig, opts: {
    clearCategory: boolean;
}): TrackCopySnapshot;
interface TrackActionSession<C> {
    editConfiguration: (config: AnyConfigurationModel | {
        trackId: string;
    }, opts?: {
        expandedDisplayId?: string;
    }) => void;
    addTrackConf: (conf: C) => unknown;
    deleteTrackConf: (conf: AnyConfigurationModel) => void;
    resetTrackConfiguration?: (trackId: string) => void;
}
export declare function trackActionItems<C extends {
    trackId: string;
}>({ session, config, view, canEdit, isSessionOverride, makeCopy, }: {
    session: TrackActionSession<C>;
    config: BaseTrackConfig;
    view?: TrackActionView;
    canEdit: boolean;
    isSessionOverride?: boolean;
    makeCopy: () => C;
}): MenuItem[];
interface SessionWithDialog {
    queueDialog: (cb: (done: () => void) => [DialogComponentType, Record<string, unknown>]) => void;
}
type TrackConfig = AnyConfigurationModel | Record<string, unknown>;
export declare function aboutTrackMenuItem(session: SessionWithDialog, config: TrackConfig): MenuItem;
export declare function pluginExtraTrackItems(pluginManager: PluginManager, session: SessionWithDialog, config: AnyConfigurationModel, view?: TrackActionView): MenuItem[];
export declare function trackListMenuItems(session: SessionWithDialog, config: TrackConfig, actions: MenuItem[]): MenuItem[];
export declare function trackActionMenuItems(session: SessionWithDialog, config: TrackConfig, actions: MenuItem[]): MenuItem[];
export declare function TrackMenuItemsSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    getTrackListMenuItems(config: BaseTrackConfig, view?: TrackActionView): MenuItem[];
    getTrackActionMenuItems({ config, view, }: {
        config: BaseTrackConfig;
        view?: TrackActionView;
    }): MenuItem[];
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export {};
