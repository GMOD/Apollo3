import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { MenuItem } from '@jbrowse/core/ui';
import type { TrackActionView } from '@jbrowse/core/util/types';
export declare function TrackMenuSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    getTrackListMenuItems(config: AnyConfigurationModel, view?: TrackActionView): MenuItem[];
    getTrackActionMenuItems({ config, view, }: {
        config: AnyConfigurationModel;
        view?: TrackActionView;
    }): MenuItem[];
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
