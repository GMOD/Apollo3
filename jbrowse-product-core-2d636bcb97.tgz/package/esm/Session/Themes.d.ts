import type PluginManager from '@jbrowse/core/PluginManager';
import type { SerializableThemeArgs, ThemeMap } from '@jbrowse/core/ui';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
export declare function ThemeManagerSessionMixin(_pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    sessionThemeName: string;
} & {
    allThemes(): ThemeMap;
    readonly themeName: string;
    readonly themeOptions: SerializableThemeArgs;
    readonly theme: import("@mui/material").Theme;
    getActiveThemeOptions(name?: string): (import("@mui/material").ThemeOptions & {
        name?: string;
    }) | undefined;
} & {
    setThemeName(name: string): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type SessionWithThemesType = ReturnType<typeof ThemeManagerSessionMixin>;
export type SessionWithThemes = Instance<SessionWithThemesType>;
export declare function isSessionWithThemes(session: IAnyStateTreeNode): session is SessionWithThemes;
