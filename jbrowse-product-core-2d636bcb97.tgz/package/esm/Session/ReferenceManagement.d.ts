import type PluginManager from '@jbrowse/core/PluginManager';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
export interface ReferringNode {
    node: IAnyStateTreeNode;
    key: string;
}
export declare function ReferenceManagementSessionMixin(_pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    getReferringMultiple(trackIds: string[]): Map<string, ReferringNode[]>;
} & {
    getReferring(trackId: string): ReferringNode[];
} & {
    dereferenceTrack(trackId: string, referring: ReferringNode[]): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type SessionWithReferenceManagementType = ReturnType<typeof ReferenceManagementSessionMixin>;
export type SessionWithReferenceManagement = Instance<SessionWithReferenceManagementType>;
export declare function isSessionWithReferenceManagement(thing: IAnyStateTreeNode): thing is SessionWithReferenceManagement;
