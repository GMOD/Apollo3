import type { BaseRootModelType } from '../RootModel/BaseRootModel.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { BaseAssemblyConfigModel } from '@jbrowse/core/assemblyManager';
import type { AnyConfigurationSchemaType } from '@jbrowse/core/configuration';
import type { AnimationMode, DialogComponentType, TrackConfigChange } from '@jbrowse/core/util';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
type DoneCallback = (doneCallback: () => void) => [DialogComponentType, Record<string, unknown>];
export declare function displayTypeDefaultKey(displayType: string, slot: string): string;
export declare function parseDisplayTypeDefaultKey(key: string): {
    displayType: string;
    slot: string;
} | undefined;
export declare const DISPLAY_TYPE_DEFAULTS_PATH_HEAD = "displayTypeDefaults";
export declare function BaseSessionModel<ROOT_MODEL_TYPE extends BaseRootModelType, JB_CONFIG_SCHEMA extends AnyConfigurationSchemaType>(_pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    margin: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    focusedViewId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    highlightsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, never>, {
    selection: unknown;
    hovered: unknown;
    queueOfDialogs: [DialogComponentType, Record<string, unknown>][];
    preferencesOverrides: import("mobx").ObservableMap<string, unknown>;
} & {
    readonly root: import("@jbrowse/mobx-state-tree").TypeOrStateTreeNodeToStateTreeNode<ROOT_MODEL_TYPE>;
} & {
    readonly jbrowse: any;
    readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    readonly configuration: Instance<JB_CONFIG_SCHEMA>;
    readonly adminMode: boolean;
    readonly textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
} & {
    readonly assemblies: BaseAssemblyConfigModel[];
    readonly DialogComponent: DialogComponentType | undefined;
    readonly DialogProps: Record<string, unknown> | undefined;
} & {
    getPreference(key: string): unknown;
    getDisplayTypeDefault(displayType: string, slot: string): unknown;
    getPreferenceChanges(): TrackConfigChange[];
} & {
    readonly animationMode: AnimationMode;
    readonly scrollZoom: boolean;
} & {
    setSelection(thing: unknown): void;
    clearSelection(): void;
    setHovered(thing: unknown): void;
    setHighlightsVisible(arg: boolean): void;
    revealHighlights(): void;
    setPreferenceOverride(key: string, value: unknown): void;
    clearPreferenceOverrides(): void;
    clearPreferenceOverride(key: string): void;
    setScrollZoom(flag: boolean): void;
    setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
    setName(str: string): void;
    setFocusedViewId(viewId: string): void;
    removeActiveDialog(): void;
    queueDialog(doneCallback: DoneCallback): void;
} & {
    snackbarMessages: import("mobx").IObservableArray<import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
    errorDialog: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined;
} & {
    readonly snackbarMessageSet: Map<string, import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
} & {
    notify(message: string, level?: import("@jbrowse/core/util").NotificationLevel, action?: import("@jbrowse/core/util").SnackAction | import("@jbrowse/core/util").SnackAction[]): void;
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: import("@jbrowse/core/util").SnackAction): void;
    setErrorDialog(state: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined): void;
    pushSnackbarMessage(message: string, level?: import("@jbrowse/core/util").NotificationLevel, actions?: import("@jbrowse/core/util").SnackAction[]): void;
    popSnackbarMessage(): import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage | undefined;
    removeSnackbarMessage(message: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseSessionType = ReturnType<typeof BaseSessionModel>;
export type BaseSession = Instance<BaseSessionType>;
export declare function isBaseSession(thing: IAnyStateTreeNode): thing is BaseSession;
export declare function isSession(thing: unknown): thing is BaseSession;
export {};
