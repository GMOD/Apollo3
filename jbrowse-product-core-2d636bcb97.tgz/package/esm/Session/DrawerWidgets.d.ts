import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
export declare function DrawerWidgetSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    drawerPosition: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    drawerWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    widgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    activeWidgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>>, [undefined]>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    readonly visibleWidget: any;
} & {
    poppedOut: boolean;
} & {
    setDrawerPosition(arg: string): void;
    updateDrawerWidth(drawerWidth: number): number;
    resizeDrawer(distance: number): number;
    addWidget(typeName: string, id: string, initialState?: any, conf?: unknown): any;
    showWidget(widget: any): void;
    hideWidget(widget: any): void;
    minimizeWidgetDrawer(): void;
    showWidgetDrawer(): void;
    popoutWidget(): void;
    returnWidgetToDrawer(): void;
    hideAllWidgets(): void;
    editConfiguration(configuration: AnyConfigurationModel | {
        trackId: string;
    }, opts?: {
        expandedDisplayId?: string;
    }): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
    drawerPosition: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    drawerWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    widgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    activeWidgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>>, [undefined]>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}>>;
export type SessionWithDrawerWidgetsType = ReturnType<typeof DrawerWidgetSessionMixin>;
export type SessionWithDrawerWidgets = Instance<SessionWithDrawerWidgetsType>;
export declare function isSessionWithDrawerWidgets(session: IAnyStateTreeNode): session is SessionWithDrawerWidgets;
