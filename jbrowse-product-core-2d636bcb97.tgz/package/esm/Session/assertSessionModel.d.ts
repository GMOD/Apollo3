import type { AssertExtends } from '../assertExtends.ts';
import type { AbstractSessionModel } from '@jbrowse/core/util/types';
export type AssertSessionModel<T extends AbstractSessionModel> = AssertExtends<T, AbstractSessionModel>;
