import type { AbstractSessionModel } from '@jbrowse/core/util';
export declare function bakePromotedDefaultsIntoSnapshot(session: AbstractSessionModel, snapshot: Record<string, unknown>): Record<string, unknown>;
