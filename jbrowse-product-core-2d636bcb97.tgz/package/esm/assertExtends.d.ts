export type AssertExtends<Actual extends Expected, Expected> = Actual;
