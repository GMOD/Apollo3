import type { BaseRootModel } from './RootModel/BaseRootModel.ts';
import type { BaseSession } from './Session/BaseSession.ts';
export declare function asSession<S>(self: S): S & BaseSession;
export declare function asRoot<S>(self: S): S & BaseRootModel;
