import type { AboutPanelProps } from './util.ts';
declare const AboutDialogContents: ({ config, session, }: AboutPanelProps) => import("react").JSX.Element;
export default AboutDialogContents;
