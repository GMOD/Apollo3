import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
export default function FileInfoPanel({ config, session, }: {
    config: AnyConfigurationModel | Record<string, unknown>;
    session: AbstractSessionModel;
}): import("react").JSX.Element;
