import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
declare const RefNameInfoDialog: ({ config, session, onClose, }: {
    config: AnyConfigurationModel | Record<string, unknown>;
    session: AbstractSessionModel;
    onClose: () => void;
}) => import("react").JSX.Element;
export default RefNameInfoDialog;
