import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
import type { JexlInstance } from '@jbrowse/core/util/jexlStrings';
import type { ComponentType } from 'react';
export type AboutConfig = AnyConfigurationModel | Record<string, unknown>;
export interface AboutPanelProps {
    session: AbstractSessionModel;
    config: AboutConfig;
}
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-extraAboutPanel': {
            args: ComponentType<AboutPanelProps>[];
            result: ComponentType<AboutPanelProps>[];
            props: AboutPanelProps;
        };
        'Core-replaceAbout': {
            args: ComponentType<AboutPanelProps>;
            result: ComponentType<AboutPanelProps>;
            props: AboutPanelProps;
        };
        'Core-customizeAbout': {
            args: {
                config: Record<string, unknown>;
            };
            result: {
                config: {
                    metadata?: Record<string, unknown>;
                    [key: string]: unknown;
                };
            };
            props: AboutPanelProps;
        };
    }
}
export declare function readConfSlot<T = unknown>(config: AnyConfigurationModel | Record<string, unknown>, slotPath: string | string[], args?: Record<string, unknown>, jexl?: JexlInstance): T;
export declare function getAboutDialogConfig({ config, session, pluginManager, }: {
    config: AnyConfigurationModel | Record<string, unknown>;
    session: AbstractSessionModel;
    pluginManager: PluginManager;
}): {
    config: {
        metadata?: Record<string, unknown>;
        [key: string]: unknown;
    };
};
