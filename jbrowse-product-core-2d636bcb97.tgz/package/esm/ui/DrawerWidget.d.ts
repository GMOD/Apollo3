import type { SessionWithDrawerWidgets } from '@jbrowse/core/util';
declare const DrawerWidget: ({ session, }: {
    session: SessionWithDrawerWidgets;
}) => import("react").JSX.Element;
export default DrawerWidget;
