import type { SessionWithDrawerWidgets } from '@jbrowse/core/util';
declare const Drawer: ({ session, children, ref, }: {
    session: SessionWithDrawerWidgets;
    children: React.ReactNode;
    ref?: React.Ref<HTMLDivElement>;
}) => import("react").JSX.Element;
export default Drawer;
