import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
export default function AboutDialog({ config, session, handleClose, }: {
    config: AnyConfigurationModel | Record<string, unknown>;
    session: AbstractSessionModel;
    handleClose: () => void;
}): import("react").JSX.Element;
