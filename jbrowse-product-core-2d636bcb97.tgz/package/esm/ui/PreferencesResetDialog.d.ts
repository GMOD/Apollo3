import type { TrackConfigChange } from '@jbrowse/core/util';
declare const PreferencesResetDialog: ({ changes, onReset, onResetRow, onClose, }: {
    changes: TrackConfigChange[];
    onReset: () => void;
    onResetRow: (change: TrackConfigChange) => void;
    onClose: () => void;
}) => import("react").JSX.Element;
export default PreferencesResetDialog;
