import type { SessionWithDrawerWidgets } from '@jbrowse/core/util';
declare const DrawerHeader: ({ session, setToolbarHeight, }: {
    session: SessionWithDrawerWidgets;
    setToolbarHeight: (arg: number) => void;
}) => import("react").JSX.Element;
export default DrawerHeader;
