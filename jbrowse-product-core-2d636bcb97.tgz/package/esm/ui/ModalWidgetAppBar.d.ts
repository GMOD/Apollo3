import type PluginManager from '@jbrowse/core/PluginManager';
import type { Widget } from '@jbrowse/core/util';
declare const ModalWidgetAppBar: ({ widget, pluginManager, onClose, }: {
    widget: Widget;
    pluginManager: PluginManager;
    onClose: () => void;
}) => import("react").JSX.Element;
export default ModalWidgetAppBar;
