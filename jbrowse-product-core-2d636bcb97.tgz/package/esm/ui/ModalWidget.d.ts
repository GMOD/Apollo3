import type { SessionWithWidgets } from '@jbrowse/core/util';
declare const ModalWidget: ({ session, onClose, }: {
    session: SessionWithWidgets;
    onClose: () => void;
}) => import("react").JSX.Element | null;
export default ModalWidget;
