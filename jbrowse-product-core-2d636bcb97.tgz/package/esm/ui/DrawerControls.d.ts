import type { SessionWithDrawerWidgets } from '@jbrowse/core/util';
declare const DrawerControls: ({ session, }: {
    session: SessionWithDrawerWidgets;
}) => import("react").JSX.Element;
export default DrawerControls;
