import type PluginManager from '@jbrowse/core/PluginManager';
import type { Widget } from '@jbrowse/core/util';
declare function WidgetHeading({ widget, pluginManager, }: {
    widget: Widget;
    pluginManager: PluginManager;
}): import("react").JSX.Element;
export default WidgetHeading;
