import type { SessionWithDrawerWidgets } from '@jbrowse/core/util';
declare const DrawerWidgetSelector: ({ session, }: {
    session: SessionWithDrawerWidgets;
}) => import("react").JSX.Element;
export default DrawerWidgetSelector;
