interface HeaderButtonsProps {
    conf: Record<string, unknown>;
    hideUris?: boolean;
    setShowRefNames: (show: boolean) => void;
}
declare function HeaderButtons({ conf, hideUris, setShowRefNames, }: HeaderButtonsProps): import("react").JSX.Element;
export default HeaderButtons;
