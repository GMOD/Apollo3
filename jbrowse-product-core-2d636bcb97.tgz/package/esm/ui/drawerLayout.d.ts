export declare function drawerGridTemplateColumns({ drawerVisible, drawerPosition, drawerWidth, }: {
    drawerVisible: boolean;
    drawerPosition: string;
    drawerWidth: number;
}): string;
