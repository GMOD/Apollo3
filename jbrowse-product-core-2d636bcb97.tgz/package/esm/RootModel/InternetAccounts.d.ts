import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { UriLocation } from '@jbrowse/core/util';
import type { Instance } from '@jbrowse/mobx-state-tree';
export declare function InternetAccountsRootModelMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    internetAccounts: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
}, {
    initializeInternetAccount(internetAccountConfig: AnyConfigurationModel, initialSnapshot?: any): any;
    createEphemeralInternetAccount(internetAccountId: string, initialSnapshot: Record<string, unknown>, url: string): any;
} & {
    findAppropriateInternetAccount(location: UriLocation): any;
} & {
    afterCreate(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type RootModelWithInternetAccountsType = ReturnType<typeof InternetAccountsRootModelMixin>;
export type RootModelWithInternetAccounts = Instance<RootModelWithInternetAccountsType>;
