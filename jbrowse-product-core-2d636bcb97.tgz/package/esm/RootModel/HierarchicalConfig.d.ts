export declare function HierarchicalConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly sort: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly trackNames: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        readonly categories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly defaultFolderCategories: {
        readonly type: "stringArray";
        readonly description: "list of category names to display as folders by default";
        readonly defaultValue: readonly [];
    };
    readonly defaultCollapsed: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly categoryNames: {
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
        readonly topLevelCategories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        readonly subCategories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
