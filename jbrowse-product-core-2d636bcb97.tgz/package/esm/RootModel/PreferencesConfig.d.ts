export declare function PreferencesConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly animationMode: {
        readonly model: import("@jbrowse/mobx-state-tree").ISimpleType<"disabled" | "enabled" | "system">;
        readonly type: "stringEnum";
        readonly defaultValue: "enabled";
    };
    readonly scrollZoom: {
        readonly type: "boolean";
        readonly defaultValue: false;
    };
    readonly useWorkspaces: {
        readonly type: "boolean";
        readonly defaultValue: false;
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
