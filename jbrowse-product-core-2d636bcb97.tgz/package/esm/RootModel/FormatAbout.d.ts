export declare function FormatAboutConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly config: {
        readonly type: "frozen";
        readonly description: "formats configuration object in about dialog";
        readonly defaultValue: {};
        readonly contextVariable: ["config"];
    };
    readonly hideUris: {
        readonly type: "boolean";
        readonly defaultValue: false;
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
