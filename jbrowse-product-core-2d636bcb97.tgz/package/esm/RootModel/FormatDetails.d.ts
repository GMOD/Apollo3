export declare function FormatDetailsConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly feature: {
        readonly type: "frozen";
        readonly description: "adds extra fields to the feature details";
        readonly defaultValue: {};
        readonly contextVariable: ["feature"];
    };
    readonly subfeatures: {
        readonly type: "frozen";
        readonly description: "adds extra fields to the subfeatures of a feature";
        readonly defaultValue: {};
        readonly contextVariable: ["feature"];
    };
    readonly depth: {
        readonly type: "number";
        readonly defaultValue: 2;
        readonly description: "depth to iterate the formatDetails->subfeatures callback on subfeatures (used for example to only apply the callback to the first layer of subfeatures)";
    };
    readonly maxDepth: {
        readonly type: "number";
        readonly defaultValue: 10000;
        readonly description: "hide subfeatures greater than a certain depth";
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
