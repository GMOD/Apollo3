import type { BlendState, GlAttributeLayout, PassDescriptor, ShaderBinding, TextureBinding } from './hal';
export interface ShaderModule {
    WGSL_SOURCE: string;
    GLSL_VERTEX: string;
    GLSL_FRAGMENT: string;
    INSTANCE_STRIDE_BYTES: number;
    GL_ATTRIBUTES: readonly GlAttributeLayout[];
    VERTS_PER_INSTANCE?: number;
    TEXTURES?: readonly [TextureBinding, ...TextureBinding[]];
    BINDINGS?: readonly ShaderBinding[];
}
export interface SlangPassOpts {
    id: string;
    mod: ShaderModule;
    verticesPerInstance?: number;
    topology?: PassDescriptor['topology'];
    blend?: boolean;
    blendState?: BlendState;
    textures?: [TextureBinding, ...TextureBinding[]];
    wgslFragmentEntry?: string;
    glslFragmentOverride?: string;
    bufferStride?: number;
    bufferAttributes?: readonly GlAttributeLayout[];
}
export declare function slangPass(opts: SlangPassOpts): PassDescriptor;
