export declare const MIN_DRAWN_ROW_PX = 1;
