import type React from 'react';
declare function ResizeHandle({ onDrag, onDragStart, onDragEnd, vertical, bar, gain, className: originalClassName, onPointerDown, ...props }: {
    onDrag: (distance: number) => void;
    onDragStart?: () => void;
    onDragEnd?: () => void;
    vertical?: boolean;
    bar?: boolean;
    /**
     * How many px this handle moves per px of the value it drags — see
     * `useResizeDrag`. Pass it when the value is shared by several stacked bands
     * and this handle sits below more than one of them.
     */
    gain?: number;
} & Omit<React.ComponentPropsWithoutRef<'div'>, 'onDrag' | 'onDragStart' | 'onDragEnd'>): React.JSX.Element;
export default ResizeHandle;
