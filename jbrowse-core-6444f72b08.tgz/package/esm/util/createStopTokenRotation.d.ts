import type { RpcStatus, StatusWindow } from './progress.ts';
import type { StopToken } from './stopToken.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Where a rotation reports, in the one of two modes the host is actually in.
 *
 * A union rather than one shape with an optional window, because the two modes
 * do not use the same member and the optional version required the one that is
 * dead in the lending mode: when a host lends its `statusWindow` the rotation
 * writes through the window and never calls `setStatusMessage`, so a caller
 * supplying both got silence from the half it thought it was wiring up.
 * `FetchMixin` was that caller.
 */
export type StatusReporter = {
    /**
     * The host's own window, present on any display composing the LGV fetch
     * mixins. The rotation reports through it rather than opening a SECOND on
     * the same status field — which is what one-window-per-owner exists to
     * prevent.
     */
    statusWindow: StatusWindow;
    setStatusMessage?: never;
} | {
    /**
     * The sink for the window the rotation opens for itself. This is the mode
     * the displays this helper was written for are in (dotplot, synteny),
     * which compose no fetch mixin, along with every
     * {@link createStatusChannel} holder.
     */
    setStatusMessage: (status?: RpcStatus) => void;
    statusWindow?: never;
};
/**
 * A {@link StatusReporter} a model can hold in **one** volatile, for something
 * that has one operation to narrate and no reason to grow a status vocabulary
 * of its own. `ProgressChip` takes `message`/`fraction` straight off it.
 *
 * The alternative is what every display does: two volatiles and an action
 * calling {@link statusMessageText} and {@link statusFraction}. That is the
 * right shape where the fields are part of the model's own surface —
 * `BaseDisplay` and `FetchMixin` declare them because half the display API reads
 * them — and a lot of declaration for a view that wants a corner chip while one
 * fetch runs. A plain function rather than a mixin because a compose layer is
 * what the model chains here cannot afford (ADR-041).
 */
export interface StatusChannel {
    setStatusMessage: (status?: RpcStatus) => void;
    readonly message: string | undefined;
    readonly fraction: number | undefined;
}
export declare function createStatusChannel(): StatusChannel;
export interface ActiveFetch {
    /** stop token to forward to the RPC call */
    stopToken: StopToken;
    /**
     * True only while this is still the most recent fetch AND `self` is alive.
     * Gate every post-await write — result commit, error set — on it so a
     * superseded or torn-down fetch never writes back.
     */
    isCurrent: () => boolean;
    /**
     * RPC `statusCallback` pre-gated by `isCurrent`: forwards progress to
     * `setStatusMessage` only while this is still the latest fetch, so a
     * superseded fetch's late status update can't flicker the overlay, and
     * throttled to the same leading edge as `FetchMixin`'s callbacks. Pass it
     * straight as the RPC `statusCallback` arg.
     */
    statusCallback: (status: RpcStatus) => void;
    /**
     * Call in the `finally` of the run that owns this fetch: closes `isCurrent`
     * and retires this fetch's status slot, which blanks the field only if no
     * other operation on the host is still reporting.
     *
     * Both together, because a caller doing it by hand gets a subset.
     * `isCurrent` is `token === current && isAlive`, and a run that *completes*
     * never rotates its own token — so without this the guard stays open past the
     * work and a trailing write lands on top of a hand-written
     * `setStatusMessage(undefined)` up to a window later.
     *
     * A **superseded** run calls it too, and must: its slot goes on voting for a
     * phase that is over until it does. The run that replaced it has already
     * opened its own slot by then, so the label the user is looking at survives.
     */
    end: () => void;
}
/**
 * Latest-wins stop-token rotation for a fetch that runs in a bare `autorun`
 * rather than through `FetchMixin.runFetch` (which welds the same mechanics to
 * `fetchGeneration`, so it's only for viewport-driven LGV fetches). Each
 * `begin()` aborts the prior fetch's token and returns a fresh one plus an
 * `isCurrent()` guard that captures this run's token — gate every post-await
 * write on it and a superseded or torn-down fetch can never clobber fresher
 * data. The guard is the return value, so a caller can't forget to compare a
 * token by hand.
 *
 * `end()` in the run's `finally` is the other half, and for the same reason —
 * see {@link ActiveFetch.end} for the two things it does together.
 *
 * Owns the token mechanics and the status channel; the caller keeps its own
 * loading/error/commit side-effects. Three holders: `FetchMixin` as a member
 * (so `cancelFetch` can reach it), `installFetch` one per installation (every
 * other fetch in the tree runs on that skeleton), and the synteny diagonalize
 * progress wrapper (`withDiagonalizeProgress`) directly.
 *
 * `report` is passed rather than read off `self`, so where the status lands is
 * the caller's decision and not a shape this imposes. A display passes itself —
 * its status fields are part of its own API, and one composing `FetchMixin`
 * passes the model-wide window along with them (see `StatusReporter`).
 * Anything with one operation to narrate and no status vocabulary of its own
 * passes a {@link createStatusChannel}, which is one volatile instead of two
 * fields and an action.
 */
export declare function createStopTokenRotation(self: IStateTreeNode, report: StatusReporter): {
    begin(): ActiveFetch;
    cancel: () => void;
    dispose(): void;
};
