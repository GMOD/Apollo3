import type { RefObject } from 'react';
export declare function useFocusOnInteraction(ref: RefObject<HTMLElement | null>, onInteract: () => void): void;
export declare function useDebounce<T>(value: T, delay: number): T;
export declare function useWidthSetter(view: {
    setWidth: (arg: number) => void;
    id?: string;
}): RefObject<HTMLDivElement | null>;
/**
 * Build a value exactly once per mount — including under React StrictMode,
 * which `useState(() => build())` does not.
 *
 * StrictMode double-invokes a state initializer in development and throws the
 * SECOND result away. For an ordinary value that is the intended lint: it
 * surfaces impure initializers and costs nothing. For anything that owns
 * something — an MST tree, a worker pool, a subscription — it stands up a second
 * one and then drops the only reference to it, so nothing can ever tear it down,
 * and it is invisible because the one React kept behaves perfectly.
 *
 * A ref is written once and survives the double render; this is React's own
 * "avoiding recreating the ref contents" pattern.
 */
export declare function useCreateOnce<T>(create: () => T): T;
/**
 * Run `cleanup` when the component *really* unmounts.
 *
 * "Really" is the whole difficulty, because React does not distinguish a final
 * unmount from a simulated one. The obvious spelling —
 * `useEffect(() => () => cleanup(), [])` — is wrong in exactly the environment
 * most hosts develop in, jbrowse-web included: StrictMode runs
 * setup → cleanup → setup on a live component, so a cleanup that destroys
 * something leaves the component holding the destroyed thing for the rest of its
 * life, with the second setup having nothing to rebuild from. For an MST tree
 * that is not a quiet degradation — the next read throws `[mobx-state-tree] …
 * [dead]`.
 *
 * So the teardown is deferred by a microtask and cancelled if setup runs again.
 * StrictMode's cleanup and re-setup are one synchronous block, so the cancel
 * always wins there; a real unmount never runs setup again, so the microtask
 * fires.
 *
 * This owns a *component's* teardown, not a per-value one: `cleanup` always sees
 * the latest render's closure, and swapping the thing being torn down mid-life
 * is not supported. Pair it with {@link useCreateOnce}, which is the shape that
 * makes that true.
 *
 * Deliberately not covered: a subtree hidden with `<Activity>`, which destroys
 * effects and re-creates them a TASK later rather than synchronously, so the
 * cancel below cannot reach it. Measured, not assumed — `useFinalUnmount.test.tsx`
 * pins that hiding tears the value down and showing does not rebuild it, since
 * `useCreateOnce`'s ref survives the hide. A host that needs a view to survive
 * being hidden owns the engine itself and keeps it outside the hidden tree.
 */
export declare function useFinalUnmount(cleanup: () => void): void;
/**
 * `useState` backed by a localStorage key.
 *
 * Originally https://usehooks.com/useLocalStorage/, which is per-instance: two
 * components on the same key each kept their own copy of it, so toggling a
 * setting in one BreakpointSplitView header left a second one open beside it
 * showing the old value until it remounted. Instances on a key now subscribe to
 * each other's writes, and to other tabs' — `subscribeToLocalStorageKey`, which
 * the grid-bookmark widget shares from its state model.
 *
 * The store is read on every notify rather than cached, so nothing here can go
 * stale against a `localStorage.clear()`. Which also means a functional update
 * resolves against what is actually stored: two `setValue(v => …)` calls in one
 * handler used to keep only the second, because both resolved against the value
 * captured by the render that produced the setter.
 *
 * `enabled: false` keeps the value in component state only: nothing is read,
 * written or shared. Callers use it for a key that isn't meaningful yet (no
 * assembly chosen, so nothing to scope the key to). A page with no usable store
 * at all — an RPC worker, SSR, a cross-origin iframe with third-party storage
 * blocked, which is the embedded products on someone else's page — runs in that
 * same mode, because reading a key back through a store that dropped the write
 * answers the default and would report it as the stored value: the control
 * would revert the instant the user moved it.
 */
export declare function useLocalStorage<T>(key: string, initialValue: T, enabled?: boolean): readonly [T, (value: T | ((val: T) => T)) => void];
/**
 * The CSS custom property a scroll port publishes its own visible height as, for
 * descendants that have to size against the surface they actually scroll in.
 *
 * `100vh` is the wrong answer for all three of JBrowse's scroll ports and looks
 * right in the one place it is least wrong: the classic view stack sits under a
 * 48px AppBar (measured 852 against a 900px window), a workspace panel is an
 * arbitrary dockview cell, and a bounded embedded view is whatever box the host
 * gave it. A sticky element's offsets are relative to its scroll port, so a
 * `max-height` that bounds one has to be too.
 */
export declare const SCROLL_PORT_HEIGHT_VAR = "--jbrowse-scrollport-height";
/**
 * Publishes {@link SCROLL_PORT_HEIGHT_VAR} on the element the returned ref is
 * attached to. Put it on the element that actually scrolls; the property
 * inherits, so anything inside can read it with a `100vh` fallback for hosts
 * that never mount one.
 *
 * Written straight to the node instead of through state on purpose. This sits on
 * a container wrapping every view, so a re-render per resize frame would
 * re-render all of them to produce a number only CSS reads.
 */
export declare function useScrollPortHeightVar(): RefObject<HTMLDivElement | null>;
/**
 * Whether the element the ref is on is taller than the scroll port it sits in —
 * i.e. whether there is content a user could actually scroll to.
 *
 * Not the same question as "does the port overflow": a port can overflow by
 * trailing space it renders for its own reasons, and a scrollbar offering only
 * that is worse than none, since it says the page has more to show when it does
 * not. So this measures the *content* box and leaves the trailing space out of
 * the comparison, which means the caller has to keep that space outside the
 * measured element.
 *
 * Stable rather than oscillating, and not by luck: turning the answer true adds
 * a scrollbar, which narrows the content, and narrowing can only make content
 * taller — so a true answer stays true and a false one stays false.
 *
 * `useLayoutEffect`, so the first measurement and the re-render it causes both
 * land before paint. A view added to the stack scrolls itself into view from a
 * passive effect, and passive effects run after every layout effect in the tree:
 * measuring here means the trailing space this gates is already in the DOM by
 * the time that scroll is computed against it.
 */
export declare function useScrollPortOverflow(ref: React.RefObject<HTMLElement | null>): boolean;
/**
 * Heights of the chrome boxes a sticky element below them has to clear. Each is
 * published from a measurement rather than assumed, because the constants they
 * default to are nominal: `VIEW_HEADER_HEIGHT` and the LGV header bar's height
 * were written into the CSS by the pin-elements work (#4237) so that the sticky
 * offsets summing them would be true, and a box pinned to a constant clips its
 * own content once the root font size grows — measured on the stock theme, the
 * view header overflows at a 18px root and the LGV controls row at 24px.
 *
 * So those CSS heights are minimums and these carry the truth. The fallbacks
 * keep the nominal answer for the frame before the first measurement, and for a
 * host that mounts no publisher. A box that stays fixed still publishes — see
 * the embedded `ViewTitle`, which is a density choice rather than a constraint
 * now that nothing below it re-derives its height.
 *
 * Cheap enough to put on every view: measured across a jbrowse-web session, the
 * observers behind these fired 0 times over 60 pan frames and 10 zooms, and ~5
 * times per window resize.
 */
export declare const VIEW_HEADER_HEIGHT_VAR = "--jbrowse-view-header-height";
export declare const LGV_HEADER_HEIGHT_VAR = "--jbrowse-lgv-header-height";
/**
 * Publishes the measured height of `ref`'s element as `varName`, set on its
 * **parent**. The parent, not the element itself: what reads these is a sticky
 * sibling *below* the measured box, so publishing on the box would put the
 * property out of the reader's inheritance chain.
 *
 * Takes the ref rather than returning one — the boxes being measured are also
 * the ones a view scrolls into view or hangs a gesture on, so they tend to
 * already have one.
 *
 * Written straight to the node rather than through state, for the reason
 * {@link useScrollPortHeightVar} gives — and here with the extra one that a
 * header re-rendering on its own resize is a loop waiting for a rounding error.
 */
export declare function useChromeHeightVar(ref: React.RefObject<HTMLElement | null>, varName: string): void;
