import type { FileLocation } from './types/data.ts';
export declare const adapterTypes: readonly ['IndexedFastaAdapter', 'BgzipFastaAdapter', 'FastaAdapter', 'TwoBitAdapter', 'ChromSizesAdapter'];
export type AdapterType = (typeof adapterTypes)[number];
export declare const adapterLabels: Record<AdapterType, string>;
export declare function adapterHasSequence(adapterSelection: AdapterType): adapterSelection is "BgzipFastaAdapter" | "FastaAdapter" | "IndexedFastaAdapter" | "TwoBitAdapter";
export interface FormState {
    adapterSelection: AdapterType;
    assemblyName: string;
    assemblyDisplayName: string;
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
    gziLocation: FileLocation;
    twoBitLocation: FileLocation;
    chromSizesLocation: FileLocation;
    refNameAliasesLocation: FileLocation;
    cytobandsLocation: FileLocation;
}
export type LocationField = {
    [K in keyof FormState]: FormState[K] extends FileLocation ? K : never;
}[keyof FormState];
export declare const sidecarRoles: readonly ['fai', 'gzi'];
export type SidecarRole = (typeof sidecarRoles)[number];
export declare const sidecars: {
    readonly fai: {
        readonly field: 'faiLocation';
        readonly ext: '.fai';
        readonly label: 'FASTA index (.fai) file';
    };
    readonly gzi: {
        readonly field: 'gziLocation';
        readonly ext: '.gzi';
        readonly label: 'FASTA gzip index (.gzi) file';
    };
};
export declare function makeSetField(setForm: (update: (prev: FormState) => FormState) => void): <K extends keyof FormState>(key: K) => (value: FormState[K]) => void;
export declare function initialFormState(): FormState;
export declare function applyPrimaryFile(state: FormState, location: FileLocation): FormState;
export declare function applyTwoBitFile(state: FormState, location: FileLocation): FormState;
export declare function clearFormFields(state: FormState): FormState;
export declare function clearSequenceFiles(state: FormState): FormState;
export declare function getBaseAssemblyConfig(state: FormState): {
    name: string;
    displayName?: string | undefined;
    refNameAliases?: {
        adapter: {
            type: string;
            location: FileLocation;
        };
    } | undefined;
    cytobands?: {
        adapter: {
            type: string;
            cytobandLocation: FileLocation;
        };
    } | undefined;
};
export type AssemblyAdapter = {
    type: 'IndexedFastaAdapter';
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
} | {
    type: 'BgzipFastaAdapter';
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
    gziLocation: FileLocation;
} | {
    type: 'UnindexedFastaAdapter';
    fastaLocation: FileLocation;
} | {
    type: 'TwoBitAdapter';
    twoBitLocation: FileLocation;
    chromSizesLocation?: FileLocation;
} | {
    type: 'ChromSizesAdapter';
    chromSizesLocation: FileLocation;
};
export type AssemblyConf = ReturnType<typeof getBaseAssemblyConfig> & {
    sequence: {
        type: 'ReferenceSequenceTrack';
        trackId: string;
        adapter: AssemblyAdapter;
    };
};
export declare function isBlank(location: FileLocation): boolean;
export declare function formHasSequence(form: FormState): boolean;
export declare function getAssemblyName(form: FormState): string;
export declare function getMissingSidecars(form: FormState): ({
    readonly field: 'faiLocation';
    readonly ext: '.fai';
    readonly label: 'FASTA index (.fai) file';
} | {
    readonly field: 'gziLocation';
    readonly ext: '.gzi';
    readonly label: 'FASTA gzip index (.gzi) file';
})[];
export declare function isFormReady(form: FormState): boolean;
export declare function isFormDirty(form: FormState): boolean;
export declare function partitionExtraLocations(form: FormState): {
    used: FileLocation[];
    unused: FileLocation[];
};
export declare function getAssemblyNameFromFilename(filename: string): string;
export declare function detectAdapterType(filename: string): AdapterType | undefined;
export type FileRole = 'fasta' | 'fastaGz' | 'fai' | 'gzi' | 'twoBit' | 'chromSizes' | 'cytobands' | 'refNameAliases';
export declare function classifyFilename(filename: string): FileRole | undefined;
export declare function classifyAssemblyFiles(locations: FileLocation[]): Partial<FormState>;
export declare function isSequenceRole(role: FileRole | undefined): boolean;
export interface ClassifiedLocation {
    location: FileLocation;
    role: FileRole | undefined;
}
export declare function classifyLocations(locations: FileLocation[]): ClassifiedLocation[];
/**
 * Rebuild the file-location fields (plus adapter/name) of `state` from a freshly
 * classified set of dropped/pasted files.
 *
 * The file set is authoritative: a field it says nothing about resets, so
 * deleting a URL from the box clears the slot it filled. `edited` is the way out
 * — the fields the user set by hand, which the classifier never gets to answer
 * for. Without it, typing a .fai into the "this format needs its index" input
 * and then adding one more URL wiped the .fai and the pane re-asked for it.
 *
 * refName aliases and cytobands merge instead of resetting even when untouched:
 * they are the two slots "More options" also fills, and no file set that omits
 * them is making a claim about them.
 */
export declare function applyClassifiedFiles(state: FormState, locations: FileLocation[], edited: ReadonlySet<keyof FormState>): FormState;
export declare function buildAssemblyConf(form: FormState, resolveFastaAdapter: (fastaLocation: FileLocation) => Promise<AssemblyAdapter> | AssemblyAdapter): Promise<AssemblyConf>;
export declare function urlTextToLocations(text: string): FileLocation[];
export type AdapterConfigResult = {
    kind: 'ready';
    adapter: AssemblyAdapter;
} | {
    kind: 'needsFastaIndex';
    fastaLocation: FileLocation;
};
export declare function getAdapterConfig({ adapterSelection, fastaLocation, faiLocation, gziLocation, twoBitLocation, chromSizesLocation, }: {
    adapterSelection: AdapterType;
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
    gziLocation: FileLocation;
    twoBitLocation: FileLocation;
    chromSizesLocation: FileLocation;
}): AdapterConfigResult;
