import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/** what a diagnostic calls the view: its snapshot `type`, or the model name */
export declare function viewLabel(self: IStateTreeNode): string;
/**
 * What every surface calls this mistake. A session spec launches a view without
 * ever building a snapshot, so it classifies its own keys and reports them
 * through its own session rather than through the sink below — one wording, so
 * a typo reads the same whether it was written in a config or in a URL.
 */
export declare function unknownKeysMessage(label: string, keys: string[]): string;
/**
 * Name the keys a view was handed and could not place, from the partition
 * `withLaunchInput` runs on the snapshot.
 */
export declare function reportUnknownKeys(self: IStateTreeNode, keys: string[]): void;
/**
 * Name the row lists a view refused whole. `withLaunchInput` splits an authored
 * array into the recipes a launcher resolves and the built snapshots MST
 * restores, per entry — but a row list is indexed against the view's `levels`
 * and per-level tracks, so a list holding both kinds has no correct split and
 * is refused rather than renumbered.
 */
export declare function reportMalformedRows(self: IStateTreeNode, keys: string[]): void;
/**
 * What every surface calls v4's nested `init`. v5 takes every setting directly
 * on the view object, so the key names no declared property and nothing reads
 * what is under it — the view opens on its defaults, which is why this says
 * more than the generic unknown-key line would.
 */
export declare function legacyInitMessage(label: string): string;
/** Name a snapshot that still writes v4's nested `init`. */
export declare function reportLegacyInit(self: IStateTreeNode): void;
