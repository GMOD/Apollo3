import type { GradientStop } from '../ui/SvgGradientLegend.tsx';
/** One evenly-spaced ramp stop: 8-bit red, green, blue, alpha. */
export type ColorRampStop = readonly [number, number, number, number];
/**
 * #api
 * The 256 viridis stops, fully opaque. Feed them to {@link buildColorRampLut}
 * for the texture/fillStyle form, or to {@link sampleColorRamp} for legend
 * stops.
 */
export declare const VIRIDIS_STOPS: readonly ColorRampStop[];
/**
 * #api
 * The color at `t` in `[0, 1]` across a list of EVENLY SPACED stops, linearly
 * interpolated per channel. `t` is clamped, so the ends are the end stops
 * rather than an extrapolation past them, and a one-stop ramp is that stop
 * everywhere.
 */
export declare function sampleColorRamp(stops: readonly ColorRampStop[], t: number): ColorRampStop;
/**
 * #api
 * An RGBA lookup table over {@link sampleColorRamp}, laid out as the Nx1
 * texture both GPU backends upload and the Canvas2D twins index — entry `i` is
 * the color at `t = i / (N - 1)`. N comes off the shader that samples it, so
 * the table and `rampColor`'s texel mapping cannot disagree.
 */
export declare function buildColorRampLut(stops: readonly ColorRampStop[]): Uint8Array<ArrayBuffer>;
/**
 * #api
 * `n` evenly spaced legend stops read straight out of a
 * {@link buildColorRampLut} byte table — the same 256×1 RGBA array
 * `uploadColorRampLut` hands the GPU and the Canvas2D fillStyle LUTs index —
 * formatted for `SvgGradientLegend`. It holds one claim by construction: the
 * swatch at bar fraction `t` is byte-identical to the ramp entry at `t` on
 * both backends. Alpha rides `opacity` (the juicebox fade), never baked into
 * the color string.
 */
export declare function stopsFromRampLut(lut: Uint8Array, n: number): GradientStop[];
