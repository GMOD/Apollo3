import type PluginManager from '../../PluginManager.ts';
import type { FileLocation, UriLocation } from '../types/data.ts';
import type { Fetcher, GenericFilehandle } from 'generic-filehandle2';
/** if a UriLocation has a baseUri, resolves its uri with respect to that base */
export declare function resolveUriLocation(location: UriLocation): UriLocation;
export declare function openLocation(location: FileLocation, pluginManager?: PluginManager): GenericFilehandle;
/**
 * Open a tabix-style index (TBI or CSI) and return it under the correct
 * filehandle key for `new TabixIndexedFile(...)`. Centralizes the CSI-vs-TBI
 * branch so callers can't mismatch the two — e.g. writing `=== 'CSI'` on both
 * the csi and tbi lines, which silently yields no index at all.
 */
export declare function openTabixIndexFilehandle(location: FileLocation, indexType: string | undefined, pluginManager?: PluginManager): {
    csiFilehandle: GenericFilehandle;
    tbiFilehandle?: undefined;
} | {
    csiFilehandle?: undefined;
    tbiFilehandle: GenericFilehandle;
};
/**
 * A fetch that presents `location`'s credentials — and only for urls that
 * credential covers.
 *
 * An account's own fetcher signs whatever url it is handed: the location it was
 * built from decides which token to mint, not where the token may go. That is
 * fine for a caller holding one url, which is what `openLocation` is, and wrong
 * for one that fetches urls a *server* names. Htsget is the second kind — a
 * ticket request answers with data-block urls that can point anywhere — and it
 * had no way to ask whether a given url was still in scope.
 *
 * So ask here. Every url other than the one the fetcher was requested for goes
 * back through the account's `handlesLocation`, which is the same
 * `uriMatchesDomains` test that chose the account in the first place. Both
 * directions matter: `domains` entries scope to a path as well as a host
 * (`data.mylab.org/private`, and the origin-plus-directory form every ephemeral
 * HTTP Basic account is minted with), and one account routinely spans several
 * hosts (Dropbox lists seven). An origin comparison is wrong for both.
 *
 * Anything out of scope gets a plain fetch rather than `checkAuthNeededFetch`:
 * a 401 from a url the config never named should not raise a credential prompt
 * for a host the server picked.
 */
export declare function getFetcher(location: FileLocation, pluginManager?: PluginManager): Fetcher;
export { CachedFilehandle, RemoteFileWithRangeCache, } from './RemoteFileWithRangeCache.ts';
