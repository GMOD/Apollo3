export default class GranularRectLayout {
    private pitchX;
    private pitchY;
    private hardRowLimit;
    private bitmap;
    private rectangles;
    private maxHeight;
    /**
     * pitchX - layout grid pitch in the X direction
     * pitchY - layout grid pitch in the Y direction
     * maxHeight - maximum layout height in pixels, default 10000
     */
    constructor({ pitchX, pitchY, maxHeight, hardRowLimit, }?: {
        pitchX?: number;
        pitchY?: number;
        maxHeight?: number;
        hardRowLimit?: number;
    });
    /**
     * @returns top position for the rect, or Null if laying
     *  out the rect would exceed maxHeight
     */
    addRect(id: string, left: number, right: number, height: number): number | null;
    private getOrCreateRow;
}
