/**
 * Minimal row-packing primitive for integer-indexed 1D layouts.
 *
 * `rows[y]` is a flat `[s1,e1,s2,e2,...]` sorted ascending by start, where
 * intervals within a row never overlap. `placeRect` finds the first row
 * with no collision (or appends a new row), inserts `[start, end+2]`,
 * and returns the row INDEX (0, 1, 2, ...).
 *
 * How this differs from `GranularRectLayout` in this same folder, and
 * why this exists as a separate primitive:
 *
 * - **Keys:** GranularRectLayout keys rectangles by string ID in a
 *   `Map`, so re-adding an id returns the row it already holds;
 *   `placeRect` has no ID and no rectangle object. Callers with numeric
 *   indices (e.g. BAM read indices) don't pay the cost of allocating
 *   string IDs, Rectangle objects, or the outer Map — they use a
 *   `Uint16Array` of row indices instead.
 *
 * - **Scaling / height:** GranularRectLayout has `pitchX`, `pitchY`,
 *   multi-row rectangle heights, `maxHeight` / `hardRowLimit`, and
 *   returns pixel `top` values. `placeRect` is unit-agnostic (bp or
 *   px), one-row-per-rect, no limits, and returns a row index.
 *
 * - **State ownership:** GranularRectLayout is a class with internal
 *   state; `placeRect` is a pure function operating on a caller-owned
 *   `number[][]` array, so memory lifetime matches the caller's scope.
 *
 * Neither hit-tests: both are packing only, and consumers that need
 * hit-testing build a Flatbush over the result.
 *
 * Use `placeRect` for tight per-call layouts over typed-array data
 * (alignments pileup and chain rendering). Use `GranularRectLayout`
 * when rects have variable heights or the layout needs a row limit
 * (feature/gene tracks).
 *
 * Per-row complexity:
 *   - O(1) append when the row's last end ≤ new start (start-sorted
 *     input — the common case)
 *   - O(log M) collision + insertion-point lookup for wide rows via
 *     binary search on ends. Ends are monotone within a row because
 *     intervals are non-overlapping and sorted by start.
 *   - O(M) for the splice shift when inserting mid-row; only taken
 *     once per placement, and only when the fast-path misses.
 *
 * @param rows  mutable `number[][]` — each row is `[s1,e1,s2,e2,...]`
 * @param start rect start (any numeric unit — bp, px, etc.)
 * @param end   rect end (exclusive)
 * @returns     the row index the rect was placed in
 */
export declare function placeRect(rows: number[][], start: number, end: number): number;
