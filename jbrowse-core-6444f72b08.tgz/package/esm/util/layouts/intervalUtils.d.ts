/**
 * Shared utilities for interval-based layout algorithms, used by
 * GranularRectLayout.
 */
/**
 * Find insertion point for a new interval in a sorted interval array.
 * Returns the index where [left, right] should be inserted.
 */
export declare function findInsertionPoint(intervals: number[], left: number): number;
/**
 * Insert an interval into a sorted interval array using manual shift
 * (avoids splice GC pressure).
 */
export declare function insertInterval(intervals: number[], idx: number, left: number, right: number): void;
