import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyReactComponentType } from '../util/index.ts';
import type { IAnyModelType } from '@jbrowse/mobx-state-tree';
export default class DisplayType extends PluggableElementBase {
    stateModel: IAnyModelType;
    configSchema: AnyConfigurationSchemaType;
    ReactComponent: AnyReactComponentType;
    /**
     * The track type the display is associated with
     */
    trackType: string;
    subDisplay?: {
        type: string;
        [key: string]: unknown;
    };
    /**
     * The view type the display is associated with
     */
    viewType: string;
    /**
     * Help text describing the display type
     */
    helpText?: string;
    constructor(stuff: {
        name: string;
        stateModel: IAnyModelType;
        trackType: string;
        viewType: string;
        displayName?: string;
        subDisplay?: {
            type: string;
            [key: string]: unknown;
        };
        configSchema: AnyConfigurationSchemaType;
        ReactComponent: AnyReactComponentType;
        helpText?: string;
        aliases?: string[];
    });
}
