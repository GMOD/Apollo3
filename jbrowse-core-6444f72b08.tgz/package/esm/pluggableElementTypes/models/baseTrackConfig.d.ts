import type PluginManager from '../../PluginManager.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * Snapshot normalization shared by every track config schema (including
 * ReferenceSequenceTrack). Runs the `Core-preProcessTrackConfig` extension
 * point, expands the `displayDefaults` shorthand, auto-fills a stub display for
 * each of the track type's registered displays, normalizes legacy display-type
 * aliases to their canonical name, dedupes by type (first wins), and lifts
 * legacy renderer configs.
 */
export declare function preprocessTrackConfigSnapshot(pluginManager: PluginManager, snapshot: Record<string, unknown>): {
    trackId: string;
    name: string;
    type: string;
    displays: {
        type: string;
        featureHeight?: {} | null | undefined;
        displayId: string;
    }[];
};
/**
 * The `addDisplayConf` action shared by every track config schema — appends a
 * display config unless one with the same displayId already exists.
 */
interface DisplayConf {
    type: string;
    displayId: string;
}
export declare function trackConfigActions(self: unknown): {
    addDisplayConf(conf: DisplayConf): DisplayConf | undefined;
};
/**
 * #config BaseTrack
 * Configuration shared by all track types. Concrete tracks (FeatureTrack,
 * AlignmentsTrack, VariantTrack, ...) extend this, so every track accepts these
 * fields in addition to its own.
 */
export declare function createBaseTrackConfig(pluginManager: PluginManager): import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    /**
     * #slot
     */
    readonly name: {
        readonly description: "descriptive name of the track, falls back to the trackId when unset";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly assemblyNames: {
        readonly description: "name of the assembly (or assemblies) track belongs to";
        readonly type: "stringArray";
        readonly defaultValue: readonly ["assemblyName"];
    };
    /**
     * #slot
     */
    readonly description: {
        readonly description: "a description of the track";
        readonly type: "string";
        readonly defaultValue: "";
    };
    /**
     * #slot
     */
    readonly category: {
        readonly description: "the category and sub-categories of a track";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
    /**
     * #slot
     */
    readonly metadata: {
        readonly type: "frozen";
        readonly description: "anything to add about this track";
        readonly defaultValue: {};
    };
    /**
     * #slot
     * where this track's data comes from. Its `type` names the adapter for
     * the file format (`BamAdapter`, `Gff3TabixAdapter`, ...) and the rest of
     * the object is that adapter's own slots — see the adapter pages for
     * each. Most adapters also accept a `uri` shorthand in place of writing
     * their location slots out.
     */
    readonly adapter: import("@jbrowse/mobx-state-tree").IAnyType;
    readonly textSearching: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        /**
         * #slot textSearching.indexingAttributes
         */
        readonly indexingAttributes: {
            readonly type: "stringArray";
            readonly description: "list of which feature attributes to index for text searching";
            readonly defaultValue: readonly ["Name", "ID", "symbol"];
        };
        /**
         * #slot textSearching.indexingFeatureTypesToExclude
         */
        readonly indexingFeatureTypesToExclude: {
            readonly type: "stringArray";
            readonly description: "list of feature types to exclude in text search index";
            readonly defaultValue: readonly ["CDS", "exon"];
        };
        /**
         * #slot textSearching.indexingFeatureTypesToInclude
         * The only feature types to index, dropping every other type the file
         * carries. Empty (the default) means no allow list, i.e. index
         * everything `indexingFeatureTypesToExclude` does not name.
         *
         * Use this instead of the exclude list when the file draws from a
         * vocabulary you do not control. An NCBI RefSeq GFF3 uses 115 feature
         * types, 80 of them leaf records with nothing to search for — a `match`
         * is labelled with a bare UUID, a `cDNA_match` with an MD5, every
         * `biological_region` with the literal string "biological region" — so
         * a deny list leaks whichever type is added next, while the allow list
         * (gene, pseudogene, and the transcript types) does not grow. Both may
         * be set: this one admits, the exclude list then narrows.
         *
         * GFF3 only; the GTF and VCF indexers do not filter by type.
         */
        readonly indexingFeatureTypesToInclude: {
            readonly type: "stringArray";
            readonly description: "the only feature types to index; empty means index every type not excluded";
            readonly defaultValue: readonly [];
        };
        /**
         * #slot textSearching.textSearchAdapter
         * a per-track name search index, normally a `TrixTextSearchAdapter`
         * over what `jbrowse text-index --tracks` built. Without one, this
         * track's features are only findable through an assembly-wide search
         * adapter.
         */
        readonly textSearchAdapter: import("@jbrowse/mobx-state-tree").IAnyType;
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    /**
     * #slot
     * An **array** of full display configs, e.g.
     * `displays: [{ type: 'LinearBasicDisplay', color: 'green' }]`. Each entry
     * names a display `type`; use this when you need exact control — your own
     * `displayId`, different settings for two displays, or choosing which
     * display is the default.
     *
     * For the common case, prefer the `displayDefaults` shorthand instead — an
     * object of appearance settings (e.g. `displayDefaults: { color: 'green' }`)
     * that JBrowse routes to whichever display uses each setting, so you don't
     * have to name the display or write the array.
     *
     * See the [track config guide](/docs/config_guides/tracks/#configuring-displays).
     */
    readonly displays: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    /**
     * #slot
     * jexl callbacks that add, rewrite or hide fields in this track's
     * feature-details panel. Four slots, listed at
     * [FormatDetails](/docs/config/formatdetails), and the same schema exists
     * session-wide as `configuration.formatDetails`.
     */
    readonly formatDetails: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly feature: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the feature details";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        readonly subfeatures: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the subfeatures of a feature";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        readonly depth: {
            readonly type: "maybeNumber";
            readonly description: "levels of subfeature the formatDetails.subfeatures callback runs on, default 2";
        };
        readonly maxDepth: {
            readonly type: "maybeNumber";
            readonly description: "hide subfeatures nested deeper than this, default no limit";
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    /**
     * #slot
     * jexl callbacks that add, rewrite or hide fields in this track's About
     * dialog. Two slots, listed at
     * [FormatAbout](/docs/config/formatabout), and the same schema exists
     * session-wide as `configuration.formatAbout`.
     */
    readonly formatAbout: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly config: {
            readonly type: "frozen";
            readonly description: "formats configuration object in about dialog";
            readonly defaultValue: {};
            readonly contextVariable: ["config"];
        };
        readonly hideUris: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "trackId">>;
export type BaseTrackConfigSchema = ReturnType<typeof createBaseTrackConfig>;
export type BaseTrackConfig = Instance<BaseTrackConfigSchema>;
export {};
