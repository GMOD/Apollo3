import type { LinearGenomeViewModel } from './model.ts';
import type { InitState } from './types.ts';
import type { AssemblyHost, NotificationSink } from '@jbrowse/core/util';
/**
 * Apply an init blob's `highlight` entries to a view, coercing each locstring
 * or wire-format object and reporting a bad one without taking out its
 * siblings.
 *
 * Exported because a LinearSyntenyView row is a LinearGenomeView that does NOT
 * go through this file's init autorun — the synteny view builds each row's
 * snapshot and navigates it itself — so the row's own `highlight` had nowhere
 * to be applied and was dropped in silence.
 */
export declare function applyInitHighlights(self: LinearGenomeViewModel, session: AssemblyHost & NotificationSink, init: Pick<InitState, 'highlight' | 'assembly'>): void;
/**
 * Autorun that handles the init state - navigating to initial location,
 * showing tracks, etc.
 */
export declare function setupInitAutorun(self: LinearGenomeViewModel): void;
/**
 * Sets up all afterAttach autoruns for the LinearGenomeView
 */
export declare function doAfterAttach(self: LinearGenomeViewModel): void;
