/**
 * A window of the view's linearized bp space — the space `windowStartBp` is in,
 * so a position here is invariant under zoom and a flight can be planned once
 * for a path whose scale changes under it.
 */
export interface FlightViewport {
    centerBp: number;
    windowWidthBp: number;
}
export interface Flight {
    durationMs: number;
    /** the viewport at `t` in [0,1]; exactly the destination at t >= 1 */
    at: (t: number) => FlightViewport;
}
/**
 * The viewport path from `from` to `to`, and how long to spend on it.
 *
 * The path is equation (9) of the paper cited at the top of this file: it zooms
 * out as it travels and back in as it arrives, along the geodesic that holds
 * the *perceived* velocity constant, so the reader can follow the whole journey
 * rather than watching one blurred smear.
 *
 * A STRAIGHT PAN IS NOT THE ALTERNATIVE, it is the thing this exists to avoid.
 * The jump that wants animating here is a synteny row showing a whole assembly
 * being sent to a mate on another chromosome: tens of megabases at a window of
 * tens of kilobases, which is a thousand screens of travel. Panned at constant
 * scale that is a thousand screens of unreadable streaking and no frame in
 * which the reader is anywhere identifiable. Pulled back to where both ends fit
 * and then dropped in, it is a picture of where they came from and where they
 * landed.
 *
 * The zoomed-out apex is `w0 * cosh(r0)` — for a same-zoom hop, about the
 * distance travelled — so the arc naturally tops out at "both endpoints on
 * screen". A view whose `maxBpPerPx` is tighter than that simply clamps there
 * and flies the middle of the path flat; nothing here has to know the limit,
 * because the caller writes through `zoomTo` and reads back what it got.
 */
export declare function planFlight(from: FlightViewport, to: FlightViewport): Flight;
