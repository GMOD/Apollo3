export declare function partitionLaunchKeys(spec: object, viewPropKeys: ReadonlySet<string>): {
    init: Record<string, unknown>;
    viewProps: Record<string, unknown>;
    unknown: Record<string, unknown>;
};
export declare function linearGenomeViewPropKeys(pluginManager: {
    getViewType: (name: string) => {
        stateModel: {
            properties: object;
        };
    };
}): ReadonlySet<string>;
