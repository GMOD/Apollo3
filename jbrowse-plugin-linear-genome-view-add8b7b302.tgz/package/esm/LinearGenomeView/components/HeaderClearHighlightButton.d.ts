import type { LinearGenomeViewModel } from '../index.ts';
interface FeatureHighlightCapableDisplay {
    featureHighlights: {
        length: number;
    };
    clearFeatureHighlights: () => void;
}
/**
 * Every display in the view with an active feature highlight — from a text
 * search or the right-click "Highlight feature" menu, which land in the same
 * set.
 *
 * The header reads this rather than leaving it to the button below, because
 * whether the button is in the row changes how much of the row is left for
 * everything else (see `headerFit`).
 */
export declare function highlightedDisplays(model: LinearGenomeViewModel): FeatureHighlightCapableDisplay[];
declare const HeaderClearHighlightButton: ({ highlighted, }: {
    highlighted: FeatureHighlightCapableDisplay[];
}) => import("react").JSX.Element | null;
export default HeaderClearHighlightButton;
