import type { LinearGenomeViewModel } from '../model.ts';
declare const HeaderSearchBoxRow: ({ views, sideBySide, }: {
    views: LinearGenomeViewModel[];
    sideBySide: boolean;
}) => import("react").JSX.Element;
export default HeaderSearchBoxRow;
