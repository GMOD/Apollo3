import type { LinearGenomeViewModel } from '../model.ts';
import type React from 'react';
/**
 * What the box asks its row for at `value`, margins included — the number
 * `headerFit` sheds against.
 *
 * The ask follows the locstring, which is the whole point of asking: 194px at
 * `ctgA:1..20,000` and 284px at `chr22:10,510,000..10,610,000`, so a row sized
 * against the 189px floor sheds too little and flexbox squeezes the box anyway.
 * It is `getInputWidth`, the same function the box sizes itself with, rather
 * than that arithmetic done again out here.
 *
 * `showHelp` is the component's own default below, and with help on
 * `adornmentReservePx` returns the same number whatever the recent-locations
 * menu holds — so the count only this component's hook knows cannot change the
 * answer.
 */
export declare function searchBoxWidth(value: string): number;
declare const SearchBox: ({ model, showHelp, minWidth, maxWidth, style, }: {
    showHelp?: boolean;
    model: LinearGenomeViewModel;
    minWidth?: number;
    maxWidth?: number;
    style?: React.CSSProperties;
}) => React.JSX.Element;
export default SearchBox;
