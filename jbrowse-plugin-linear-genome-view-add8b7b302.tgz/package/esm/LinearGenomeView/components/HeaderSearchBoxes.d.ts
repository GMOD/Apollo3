import type { LinearGenomeViewModel } from '../model.ts';
declare const HeaderSearchBoxes: ({ view, }: {
    view: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default HeaderSearchBoxes;
