import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function HeaderPanControls({ model, compact, }: {
    model: LGV;
    compact?: boolean;
}): import("react").JSX.Element;
export {};
