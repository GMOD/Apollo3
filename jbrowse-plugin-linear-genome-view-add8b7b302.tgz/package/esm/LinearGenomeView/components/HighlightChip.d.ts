import type { MenuItem } from '@jbrowse/core/ui';
import type { Colord } from '@jbrowse/core/util/colord';
export default function HighlightChip({ color, label, tooltip, menuItems, setOpen, }: {
    color: Colord;
    label?: string;
    tooltip?: string;
    menuItems: MenuItem[];
    setOpen?: (arg: boolean) => void;
}): import("react").JSX.Element;
