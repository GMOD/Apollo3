import type { LinearGenomeViewModel } from '../index.ts';
declare const HeaderZoomControls: ({ model, showSlider, }: {
    model: LinearGenomeViewModel;
    showSlider?: boolean;
}) => import("react").JSX.Element;
export default HeaderZoomControls;
