import type { LinearGenomeViewModel } from '../index.ts';
declare const HeaderTrackSelectorButton: ({ model, indent, }: {
    model: LinearGenomeViewModel;
    indent?: boolean;
}) => import("react").JSX.Element;
export default HeaderTrackSelectorButton;
