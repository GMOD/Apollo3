import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const PaddingBlocks: ({ model, offset, }: {
    model: LGV;
    offset?: number;
}) => import("react").JSX.Element | null;
export default PaddingBlocks;
