import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * A container's zoom-out ceiling for the rows it stacks. Unanswered is its own
 * state rather than a zero: a row that has not been laid out yet cannot supply
 * a fit, and reading that as "no shared ceiling" is a different claim. See
 * `LinearComparativeView/sharedFit.ts`.
 */
export type SharedFit = {
    answered: false;
} | {
    answered: true;
    bpPerPx: number;
};
export interface SharedScaleContainer {
    sharedFit: SharedFit;
}
export declare function isSharedScaleContainer(thing: unknown): thing is SharedScaleContainer;
export declare function sharedScaleContainerOf(node: IAnyStateTreeNode): SharedScaleContainer | undefined;
