declare const SHEDDABLE: readonly [readonly ['trackSelectorIndent', 16], readonly ['panButtonSpacing', 100], readonly ['scrollZoomLabel', 83], readonly ['zoomSlider', 100], readonly ['regionWidth', 54]];
export type HeaderFit = Record<(typeof SHEDDABLE)[number][0], boolean>;
/**
 * Which of the header bar's optional pieces a header `width` px wide still has
 * room for, given what the search box is asking for — `searchBoxWidth`, margins
 * included — and whether the clear-highlights button is currently in the row.
 * An unmeasured width — the first render, before the ResizeObserver has
 * reported — keeps all of them, so the common wide case paints its final form
 * immediately rather than flashing the compact one.
 *
 * `searchBoxPx` is the box's ask and not its floor, because the two differ by
 * the locstring — 189px empty, 194 at `ctgA:1..20,000`, 284 at
 * `chr22:10,510,000..10,610,000`. Shedding against the floor is what left
 * flexbox squeezing the box this whole table exists to protect: against the
 * floor the probe read 184px of an asked 210 at an 800px window and 186 at 600.
 *
 * The fully shed row costs 238px, so under `238 + searchBoxPx` the row overflows
 * whatever it gives up and the box shrinks like any flex item. That is a floor,
 * not a cliff: it shrinks from what it asked for rather than from the 101px the
 * unshed row used to leave it.
 */
export declare function headerFit({ width, searchBoxPx, clearHighlight, }: {
    width: number | undefined;
    searchBoxPx: number;
    clearHighlight?: boolean;
}): HeaderFit;
export {};
