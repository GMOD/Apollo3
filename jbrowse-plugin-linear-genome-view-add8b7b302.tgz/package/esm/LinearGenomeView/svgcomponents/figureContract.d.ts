import type { RefObject } from 'react';
/**
 * One live figure per view.
 *
 * Every id a figure mints is `<what>-${svgNodeId(view)}`, deterministic so that
 * exporting an unchanged view twice produces the same bytes (see `svgNodeId`).
 * The same property makes two figures of ONE view collide on all of them, and
 * SVG ids are document-global with `url(#…)` resolving to the first match — so
 * the second figure's tracks are clipped by the first figure's rects. With
 * different options on the two (the reason to draw two in the first place) those
 * rects are the wrong size, and it reads as a track drawn unclipped or a
 * highlight band cut short.
 *
 * Deliberately not fixed by scoping the ids per figure. The determinism is load
 * bearing for the file export that shares these components, and a second figure
 * of one view is a thing to do differently rather than a case to support.
 */
export declare function useOneFigurePerView(view: {
    id: string;
}): void;
/**
 * Nothing inside a figure re-renders itself.
 *
 * A figure's track bodies are built once and frozen; its ruler, scalebar and
 * seams re-derive from the model on any render they get. The `memo` in
 * `useViewSvgFigure` is what keeps those in step, and it sits between the figure
 * and its PARENT — it is not between a component inside the figure and MobX. An
 * `observer` in there re-renders on its own subscription and slides across
 * bodies drawn at a moment in the past, which is a rendering bug the picture
 * gives no sign of.
 *
 * Checked as the state rather than the shape, because the shape is not
 * detectable: `observer(f)` on a function component is `memo(f)` with no marker
 * on it, so it cannot be told from a plain `memo`, which is harmless. Watching
 * for the symptom also covers what an enumeration would miss — a plugin's
 * component reached through `LinearGenomeView-HighlightSVGComponent`, an
 * observer a display's `renderSvg` returned, or a subscription that is not
 * MobX's at all.
 *
 * A mutation is only a violation while the snapshot is unchanged. React's own
 * commit for a NEW snapshot mutates this subtree too, so `rendered` moves to
 * that snapshot during the render that precedes the commit and the records are
 * ignored.
 */
export declare function useFrozenFigureContract(ref: RefObject<SVGSVGElement | null>, snapshot: object): void;
