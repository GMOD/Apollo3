import type { LinearGenomeViewModel } from '../index.ts';
export default function SVGHighlights({ model, height, }: {
    model: LinearGenomeViewModel;
    height: number;
}): (import("react").JSX.Element | null)[] | null;
