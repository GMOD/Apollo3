import type { LinearGenomeViewModel } from './model.ts';
import type { BpOffset } from './types.ts';
import type { MenuItem } from '@jbrowse/core/ui';
/**
 * Zoom all the way out, shared by the view menu and the header's zoom menu —
 * one definition so the two cannot drift in label, and the view menu is the
 * only one of the two that survives `hideHeader`.
 *
 * The zoom menu earns it on the merits: this is the bottom of the same "Zoom
 * out 100x" ladder, and it is where someone already zooming looks.
 *
 * The label is the import form's button text verbatim (`ImportForm.tsx`), which
 * is where most people meet the phrase. No icon: the four-arrows glyph it
 * carried reads as "fullscreen", and nothing else names the same gesture, so a
 * substitute would be decoration rather than a distinction.
 */
export declare function showAllRegionsMenuItem(self: LinearGenomeViewModel): MenuItem;
/**
 * Build the main view menu items
 */
export declare function buildMenuItems(self: LinearGenomeViewModel): MenuItem[];
/**
 * Build rubberband selection menu items. `launchItems` are the plugin-supplied
 * things a selection can start (`rubberBandLaunchMenuItems()`); they collect
 * under one "Launch" submenu so the menu stays three actions plus a group
 * however many plugins are loaded, and vanish entirely when none apply.
 */
export declare function buildRubberBandMenuItems(self: LinearGenomeViewModel, launchItems: MenuItem[]): MenuItem[];
/**
 * Build rubberband click menu items (single click on rubberband area)
 */
export declare function buildRubberbandClickMenuItems(self: LinearGenomeViewModel, clickOffset: BpOffset): MenuItem[];
