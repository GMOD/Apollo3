import type { HTTPBasicInternetAccountConfigModel } from './configSchema.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel HTTPBasicInternetAccount
 * Internet account that authenticates requests with an HTTP Basic
 * username/password the user enters through a dialog, optionally validated with
 * a HEAD request. See [TokenEntryInternetAccount](../tokenentryinternetaccount)
 * for the shared behavior.
 */
declare const stateModelFactory: (configSchema: HTTPBasicInternetAccountConfigModel) => import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
}, "configuration" | "type"> & {
    type: import("@jbrowse/mobx-state-tree").ISimpleType<"HTTPBasicInternetAccount">;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>;
}, {
    readonly name: string;
    readonly description: string;
    readonly internetAccountId: string;
    readonly authHeader: string;
    readonly tokenType: string;
    readonly domains: string[];
    readonly toggleContents: React.ReactNode;
    readonly SelectorComponent: import("@jbrowse/core/util").AnyReactComponentType | undefined;
    readonly selectorLabel: string | undefined;
    readonly showInFileSelector: boolean;
} & {
    handlesLocation(location: import("@jbrowse/core/util").UriLocation): boolean;
    readonly tokenKey: string;
} & {
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    storeToken(token: string): void;
    retrieveToken(): string | undefined;
    validateToken(token: string, _loc: import("@jbrowse/core/util").UriLocation): Promise<string>;
} & {
    removeToken(): void;
    getToken(location?: import("@jbrowse/core/util").UriLocation): Promise<string>;
} & {
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    fetchWithToken(loc: import("@jbrowse/core/util").UriLocation | undefined, run: (token: string) => Promise<Response>): Promise<Response>;
    getPreAuthorizationInformation(location: import("@jbrowse/core/util").UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        };
    }>;
} & {
    getFetcher(loc?: import("@jbrowse/core/util").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    openLocation(location: import("@jbrowse/core/util").UriLocation): import("@jbrowse/core/util/io").RemoteFileWithRangeCache;
} & {
    readonly validateWithHEAD: boolean;
} & {
    getTokenFromUser(resolve: (token: string) => void, reject: (error: Error) => void): void;
    validateToken(token: string, location: import("@jbrowse/core/util").UriLocation): Promise<string>;
} & {
    /**
     * #getter
     * There is nothing to pick: an HTTP Basic account matches by domain and
     * prompts on its own. RpcManager also mints one of these per origin on a
     * 401, so offering them would fill the picker with a toggle per server the
     * session happened to touch.
     */
    readonly showInFileSelector: boolean;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default stateModelFactory;
export type HTTPBasicStateModel = ReturnType<typeof stateModelFactory>;
export type HTTPBasicModel = Instance<HTTPBasicStateModel>;
