import type { HeightMode } from './heightMode.ts';
export default function TrackHeightIndicator({ heightMode, hasOverflow, scrollZoom, noun, truncatedCount, fitNote, onSetHeightMode, }: {
    heightMode: HeightMode;
    hasOverflow: boolean;
    scrollZoom: boolean;
    noun: string;
    truncatedCount?: number;
    fitNote?: string;
    onSetHeightMode: (mode: HeightMode) => void;
}): import("react").JSX.Element;
