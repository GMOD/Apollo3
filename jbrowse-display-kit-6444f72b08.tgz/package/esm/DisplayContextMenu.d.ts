import type { ContextMenuAnchor, MenuItem } from '@jbrowse/core/ui';
/**
 * The right-click menu of a display composing `ContextMenuMixin`, in an
 * observer of its own: reading `contextMenuInfo` in the component that mounts
 * `DisplayChrome` would attribute it to the chrome's observer and re-render
 * the whole subtree on every open.
 */
export declare const DisplayContextMenu: ({ model, }: {
    model: {
        contextMenuInfo?: ContextMenuAnchor;
        contextMenuItems: () => MenuItem[];
        closeContextMenu: () => void;
    };
}) => import("react").JSX.Element;
