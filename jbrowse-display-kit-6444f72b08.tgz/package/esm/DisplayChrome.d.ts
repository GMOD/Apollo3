import type { DisplayChromeBaseProps } from './DisplayChromeBase.tsx';
import type { DisplayStatusChromeBaseProps } from './DisplayStatusChromeBase.tsx';
import type { RenderingBackend } from '@jbrowse/render-core/renderingBackendBase';
export type { ChromeModel } from './DisplayChromeBase.tsx';
export type { StatusChromeModel } from './DisplayStatusChromeBase.tsx';
/**
 * The chrome every in-tree GPU/Canvas2D display renders: `DisplayChromeBase`
 * with JBrowse's own MUI overlays bound in, unless a
 * `DisplayChromeOverlayProvider` above it says otherwise.
 *
 * All the behavior lives in `DisplayChromeBase` — see that file for the
 * `displayPhase` contract, the subtree-replacing terminal states, and the
 * canvas dispose/re-init lifecycle.
 *
 * Not an `observer`: it reads no observables, it only picks an overlay set and
 * forwards. The generic `<B>` threads through to `DisplayChromeBase`, which is
 * the observer.
 */
export default function DisplayChrome<B extends RenderingBackend>(props: Omit<DisplayChromeBaseProps<B>, 'overlays'>): import("react").JSX.Element;
/**
 * The same chrome for a display with **no rendering backend** — arc's own
 * main-thread Canvas2D. Identical container, testid, `data-display-phase`
 * and overlays; it just takes the phase and the first-paint flag as props
 * instead of reading them off a `RenderLifecycleMixin`, and offers no
 * `renderError` banner because there is no backend to fail (hence
 * `DisplayStatusPhase`, which cannot name that state).
 *
 * A backend-less display should render this rather than assembling banners
 * itself: doing it by hand is what let arc drift into showing no
 * background-progress chip. Not an `observer` — like `DisplayChrome` it only
 * picks an overlay set and forwards; the caller reading `model.displayPhase`
 * is the observer.
 */
export declare function DisplayStatusChrome(props: Omit<DisplayStatusChromeBaseProps, 'overlays'>): import("react").JSX.Element;
