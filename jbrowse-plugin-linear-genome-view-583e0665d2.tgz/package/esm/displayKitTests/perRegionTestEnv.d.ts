import { createDisplayTestEnvironment } from '@jbrowse/display-test-utils';
import type { AnyConfigurationSchemaType } from '@jbrowse/core/configuration';
import type { IndexedRegion } from '@jbrowse/display-kit/planRegionFetch';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * The knobs a test needs on the display's fetch, held in a closure rather than
 * as volatiles. `regionHasData` must stay a **view** — as an action MobX runs it
 * untracked and the autorun keeps a stale answer (see the hook block in
 * `MultiRegionDisplayMixin`) — and a view may not write, so its call counter
 * cannot live in the tree.
 */
export interface PerRegionTestControl {
    /** how many times the fetch autorun has asked `regionHasData` */
    cacheValidCalls: number;
    /**
     * How many further `regionHasData` calls answer false, decremented each time.
     * Bounded on purpose: a permanently-invalid cache refetches forever, which is
     * correct behavior and an unfalsifiable test.
     */
    staleAnswers: number;
    /** the next fetch rejects, the way a failed RPC does */
    failNextFetch: boolean;
    /** hold each fetch open this long, so a test can act while one is in flight */
    fetchDelayMs: number;
    /**
     * What the display's own fetch measures for a region, and how often it
     * measured. There is no separate estimate RPC any more: a gated display
     * passes `resolvedByteLimit()` into its fetch, the fetch measures first and
     * answers a `RegionTooLargeResult` instead of a payload when it is over — so
     * this stands in for the worker-side `measureRegionBytes`.
     */
    estimateBytes: number;
    estimateCalls: number;
    /** the display's own density verdict, canvas's second too-large axis */
    densityTooLarge: boolean;
}
/**
 * The smallest possible display on `MultiRegionDisplayMixin`: it fetches, it
 * records what it was asked to fetch, and it does nothing else. Nine real
 * displays compose this foundation, and every one of them adds a plugin's worth
 * of behavior on top — so a test that boots one is testing that plugin as much
 * as the foundation, which is how the foundation's own autoruns came to be
 * pinned only by canvas's suite.
 */
/** Which of the gate's opt-in hooks this display overrides. */
export interface GateOptIns {
    gateEnabled?: boolean;
    densityGateEnabled?: boolean;
}
declare function makeStateModel(control: PerRegionTestControl, gate: GateOptIns, configSchema: AnyConfigurationSchemaType): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, never>, never> & Omit<Omit<Omit<{}, never>, never>, never>, "configuration" | "type"> & {
    type: import("@jbrowse/mobx-state-tree").ILiteralType<"PerRegionTestDisplay">;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<AnyConfigurationSchemaType>;
}, {
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
} & {
    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
} & {
    readonly RenderingComponent: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        onHorizontalScroll?: (distance: number) => void;
        blockState?: Record<string, unknown>;
    }>;
    readonly DisplayBlurb: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }> | null;
    readonly adapterConfig: Record<string, unknown>;
    readonly isMinimized: boolean;
    readonly hoveredFeature: unknown;
    readonly featureNoun: string;
    readonly featureWidgetType: {
        type: string;
        id: string;
    };
} & {
    renderingProps(): {
        displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: Record<string, unknown>;
            readonly isMinimized: boolean;
            readonly hoveredFeature: unknown;
            readonly featureNoun: string;
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: Record<string, unknown>;
            readonly isMinimized: boolean;
            readonly hoveredFeature: unknown;
            readonly featureNoun: string;
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    trackMenuItems(): import("@jbrowse/core/ui").MenuItem[];
} & {
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    setError(error?: unknown): void;
    clearHoveredFeature(): void;
    reload(): void;
} & {
    scrollTop: number;
} & {
    readonly height: number;
    readonly resizing: boolean;
    readonly scrollableHeight: number;
} & {
    setScrollTop(scrollTop: number): void;
    setHeight(displayHeight: number): number;
    resizeHeight(distance: number): number;
} & {
    expandToContentHeight(): number;
    afterAttach(): void;
} & {
    forceLoadTrack: boolean;
    byteEstimate: import("@jbrowse/display-kit/regionTooLargeUtils").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly byteGateAdapterPath: string[];
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("@jbrowse/display-kit/regionTooLargeUtils").GateViewport | undefined;
} & {
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
    gateFetchState(): import("@jbrowse/display-kit/regionTooLargeUtils").GateFetchState;
} & {
    readonly tooLargeStatus: import("@jbrowse/display-kit/regionTooLargeUtils").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number;
        viewport: import("@jbrowse/display-kit/regionTooLargeUtils").GateViewport;
    }): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("@jbrowse/display-kit/regionTooLargeUtils").GateFetchState): void;
} & {
    forceLoad(): void;
} & {
    afterAttach(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
    readonly rendersCanvas: boolean;
    readonly paintInert: boolean;
} & {
    readonly painted: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    reloadCounter: number;
    statusWindow: import("@jbrowse/core/util").StatusWindow;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
} & {
    fetchRotation: {
        begin(): import("@jbrowse/core/util").ActiveFetch;
        cancel: () => void;
        dispose(): void;
    };
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly fetchInert: boolean;
    readonly awaitingPrerequisite: boolean;
    readonly rpcPropsCacheKey: string;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
} & {
    stopActiveFetch(): void;
    openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
} & {
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    endFetch(current: boolean, stopToken: import("@jbrowse/core/util").StopToken): void;
} & {
    runFetch: (work: (ctx: import("@jbrowse/display-kit/FetchMixin").FetchContext) => Promise<void>) => Promise<void>;
} & {
    loadedRegions: import("mobx").ObservableMap<number, import("@jbrowse/display-kit/regionCommit").LoadedRegion>;
} & {
    readonly host: import("@jbrowse/display-kit/regionHost").RegionHost;
    readonly canvasWidthPx: number;
    readonly canRender: boolean;
    readonly viewportWithinLoadedData: boolean;
    readonly viewportEmpty: boolean;
    readonly layoutReady: boolean;
    readonly regionFetchKey: string;
    regionHasData(_displayedRegionIndex: number): boolean;
    readonly dataSuperseded: boolean;
    readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
} & {
    isCacheValid(displayedRegionIndex: number): boolean;
} & {
    readonly dataCurrent: boolean;
    readonly loadedAssembly: import("@jbrowse/core/assemblyManager/assembly").Assembly | undefined;
} & {
    readonly svgReady: boolean;
    readonly paintInert: boolean;
    readonly displayPhase: import("@jbrowse/render-core/displayPhase").DisplayPhase;
} & {
    setLoadedRegion(displayedRegionIndex: number, region: import("@jbrowse/core/util").Region, fetchKey?: string): void;
    dropLoadedRegion(displayedRegionIndex: number): void;
    clearDisplaySpecificData(): void;
} & {
    clearAllRpcData(): void;
    reload(): void;
} & {
    fetchNeeded(_needed: IndexedRegion[]): void;
} & {
    fetchRegions(needed: IndexedRegion[], work: (ctx: import("@jbrowse/display-kit/regionCommit").RegionFetchContext) => Promise<void>): Promise<void>;
} & {
    afterAttach(): void;
} & {
    /** every `fetchNeeded` call, as the region list it was handed */
    fetchLog: IndexedRegion[][];
    loadedData: Map<number, string>;
    /**
     * What `regionFetchKey` answers. A volatile, not a `control` knob, and
     * that is the point: a real display's key reads view state, so the
     * autorun re-runs when it moves. A plain closure value would be memoized
     * by the computed and never invalidate.
     */
    fetchKey: string;
} & {
    readonly gateEnabled: boolean;
    readonly densityGateEnabled: boolean;
    readonly densityTooLarge: boolean;
    readonly regionFetchKey: string;
    regionHasData(_displayedRegionIndex: number): boolean;
} & {
    setFetchKey(key: string): void;
    setLoaded(displayedRegionIndex: number, value: string): void;
    clearDisplaySpecificData(): void;
} & {
    fetchNeeded(needed: IndexedRegion[]): Promise<void>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type PerRegionTestDisplay = Instance<ReturnType<typeof makeStateModel>>;
/**
 * A real `MultiRegionDisplayMixin` display inside a real `LinearGenomeView`, so
 * `afterAttach` runs and `installPerRegionFetchAutoruns` installs for real.
 */
export declare function createPerRegionTestEnvironment({ measuresBytes, gate, estimateBytes, ...opts }?: Partial<Parameters<typeof createDisplayTestEnvironment>[0]> & {
    /** shorthand for `gate: { gateEnabled: true }` */
    measuresBytes?: boolean;
    /** which of the gate's opt-in hooks the display overrides */
    gate?: GateOptIns;
    /**
     * What the display's fetch measures, set before the display exists. A test
     * that wants the banner has to pass it here rather than raise
     * `control.estimateBytes` afterwards: the fetch autorun is leading-edge, so
     * the first fetch runs the moment the display attaches, and a later write
     * would be measuring a display that had already loaded at the default.
     */
    estimateBytes?: number;
}): {
    createDisplay: ({ displayedRegions, displaySnapshot, skipWidth, regionsInSnapshot, }?: {
        displayedRegions?: import("@jbrowse/core/util").Region[];
        displaySnapshot?: Record<string, unknown>;
        skipWidth?: boolean;
        regionsInSnapshot?: boolean;
    }) => {
        session: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            name: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
            view: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyModelType>;
            configuration: import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IType<any, any, any>>;
            displayTypeDefaults: import("@jbrowse/mobx-state-tree").IType<Record<string, Record<string, unknown>> | null | undefined, Record<string, Record<string, unknown>>, Record<string, Record<string, unknown>>>;
        }> & {
            rpcManager: unknown;
            assemblyManager: unknown;
            theme: import("@mui/material").Theme;
            palette: import("@jbrowse/core/ui/palette").JBrowsePalette;
            queuedDialogs: import("@jbrowse/display-test-utils").QueuedDialog[];
            selection: unknown;
            notifications: {
                message: string;
                level?: string;
            }[];
        } & {
            getTrackById: (id: string) => unknown;
            getDisplayTypeDefault(displayType: string, slot: string): unknown;
        } & {
            setView(view: any): any;
            notify(message: string, level?: string): void;
            notifyError(message: string): void;
            queueDialog(cb: (handleClose: () => void) => import("@jbrowse/display-test-utils").QueuedDialog): void;
            setSelection(thing: unknown): void;
            setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            name: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
            view: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyModelType>;
            configuration: import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IType<any, any, any>>;
            displayTypeDefaults: import("@jbrowse/mobx-state-tree").IType<Record<string, Record<string, unknown>> | null | undefined, Record<string, Record<string, unknown>>, Record<string, Record<string, unknown>>>;
        }, {
            rpcManager: unknown;
            assemblyManager: unknown;
            theme: import("@mui/material").Theme;
            palette: import("@jbrowse/core/ui/palette").JBrowsePalette;
            queuedDialogs: import("@jbrowse/display-test-utils").QueuedDialog[];
            selection: unknown;
            notifications: {
                message: string;
                level?: string;
            }[];
        } & {
            getTrackById: (id: string) => unknown;
            getDisplayTypeDefault(displayType: string, slot: string): unknown;
        } & {
            setView(view: any): any;
            notify(message: string, level?: string): void;
            notifyError(message: string): void;
            queueDialog(cb: (handleClose: () => void) => import("@jbrowse/display-test-utils").QueuedDialog): void;
            setSelection(thing: unknown): void;
            setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        view: any;
        track: any;
        display: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Omit<Omit<Omit<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, never>, never> & Omit<Omit<Omit<{}, never>, never>, never>, "configuration" | "type"> & {
            type: import("@jbrowse/mobx-state-tree").ILiteralType<"PerRegionTestDisplay">;
            configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<AnyConfigurationSchemaType>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: Record<string, unknown>;
            readonly isMinimized: boolean;
            readonly hoveredFeature: unknown;
            readonly featureNoun: string;
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        } & {
            renderingProps(): {
                displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            };
            trackMenuItems(): import("@jbrowse/core/ui").MenuItem[];
        } & {
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
            setError(error?: unknown): void;
            clearHoveredFeature(): void;
            reload(): void;
        } & {
            scrollTop: number;
        } & {
            readonly height: number;
            readonly resizing: boolean;
            readonly scrollableHeight: number;
        } & {
            setScrollTop(scrollTop: number): void;
            setHeight(displayHeight: number): number;
            resizeHeight(distance: number): number;
        } & {
            expandToContentHeight(): number;
            afterAttach(): void;
        } & {
            forceLoadTrack: boolean;
            byteEstimate: import("@jbrowse/display-kit/regionTooLargeUtils").ByteEstimate | undefined;
            gateMeasuredViewportKey: string | undefined;
        } & {
            readonly gateEnabled: boolean;
            readonly densityGateEnabled: boolean;
            readonly byteGateAdapterConfig: Record<string, unknown>;
            readonly configuredFetchSizeLimit: number;
            readonly densityTooLarge: boolean;
            readonly byteGateAdapterPath: string[];
            readonly adapterFetchSizeLimit: number | undefined;
            readonly configForceLoad: boolean;
            readonly gateViewport: import("@jbrowse/display-kit/regionTooLargeUtils").GateViewport | undefined;
        } & {
            readonly byteGateAdapterKey: string;
            readonly aboveForceLoadFloor: boolean;
            readonly gateExempt: boolean;
            readonly estimatedFetchBytes: number | undefined;
            readonly gateMeasurementStale: boolean;
        } & {
            readonly gateByteLimit: number;
            readonly gateActive: boolean;
        } & {
            readonly densityGateActive: boolean;
            resolvedByteLimit(): number | undefined;
            gateFetchState(): import("@jbrowse/display-kit/regionTooLargeUtils").GateFetchState;
        } & {
            readonly tooLargeStatus: import("@jbrowse/display-kit/regionTooLargeUtils").RegionTooLargeStatus;
        } & {
            readonly regionTooLarge: boolean;
            readonly regionTooLargeReason: string;
            readonly zoomCanReleaseGate: boolean;
        } & {
            readonly gateSkipsMeasuredViewport: boolean;
        } & {
            setByteEstimate(measurement: {
                bytes: number;
                viewport: import("@jbrowse/display-kit/regionTooLargeUtils").GateViewport;
            }): void;
            clearByteEstimate(): void;
            setForceLoadTrack(flag: boolean): void;
            reload(): void;
        } & {
            commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("@jbrowse/display-kit/regionTooLargeUtils").GateFetchState): void;
        } & {
            forceLoad(): void;
        } & {
            afterAttach(): void;
        } & {
            canvasDrawn: boolean;
            currentRenderingBackend: unknown;
            renderTick: number;
            autorunsInstalled: boolean;
            renderError: unknown;
        } & {
            readonly canRender: boolean;
            readonly rendersCanvas: boolean;
            readonly paintInert: boolean;
        } & {
            readonly painted: boolean;
        } & {
            markCanvasDrawn(): void;
            resetCanvasDrawn(): void;
            stopRenderingBackend(): void;
            renderNow(): void;
            setRenderError(error: unknown): void;
        } & {
            attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
        } & {
            activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
            fetchGeneration: number;
            reloadCounter: number;
            statusWindow: import("@jbrowse/core/util").StatusWindow;
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
            fetchCanceled: boolean;
        } & {
            fetchRotation: {
                begin(): import("@jbrowse/core/util").ActiveFetch;
                cancel: () => void;
                dispose(): void;
            };
        } & {
            readonly isLoading: boolean;
        } & {
            readonly isLoadingOrCanceled: boolean;
            readonly fetchInert: boolean;
            readonly awaitingPrerequisite: boolean;
            readonly rpcPropsCacheKey: string;
        } & {
            setError(error?: unknown): void;
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
        } & {
            stopActiveFetch(): void;
            openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
        } & {
            cancelFetch(): void;
            cancelFetchByUser(): void;
            beforeDestroy(): void;
            endFetch(current: boolean, stopToken: import("@jbrowse/core/util").StopToken): void;
        } & {
            runFetch: (work: (ctx: import("@jbrowse/display-kit/FetchMixin").FetchContext) => Promise<void>) => Promise<void>;
        } & {
            loadedRegions: import("mobx").ObservableMap<number, import("@jbrowse/display-kit/regionCommit").LoadedRegion>;
        } & {
            readonly host: import("@jbrowse/display-kit/regionHost").RegionHost;
            readonly canvasWidthPx: number;
            readonly canRender: boolean;
            readonly viewportWithinLoadedData: boolean;
            readonly viewportEmpty: boolean;
            readonly layoutReady: boolean;
            readonly regionFetchKey: string;
            regionHasData(_displayedRegionIndex: number): boolean;
            readonly dataSuperseded: boolean;
            readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
        } & {
            isCacheValid(displayedRegionIndex: number): boolean;
        } & {
            readonly dataCurrent: boolean;
            readonly loadedAssembly: import("@jbrowse/core/assemblyManager/assembly").Assembly | undefined;
        } & {
            readonly svgReady: boolean;
            readonly paintInert: boolean;
            readonly displayPhase: import("@jbrowse/render-core/displayPhase").DisplayPhase;
        } & {
            setLoadedRegion(displayedRegionIndex: number, region: import("@jbrowse/core/util").Region, fetchKey?: string): void;
            dropLoadedRegion(displayedRegionIndex: number): void;
            clearDisplaySpecificData(): void;
        } & {
            clearAllRpcData(): void;
            reload(): void;
        } & {
            fetchNeeded(_needed: IndexedRegion[]): void;
        } & {
            fetchRegions(needed: IndexedRegion[], work: (ctx: import("@jbrowse/display-kit/regionCommit").RegionFetchContext) => Promise<void>): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            /** every `fetchNeeded` call, as the region list it was handed */
            fetchLog: IndexedRegion[][];
            loadedData: Map<number, string>;
            /**
             * What `regionFetchKey` answers. A volatile, not a `control` knob, and
             * that is the point: a real display's key reads view state, so the
             * autorun re-runs when it moves. A plain closure value would be memoized
             * by the computed and never invalidate.
             */
            fetchKey: string;
        } & {
            readonly gateEnabled: boolean;
            readonly densityGateEnabled: boolean;
            readonly densityTooLarge: boolean;
            readonly regionFetchKey: string;
            regionHasData(_displayedRegionIndex: number): boolean;
        } & {
            setFetchKey(key: string): void;
            setLoaded(displayedRegionIndex: number, value: string): void;
            clearDisplaySpecificData(): void;
        } & {
            fetchNeeded(needed: IndexedRegion[]): Promise<void>;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, never>, never> & Omit<Omit<Omit<{}, never>, never>, never>, "configuration" | "type"> & {
            type: import("@jbrowse/mobx-state-tree").ILiteralType<"PerRegionTestDisplay">;
            configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<AnyConfigurationSchemaType>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: Record<string, unknown>;
            readonly isMinimized: boolean;
            readonly hoveredFeature: unknown;
            readonly featureNoun: string;
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        } & {
            renderingProps(): {
                displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            };
            trackMenuItems(): import("@jbrowse/core/ui").MenuItem[];
        } & {
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
            setError(error?: unknown): void;
            clearHoveredFeature(): void;
            reload(): void;
        } & {
            scrollTop: number;
        } & {
            readonly height: number;
            readonly resizing: boolean;
            readonly scrollableHeight: number;
        } & {
            setScrollTop(scrollTop: number): void;
            setHeight(displayHeight: number): number;
            resizeHeight(distance: number): number;
        } & {
            expandToContentHeight(): number;
            afterAttach(): void;
        } & {
            forceLoadTrack: boolean;
            byteEstimate: import("@jbrowse/display-kit/regionTooLargeUtils").ByteEstimate | undefined;
            gateMeasuredViewportKey: string | undefined;
        } & {
            readonly gateEnabled: boolean;
            readonly densityGateEnabled: boolean;
            readonly byteGateAdapterConfig: Record<string, unknown>;
            readonly configuredFetchSizeLimit: number;
            readonly densityTooLarge: boolean;
            readonly byteGateAdapterPath: string[];
            readonly adapterFetchSizeLimit: number | undefined;
            readonly configForceLoad: boolean;
            readonly gateViewport: import("@jbrowse/display-kit/regionTooLargeUtils").GateViewport | undefined;
        } & {
            readonly byteGateAdapterKey: string;
            readonly aboveForceLoadFloor: boolean;
            readonly gateExempt: boolean;
            readonly estimatedFetchBytes: number | undefined;
            readonly gateMeasurementStale: boolean;
        } & {
            readonly gateByteLimit: number;
            readonly gateActive: boolean;
        } & {
            readonly densityGateActive: boolean;
            resolvedByteLimit(): number | undefined;
            gateFetchState(): import("@jbrowse/display-kit/regionTooLargeUtils").GateFetchState;
        } & {
            readonly tooLargeStatus: import("@jbrowse/display-kit/regionTooLargeUtils").RegionTooLargeStatus;
        } & {
            readonly regionTooLarge: boolean;
            readonly regionTooLargeReason: string;
            readonly zoomCanReleaseGate: boolean;
        } & {
            readonly gateSkipsMeasuredViewport: boolean;
        } & {
            setByteEstimate(measurement: {
                bytes: number;
                viewport: import("@jbrowse/display-kit/regionTooLargeUtils").GateViewport;
            }): void;
            clearByteEstimate(): void;
            setForceLoadTrack(flag: boolean): void;
            reload(): void;
        } & {
            commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("@jbrowse/display-kit/regionTooLargeUtils").GateFetchState): void;
        } & {
            forceLoad(): void;
        } & {
            afterAttach(): void;
        } & {
            canvasDrawn: boolean;
            currentRenderingBackend: unknown;
            renderTick: number;
            autorunsInstalled: boolean;
            renderError: unknown;
        } & {
            readonly canRender: boolean;
            readonly rendersCanvas: boolean;
            readonly paintInert: boolean;
        } & {
            readonly painted: boolean;
        } & {
            markCanvasDrawn(): void;
            resetCanvasDrawn(): void;
            stopRenderingBackend(): void;
            renderNow(): void;
            setRenderError(error: unknown): void;
        } & {
            attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
        } & {
            activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
            fetchGeneration: number;
            reloadCounter: number;
            statusWindow: import("@jbrowse/core/util").StatusWindow;
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
            fetchCanceled: boolean;
        } & {
            fetchRotation: {
                begin(): import("@jbrowse/core/util").ActiveFetch;
                cancel: () => void;
                dispose(): void;
            };
        } & {
            readonly isLoading: boolean;
        } & {
            readonly isLoadingOrCanceled: boolean;
            readonly fetchInert: boolean;
            readonly awaitingPrerequisite: boolean;
            readonly rpcPropsCacheKey: string;
        } & {
            setError(error?: unknown): void;
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
        } & {
            stopActiveFetch(): void;
            openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
        } & {
            cancelFetch(): void;
            cancelFetchByUser(): void;
            beforeDestroy(): void;
            endFetch(current: boolean, stopToken: import("@jbrowse/core/util").StopToken): void;
        } & {
            runFetch: (work: (ctx: import("@jbrowse/display-kit/FetchMixin").FetchContext) => Promise<void>) => Promise<void>;
        } & {
            loadedRegions: import("mobx").ObservableMap<number, import("@jbrowse/display-kit/regionCommit").LoadedRegion>;
        } & {
            readonly host: import("@jbrowse/display-kit/regionHost").RegionHost;
            readonly canvasWidthPx: number;
            readonly canRender: boolean;
            readonly viewportWithinLoadedData: boolean;
            readonly viewportEmpty: boolean;
            readonly layoutReady: boolean;
            readonly regionFetchKey: string;
            regionHasData(_displayedRegionIndex: number): boolean;
            readonly dataSuperseded: boolean;
            readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
        } & {
            isCacheValid(displayedRegionIndex: number): boolean;
        } & {
            readonly dataCurrent: boolean;
            readonly loadedAssembly: import("@jbrowse/core/assemblyManager/assembly").Assembly | undefined;
        } & {
            readonly svgReady: boolean;
            readonly paintInert: boolean;
            readonly displayPhase: import("@jbrowse/render-core/displayPhase").DisplayPhase;
        } & {
            setLoadedRegion(displayedRegionIndex: number, region: import("@jbrowse/core/util").Region, fetchKey?: string): void;
            dropLoadedRegion(displayedRegionIndex: number): void;
            clearDisplaySpecificData(): void;
        } & {
            clearAllRpcData(): void;
            reload(): void;
        } & {
            fetchNeeded(_needed: IndexedRegion[]): void;
        } & {
            fetchRegions(needed: IndexedRegion[], work: (ctx: import("@jbrowse/display-kit/regionCommit").RegionFetchContext) => Promise<void>): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            /** every `fetchNeeded` call, as the region list it was handed */
            fetchLog: IndexedRegion[][];
            loadedData: Map<number, string>;
            /**
             * What `regionFetchKey` answers. A volatile, not a `control` knob, and
             * that is the point: a real display's key reads view state, so the
             * autorun re-runs when it moves. A plain closure value would be memoized
             * by the computed and never invalidate.
             */
            fetchKey: string;
        } & {
            readonly gateEnabled: boolean;
            readonly densityGateEnabled: boolean;
            readonly densityTooLarge: boolean;
            readonly regionFetchKey: string;
            regionHasData(_displayedRegionIndex: number): boolean;
        } & {
            setFetchKey(key: string): void;
            setLoaded(displayedRegionIndex: number, value: string): void;
            clearDisplaySpecificData(): void;
        } & {
            fetchNeeded(needed: IndexedRegion[]): Promise<void>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        mockRpcCall: jest.Mock<any, any, any>;
    };
    mockRpcCall: jest.Mock<any, any, any>;
    pluginManager: import("@jbrowse/core/PluginManager").default;
    trackConfig: any;
    control: PerRegionTestControl;
};
export {};
