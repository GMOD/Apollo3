import type { Feature } from '../util/index.ts';
import type { JexlInstance } from '../util/jexlStrings.ts';
import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationModel, AnyConfigurationSchemaType, AnyConfigurationSnapshot, ConfigurationSchemaForModel, ConfigurationSlotName, ConfigurationSlotValue } from './types.ts';
import type { IMSTMap } from '@jbrowse/mobx-state-tree';
/**
 * #api core/configuration
 * Given a configuration model (an instance of a ConfigurationSchema), read the
 * configuration value at the given path. Use this when you hold the
 * configuration model directly, e.g. an entry from `session.tracks`.
 *
 * Wants a **live config node**, not a snapshot of one, and passing a snapshot is
 * a type error. Slots are built with `types.stripDefault`, so a slot sitting at
 * its default is absent from a snapshot — "unset" and "at its default" are
 * indistinguishable there, and a read off one reports a default as missing.
 *
 * That is enforced in the types only, deliberately: it can't be a runtime check.
 * `generateHierarchy` reads slots straight off the **un-hydrated frozen** entries
 * of `jbrowse.tracks` on purpose, because hydrating every track to answer the
 * track selector is what `types.frozen` exists to avoid — and those reads are
 * indistinguishable at runtime from the broken spelling.
 *
 * @param model - instance of ConfigurationSchema
 * @param slotPaths - array of paths to read
 * @param args - extra arguments e.g. for a feature callback,
 *  will be sent to each of the slotNames
 */
export declare function readConfObject(confObject: AnyConfigurationModel): AnyConfigurationSnapshot;
export declare function readConfObject<CONFMODEL extends AnyConfigurationModel, SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>> | string[] = ConfigurationSlotName<ConfigurationSchemaForModel<CONFMODEL>>>(confObject: CONFMODEL, slotPath?: SLOT, args?: Record<string, unknown>): SLOT extends string ? ConfigurationSlotValue<ConfigurationSchemaForModel<CONFMODEL>, SLOT> : any;
export declare function readConfObject(confObject: IMSTMap<AnyConfigurationSchemaType> | AnyConfigurationModel, slotPath?: string | string[], args?: Record<string, unknown>): any;
/**
 * Plain-object snapshot of a configuration model including ALL values, even
 * defaults. Unlike `getSnapshot()`, which strips a slot sitting at its default
 * via `types.stripDefault`, this returns every slot's current value, so the
 * result is a self-contained config object an RPC worker can read with no
 * schema. JEXL callback slots keep their raw `"jexl:..."` string for the worker
 * to evaluate per-feature.
 *
 * **Why this isn't exported from `@jbrowse/core/configuration`.** It was
 * (as `getConfSnapshot`), and being reachable was the hazard. A promotable slot
 * resolves against the session at read time, so snapshotting one raw ships the
 * bare `undefined` inherit sentinel to a worker with no session to resolve it
 * against — and every display in the repo now has promotable slots. The public
 * form used to defend itself by *throwing* on such a config, which meant the
 * obvious spelling in a new `rpcProps()` failed at runtime, on the first fetch,
 * in whichever product exercised that display. Off the barrel, the same mistake
 * is an unresolved import: it can't be written at all, and
 * `getConfigSnapshotWithPromotables(display)` is the one way across the boundary.
 * So this is the shared walker those resolvers are built on, not an entry point.
 *
 * The nested-schema guard below is the part of that defense still worth
 * enforcing at runtime, since no import can express it.
 *
 * Note: only handles slots and direct sub-configuration models. Arrays or maps
 * of sub-schemas are silently dropped — nothing has needed them.
 */
export declare function fullConfSnapshot(confObject: AnyConfigurationModel): Record<string, unknown>;
/**
 * given a union of explicitly typed configuration schema types,
 * extract an array of the type names contained in the union
 *
 * @param unionType -
 * @returns Array of type names contained in the union
 */
export declare function getTypeNamesFromExplicitlyTypedUnion(maybeUnionType: unknown): string[];
export declare function isBareConfigurationSchemaType(thing: unknown): thing is AnyConfigurationSchemaType;
export declare function isConfigurationSchemaType(thing: unknown): thing is AnyConfigurationSchemaType;
/**
 * A configuration schema definition maps each key to exactly one of three kinds
 * of entry. Together with `isConfigurationSchemaType` (the sub-schema case),
 * these predicates are the single source of truth for that classification —
 * shared by schema construction and every reader, so "what kind of entry is
 * this?" has one answer everywhere.
 *
 *  - constant   → a bare string/number (becomes a volatile instance constant)
 *  - slot       → a ConfigSlotDefinition object (has a `type` field, not a type)
 *  - sub-schema → an MST configuration-schema type, see isConfigurationSchemaType
 */
export declare function isConstantEntry(def: unknown): def is string | number;
export declare function isSlotDefinitionEntry(def: unknown): def is ConfigSlotDefinition;
export declare function isConfigurationModel(thing: unknown): thing is AnyConfigurationModel;
/**
 * The slot/sub-schema/constant table for a live config node (includes slots
 * merged in from `baseConfiguration` at schema construction). Undefined when the
 * node's type isn't a registered configuration schema. The single accessor for
 * "what are this config's slots?" — shared by the slot facade, promotable
 * defaults, and fullConfSnapshot.
 */
export declare function getConfigurationSchemaDefinition(node: AnyConfigurationModel): import("./configurationSchema.ts").ConfigurationSchemaDefinition | undefined;
export declare function promotableSlotNames(config: AnyConfigurationModel): ReadonlySet<string>;
/**
 * Read a value from a plain config snapshot object. Automatically evaluates
 * "jexl:..." strings per-feature. Works without MST — intended for use in
 * rendering code (GPU, Canvas2D, workers). Pass the realm's `pluginManager.jexl`
 * so plugin-registered functions (e.g. in a custom `mouseover` slot) resolve.
 */
export declare function readConfigValue<T>(config: Record<string, unknown>, key: string | string[], feature: Feature, jexl: JexlInstance): T;
