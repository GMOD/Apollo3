import type { AbstractSessionModel } from '../util/index.ts';
import type { TrackConfigChange } from '../util/trackConfigDelta.ts';
import type { ResolvableDisplay } from './promotableResolve.ts';
import type { AnyConfigurationModel } from './types.ts';
/**
 * #api core/configuration
 * Whether this track has customized the slot (holds a non-default value of its
 * own) rather than following the display type's default. The correct "reset to
 * default" predicate for a promotable slot: comparing the resolved value to the
 * base instead reads as at-default for a track merely *following* a non-base
 * promoted default, so the reset control lights up on a no-op.
 */
export declare function isSlotCustomized(self: ResolvableDisplay, slot: string): boolean;
/**
 * #api core/configuration
 * The display's full config snapshot with every `promotable`
 * slot overwritten by its resolved value in place. For building a worker payload:
 * a promotable slot serializes as its raw inherit sentinel (`undefined`, since
 * they're all `maybe*` types), which the worker can't interpret — it has no
 * session to resolve against. This hands it concrete values instead, with no per-slot
 * bookkeeping, so adding a promotable worker-consumed slot needs no rpcProps
 * change and can't silently ship a sentinel. Main-thread only (the cascade
 * consults the session). Display-only promotable slots the worker never reads
 * (e.g. displayMode) are still excluded by the caller — resolving them here is a
 * harmless no-op since they're dropped anyway.
 */
export declare function getConfigSnapshotWithPromotables(self: ResolvableDisplay): Record<string, unknown>;
/**
 * #api core/configuration
 * A track config snapshot with every display's `promotable` slots resolved, plus
 * the list of values that came from a session-wide default rather than from the
 * config itself.
 *
 * For handing a track's config to somewhere that leaves the cascade for good —
 * the About dialog's "Copy config", whose output a user pastes into a
 * `config.json`. A raw `getSnapshot` records a slot a track merely *follows* as
 * absent (`stripDefault` collapsed it), so the copied config renders differently
 * from the track it was copied from. This is `getComputedStyle` at that
 * boundary, and `fromDisplayTypeDefaults` is what lets the UI say so rather than
 * silently materializing a session preference into a track config.
 *
 * Resolves through the open display when the track is open, and from the display
 * config alone when it isn't — an unopened track has no display state, but "what
 * would this render as" still has an answer.
 *
 * **Writes every promotable slot, including the ones sitting at `promotedBase`,
 * and that is the decision — don't "align" it with the share bake.** The bake
 * writes only genuinely-inherited values, because a baked value reads as
 * customized on the recipient's side and an at-base slot needs nothing. A pasted
 * `config.json` is read by a *different mechanism* — there is no cascade there at
 * all — so writing only the inherited ones would leave every other slot to pick
 * up whatever the reader has promoted in their own browser. What a user copying a
 * config wants is the values they are looking at. The cost is that the pasted
 * track is customized on those slots and no longer follows a later promoted
 * default, which is what a config file means.
 */
export interface TrackConfigWithPromotables {
    config: Record<string, unknown>;
    /** `<displayType>.<slot>`, one per value inherited from a promoted default */
    fromDisplayTypeDefaults: string[];
}
/**
 * #api core/configuration
 * See {@link TrackConfigWithPromotables}.
 */
export declare function getTrackConfigWithPromotables(session: AbstractSessionModel, trackConfig: AnyConfigurationModel): TrackConfigWithPromotables;
/**
 * #api core/configuration
 * A promotable "default for all tracks of this type" control, bundled so a menu
 * row's trailing pin consumes it as a single prop. `active` = this value is
 * currently the session default (a filled pin); `toggle` sets it as the default
 * or clears it, touching no track's own value (see `applyDefaultToggle`). On
 * set it raises a snackbar with an "Override N customized tracks" action for every
 * open track not already showing this value — that action is the only thing in
 * the subsystem that rewrites a track.
 */
export interface DisplayTypeDefaultControl {
    active: boolean;
    toggle: () => void;
}
/**
 * #api core/configuration
 * Every display on an open track, across all open views — the reach of anything
 * that acts on "the tracks the user is looking at": the cascade's own "apply to
 * open tracks", and the share/export bake. One walk so those can't drift apart.
 *
 * Recurses into composite views. A display nested in one resolves the cascade
 * like any other but was invisible to both callers, so the share/export bake
 * didn't bake its inherited values and a shared session containing a
 * breakpoint-split or synteny view rendered differently for the recipient.
 * `LGVSyntenyDisplay` is only ever reached through this branch, so don't flatten
 * the recursion away. `hasChildViews` names the one composite shape it does not
 * cover.
 *
 * A view holding neither (e.g. spreadsheet) drops out via the structural guards.
 * A view whose displays declare no promotable slot (e.g. dotplot, which does
 * hold tracks) is walked and contributes nothing — harmless, and cheaper than
 * asking each display whether it has anything to promote.
 */
export declare function openPromotableDisplays(session: AbstractSessionModel): ResolvableDisplay[];
/**
 * Unset each display's own value on `slot`, so it follows the display type's
 * default instead of baking in a value that wouldn't track a later default
 * change. Backs the snackbar's "apply to open tracks" action. Displays already
 * unset are skipped. Takes the display set explicitly so it's unit-testable.
 *
 * Clearing the slot is the whole of it — this is the subsystem's only write to a
 * display, and it goes through the config. It used to also lift a per-display
 * `ignorePromotedDefaults` opt-out, which is what made a write-capable
 * `PromotableDisplay` shape necessary; with that flag gone, a received track
 * rejoins the cascade by having nothing to reject it.
 *
 * Dead displays are skipped rather than trusted: the "apply to open tracks"
 * snackbar can outlive a track the user closes in the meantime, and both reads
 * and writes throw on a destroyed MST node.
 */
export declare function resetSlotToInherit(displays: ResolvableDisplay[], slot: string): void;
/**
 * Whether `value` is the current session default for `slot`. The live state the
 * pin's filled/outline reflects — a session-wide fact, so it reads the raw
 * promoted default rather than what this display resolves to (a customized track
 * can be showing something else entirely). Module-internal (exercised by
 * promotableDefaults.test.ts); not part of the public barrel.
 */
export declare function isPromotableDefault(self: ResolvableDisplay, slot: string, value: unknown): boolean;
/**
 * Open tracks (across all views) whose resolved value for `slot` differs from
 * `value` — the ones "apply to open tracks" would visibly change by resetting
 * them to follow the default. Drives that action's count. Module-internal
 * (exercised by promotableDefaults.test.ts); not part of the public barrel.
 */
export declare function tracksDifferingFrom(self: ResolvableDisplay, slot: string, value: unknown): ResolvableDisplay[];
/**
 * #api core/configuration
 * Per-value control: "make `slot === onValue` the session default". The meaning
 * is per-value ("make arcs the default"), independent of the track's current
 * value — so an always-visible control never promotes a meaningless value, and
 * two toggles sharing one slot (arcs vs read cloud) stay independent.
 */
export declare function makeDisplayTypeDefaultControl(self: ResolvableDisplay, slot: string, onValue: unknown): DisplayTypeDefaultControl;
/**
 * #api core/configuration
 * Promote-current control: "make this track's current resolved value the
 * session default". Use for a symmetric setting (a `maybeBoolean` toggle, or a
 * multi-mode slot like displayMode) where the pin means "whatever I'm showing",
 * not a fixed on-value.
 */
export declare function makeCurrentValueDisplayTypeDefaultControl(self: ResolvableDisplay, slot: string): DisplayTypeDefaultControl;
/**
 * #api core/configuration
 * Effective differences a track following the default inherits from session-wide
 * defaults, one per promotable slot whose inherited value differs from its schema
 * default. Drives the track-selector "affected by a session default" badge.
 */
export declare function getDisplayTypeDefaultChanges(self: ResolvableDisplay): TrackConfigChange[];
/**
 * #api core/configuration
 * Clear promoted defaults for this display type, so every track following one
 * reverts to its own config value. Backs the badge's "clear session default"
 * action, which passes the slots it actually listed
 * (`getDisplayTypeDefaultChanges`).
 *
 * Pass `slots` whenever the UI named what it was clearing. The all-slots default
 * reaches further than any such list: a promoted default the track *customized*
 * over, or one promoted to a value equal to `promotedBase`, is invisible in the
 * badge dialog (neither is `inherited`) yet still governs sibling tracks — so
 * clearing it from a dialog that never showed it changes tracks other than the
 * one whose badge was clicked.
 */
export declare function clearPromotedDefaults(self: ResolvableDisplay, slots?: Iterable<string>): void;
