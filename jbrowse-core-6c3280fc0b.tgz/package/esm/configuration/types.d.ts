import type { FileLocation } from '../util/types/index.ts';
import type { ConfigurationSchemaOptions, ConfigurationSchemaType } from './configurationSchema.ts';
import type { ISimpleType, IStateTreeNode, Instance, SnapshotOut } from '@jbrowse/mobx-state-tree';
export type GetOptions<SCHEMA> = SCHEMA extends ConfigurationSchemaType<any, infer OPTIONS> ? OPTIONS : never;
export type GetBase<SCHEMA> = SCHEMA extends undefined ? never : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<undefined, any> ? undefined : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<infer BASE extends AnyConfigurationSchemaType, any> ? BASE : never;
export type GetExplicitIdentifier<SCHEMA> = GetOptions<SCHEMA> extends ConfigurationSchemaOptions<any, infer EXPLICIT_IDENTIFIER extends string> ? EXPLICIT_IDENTIFIER : never;
/**
 * The identifier prop a schema declares **or inherits** — `trackId`,
 * `displayId`, or whatever `explicitIdentifier` names. Recursive because most
 * display schemas never declare it themselves: they pick up `displayId` from
 * `baseConfiguration: baseLinearDisplayConfigSchema`, whose options
 * `preprocessConfigurationSchemaArguments` merges in at runtime, leaving the
 * subclass's own `EXPLICIT_IDENTIFIER` param `undefined`. Same walk
 * `ConfigurationSlotName` does for inherited slot names.
 */
export type GetInheritedIdentifier<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<any, any> ? GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? GetInheritedIdentifier<GetBase<SCHEMA>> : never) : never;
export type ConfigurationSchemaForModel<MODEL> = MODEL extends IStateTreeNode<infer SCHEMA extends AnyConfigurationSchemaType> ? SCHEMA : never;
export type ConfigurationSlotName<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<infer D, any> ? (keyof D & string) | GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotName<GetBase<SCHEMA>> : never) : never;
type SlotValueResolvedFromDef<DEF> = DEF extends {
    promotedBase: unknown;
} ? Exclude<SlotValueRawFromDef<DEF>, undefined> : SlotValueRawFromDef<DEF>;
type SlotValueRawFromDef<DEF> = DEF extends AnyConfigurationSchemaType ? AnyConfigurationSnapshot : DEF extends {
    model: ISimpleType<infer T extends string>;
} ? DEF extends {
    type: 'maybeStringEnum';
} ? T | undefined : T : DEF extends {
    type: 'stringArray';
} ? string[] : DEF extends {
    type: 'stringArrayMap';
} ? Record<string, string[]> : DEF extends {
    type: 'numberMap';
} ? Record<string, number> : DEF extends {
    type: 'fileLocation';
} ? FileLocation : DEF extends {
    type: 'maybeNumber';
} ? number | undefined : DEF extends {
    type: 'maybeBoolean';
} ? boolean | undefined : DEF extends {
    type: 'maybeColor';
} ? string | undefined : DEF extends {
    type: 'maybeFrozen';
} ? any : DEF extends {
    type: 'number' | 'integer';
} ? number : DEF extends {
    type: 'boolean';
} ? boolean : DEF extends {
    type: 'string' | 'text' | 'color';
} ? string : DEF extends {
    defaultValue: infer V;
} ? [V] extends [boolean] ? boolean : [V] extends [string] ? string : [V] extends [number] ? number : any : any;
/** what a raw read (`getConf` / `readConfObject`) of this slot yields */
export type ConfigurationSlotValue<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueRawFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValue<GetBase<SCHEMA>, K> : any : any;
/**
 * what `resolveConf` yields: the same, minus the inherit sentinel on a
 * promotable slot — the cascade always produces a real value.
 */
export type ConfigurationSlotValueResolved<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueResolvedFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValueResolved<GetBase<SCHEMA>, K> : any : any;
/**
 * Naming convention for config types, paired per schema:
 * - `XConfigSchema` is the MST IType (the schema itself). Use it for
 *   `getConf`, `ConfigurationReference`, and factory params — anywhere a schema
 *   is expected.
 * - `XConfigModel` is `Instance<XConfigSchema>` (a resolved config node). Use it
 *   for `readConfObject` results, model fields, and values read off a session.
 *
 * Prefer a named `XConfigModel` alias over inlining `Instance<XConfigSchema>` at
 * call sites. Two historical names predate this convention and stay as-is:
 * `BaseTrackConfig` (the track instance type) and `AnyConfiguration` (a
 * model-or-snapshot union, not a plain instance).
 */
export type AnyConfigurationSchemaType = ConfigurationSchemaType<any, any>;
export type AnyConfigurationModel = Instance<AnyConfigurationSchemaType>;
/** a plain-object snapshot of a configuration model (not a live MST node) */
export type AnyConfigurationSnapshot = SnapshotOut<AnyConfigurationModel>;
/**
 * A value readable as configuration: either a live configuration model or a
 * plain snapshot of one. `session.tracks` legitimately holds a mix (live
 * `sessionTracks` nodes, plus plain frozen/merged base entries that hydrate to
 * MST only on first reference access), and `readConfObject` reads both — so this
 * is the honest type at those boundaries. Reserve `AnyConfigurationModel` for
 * values that must be live (actions, identity, reference resolution).
 */
export type AnyConfiguration = AnyConfigurationModel | AnyConfigurationSnapshot;
export {};
