import type { AnyConfigurationModel } from './types.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Everything the cascade needs to read a promotable slot: the display type it
 * keys the session-wide default on, and the config holding the track's own
 * value. Every entry point takes this — `resolveConf`, the control builders,
 * the worker snapshot, the badge diff — so each can take a display state node
 * directly rather than through a cast.
 *
 * Read-only, and there is no write-capable variant. A `PromotableDisplay` used
 * to exist for the one member the subsystem wrote (`setIgnorePromotedDefaults`,
 * the received-session opt-out); with that flag gone the subsystem writes
 * nothing to a display but a config slot, which `setConf` reaches through
 * `configuration`.
 */
export type ResolvableDisplay = IAnyStateTreeNode & {
    type: string;
    configuration: AnyConfigurationModel;
};
/**
 * Where the session-wide tier of the cascade is read from. Narrowed to the one
 * method so the resolver doesn't depend on the whole session type.
 */
export interface PromotedDefaultStore {
    getDisplayTypeDefault: (displayType: string, slot: string) => unknown;
}
/**
 * The cascade's inputs, stated directly rather than read off a display state
 * node. `ResolvableDisplay` is the usual way to supply them (see
 * `cascadeContextFor`), but a display config can also be resolved with **no
 * state node at all** — a track that isn't open has none, and "Copy config" in
 * the About dialog still has to show what it would render as. That path passes
 * the display's config plus the session directly.
 */
export interface CascadeContext {
    config: AnyConfigurationModel;
    displayType: string;
    defaults: PromotedDefaultStore;
}
export declare function cascadeContextFor(self: ResolvableDisplay): CascadeContext;
/**
 * What the slot literally holds, unevaluated — a stray `jexl:` string yields the
 * raw string rather than running it. Both callers ask "is the slot set, and to
 * what kind of thing?", which has to be answerable with no feature context.
 *
 * Deliberately not `readConfObject`: for a promotable slot this is the whole
 * stored read, and both of that reader's extra behaviors are unwanted here — it
 * evaluates a `jexl:` string (which `isUsableValue` refuses anyway) and it
 * snapshots an MST-node value, which a `maybe*` slot never holds.
 */
export declare function storedSlotValue(config: AnyConfigurationModel, slot: string): unknown;
/**
 * The outcome of walking the cascade for one slot: the two tiers that fed it,
 * whether the track customized it, and the settled value.
 *
 * There is deliberately **no callback case** — a `jexl:` value fails
 * `isUsableValue` like any other unusable value and degrades to the inherited
 * one, so `value` is always readable. See `isUsableValue`.
 */
export interface SlotResolution {
    /** value a track following the default shows with nothing promoted (CSS `initial`) */
    base: unknown;
    /** the raw session-wide promoted default, if any */
    promoted: unknown;
    /** track holds its own value rather than following the default */
    customized: boolean;
    /**
     * the value came from the session-wide tier — the track follows the default
     * *and* that default moves it off `base`. The "this display picked something
     * up from the session" predicate, for the badge diff and the About dialog's
     * copy-config note. A field rather than a `!customized && !deepEqual(value,
     * base)` at each call site, because getting either half wrong is silent:
     * dropping `customized` reports a customized track as inheriting, dropping
     * the `base` compare flags a promoted default that changes nothing.
     */
    inherited: boolean;
    /** the final cascaded value (never the `undefined` inherit sentinel) */
    value: unknown;
}
export declare function resolveSlot(self: ResolvableDisplay, slot: string): SlotResolution;
export declare function resolveSlotIn(ctx: CascadeContext, slot: string): SlotResolution;
