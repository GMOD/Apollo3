import type { ConfigSlotDefinition } from './configurationSlot.ts';
/**
 * Whether `value` has a JS shape this slot could hold. Guards the untyped
 * session store / saved snapshot against garbage; not a full validation
 * (`validate` layers semantics on top).
 *
 * Keyed off `promotedBase` because that is the only concrete specimen of the
 * slot's value space a promotable slot declares — `defaultValue` is always the
 * inherit sentinel, so keying off it would demand `typeof value === 'undefined'`.
 * A `promotedBase` checked against itself therefore only exercises the
 * `SHAPE_CHECKS` entries, which is exactly the half that can be authored wrong
 * (an enum member that isn't in the vocabulary, a non-finite number).
 *
 * Can't delegate to the slot's MST `model.is(value)`: too permissive exactly
 * where this guard matters — `types.number.is(NaN)` and
 * `types.frozen().is('any-string')` are both `true`.
 */
export declare function matchesSlotShape(def: ConfigSlotDefinition, value: unknown): boolean;
/**
 * Whether a stored value could really be a value of this slot. An unusable value
 * is dropped by the cascade, so the getter, the pin and the badge all fall back
 * in lockstep.
 *
 * The `jexl:` check is the only place the subsystem handles a callback, and it
 * handles it by refusing it. Nothing in the app can author one, but a
 * hand-edited config or default store is untyped, and a `jexl:` string would
 * otherwise sail through `maybeColor`'s bare `typeof === 'string'` and reach a
 * renderer as a literal color. DISPLAY_TYPE_DEFAULTS.md §"No callbacks".
 */
export declare function isUsableValue(def: ConfigSlotDefinition, value: unknown): boolean;
