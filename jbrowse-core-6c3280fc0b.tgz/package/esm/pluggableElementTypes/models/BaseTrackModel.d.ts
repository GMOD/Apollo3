import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../../configuration/index.ts';
import type { MenuItem } from '../../ui/index.ts';
import type { DisplayModel } from './BaseDisplayModel.tsx';
import type { FileTypeExporter } from './saveTrackFileTypes/types.ts';
import type { IAnyStateTreeNode, IType, Instance } from '@jbrowse/mobx-state-tree';
export declare function getCompatibleDisplays(self: IAnyStateTreeNode): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
} & import("@jbrowse/mobx-state-tree").IStateTreeNode<AnyConfigurationSchemaType>)[];
/**
 * #stateModel BaseTrackModel
 * #category track
 *
 * these MST models only exist for tracks that are *shown*. they should contain
 * only UI state for the track, and have a reference to a track configuration.
 * note that multiple displayed tracks could use the same configuration.
 */
export declare function createBaseTrackModel(pm: PluginManager, trackType: string, baseTrackConfig: AnyConfigurationSchemaType): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    /**
     * #property
     */
    configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<AnyConfigurationSchemaType>;
    /**
     * #property
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    /**
     * #property
     */
    pinned: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    /**
     * #property
     * The runtime plugin union (`pluggableMstType`) is typed only as
     * `IAnyType`, erasing the element to `any`. Assert the concrete
     * `DisplayModel` instance every registered display satisfies so reads
     * (`activeDisplay`, `trackMenuItems`) are checked;
     * create/snapshot stay `unknown` since the union's snapshot shape is
     * genuinely dynamic (`replaceDisplay` writes a partial snapshot).
     */
    displays: import("@jbrowse/mobx-state-tree").IArrayType<IType<unknown, unknown, DisplayModel>>;
}, {
    /**
     * #getter
     */
    readonly trackId: string;
    /**
     * #getter
     * determines which webworker to send the track to, currently based on trackId
     */
    readonly rpcSessionId: string;
    /**
     * #getter
     */
    readonly name: string;
    /**
     * #getter
     */
    readonly textSearchAdapter: any;
    /**
     * #getter
     */
    readonly adapterConfig: any;
    /**
     * #getter
     * a shown track always has at least one display
     */
    readonly activeDisplay: DisplayModel & import("@jbrowse/mobx-state-tree").IStateTreeNode<IType<unknown, unknown, DisplayModel>>;
    /**
     * #getter
     */
    readonly canConfigure: boolean;
} & {
    /**
     * #getter
     */
    readonly adapterType: import("../AdapterType.ts").default;
} & {
    /**
     * #action
     */
    setPinned(flag: boolean): void;
    /**
     * #action
     */
    setMinimized(flag: boolean): void;
    /**
     * #action
     */
    replaceDisplay(oldDisplayId: string, newDisplayId: string, initialSnapshot?: any): void;
    /**
     * #action
     * Persist any config-schema mutation (quick track-menu edits calling
     * `setSlot` directly, or the full Settings dialog) back to the session,
     * debounced, mirroring ConfigurationEditorWidget's own save. Both savers
     * intentionally coexist — this one covers direct setSlot edits on a shown
     * track, the widget covers an unshown track edited from the selector (no
     * BaseTrackModel). When both fire they compute an identical delta, deduped
     * in updateTrackConfiguration; don't drop one to "simplify". `reaction`
     * (not `autorun`) on purpose: `self.configuration` is defined
     * immediately on attach, unlike ConfigurationEditorWidget's `target`
     * (which starts undefined), so an autorun's guaranteed first run would
     * otherwise schedule a spurious flush for every track ever shown, even
     * completely untouched ones — `reaction` only fires on an actual change.
     *
     * `equals: compareStructural` is load-bearing, not an optimization:
     * `self.configuration` is a re-resolving reference, and persisting a save
     * swaps the resolved node identity (admin `updateTrackConf` replaces the
     * frozen `jbrowse.tracks` entry, rehydrating a brand-new MST node; the
     * non-admin path reconciles in place but still churns once). Referential
     * comparison would treat every such swap as a fresh change and re-fire the
     * save, which for the admin/desktop path (new node every write) is an
     * unbounded debounced loop. Structural comparison settles once the content
     * stops changing.
     */
    afterAttach(): void;
} & {
    /**
     * #method
     */
    saveTrackFileFormatOptions(): Record<string, FileTypeExporter>;
} & {
    /**
     * #getter
     * the "Save track data" menu entry. Kept separate from trackMenuItems so
     * consumers (e.g. the LGV track-label menu) can place it alongside the
     * session's Settings/Copy/Delete track actions without fishing it back out
     * of the general list
     */
    readonly saveTrackDataMenuItem: MenuItem;
    /**
     * #method
     */
    trackMenuItems(): MenuItem[];
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseTrackStateModel = ReturnType<typeof createBaseTrackModel>;
export type BaseTrackModel = Instance<BaseTrackStateModel>;
