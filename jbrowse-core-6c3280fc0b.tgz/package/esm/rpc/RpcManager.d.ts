import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type BaseRpcDriver from './BaseRpcDriver.ts';
import type { RpcArgs, RpcMethodName, RpcReturn } from './RpcRegistry.ts';
export type RpcDriverFactory = (config: AnyConfigurationModel, pluginManager: PluginManager) => BaseRpcDriver;
type RpcCallArgs<M extends string> = M extends RpcMethodName ? Omit<RpcArgs<M & RpcMethodName>, 'sessionId'> : Record<string, unknown>;
type RpcCallReturn<M extends string> = M extends RpcMethodName ? RpcReturn<M & RpcMethodName> : unknown;
export interface RpcManagerOptions {
    makeWorkerInstance?: () => Worker;
    defaultDriverName?: string;
}
export default class RpcManager {
    static configSchema: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly defaultDriver: {
            readonly type: "string";
            readonly description: "the RPC driver to use for tracks and tasks that are not configured to use a specific RPC backend";
            readonly defaultValue: "";
            readonly advanced: true;
        };
        readonly workerCount: {
            readonly type: "number";
            readonly description: "The number of workers to use. If 0 (the default) JBrowse will decide how many workers to use.";
            readonly defaultValue: 0;
            readonly advanced: true;
        };
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    pluginManager: PluginManager;
    mainConfiguration: AnyConfigurationModel;
    defaultDriverName: string;
    driverObjects: Map<string, BaseRpcDriver>;
    driverFactories: Map<string, RpcDriverFactory>;
    constructor(pluginManager: PluginManager, mainConfiguration: AnyConfigurationModel, { makeWorkerInstance, defaultDriverName, }?: RpcManagerOptions);
    registerDriverFactory(name: string, factory: RpcDriverFactory): void;
    getDriver(backendName: string): BaseRpcDriver;
    private getDriverForCall;
    call<M extends string>(sessionId: string, functionName: M, args: RpcCallArgs<M>, opts?: {
        rpcDriverName?: string;
    } & Record<string, unknown>): Promise<RpcCallReturn<M>>;
    /**
     * Run an RPC thunk, and if it fails because a location needs auth, set up
     * credentials for the origin and run it exactly once more. The single retry
     * is structural — there is no loop — so a persistent auth failure surfaces
     * the error instead of spinning. The retry re-runs serializeArguments, which
     * now finds the new account and injects pre-authorization (prompting the
     * user). If auth can't be set up, the original error is rethrown unchanged.
     */
    private withAuthRetry;
    /**
     * Ensure an ephemeral HTTP-basic internet account exists for a location's
     * origin so a retried RPC call can authenticate. The account id is derived
     * from the origin and reused if already present: when a track first loads,
     * many block RPC calls fail auth near-simultaneously, and a single shared
     * account collapses them into one credential prompt (BaseInternetAccountModel
     * memoizes the token via a per-account promise). Returns false when the root
     * model can't hold accounts or no HTTPBasicInternetAccount type is registered
     * (authentication plugin not loaded), signaling the caller not to retry.
     */
    private ensureAuthForOrigin;
    /**
     * Drop a session's sticky worker assignment on every driver so the
     * workerAssignments map doesn't grow unboundedly as sessions are freed.
     * Reached only via CoreFreeResources, which currently has no caller — see
     * the note on that method.
     */
    private freeSessionOnAllDrivers;
    /**
     * Terminate every driver's worker threads. Call when discarding the owning
     * root model (e.g. switching sessions or reloading after a plugin change) so
     * orphaned workers don't accumulate across a desktop run.
     */
    destroy(): void;
}
export {};
