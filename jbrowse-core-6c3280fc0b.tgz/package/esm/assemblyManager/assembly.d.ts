import QuickLRU from '../util/QuickLRU/index.ts';
import type PluginManager from '../PluginManager.ts';
import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
import type RpcManager from '../rpc/RpcManager.ts';
import type { Feature, Region } from '../util/index.ts';
import type { RefNameAliases, RefNameMaps } from './refNameMaps.ts';
import type { IAnyType, Instance } from '@jbrowse/mobx-state-tree';
export { getSequenceAdapterConfig } from './getSequenceAdapterConfig.ts';
export { buildRefNameMaps } from './refNameMaps.ts';
export { lookupGeneticCodeId } from './geneticCodes.ts';
export type { RefNameAliases, RefNameMaps } from './refNameMaps.ts';
type AdapterConf = Record<string, unknown>;
export interface BasicRegion {
    start: number;
    end: number;
    refName: string;
    assemblyName: string;
}
/**
 * #stateModel Assembly
 */
export default function assemblyFactory(assemblyConfigType: IAnyType, pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
}, {
    /**
     * #volatile
     */
    error: unknown;
    /**
     * #volatile
     */
    loadingP: Promise<void> | undefined;
    adapterLoads: QuickLRU<string, Promise<RefNameAliases>>;
    /**
     * #volatile
     */
    volatileRegions: BasicRegion[] | undefined;
    /**
     * #volatile
     */
    refNameAliases: RefNameAliases | undefined;
    /**
     * #volatile
     * Maps canonical refName -> sequence adapter refName (in FASTA).
     * These may differ when refNameAliases with override:true remap names.
     */
    canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
    /**
     * #volatile
     */
    cytobands: Feature[] | undefined;
    /**
     * #volatile
     * refName -> NCBI genetic-code id loaded from `geneticCodesLocation`;
     * merged with (and overridden by) the inline `geneticCodes` config slot
     */
    loadedGeneticCodes: Record<string, number> | undefined;
    /**
     * #volatile
     * Precomputed in loadPre to avoid expensive synchronous computation
     * when MobX triggers the autorun after setLoaded
     */
    lowerCaseRefNameAliases: RefNameAliases | undefined;
} & {
    /**
     * #method
     */
    getConf(arg: string): any;
} & {
    /**
     * #getter
     */
    readonly name: string;
    /**
     * #getter
     */
    readonly aliases: string[];
    /**
     * #getter
     */
    readonly displayName: string;
    /**
     * #getter
     */
    readonly refNameColors: string[];
} & {
    /**
     * #getter
     */
    readonly allAliases: string[];
    /**
     * #method
     */
    hasName(name: string): boolean;
} & {
    /**
     * #action
     * Applies all load-time state in a single transaction so dependent
     * autoruns fire once, with the precomputed lowercase/name lookups already
     * in place by the time refNameAliases becomes observable.
     */
    setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: RefNameMaps & {
        regions: Region[];
        cytobands: Feature[];
        geneticCodes: Record<string, number>;
    }): void;
    /**
     * #action
     */
    setError(e: unknown): void;
    /**
     * #action
     */
    setLoadingP(p?: Promise<void>): void;
    /**
     * #action
     */
    loadPre(): Promise<void>;
} & {
    /**
     * #action
     * Resolves once regions + refNameAliases are set, and rejects with the
     * load failure. Idempotent: concurrent callers share one attempt, and a
     * failed attempt is discarded so the next call retries.
     *
     * The rejection is the authoritative signal for a caller that awaits it.
     * `self.error` mirrors it for reactive consumers only (the UI renders it),
     * and must not be consulted after an await: a concurrent retry clears it,
     * so an awaiter reading it can see a cleared error and mistake a failed
     * load for a successful one.
     */
    load(): Promise<void>;
} & {
    afterAttach(): void;
} & {
    /**
     * #getter
     */
    readonly initialized: boolean;
    /**
     * #getter
     */
    readonly regions: BasicRegion[] | undefined;
    /**
     * #getter
     * note: lowerCaseRefNameAliases not included here: this allows the list
     * of refnames to be just the "normal casing", but things like
     * getCanonicalRefName can resolve a lower-case name if needed
     */
    readonly allRefNames: string[] | undefined;
    /**
     * #getter
     */
    readonly rpcManager: RpcManager;
} & {
    /**
     * #getter
     */
    readonly refNames: string[] | undefined;
} & {
    /**
     * #getter
     * memoized refName -> first region index, so getRefNameColor is O(1)
     * instead of an O(n) indexOf per call (matters for assemblies with many
     * contigs rendered in overview scalebars/rulers)
     */
    readonly refNameToIndex: Map<string, number> | undefined;
} & {
    /**
     * #method
     * Returns the canonical refName for a given alias or refName.
     * Note: The canonical name may differ from what's in the FASTA file when
     * refNameAliases with override:true are configured. To get the name that
     * matches the FASTA file, use getSeqAdapterRefName().
     */
    getCanonicalRefName(refName: string): string | undefined;
    /**
     * #method
     */
    getRefNameColor(refName: string): string | undefined;
    /**
     * #method
     * NCBI genetic-code (translation table) id for a refName, from the
     * assembly's `geneticCodes` config map (e.g. a mitochondrial contig = 2).
     * Falls back to the standard code (1) for unlisted refNames.
     */
    getGeneticCodeId(refName: string): number;
    /**
     * #method
     * Given a canonical refName, returns the refName used by the sequence
     * adapter (what's in the FASTA file). Falls back to the input if no
     * mapping exists.
     */
    getSeqAdapterRefName(canonicalRefName: string): string;
} & {
    /**
     * #method
     * Returns canonical refName, falling back to input if not found.
     * See getCanonicalRefName() for details.
     */
    getCanonicalRefName2(refName: string): string;
    /**
     * #method
     */
    isValidRefName(refName: string): boolean;
} & {
    /**
     * #method
     * get Map of `canonical-name -> adapter-specific-name`, memoized per
     * adapter config so concurrent callers share one load
     */
    getRefNameMapForAdapter(adapterConf: AdapterConf, options: BaseOptions): Promise<RefNameAliases>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type AssemblyModel = ReturnType<typeof assemblyFactory>;
export type Assembly = Instance<AssemblyModel>;
