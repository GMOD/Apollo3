import type PluginManager from '../PluginManager.ts';
import type { FileLocation } from '../util/types/index.ts';
import type { RefNameAliases } from './refNameMaps.ts';
/**
 * NCBI genetic-code (translation table) id for `refName`, taken from the first
 * of `maps` holding an entry for it, else the standard code (1).
 *
 * A map key and `refName` may each independently be a canonical name or an
 * alias of one: a config generated from NCBI keys by the GFF's RefSeq accession
 * while the assembly's canonical name is the UCSC-style one, and callers that
 * pass a feature's own refName rather than the canonical one. Both sides are
 * resolved through `refNameAliases` (loaded from the chromAlias file) so they
 * meet. The maps are per-assembly contig lists, so scanning them is cheap.
 */
export declare function lookupGeneticCodeId(refName: string, refNameAliases: RefNameAliases | undefined, maps: Record<string, number>[]): number;
export declare function getGeneticCodesFromFile({ location, pluginManager, }: {
    location: FileLocation | undefined;
    pluginManager: PluginManager;
}): Promise<Record<string, number>>;
