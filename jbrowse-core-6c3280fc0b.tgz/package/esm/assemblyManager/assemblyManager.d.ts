import type PluginManager from '../PluginManager.ts';
import type RpcManager from '../rpc/RpcManager.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { StopToken } from '../util/stopToken.ts';
import type { Assembly } from './assembly.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
type AdapterConf = Record<string, unknown>;
export interface AssemblyBaseOpts {
    stopToken?: StopToken;
    sessionId: string;
    statusCallback?: StatusCallback;
}
/**
 * #stateModel AssemblyManager
 */
declare function assemblyManagerFactory(conf: IAnyType, pm: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     * this is automatically managed by an autorun which looks in the parent
     * session.assemblies, session.sessionAssemblies, and
     * session.temporaryAssemblies
     */
    assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {
    /**
     * #getter
     */
    readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
} & {
    /**
     * #method
     */
    getCanonicalAssemblyName(asmName: string): string | undefined;
    /**
     * #method
     */
    getDisplayName(asmName: string): string;
    /**
     * #method
     * The assembly `asmName` names, or undefined. Reports a name it doesn't
     * know to `Core-handleUnrecognizedAssembly` so a plugin can go supply it,
     * which is a side effect: a caller only asking *whether* the session has
     * the assembly wants {@link has} instead.
     */
    get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #method
     * Whether the session knows this assembly. Use this, not `get`, to ask
     * only whether the assembly is present: `!has(name)` is exactly the
     * condition under which `get` reports `name` to
     * `Core-handleUnrecognizedAssembly`, so probing with `get` tells every
     * installed plugin to go resolve a name that a caller supplying the
     * assembly itself (a hub connection, MAF row navigation) is about to
     * create.
     */
    has(asmName: string): boolean;
    /**
     * #getter
     * read via readConfObject, matching how the afterAttach autorun names the
     * assemblies it creates: get() treats a name found here as "a config
     * exists, its model is just not built yet", so the two must agree
     */
    readonly assemblyNamesList: string[];
    /**
     * #getter
     * combined jbrowse.assemblies, session.sessionAssemblies, and
     * session.temporaryAssemblies
     */
    readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
    readonly rpcManager: RpcManager;
} & {
    /**
     * #method
     * use this method instead of assemblyManager.get(assemblyName) to get an
     * assembly with regions loaded
     */
    waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
    /**
     * #method
     */
    getRefNameMapForAdapter(adapterConf: AdapterConf, assemblyName: string | undefined, opts: AssemblyBaseOpts): Promise<import("./refNameMaps.ts").RefNameAliases>;
    /**
     * #method
     */
    isValidRefName(refName: string, assemblyName: string): boolean;
} & {
    afterAttach(): void;
    /**
     * #action
     * private: you would generally want to add to manipulate
     * jbrowse.assemblies, session.sessionAssemblies, or
     * session.temporaryAssemblies instead of using this directly
     */
    removeAssembly(asm: Assembly): void;
    /**
     * #action
     * private: you would generally want to add to manipulate
     * jbrowse.assemblies, session.sessionAssemblies, or
     * session.temporaryAssemblies instead of using this directly
     *
     * this can take an active instance of an assembly, in which case it is
     * referred to, or it can take an identifier e.g. assembly name, which is
     * used as a reference. snapshots cannot be used
     */
    addAssembly(configuration: any): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default assemblyManagerFactory;
