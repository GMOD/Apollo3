import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyDataAdapter } from './BaseAdapter/index.ts';
import type { SnapshotIn } from '@jbrowse/mobx-state-tree';
type ConfigSnap = SnapshotIn<AnyConfigurationSchemaType>;
export declare function adapterConfigCacheKey(conf?: Record<string, unknown>): string;
interface AdapterCacheEntry {
    dataAdapter: AnyDataAdapter;
    sessionIds: Set<string>;
}
/** instantiate a data adapter, or return a cached one with the same config */
export declare function getAdapter(pluginManager: PluginManager, sessionId: string, adapterConfigSnapshot: SnapshotIn<AnyConfigurationSchemaType>): Promise<AdapterCacheEntry>;
/**
 * this is a callback that is passed to adapters that allows them to get any
 * sub-adapters that they need internally, staying with the same worker session
 * ID
 */
export type getSubAdapterType = (adapterConfigSnap: ConfigSnap) => ReturnType<typeof getAdapter>;
export declare function freeAdapterResources(args: {
    sessionId?: string;
}): Promise<void>;
export declare function clearAdapterCache(): void;
export {};
