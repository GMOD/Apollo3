export interface MouseState {
    x: number;
    y: number;
    clientX: number;
    clientY: number;
}
/**
 * Container-relative mouse position for the overlays that follow the pointer
 * (`Crosshairs`, tooltips), coalesced to one update per frame.
 *
 * Bind the handlers and the ref to the same element — the position is measured
 * against that element's box, which is what the overlays are positioned in. A
 * display that also hit-tests takes `onMove`, so its hit and its guides come off
 * one measurement in one frame instead of two pointer paths that have to agree.
 */
export declare function useMouseTracking(ref: React.RefObject<HTMLDivElement | null>, onMove?: (state?: MouseState) => void): {
    mouseState: MouseState | undefined;
    handleMouseMove: (event: React.MouseEvent) => void;
    handleMouseLeave: () => void;
};
