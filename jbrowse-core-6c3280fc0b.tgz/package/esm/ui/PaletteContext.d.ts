import type { JBrowsePalette } from './palette.ts';
import type { ReactNode } from 'react';
export declare function PaletteProvider({ palette, children, }: {
    palette: JBrowsePalette;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function usePalette(): JBrowsePalette;
