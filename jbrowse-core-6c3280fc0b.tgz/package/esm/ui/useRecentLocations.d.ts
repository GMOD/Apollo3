/**
 * Remembers the locations recently opened from an import form, most-recent
 * first and deduplicated, scoped per assembly (and per host/path/config like
 * the remembered assembly). Disabled under jest so tests don't touch
 * localStorage; the in-memory list still updates, so the behavior stays
 * testable.
 */
export declare function useRecentLocations(assemblyName?: string): {
    recentLocations: string[];
    addRecentLocation: (loc: string) => void;
    clearRecentLocations: () => void;
};
