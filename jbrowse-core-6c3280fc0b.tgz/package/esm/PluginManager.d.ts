import PhasedScheduler from './PhasedScheduler.ts';
import type Plugin from './Plugin.ts';
import type AdapterType from './pluggableElementTypes/AdapterType.ts';
import type AddTrackWorkflowType from './pluggableElementTypes/AddTrackWorkflowType.ts';
import type ConnectionType from './pluggableElementTypes/ConnectionType.ts';
import type DisplayType from './pluggableElementTypes/DisplayType.ts';
import type InternetAccountType from './pluggableElementTypes/InternetAccountType.ts';
import type PluggableElementBase from './pluggableElementTypes/PluggableElementBase.ts';
import type RpcMethodType from './pluggableElementTypes/RpcMethodType.ts';
import type TextSearchAdapterType from './pluggableElementTypes/TextSearchAdapterType.ts';
import type TrackType from './pluggableElementTypes/TrackType.ts';
import type ViewType from './pluggableElementTypes/ViewType.ts';
import type WidgetType from './pluggableElementTypes/WidgetType.ts';
import type { PluggableElementType } from './pluggableElementTypes/index.ts';
import type { PluginDefinition } from './pluginDefinitions.ts';
import type { AbstractRootModel, AbstractSessionModel, SimpleFeatureSerialized } from './util/index.ts';
import type { IAnyModelType, IAnyStateTreeNode, IAnyType } from '@jbrowse/mobx-state-tree';
import type { ComponentType } from 'react';
type PluggableElementTypeGroup = 'adapter' | 'display' | 'track' | 'connection' | 'view' | 'widget' | 'rpc method' | 'internet account' | 'text search adapter' | 'add track workflow';
/** internal class that holds the info for a certain element type */
declare class TypeRecord<ElementClass extends PluggableElementBase> {
    registeredTypes: Record<string, ElementClass>;
    typeName: string;
    constructor(typeName: string);
    add(name: string, t: ElementClass): void;
    has(name: string): boolean;
    get(name: string): ElementClass;
    all(): ElementClass[];
}
type AnyFunction = (...args: any) => any;
type ExtensionPointCallback = (extendee: unknown, props?: Record<string, unknown>) => unknown;
/**
 * Marks a component built by wrapping the one the extension point accumulated
 * so far, so {@link PluginManager.evaluateComponentExtensionPoint} can tell
 * composition (two plugins each wrapping, both still visible) from a genuine
 * clobber (a second plugin discarding the first). Set by `addWidgetWrapper`.
 */
export declare const wrappedComponent: unique symbol;
type FeatureWidgetModel = IAnyStateTreeNode & {
    trackId?: string;
    trackType?: string;
};
type WidgetModel = FeatureWidgetModel & {
    type: string;
};
export interface FeaturePanelProps {
    /** has `trackId` and `trackType` */
    model: FeatureWidgetModel;
    /** snapshot of the feature being shown */
    feature: SimpleFeatureSerialized;
    /**
     * how far down the subfeature tree this card is: 0 is the feature the user
     * clicked, 1 its subfeatures, and so on. The point fires for every card, so a
     * panel that belongs only on the clicked feature selects on `depth === 0`
     */
    depth: number;
}
export interface ReplaceWidgetProps {
    session: AbstractSessionModel;
    /** has `type`; feature detail widgets also have `trackId` and `trackType` */
    model: WidgetModel;
    toolbarHeight?: number;
}
export interface ExtensionPointRegistry {
    'Core-extendPluggableElement': {
        args: PluggableElementType;
        result: PluggableElementType;
    };
    'Core-extraFeaturePanel': {
        args: ComponentType<FeaturePanelProps>[];
        result: ComponentType<FeaturePanelProps>[];
        props: FeaturePanelProps;
    };
    /** #extensionPoint Core-replaceWidget | sync | Replace or wrap the component that renders a widget */
    'Core-replaceWidget': {
        args: ComponentType<ReplaceWidgetProps>;
        result: ComponentType<ReplaceWidgetProps>;
        props: ReplaceWidgetProps;
    };
}
export type ExtensionPointName = keyof ExtensionPointRegistry;
export type ExtensionPointArgs<N extends ExtensionPointName> = ExtensionPointRegistry[N]['args'];
export type ExtensionPointResult<N extends ExtensionPointName> = ExtensionPointRegistry[N]['result'];
export type ExtensionPointProps<N extends ExtensionPointName> = 'props' extends keyof ExtensionPointRegistry[N] ? ExtensionPointRegistry[N]['props'] : Record<string, unknown>;
/**
 * The trailing `props` parameter of the evaluate methods, required exactly when
 * the point declares one. Omitting it there used to typecheck and then hand
 * `undefined` to every callback, so each one threw on destructuring the props
 * it was promised.
 */
export type ExtensionPointPropsArgs<N extends ExtensionPointName> = 'props' extends keyof ExtensionPointRegistry[N] ? [props: ExtensionPointProps<N>] : [props?: Record<string, unknown>];
/**
 * A point name that is *not* in the registry, which is what the loose evaluate
 * overloads accept. Keeping a registered name out of them is what makes the
 * typed overload binding: they otherwise match whenever it doesn't, so a call
 * that omitted a required `props` or passed the wrong `extendee` fell through
 * and compiled. Plugin-defined points, and any name that isn't a literal, are
 * unaffected.
 *
 * A registered name resolves to a message-shaped type rather than `never`
 * because this overload is the last one tried, so its error is the one TS
 * reports: `not assignable to never` says nothing about what to fix.
 */
export type UnregisteredPointName<S extends string> = S extends ExtensionPointName ? {
    ERROR: 'this extension point is in ExtensionPointRegistry; check the extendee type, and pass props if it declares them';
} : S;
/**
 * metadata related to the instance of this plugin. `isCore` is set when the
 * plugin was loaded as part of the "core" set of plugins for this application,
 * and `url` records the resolved location it was loaded from. The index
 * signature keeps it free-form so other things about why the plugin is loaded
 * (where it came from, what depends on it, etc.) can be stashed too.
 */
export interface PluginMetadata {
    isCore?: boolean;
    isGlobal?: boolean;
    url?: string;
    [key: string]: unknown;
}
export interface PluginLoadRecord {
    metadata?: PluginMetadata;
    plugin: Plugin;
}
export interface RuntimePluginLoadRecord extends PluginLoadRecord {
    definition: PluginDefinition;
}
export default class PluginManager {
    plugins: Plugin[];
    jexl: import("@jbrowse/jexl").Jexl;
    pluginMetadata: Record<string, PluginMetadata>;
    runtimePluginDefinitions: PluginDefinition[];
    elementCreationSchedule: PhasedScheduler<PluggableElementTypeGroup>;
    pluggableElementsCreated: boolean;
    adapterTypes: TypeRecord<AdapterType>;
    textSearchAdapterTypes: TypeRecord<TextSearchAdapterType>;
    trackTypes: TypeRecord<TrackType>;
    displayTypes: TypeRecord<DisplayType>;
    connectionTypes: TypeRecord<ConnectionType>;
    viewTypes: TypeRecord<ViewType>;
    widgetTypes: TypeRecord<WidgetType>;
    rpcMethods: TypeRecord<RpcMethodType<string>>;
    addTrackWidgets: TypeRecord<AddTrackWorkflowType>;
    internetAccountTypes: TypeRecord<InternetAccountType>;
    configured: boolean;
    rootModel?: AbstractRootModel;
    extensionPoints: Map<string, ExtensionPointCallback[]>;
    warnedClobber: Set<string>;
    /**
     * Lazy-hydration cache for `TrackConfigurationReference`/
     * `DisplayConfigurationReference` (configuration/configurationSchema.ts).
     * `jbrowse.tracks` is `types.frozen` for large-tracklist performance, so a
     * track config is a plain JS object until first referenced; hydrating it
     * into an MST node is deferred to that read. MST's custom-reference
     * `getValue` has no memoization of its own — it reruns on every property
     * access — so without this cache, every read of `track.configuration` would
     * fabricate a fresh, non-identical MST node. Keyed by schemaType (each track
     * type's config schema is rebuilt fresh per PluginManager instance, see
     * addTrackType) then by the frozen object itself, so a cache hit can only
     * ever come from this same PluginManager instance and this same track type.
     * See ADR-031.
     *
     * This node is never mutated: admin edits replace the frozen entry (new
     * identity drops the WeakMap entry), and a non-admin's edits go to a private
     * session working copy, not here (ADR-032). Both levels are `WeakMap`s so
     * entries collect normally — no manual invalidation needed.
     */
    trackConfigHydrationCache: WeakMap<object, WeakMap<object, unknown>>;
    constructor(initialPlugins?: (Plugin | PluginLoadRecord | RuntimePluginLoadRecord)[]);
    pluginConfigurationNamespacedSchemas(): Record<string, unknown>;
    pluginConfigurationUnnamespacedSchemas(): Record<string, unknown>;
    pluginConfigurationRootSchemas(): Record<string, unknown>;
    addPlugin(load: Plugin | PluginLoadRecord | RuntimePluginLoadRecord): this;
    getPlugin(name: string): Plugin | undefined;
    hasPlugin(name: string): boolean;
    removePlugin(pluginName: string): this;
    createPluggableElements(): this;
    setRootModel(rootModel: AbstractRootModel): this;
    configure(): this;
    getElementTypeRecord(groupName: PluggableElementTypeGroup): TypeRecord<PluggableElementBase>;
    addElementType(groupName: PluggableElementTypeGroup, creationCallback: (pluginManager: PluginManager) => PluggableElementType): this;
    getElementType(groupName: PluggableElementTypeGroup, typeName: string): PluggableElementBase;
    getElementTypesInGroup(groupName: PluggableElementTypeGroup): PluggableElementBase[];
    getViewElements(): ViewType[];
    getTrackElements(): TrackType[];
    getConnectionElements(): ConnectionType[];
    getAddTrackWorkflowElements(): AddTrackWorkflowType[];
    getRpcElements(): RpcMethodType[];
    getDisplayElements(): DisplayType[];
    getAdapterElements(): AdapterType[];
    /** get a MST type for the union of all specified pluggable MST types */
    pluggableMstType(groupName: PluggableElementTypeGroup, fieldName: string, fallback?: IAnyType): IAnyType;
    /** get a MST type for the union of all specified pluggable config schemas */
    pluggableConfigSchemaType(typeGroup: PluggableElementTypeGroup, fieldName?: string): IAnyModelType;
    jbrequireCache: Map<any, any>;
    lib: any;
    load: <FTYPE extends AnyFunction>(lib: FTYPE) => ReturnType<FTYPE>;
    /**
     * Get the re-exported version of the given package name.
     * Throws an error if the package is not re-exported by the plugin manager.
     *
     * @returns the library's default export
     */
    jbrequire: (lib: string | AnyFunction | {
        default: AnyFunction;
    }) => any;
    getAdapterType(typeName: string): AdapterType;
    getTextSearchAdapterType(typeName: string): TextSearchAdapterType;
    getTrackType(typeName: string): TrackType;
    getDisplayType(typeName: string): DisplayType;
    getViewType(typeName: string): ViewType;
    getAddTrackWorkflow(typeName: string): AddTrackWorkflowType;
    getWidgetType(typeName: string): WidgetType;
    getConnectionType(typeName: string): ConnectionType;
    getRpcMethodType(methodName: string): RpcMethodType<string>;
    getInternetAccountType(name: string): InternetAccountType;
    addAdapterType(cb: (pm: PluginManager) => AdapterType): this;
    addTextSearchAdapterType(cb: (pm: PluginManager) => TextSearchAdapterType): this;
    addTrackType(cb: (pm: PluginManager) => TrackType): this;
    addDisplayType(cb: (pluginManager: PluginManager) => DisplayType): this;
    addViewType(cb: (pluginManager: PluginManager) => ViewType): this;
    addWidgetType(cb: (pm: PluginManager) => WidgetType): this;
    addConnectionType(cb: (pm: PluginManager) => ConnectionType): this;
    addRpcMethod(cb: (pm: PluginManager) => RpcMethodType): this;
    addInternetAccountType(cb: (pm: PluginManager) => InternetAccountType): this;
    addAddTrackWorkflowType(cb: (pm: PluginManager) => AddTrackWorkflowType): this;
    addToExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, callback: (extendee: ExtensionPointArgs<N>, props: ExtensionPointProps<N>) => ExtensionPointResult<N> | Promise<ExtensionPointResult<N>>): void;
    addToExtensionPoint<T>(extensionPointName: string, callback: (extendee: T, props: Record<string, unknown>) => T | Promise<T>): void;
    evaluateExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): ExtensionPointResult<N>;
    evaluateExtensionPoint<S extends string>(extensionPointName: UnregisteredPointName<S>, extendee: unknown, props?: Record<string, unknown>): unknown;
    /**
     * Fire a *singular* component point — one where exactly one component can
     * render, so a plugin that returns its own discards whatever the plugin
     * before it returned. Same fold as {@link evaluateExtensionPoint}, plus a
     * one-time warning naming the point when more than one callback genuinely
     * takes the slot. A component built by `addWidgetWrapper` still renders the
     * one it wrapped, so it composes and is not counted.
     *
     * Used by {@link PluggableComponent}; producers should render through that
     * rather than calling this directly.
     */
    evaluateComponentExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): ExtensionPointResult<N>;
    evaluateAsyncExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): Promise<ExtensionPointResult<N>>;
    evaluateAsyncExtensionPoint<S extends string>(extensionPointName: UnregisteredPointName<S>, extendee: unknown, props?: Record<string, unknown>): Promise<unknown>;
    evaluateAsyncExtensionPointStrict<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): Promise<ExtensionPointResult<N>>;
    evaluateAsyncExtensionPointStrict<S extends string>(extensionPointName: UnregisteredPointName<S>, extendee: unknown, props?: Record<string, unknown>): Promise<unknown>;
}
export {};
