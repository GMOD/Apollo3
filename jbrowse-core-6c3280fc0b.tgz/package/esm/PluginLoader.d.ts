import type { PluginConstructor } from './Plugin.ts';
import type { CJSPluginDefinition, ESMPluginDefinition, LegacyUMDPluginDefinition, PluginDefinition, UMDPluginDefinition } from './pluginDefinitions.ts';
export interface PluginRecord {
    plugin: PluginConstructor;
    definition: PluginDefinition;
}
export interface LoadedPlugin {
    default: PluginConstructor;
}
/** A definition that could not be loaded, kept with the reason it failed */
export interface PluginLoadFailure {
    definition: PluginDefinition;
    error: unknown;
}
export default class PluginLoader {
    definitions: PluginDefinition[];
    fetchESM?: (url: string) => Promise<LoadedPlugin>;
    fetchCJS?: (url: string) => Promise<LoadedPlugin>;
    constructor(defs?: PluginDefinition[], args?: {
        fetchESM?: (url: string) => Promise<LoadedPlugin>;
        fetchCJS?: (url: string) => Promise<LoadedPlugin>;
    });
    loadCJSPlugin(def: CJSPluginDefinition, baseUri?: string): Promise<LoadedPlugin>;
    loadESMPlugin(def: ESMPluginDefinition, baseUri?: string): Promise<LoadedPlugin>;
    loadUMDPlugin(def: UMDPluginDefinition | LegacyUMDPluginDefinition, baseUri?: string): Promise<{
        default: PluginConstructor;
    }>;
    loadPlugin(def: PluginDefinition, baseUri?: string): Promise<PluginConstructor>;
    installGlobalReExports(target: WindowOrWorkerGlobalScope): this;
    /**
     * Loads every definition and separates the ones that worked from the ones
     * that didn't, instead of failing the batch on the first error.
     *
     * A remote config names its plugins at urls nobody re-checks — a store path
     * that stops being republished, a bundle that needs a newer host than the one
     * reading the config — and `load`'s all-or-nothing contract turns any of that
     * into a dead app rather than a missing feature. That is the widest blast
     * radius left in config loading: an unknown track/adapter/display type is
     * already tolerated (the track is simply not usable), so the plugin url was
     * the only field in a config that could still take a whole session down.
     *
     * Callers that can degrade (the apps) use this and report the failures;
     * callers that cannot (the RPC worker, where a half-loaded plugin set would
     * fail renders with a much worse message) keep using `load`.
     */
    loadSettled(baseUri?: string): Promise<{
        records: PluginRecord[];
        failures: PluginLoadFailure[];
    }>;
    load(baseUri?: string): Promise<PluginRecord[]>;
}
