export type ReorderDirection = 'up' | 'down' | 'top' | 'bottom';
/**
 * Move the element at `idx` within `arr` in the given direction, returning a new
 * array. An edge move (already at top/bottom) returns an unchanged copy.
 */
export declare function reorder<T>(arr: readonly T[], idx: number, direction: ReorderDirection): T[];
