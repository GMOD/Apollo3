export declare const NoAssemblyRegion: import("@jbrowse/mobx-state-tree").IModelType<{
    refName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    start: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
    end: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
    reversed: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    setRefName(newRefName: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare const Region: import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    refName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    start: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
    end: import("@jbrowse/mobx-state-tree").ISimpleType<number>;
    reversed: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "assemblyName"> & {
    assemblyName: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, {
    setRefName(newRefName: string): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare const LocalPathLocation: import("@jbrowse/mobx-state-tree").IModelType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"LocalPathLocation">;
    localPath: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare const BlobLocation: import("@jbrowse/mobx-state-tree").IModelType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"BlobLocation">;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    blobId: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare const FileHandleLocation: import("@jbrowse/mobx-state-tree").IModelType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"FileHandleLocation">;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    handleId: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare const UriLocationRaw: import("@jbrowse/mobx-state-tree").IModelType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"UriLocation">;
    uri: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    baseUri: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    internetAccountId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IModelType<{
        internetAccountType: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        authInfo: import("@jbrowse/mobx-state-tree").IType<any, any, any>;
    }, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare const UriLocation: import("@jbrowse/mobx-state-tree").ISnapshotProcessor<import("@jbrowse/mobx-state-tree").IModelType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"UriLocation">;
    uri: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    baseUri: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    internetAccountId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IModelType<{
        internetAccountType: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        authInfo: import("@jbrowse/mobx-state-tree").IType<any, any, any>;
    }, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, import("@jbrowse/mobx-state-tree")._NotCustomized, {
    locationType: "UriLocation";
    uri: string;
    internetAccountId: string | undefined;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
        internetAccountType: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        authInfo: import("@jbrowse/mobx-state-tree").IType<any, any, any>;
    }> | undefined;
}>;
export interface LegacyFileLocation {
    locationType?: undefined;
    uri?: string;
    localPath?: string;
    blob?: string;
    handleId?: string;
}
export declare const FileLocation: import("@jbrowse/mobx-state-tree").ISnapshotProcessor<import("@jbrowse/mobx-state-tree").ITypeUnion<import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "LocalPathLocation";
    localPath: string;
}> | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "BlobLocation";
    name: string;
    blobId: string;
}> | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "FileHandleLocation";
    name: string;
    handleId: string;
}> | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "UriLocation";
    uri: string;
    baseUri: string | undefined;
    internetAccountId: string | undefined;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").ModelCreationType<{
        internetAccountType: string;
        authInfo: any;
    }> | undefined;
}>, import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"LocalPathLocation">;
    localPath: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}> | import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"BlobLocation">;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    blobId: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}> | import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
    locationType: import("@jbrowse/mobx-state-tree").ISimpleType<"FileHandleLocation">;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    handleId: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}> | {
    locationType: "UriLocation";
    uri: string;
    internetAccountId: string | undefined;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
        internetAccountType: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        authInfo: import("@jbrowse/mobx-state-tree").IType<any, any, any>;
    }> | undefined;
}, ({
    blobId: string;
    locationType: "BlobLocation";
    name: string;
} & Partial<{
    locationType: "BlobLocation";
    name: string;
    blobId: string;
}>) | ({
    handleId: string;
    locationType: "FileHandleLocation";
    name: string;
} & Partial<{
    locationType: "FileHandleLocation";
    name: string;
    handleId: string;
}>) | ({
    localPath: string;
    locationType: "LocalPathLocation";
} & Partial<{
    locationType: "LocalPathLocation";
    localPath: string;
}>) | ({
    locationType: "UriLocation";
    uri: string;
} & Partial<{
    locationType: "UriLocation";
    uri: string;
    baseUri: string | undefined;
    internetAccountId: string | undefined;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").ModelCreationType<{
        internetAccountType: string;
        authInfo: any;
    }> | undefined;
}>)>, LegacyFileLocation | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "LocalPathLocation";
    localPath: string;
}> | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "BlobLocation";
    name: string;
    blobId: string;
}> | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "FileHandleLocation";
    name: string;
    handleId: string;
}> | import("@jbrowse/mobx-state-tree").ModelCreationType<{
    locationType: "UriLocation";
    uri: string;
    baseUri: string | undefined;
    internetAccountId: string | undefined;
    internetAccountPreAuthorization: import("@jbrowse/mobx-state-tree").ModelCreationType<{
        internetAccountType: string;
        authInfo: any;
    }> | undefined;
}>, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export { ElementId, createElementId } from './ElementId.ts';
