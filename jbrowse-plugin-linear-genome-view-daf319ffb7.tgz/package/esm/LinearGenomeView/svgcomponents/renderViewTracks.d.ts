import type { ExportSvgDisplayOptions } from '../../BaseLinearDisplay/types.ts';
import type { ExportSvgOptions, TrackLabelMode } from '../types.ts';
import type { ThemeOptions } from '@mui/material';
import type { ReactNode } from 'react';
export interface SvgExportTrack {
    minimized: boolean;
    displays: {
        height: number;
        svgLegendWidth?: () => number;
        renderSvg: (opts: ExportSvgDisplayOptions) => Promise<ReactNode>;
    }[];
}
export interface ViewTracksSvg<T> {
    /** the tracks that were rendered, in the order they were laid out */
    tracks: T[];
    displayResults: {
        track: T;
        result: ReactNode;
    }[];
    /** total height of the stack, valid only because the renders above resolved */
    tracksHeight: number;
    /** 0 unless `reserveLegendWidth` was asked for */
    legendWidth: number;
}
/**
 * One view's worth of exported track bodies: which tracks are in, their
 * rendered SVG, and how tall the stack ends up.
 *
 * It exists to own the two orderings that each of the three view exports got
 * wrong at least once, because neither is visible at a call site that merely
 * lists the same statements in some order:
 *
 * - `legendWidth` is measured **before** the awaits, because it is an input to
 *   them: a display draws its legend beside its body or floating over it
 *   depending on whether the container reserved room. That is why
 *   `svgLegendWidth` is specified as a function of the *settings* and not of
 *   the loaded data — see LinearHicDisplay's implementation.
 * - `tracksHeight` is measured **after** them. A display whose height follows
 *   its data (grow mode; `LinearMultiRowFeatureDisplay` is `nrow *
 *   effectiveRowHeight`) only reaches its final height once `renderSvg`'s
 *   readiness wait resolves, and `SVGTracks` re-reads `displays[0].height`
 *   later still. Measuring up front sized the canvas for the pre-fetch height
 *   and the taller bodies ran off the bottom of the export — and in the
 *   breakpoint-split export it also desynced the overlay anchors, resolved
 *   after, from the view tops, which weren't.
 *
 * The minimized filter and the track order are here for the same reason: the
 * reserved height, the rendered bodies, the label gutter and (breakpoint-split)
 * the ribbon anchors must all be derived from one list, and pinned tracks are
 * drawn at the top of a view on screen.
 */
export declare function renderViewTracks<T extends SvgExportTrack>({ view, opts, theme, textHeight, trackLabels, reserveLegendWidth, }: {
    view: {
        pinnedTracks: T[];
        unpinnedTracks: T[];
    };
    opts: ExportSvgOptions;
    theme: ThemeOptions | undefined;
    textHeight: number;
    trackLabels: TrackLabelMode;
    reserveLegendWidth?: boolean;
}): Promise<ViewTracksSvg<T>>;
