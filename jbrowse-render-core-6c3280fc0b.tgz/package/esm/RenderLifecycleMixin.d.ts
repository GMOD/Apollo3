export interface RenderingBackendCallbacks<B> {
    upload: (backend: B) => void;
    /**
     * Issue draw calls for the current frame. Return `true` if something was
     * actually drawn (flips `canvasDrawn`), `false` to skip this tick
     * (e.g. `renderState` not yet computed). Returning `true` without
     * having drawn — or forgetting a return branch — will flip the
     * `canvasDrawn` flag spuriously, which test selectors and overlay UI
     * depend on.
     */
    render: (backend: B) => boolean;
}
/**
 * Owns the GPU draw lifecycle for any display that paints to a canvas.
 *
 * Plugins compose this mixin (directly or via `MultiRegionDisplayMixin` /
 * `GlobalDataDisplayMixin`) and call
 * `self.attachRenderingBackend(backend, { upload, render })` from their own
 * `startRenderingBackend(backend)` action. The mixin owns:
 *
 *  - `canvasDrawn` — observable flag read by test-selector `data-testid` attributes to detect first paint.
 *  - `currentRenderingBackend` — the backend reference, updated on context-loss
 *    recovery. Autoruns read it each tick so they re-fire against the new
 *    one without being reinstalled.
 *  - `renderTick` — counter the render autorun observes; bumped by
 *    `renderNow()` (tab-visibility restore) and after every upload
 *    (ensures render re-fires when an upload happens but renderState
 *    identity stays stable).
 *  - `autorunsInstalled` — guards `attachRenderingBackend` so the autorun
 *    pair is spawned once per model instance, not once per backend
 *    assignment.
 *
 * The `upload` callback runs in one autorun, `render` in another. Inside
 * each, every observable read is auto-tracked by MobX — no getter-layer
 * indirection, no multi-entry config. `render` returns `true` when the
 * backend actually painted content (flips `canvasDrawn`), `false` to skip
 * this tick (e.g. `renderState` not yet computed or no regions loaded).
 *
 * #stateModel RenderLifecycleMixin
 * #category display
 * @see RenderLifecycleMixin.test.ts for the upload/render autorun behavior
 */
export declare function RenderLifecycleMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    /**
     * #getter
     * Overridable precondition (default true): both lifecycle autoruns skip
     * their callback entirely while this is false, so a display never has to
     * open its own `upload`/`render` with a readiness check.
     *
     * The LGV mixins override it with `view.initialized`, because before the
     * view is measured its geometry throws by design (`view.width`, and so
     * `visibleRegions` / `trackWidthPx` with it) and a throw in either callback
     * is routed to `renderError` — surfacing "not measured yet" as the GPU
     * render-error banner. Because it's an observable read inside the autoruns,
     * the pair re-fires the moment it flips. This is the *precondition* axis
     * only: whether any data has arrived stays the render callback's own gate
     * (return `false` to skip a tick), which is why `renderState` getters can
     * be plain resolved values.
     */
    readonly canRender: boolean;
} & {
    /**
     * #action
     */
    markCanvasDrawn(): void;
    /**
     * #action
     */
    resetCanvasDrawn(): void;
    /**
     * #action
     */
    stopRenderingBackend(): void;
    /**
     * #action
     */
    renderNow(): void;
    /**
     * #action
     * set/clear the render-backend error. Called by `useRenderingBackend`:
     * with the error when the canvas factory rejects (or context-loss
     * re-init fails), and with `undefined` on successful (re)init and on
     * retry.
     */
    setRenderError(error: unknown): void;
} & {
    /**
     * #action
     * attach a GPU/Canvas2D backend and install the upload + render autorun
     * pair (idempotent — re-calling only swaps the backend)
     */
    attachRenderingBackend<B>(backend: B, cbs: RenderingBackendCallbacks<B>): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
