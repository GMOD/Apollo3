import type { Feature } from '../../util/simpleFeature.ts';
import type { RectifiedQuantitativeStats } from '../../util/stats.ts';
import type { AugmentedRegion as Region } from '../../util/types/index.ts';
import type { BaseOptions } from './types.ts';
import type { Observable } from 'rxjs';
/**
 * What a caller that will *judge* the density knows and the probe does not: how
 * wide a window has to be before its count can settle that judgement, and when
 * a count has settled it. Supplying it turns the ladder below from "grow until
 * the estimate is precise" into "grow until the verdict is decided", which at
 * whole-genome zoom is one window instead of thirteen.
 *
 * The probe stays ignorant of what the budget means — `plugins/canvas`'s
 * `densityProbeGate` owns both numbers, so the comparison that refuses a region
 * lives beside the one the banner re-derives rather than in a second copy here.
 */
export interface DensityProbeGate {
    /** First window to sample: the narrowest one whose count can settle it. */
    initialInterval: number;
    /** Whether this many admitted features in this many bp decides the verdict. */
    settled: (admitted: number, sampledBp: number) => boolean;
}
/**
 * The adapter options a probe forwards, plus the two things only its caller
 * knows. Named rather than trailing positionals: `BaseOptions` has no required
 * member, so every one of its slots structurally accepts anything, and an
 * `admit` handed to the `opts` slot typechecks and then never filters.
 */
export interface DensityProbeOptions extends BaseOptions {
    /**
     * The caller's feature-admission predicate (config filters, type gates, ...).
     * See the note on the growth/report asymmetry below.
     */
    admit?: (feature: Feature) => boolean;
    /** Stop as soon as the verdict is decided rather than when it is precise. */
    gate?: DensityProbeGate;
}
export declare function aggregateQuantitativeStats(stats: RectifiedQuantitativeStats[]): RectifiedQuantitativeStats;
export declare function calculateFeatureDensityStats(region: Region, getFeatures: (region: Region, opts?: BaseOptions) => Observable<Feature>, { admit, gate, ...opts }?: DensityProbeOptions): Promise<{
    featureDensity: number;
}>;
export { blankStats } from '../../util/stats.ts';
