import PhasedScheduler from './PhasedScheduler.ts';
import './util/tracks.ts';
import type Plugin from './Plugin.ts';
import type AdapterType from './pluggableElementTypes/AdapterType.ts';
import type AddTrackWorkflowType from './pluggableElementTypes/AddTrackWorkflowType.ts';
import type ConnectionType from './pluggableElementTypes/ConnectionType.ts';
import type DisplayType from './pluggableElementTypes/DisplayType.ts';
import type InternetAccountType from './pluggableElementTypes/InternetAccountType.ts';
import type PluggableElementBase from './pluggableElementTypes/PluggableElementBase.ts';
import type RpcMethodType from './pluggableElementTypes/RpcMethodType.ts';
import type TextSearchAdapterType from './pluggableElementTypes/TextSearchAdapterType.ts';
import type TrackType from './pluggableElementTypes/TrackType.ts';
import type ViewType from './pluggableElementTypes/ViewType.ts';
import type WidgetType from './pluggableElementTypes/WidgetType.ts';
import type { PluggableElementType } from './pluggableElementTypes/index.ts';
import './pluggableElementTypes/models/migrateTrackConfig.ts';
import type { PluginDefinition } from './pluginDefinitions.ts';
import './rpc/WebWorkerRpcDriver.ts';
import './ui/buildExtraTrackMenuItems.ts';
import './ui/multiTrackMenuItems.ts';
import './util/addTrackComponent.ts';
import type { AbstractRootModel, AbstractSessionModel, SimpleFeatureSerialized } from './util/index.ts';
import type { IAnyModelType, IStateTreeNode, IAnyType } from '@jbrowse/mobx-state-tree';
import type { ComponentType, ReactNode } from 'react';
/**
 * Every pluggable element group, in the order `elementCreationSchedule` builds
 * them. The array is the declaration and the union is derived from it, so a
 * consumer that has to visit every group — `pruneUnbuildableNodes` walking a
 * session snapshot for containers of a pluggable union — enumerates them at
 * runtime instead of keeping a second hand-written list that goes stale.
 */
export declare const pluggableElementTypeGroups: readonly ['adapter', 'text search adapter', 'display', 'track', 'connection', 'view', 'widget', 'rpc method', 'internet account', 'add track workflow'];
export type PluggableElementTypeGroup = (typeof pluggableElementTypeGroups)[number];
/** internal class that holds the info for a certain element type */
declare class TypeRecord<ElementClass extends PluggableElementBase> {
    registeredTypes: Record<string, ElementClass>;
    typeName: string;
    constructor(typeName: string);
    add(name: string, t: ElementClass): void;
    has(name: string): boolean;
    get(name: string): ElementClass;
    registeredNames(): string;
    all(): ElementClass[];
}
type AnyFunction = (...args: any) => any;
type ExtensionPointCallback = (extendee: unknown, props?: Record<string, unknown>) => unknown;
/**
 * Marks a component built by wrapping the one the extension point accumulated
 * so far, so {@link PluginManager.evaluateComponentExtensionPoint} can tell
 * composition (two plugins each wrapping, both still visible) from a genuine
 * clobber (a second plugin discarding the first). Set by `wrapComponent`.
 */
export declare const wrappedComponent: unique symbol;
/**
 * A point that resolves to one component — a slot with a default, which a
 * plugin wraps or replaces. Declared as
 * `'Core-replaceWidget': ComponentSlot<ReplaceWidgetProps>`, produced by
 * {@link PluggableComponent}, registered on with `wrapComponent`.
 */
export interface ComponentSlot<P> {
    args: ComponentType<P>;
    result: ComponentType<P>;
    props: P;
    /**
     * Type-only: never present at runtime, and what makes the shape *declared*
     * rather than guessed. Reading it off the value cannot work — a
     * `TrackTypeGuesser` takes an argument and returns a string, which is also
     * what a function component does, so a structural test admits it as a slot.
     */
    kind: 'componentSlot';
}
/**
 * A point that accumulates an array of components — the panel points. Produced
 * by {@link PluggableComponents}, registered on with
 * {@link PluginManager.contributeToExtensionPoint}; each panel scopes itself
 * and draws its own chrome.
 */
export interface ComponentList<P> {
    args: ComponentType<P>[];
    result: ComponentType<P>[];
    props: P;
    /** type-only, see {@link ComponentSlot.kind} */
    kind: 'componentList';
}
/**
 * A point that accumulates already-rendered elements — the overlay points.
 * Produced by {@link PluggableElements}, registered on with
 * `addExtensionElement`, which fixes the React key at registration time.
 */
export interface ElementList<P> {
    args: ReactNode[];
    result: ReactNode[];
    props: P;
    /** type-only, see {@link ComponentSlot.kind} */
    kind: 'elementList';
}
/** The names of the points declared as `K`. */
export type PointsOfKind<K extends string> = {
    [N in ExtensionPointName]: ExtensionPointRegistry[N] extends {
        kind: K;
    } ? N : never;
}[ExtensionPointName];
type FeatureWidgetModel = IStateTreeNode & {
    trackId?: string;
    trackType?: string;
};
type WidgetModel = FeatureWidgetModel & {
    type: string;
};
export interface FeaturePanelProps {
    /** has `trackId` and `trackType` */
    model: FeatureWidgetModel;
    /** snapshot of the feature being shown */
    feature: SimpleFeatureSerialized;
    /**
     * how far down the subfeature tree this card is: 0 is the feature the user
     * clicked, 1 its subfeatures, and so on. The point fires for every card, so a
     * panel that belongs only on the clicked feature selects on `depth === 0`
     */
    depth: number;
}
export interface ReplaceWidgetProps {
    session: AbstractSessionModel;
    /** has `type`; feature detail widgets also have `trackId` and `trackType` */
    model: WidgetModel;
    toolbarHeight?: number;
}
/**
 * Typed registries of the view and display types a plugin can extend, in the
 * same shape as {@link ExtensionPointRegistry} and augmented the same way:
 *
 *   declare module '@jbrowse/core/PluginManager' {
 *     interface ViewTypeRegistry {
 *       LinearGenomeView: LinearGenomeViewStateModel
 *     }
 *   }
 *
 * That is what makes `extendViewType(pm, 'LinearGenomeView', …)` hand back a
 * typed state model, and a misspelled or renamed name a compile error rather
 * than an extension that quietly never applies. `getViewType` reads it too, so
 * a caller composing another view's model into its own gets the real type
 * instead of `IAnyModelType`.
 *
 * AN AUGMENTATION IS HAND-WRITTEN, so each registration annotates the model it
 * passes to `ViewType` against its own entry here (`const stateModel:
 * ViewTypeRegistry['CircularView'] = …`). That one line is what makes the
 * registry earn what `getViewType` promises: without it a drifted entry is
 * worse than the `IAnyModelType` it replaced, since a caller would get a
 * confidently wrong type rather than an unchecked one. It cannot live on
 * `ViewType`'s constructor — TypeScript forbids type parameters there, and a
 * class parameter widens `name` to `string`, so the conditional never fires. Declaring them here rather than
 * beside the helpers is load-bearing: an interface can only be augmented
 * through the module that declares it, and a barrel re-exporting the type would
 * give every augmentation its own unrelated copy.
 */
export interface ViewTypeRegistry {
}
export interface DisplayTypeRegistry {
}
export type ViewTypeName = keyof ViewTypeRegistry;
export type DisplayTypeName = keyof DisplayTypeRegistry;
export interface ExtensionPointRegistry {
    'Core-extendSession': {
        args: IAnyModelType;
        result: IAnyModelType;
    };
    'Core-handleUnrecognizedAssembly': {
        args: undefined;
        result: undefined | Promise<void>;
        props: {
            assemblyName: string;
            /**
             * the session the lookup came from. `unknown` because the assembly
             * manager holds it as the narrow shape it needs rather than the whole
             * session model, and nothing in tree reads it — narrow it yourself if you
             * do
             */
            session?: unknown;
        };
    };
    'Core-extendPluggableElement': {
        args: PluggableElementType;
        result: PluggableElementType;
        props: {
            group: PluggableElementTypeGroup;
        };
    };
    'Core-extraFeaturePanel': ComponentList<FeaturePanelProps>;
    /** #extensionPoint Core-replaceWidget | sync | Replace or wrap the component that renders a widget */
    'Core-replaceWidget': ComponentSlot<ReplaceWidgetProps>;
}
export type ExtensionPointName = keyof ExtensionPointRegistry;
export type ExtensionPointArgs<N extends ExtensionPointName> = ExtensionPointRegistry[N]['args'];
export type ExtensionPointResult<N extends ExtensionPointName> = ExtensionPointRegistry[N]['result'];
export type ExtensionPointProps<N extends ExtensionPointName> = 'props' extends keyof ExtensionPointRegistry[N] ? ExtensionPointRegistry[N]['props'] : Record<string, unknown>;
/**
 * Points that carry their whole payload in `props` and whose return value
 * nothing reads — a notification rather than a fold. Registered with
 * {@link PluginManager.listenToExtensionPoint}.
 */
export type NotificationPointName = {
    [N in ExtensionPointName]: ExtensionPointArgs<N> extends undefined ? N : never;
}[ExtensionPointName];
/**
 * Points whose `args` are an array accumulate: the value threaded through the
 * fold is every plugin's entries so far. They are registered with
 * {@link PluginManager.contributeToExtensionPoint}, never
 * {@link PluginManager.addToExtensionPoint} — see the entry type below for why.
 */
export type AccumulatingPointName = {
    [N in ExtensionPointName]: ExtensionPointArgs<N> extends readonly unknown[] ? N : never;
}[ExtensionPointName];
/** One element of an accumulating point's array — what a plugin contributes. */
export type ExtensionPointEntry<N extends AccumulatingPointName> = ExtensionPointArgs<N> extends readonly (infer E)[] ? E : never;
/**
 * The trailing `props` parameter of the evaluate methods, required exactly when
 * the point declares one. Omitting it there used to typecheck and then hand
 * `undefined` to every callback, so each one threw on destructuring the props
 * it was promised.
 */
export type ExtensionPointPropsArgs<N extends ExtensionPointName> = 'props' extends keyof ExtensionPointRegistry[N] ? [props: ExtensionPointProps<N>] : [props?: Record<string, unknown>];
/**
 * A point name that is *not* in the registry, which is what the loose evaluate
 * overloads accept. Keeping a registered name out of them is what makes the
 * typed overload binding: they otherwise match whenever it doesn't, so a call
 * that omitted a required `props` or passed the wrong `extendee` fell through
 * and compiled. Plugin-defined points, and any name that isn't a literal, are
 * unaffected.
 *
 * A registered name resolves to a message-shaped type rather than `never`
 * because this overload is the last one tried, so its error is the one TS
 * reports: `not assignable to never` says nothing about what to fix.
 */
export type UnregisteredPointName<S extends string> = S extends ExtensionPointName ? {
    ERROR: 'this extension point is in ExtensionPointRegistry; check the extendee type, and pass props if it declares them';
} : S;
/**
 * The same guard for `addToExtensionPoint`'s loose overload. Each excluded kind
 * needs its own message, because the useful thing to say is which method the
 * point does belong to.
 *
 * Excluding those names from the *typed* overload is not enough on its own. The
 * loose overload matches whenever the typed one doesn't, so
 * `addToExtensionPoint('Core-extraFeaturePanel', panels => [MyPanel])` — the one
 * call `contributeToExtensionPoint` exists to make impossible — fell through and
 * compiled, with `T` inferred from whatever the callback returned, dropping every
 * other plugin's panels exactly as if the exclusion weren't there.
 *
 * `S` is inferred from the name, so this binds on the ordinary call. It does not
 * bind when a caller writes the type argument out — `addToExtensionPoint<T>(…)`
 * pins `T` and leaves `S` on its default — which is the price of keeping that
 * arity working for plugins compiled against the older signature.
 */
export type FoldPointName<S extends string> = S extends AccumulatingPointName ? {
    ERROR: 'this extension point accumulates a list; register with contributeToExtensionPoint, whose callback returns only its own entries';
} : S extends NotificationPointName ? {
    ERROR: 'this extension point is a notification; register with listenToExtensionPoint, which joins async handlers rather than letting the last one registered replace the rest';
} : S extends ExtensionPointName ? {
    ERROR: 'this extension point is in ExtensionPointRegistry; check the callback against its args/result types';
} : S;
/**
 * metadata related to the instance of this plugin. `isCore` is set when the
 * plugin was loaded as part of the "core" set of plugins for this application,
 * and `url` records the resolved location it was loaded from. The index
 * signature keeps it free-form so other things about why the plugin is loaded
 * (where it came from, what depends on it, etc.) can be stashed too.
 */
export interface PluginMetadata {
    isCore?: boolean;
    isGlobal?: boolean;
    url?: string;
    [key: string]: unknown;
}
export interface PluginLoadRecord {
    metadata?: PluginMetadata;
    plugin: Plugin;
}
export interface RuntimePluginLoadRecord extends PluginLoadRecord {
    definition: PluginDefinition;
}
export default class PluginManager {
    #private;
    plugins: Plugin[];
    jexl: import("@jbrowse/jexl").Jexl;
    pluginMetadata: Record<string, PluginMetadata>;
    runtimePluginDefinitions: PluginDefinition[];
    elementCreationSchedule: PhasedScheduler<"adapter" | "add track workflow" | "connection" | "display" | "internet account" | "rpc method" | "text search adapter" | "track" | "view" | "widget">;
    pluggableElementsCreated: boolean;
    adapterTypes: TypeRecord<AdapterType>;
    textSearchAdapterTypes: TypeRecord<TextSearchAdapterType>;
    trackTypes: TypeRecord<TrackType>;
    displayTypes: TypeRecord<DisplayType>;
    connectionTypes: TypeRecord<ConnectionType>;
    viewTypes: TypeRecord<ViewType>;
    widgetTypes: TypeRecord<WidgetType>;
    rpcMethods: TypeRecord<RpcMethodType<string>>;
    addTrackWidgets: TypeRecord<AddTrackWorkflowType>;
    internetAccountTypes: TypeRecord<InternetAccountType>;
    configured: boolean;
    rootModel?: AbstractRootModel;
    extensionPoints: Map<string, ExtensionPointCallback[]>;
    warnedClobber: Set<string>;
    /**
     * The lazily-hydrated MST config node for one frozen track config, built by
     * `build` on first ask and returned by identity after that.
     * `configuration/configurationSchema.ts` is the only caller.
     *
     * `jbrowse.tracks` is `types.frozen` for large-tracklist performance, so a
     * track config is a plain JS object until first referenced; hydrating it into
     * an MST node is deferred to that read. MST's custom-reference `getValue` has
     * no memoization of its own — it reruns on every property access — so without
     * this, every read of `track.configuration` would fabricate a fresh,
     * non-identical node. Keyed by schemaType (each track type's config schema is
     * rebuilt fresh per PluginManager instance, see addTrackType) then by the
     * frozen object, so a hit can only ever come from this same instance and this
     * same track type. See ADR-031.
     *
     * The node is never mutated: admin edits replace the frozen entry (new
     * identity drops the WeakMap entry), and a non-admin's edits go to a private
     * session working copy, not here (ADR-032). Both levels are `WeakMap`s so
     * entries collect normally — no manual invalidation needed, which is why this
     * is a memo and not a cache with a lifecycle to expose.
     */
    hydratedTrackConfig(schemaType: IAnyType, frozen: object, build: () => unknown): unknown;
    constructor(initialPlugins?: (Plugin | PluginLoadRecord | RuntimePluginLoadRecord)[]);
    pluginConfigurationNamespacedSchemas(): Record<string, unknown>;
    pluginConfigurationUnnamespacedSchemas(): Record<string, unknown>;
    pluginConfigurationRootSchemas(): Record<string, unknown>;
    addPlugin(load: Plugin | PluginLoadRecord | RuntimePluginLoadRecord): this;
    getPlugin(name: string): Plugin | undefined;
    hasPlugin(name: string): boolean;
    removePlugin(pluginName: string): this;
    createPluggableElements(): this;
    setRootModel(rootModel: AbstractRootModel): this;
    configure(): this;
    getElementTypeRecord(groupName: PluggableElementTypeGroup): TypeRecord<PluggableElementBase>;
    addElementType(groupName: PluggableElementTypeGroup, creationCallback: (pluginManager: PluginManager) => PluggableElementType): this;
    getElementType(groupName: PluggableElementTypeGroup, typeName: string): PluggableElementBase;
    getElementTypesInGroup(groupName: PluggableElementTypeGroup): PluggableElementBase[];
    getViewElements(): ViewType[];
    getTrackElements(): TrackType[];
    getConnectionElements(): ConnectionType[];
    getAddTrackWorkflowElements(): AddTrackWorkflowType[];
    getRpcElements(): RpcMethodType[];
    getDisplayElements(): DisplayType[];
    getAdapterElements(): AdapterType[];
    /** get a MST type for the union of all specified pluggable MST types */
    pluggableMstType(groupName: PluggableElementTypeGroup, fieldName: string, fallback?: IAnyType): IAnyType;
    /** get a MST type for the union of all specified pluggable config schemas */
    pluggableConfigSchemaType(typeGroup: PluggableElementTypeGroup, fieldName?: string): IAnyType;
    jbrequireCache: Map<any, any>;
    get lib(): Record<string, unknown>;
    load: <FTYPE extends AnyFunction>(lib: FTYPE) => ReturnType<FTYPE>;
    /**
     * Get the re-exported version of the given package name.
     * Throws an error if the package is not re-exported by the plugin manager.
     *
     * @returns the library's default export
     */
    jbrequire: (lib: string | AnyFunction | {
        default: AnyFunction;
    }) => any;
    getAdapterType(typeName: string): AdapterType;
    /**
     * Whether an adapter type is registered, for a caller walking a config where
     * `type` names a track, a display and an adapter alike — `getAdapterType`
     * throws on a miss, which is right when the name came from a config that
     * claims to be an adapter and wrong when you are asking whether it is one.
     */
    hasAdapterType(typeName: string): boolean;
    getTextSearchAdapterType(typeName: string): TextSearchAdapterType;
    getTrackType(typeName: string): TrackType;
    getDisplayType(typeName: string): DisplayType;
    getViewType<N extends ViewTypeName>(typeName: N): Omit<ViewType, 'stateModel'> & {
        stateModel: ViewTypeRegistry[N];
    };
    getViewType(typeName: string): ViewType;
    getAddTrackWorkflow(typeName: string): AddTrackWorkflowType;
    getWidgetType(typeName: string): WidgetType;
    getConnectionType(typeName: string): ConnectionType;
    getRpcMethodType(methodName: string): RpcMethodType<string>;
    getInternetAccountType(name: string): InternetAccountType;
    addAdapterType(cb: (pm: PluginManager) => AdapterType): this;
    addTextSearchAdapterType(cb: (pm: PluginManager) => TextSearchAdapterType): this;
    addTrackType(cb: (pm: PluginManager) => TrackType): this;
    addDisplayType(cb: (pluginManager: PluginManager) => DisplayType): this;
    addViewType(cb: (pluginManager: PluginManager) => ViewType): this;
    addWidgetType(cb: (pm: PluginManager) => WidgetType): this;
    addConnectionType(cb: (pm: PluginManager) => ConnectionType): this;
    addRpcMethod(cb: (pm: PluginManager) => RpcMethodType): this;
    addInternetAccountType(cb: (pm: PluginManager) => InternetAccountType): this;
    addAddTrackWorkflowType(cb: (pm: PluginManager) => AddTrackWorkflowType): this;
    /**
     * Contribute entries to an accumulating point.
     *
     * The callback is handed only the props and returns what it wants to add —
     * one entry, several, or `undefined` to add nothing. It never receives the
     * array, which is the whole point: the concatenation happens here, once, so
     * no plugin can write the `[MyEntry]` that silently drops every other
     * plugin's entries. That mistake looked correct to whoever made it, because
     * with one plugin registered there is nothing to drop.
     */
    contributeToExtensionPoint<N extends AccumulatingPointName>(extensionPointName: N, callback: (props: ExtensionPointProps<N>) => ExtensionPointEntry<N> | ExtensionPointEntry<N>[] | undefined): void;
    /**
     * Listen to a notification point — one that carries its payload in `props`
     * and whose return value nothing reads. The callback returns nothing;
     * `addToExtensionPoint` rejects these names, so this is the only way in.
     *
     * The reason it is the only way in is the async join below, not the shorter
     * callback. A handler that works asynchronously states so by returning a
     * promise, and the producer waits on the folded value; written by hand
     * through `addToExtensionPoint`, the second async handler's promise silently
     * replaced the first's, so the producer stopped waiting as soon as the
     * *last*-registered handler finished rather than when they all had. That is
     * not a mistake a plugin author can see, which is why it is not left to them.
     */
    listenToExtensionPoint<N extends NotificationPointName>(extensionPointName: N, callback: (props: ExtensionPointProps<N>) => void | Promise<void>): void;
    addToExtensionPoint<N extends Exclude<ExtensionPointName, AccumulatingPointName | NotificationPointName>>(extensionPointName: N, callback: (extendee: ExtensionPointArgs<N>, props: ExtensionPointProps<N>) => ExtensionPointResult<N> | Promise<ExtensionPointResult<N>>): void;
    addToExtensionPoint<T, S extends string = string>(extensionPointName: FoldPointName<S>, callback: (extendee: T, props: Record<string, unknown>) => T | Promise<T>): void;
    /**
     * The one place a callback joins a point's chain. The three public
     * registration methods go through this rather than through each other:
     * `contributeToExtensionPoint` and `listenToExtensionPoint` register on exactly
     * the point names their own signatures reject, so routing them via
     * `addToExtensionPoint` would either fail to compile or force its guard to be
     * loose enough to let a plugin do the same thing by hand.
     */
    private pushExtensionPointCallback;
    evaluateExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): ExtensionPointResult<N>;
    evaluateExtensionPoint<S extends string>(extensionPointName: UnregisteredPointName<S>, extendee: unknown, props?: Record<string, unknown>): unknown;
    /**
     * Fire a *singular* component point — one where exactly one component can
     * render, so a plugin that returns its own discards whatever the plugin
     * before it returned. Same fold as {@link evaluateExtensionPoint}, plus a
     * one-time warning naming the point when more than one callback genuinely
     * takes the slot. A component built by `wrapComponent` still renders the
     * one it wrapped, so it composes and is not counted.
     *
     * Used by {@link PluggableComponent}; producers should render through that
     * rather than calling this directly.
     */
    evaluateComponentExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): ExtensionPointResult<N>;
    /**
     * How many callbacks are registered on `extensionPointName`. For a caller
     * that has to tell "every handler declined" apart from "nobody was
     * listening" — the two look identical in the folded result, and
     * assemblyManager waits out the first but not the second.
     */
    extensionPointCallbackCount(extensionPointName: string): number;
    evaluateAsyncExtensionPoint<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): Promise<ExtensionPointResult<N>>;
    evaluateAsyncExtensionPoint<S extends string>(extensionPointName: UnregisteredPointName<S>, extendee: unknown, props?: Record<string, unknown>): Promise<unknown>;
    evaluateAsyncExtensionPointStrict<N extends ExtensionPointName>(extensionPointName: N, extendee: ExtensionPointArgs<N>, ...props: ExtensionPointPropsArgs<N>): Promise<ExtensionPointResult<N>>;
    evaluateAsyncExtensionPointStrict<S extends string>(extensionPointName: UnregisteredPointName<S>, extendee: unknown, props?: Record<string, unknown>): Promise<unknown>;
}
export {};
