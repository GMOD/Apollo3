export interface LegendCandidate {
    rowIndex: number;
    label: string;
    color: number;
}
export interface LegendEntry {
    label: string;
    color: number;
}
export declare const MAX_LEGEND_ENTRIES = 30;
export declare const MAX_LEGEND_CANDIDATES = 1024;
/**
 * Accumulator for the distinct (row, name, color) combinations a packer walks
 * past, in first-seen order and bounded — the small list `unionLegendCandidates`
 * derives a key from, so the main thread never re-walks the features. Fed scalar
 * by scalar, from the loop that already holds the three values.
 *
 * Deduped on the whole triple rather than on (row, color): the union takes the
 * first NAME it sees for a color, so where that name is already spoken for, the
 * second name on that color has to still be in the list to carry it.
 *
 * A nameless feature contributes nothing, which is the union's rule too — so a
 * track whose features have no names ships an empty list rather than one entry
 * per feature.
 */
export declare function createLegendCandidateCollector(maxCandidates?: number): {
    candidates: LegendCandidate[];
    add(rowIndex: number, label: string, color: number): void;
};
export interface LegendCandidateSource {
    candidates: readonly LegendCandidate[];
    rowPaintsCandidateColor: (rowIndex: number) => boolean;
}
/**
 * The categorical color key over any number of packed regions: one entry per
 * distinct color, labeled by the first name seen in that color, in first-seen
 * order.
 *
 * Keyed by color rather than by name, so each key row is 1:1 with a color — a
 * row is normally a toggle and hiding a category hides features BY color, so two
 * names sharing one color must collapse to a single row. A name reused across
 * two colors keeps its first-seen color.
 *
 * `[]` when the data carries no categorical signal: nothing named, or more than
 * `maxEntries` distinct colors.
 *
 * `regions` is consumed lazily, so a caller able to answer without reading any
 * of them can pass a generator and have none of them touched.
 */
export declare function unionLegendCandidates<T>(regions: Iterable<T>, resolve: (region: T) => LegendCandidateSource, maxEntries?: number): LegendEntry[];
