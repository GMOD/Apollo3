import type { ActiveFetch, StatusReporter, StopTokenRotation } from './createStopTokenRotation.ts';
import type { FetchContext } from './fetchContext.ts';
import type { FetchPhases } from './fetchPhases.ts';
import type { StopToken } from './stopToken.ts';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * The bookkeeping a family hangs off one fetch, beside the phases. Each of the
 * five fetches in the tree fills a different subset, and that subset is the
 * only thing about them that genuinely differs.
 */
export interface FetchLifecycle {
    /**
     * Where the fetch's error lands, and the **clear-at-start rule** in the same
     * parameter: it is called with `undefined` the moment a run begins, so a
     * banner from a failed attempt cannot stand over the result a retriggered
     * run commits — a fetch re-fires on reads that never pass through `reload()`'s
     * own clear (an adapter edit, an un-minimize, a pan). One function rather
     * than a clear plus an `onError`, because a caller given two can supply one.
     *
     * A host with no error state of its own answers only the failure (the
     * breakpoint overlay raises a session notification), which is why the
     * argument is optional rather than the call being conditional.
     */
    setError: (error?: unknown) => void;
    /**
     * Runs synchronously as the fetch starts, after the rotation has superseded
     * whatever it replaced: the loading flag (`FetchMixin`'s `activeStopToken`,
     * the comparative family's `fetching`), and anything a display blanks
     * because it has no freshness signature to keep stale data honest with
     * (chord's refName map).
     *
     * Takes the token rather than the whole {@link ActiveFetch}: publishing it is
     * the only thing any implementation does with the fetch, and the guard and
     * the status slot are the skeleton's to hand out — through `ctx`, where a
     * `run` gets them pre-wired.
     */
    onBegin?: (stopToken: StopToken) => void;
    /**
     * Runs in the `finally`, before the rotation's `end()`. `current` is this
     * run's own guard, already evaluated: a **superseded** run must not clear the
     * loading flag the run that replaced it just set, and it is the only exit
     * that reaches here without having gone through either the commit or the
     * error path.
     */
    onEnd?: (current: boolean) => void;
}
/**
 * One fetch, once: **begin → clear the error → run → commit if still current →
 * {@link handleFetchError} → end**.
 *
 * That sequence was written five times — `FetchMixin.runFetch`, the
 * prerequisite skeleton, the comparative installer, the circular view's chord
 * fetch and the breakpoint split view's overlay fetch — and each copy was
 * missing a different rule: no rotation at all, an error publish guarded on
 * liveness but not currency, no clear at the start, a `finally` that stranded
 * the loading flag on an abort. The rules only pay for themselves by being the
 * same everywhere, so they live here and the differences are parameters.
 *
 * `active` comes from a {@link createStopTokenRotation} `begin()` the caller
 * already made, because who owns the rotation is one of the real differences: a
 * display's *primary* fetch rotates through `FetchMixin`, so `cancelFetch` can
 * reach it, while every other fetch's rotation lives in its installer's closure
 * ({@link installFetch}).
 *
 * **Called synchronously by every caller**, so its own prefix down to the first
 * `await` — and `run`'s prefix with it — executes wherever the caller was.
 * `installFetch` puts that inside `untracked`; `FetchMixin.runFetch` is an MST
 * flow, and so an action, which MobX runs untracked already.
 */
export declare function runFetchOnce<TArgs, TResult>(self: IStateTreeNode, active: ActiveFetch, args: TArgs, { run, commit, setError, onBegin, onEnd, }: Pick<FetchPhases<TArgs, TResult, FetchContext>, 'run' | 'commit'> & FetchLifecycle): Promise<void>;
/**
 * The host members {@link installFetch}'s autorun body reads for itself, above
 * everything the family supplies.
 *
 * `IStateTreeNode`, never `IAnyStateTreeNode` — the latter resolves to `any`
 * and silently turns off checking for every member below.
 */
export interface FetchSkeletonHost extends IStateTreeNode {
    /**
     * The pure "go again" signal, read unconditionally above every gate. After a
     * failure every other fetch input is unchanged, so nothing but this can
     * rewake the body — and a read placed under a gate drops out of the
     * dependency set on the run that declines, which is a Retry button that
     * works until the first time it is needed.
     */
    reloadCounter: number;
    /**
     * The states where this host deliberately fetches nothing, read only by the
     * retry contract check. A decline there is not a dead Retry.
     */
    fetchInert: boolean;
    /**
     * A standing user cancel, and the one durability rule for all of them: **a
     * cancel is durable — no fetch trigger un-cancels it.** Read tracked, under
     * `reloadCounter` and above every other gate, so the gesture that reopens it
     * (Retry, or the LGV foundations' clear-on-viewport-change) is in the
     * dependency set of the run it closed.
     *
     * Optional because a host with no cancel affordance has no cancel to be
     * durable — the circular view's chord fetch and the breakpoint overlay fetch
     * offer no Cancel button, so they declare nothing rather than a constant
     * `false`.
     */
    fetchCanceled?: boolean;
}
interface InstallFetchOptionsBase<TArgs, TResult> extends FetchPhases<TArgs, TResult, FetchContext>, FetchLifecycle {
    /** autorun name, for the MobX devtools/spy stream */
    name: string;
    /** how long to coalesce reruns once the body has started work once */
    delay: number;
    /**
     * An extra skip above `prepare`, reported as `gated` rather than `declined`:
     * the skeleton decided before the family's own gate was consulted, so it is
     * not the dead Retry the contract check hunts for. Must be a *tracked* read
     * that flips on the transition to wake on — a minimized track, a view that
     * is not initialized.
     */
    gate?: () => boolean;
    /**
     * The freshness signature of a run's args — the freshness gate, declared here
     * rather than folded into `prepare` because **the skeleton owns the half of it
     * that keeps being got wrong.**
     *
     * A run whose key equals the committed one declines, so a gate flip
     * (minimize→expand, a view initializing) re-runs nothing against unchanged
     * inputs. The law is ARCHITECTURE.md's: a gate on a freshness signal must
     * also be invalidated by `reload()`, or Retry re-runs the body straight into
     * the same decline and the button is dead. Every layer that has one made
     * that pairing structural in the end — the global family after arc shipped
     * the bug (`GlobalFetchMixin.reload` drops `loadedFetchSignature` in the same
     * action as the bump) — and this is that move for the skeleton: a run whose
     * `reloadCounter` has advanced since the run that last ISSUED a fetch ignores
     * this gate, so nothing has to remember to clear anything. The multi-way
     * synteny display's two dependent fetches shipped the same dead Retry from
     * spelling the comparison in `prepare` with no override to match, which is
     * what this exists to make unspellable.
     *
     * Separate from `prepare` because they answer different questions and only one
     * of them can strand a display: `prepare` returning `undefined` is "nothing to
     * fetch" (an empty viewport, no gene track configured), which is a legitimate
     * decline forever and no amount of retrying should change it. This is "I have
     * exactly this already", which a retry must be able to override.
     *
     * Omit it where the fetch holds no committed state to compare against — most
     * of them, whose `prepare` returns args unconditionally.
     */
    fetchKey?: (args: TArgs) => string;
    /**
     * The key of the data already committed, when the host keeps one — the
     * comparative displays stamp `loadedFetchKey`, which their `dataCurrent`
     * flag reads too, so a second stamp would be one more thing to disagree with
     * it. Omitted, the skeleton stamps its own at commit.
     *
     * **Either way the stamp is observable**, and the read is tracked. Zoom A→B
     * issues a fetch for B; zoom back to A before B commits and the re-run
     * declines against the still-A stamp; B then commits and stamps B, and that
     * write is what wakes the autorun to fetch A again. A closure variable would
     * leave data B under viewport A until the next input moved.
     */
    committedKey?: () => string | undefined;
    /**
     * Install the two display-contract checks under this name. Omitted
     * by a **secondary** fetch on a host whose primary foundation already
     * installed them: `assertDisplayContract` would report the second install as
     * the double-attach it is built to catch, and a second retry check would
     * consume the same `reloadCounter` bumps as the first.
     */
    contract?: string;
}
/**
 * The rotation half is either/or: `report` says where a rotation this installer
 * creates for itself reports, and `rotation` lends the host's own instead — a
 * display composing `FetchMixin` passes its `fetchRotation`, so `cancelFetch`
 * and `cancelFetchByUser` reach the fetch this installs rather than a second
 * rotation they cannot see. A lent rotation already carries its status window,
 * so `report` would be dead beside it — the same either/or `StatusReporter`
 * itself is a union for.
 */
export type InstallFetchOptions<TArgs, TResult> = InstallFetchOptionsBase<TArgs, TResult> & ({
    /**
     * Where this fetch's status lands. A display passes itself — its status
     * fields are part of its own API, and one composing `FetchMixin` lends
     * the model-wide window so this fetch takes a slot on the one field
     * beside the display's other operations rather than opening a second
     * writer over it. Anything with one operation to narrate passes a
     * `createStatusChannel`.
     */
    report: StatusReporter;
    rotation?: never;
} | {
    /** the host's own latest-wins rotation, lent whole — see above */
    rotation: StopTokenRotation;
    report?: never;
});
/**
 * A whole fetch, installed: the rotation, the leading-edge autorun, the
 * unconditional trigger reads, the gates, and {@link runFetchOnce} under them.
 *
 * Every fetch in the tree is this shape except one family — the prerequisite
 * reads (HiC's header, the multi-sample sample list), the LGV global family
 * (`installGlobalFetchAutorun`, which lends `FetchMixin`'s rotation through the
 * `rotation` option so `cancelFetch` reaches the fetch it installs), both
 * comparative displays, the circular view's chord fetch, the breakpoint overlay
 * fetch and the multi-way synteny display's two DEPENDENT fetches (lane genes,
 * lane links, each gated on the key its own commit stamps) all take it. The
 * exception is the per-region family's `FetchMixin.runFetch`: its trigger is
 * `planRegionFetch`'s autorun and its commits stream per region through
 * `ctx.commitRegion`, so it holds `runFetchOnce` directly and the autorun above
 * it is that foundation's.
 *
 * What a caller supplies is exactly what differs between them: which reads wake
 * it (`prepare`, plus `gate`), what a round trip commits, where the loading
 * flag lives (`onBegin` / `onEnd`) and where the status goes (`report`).
 *
 * Returns the rotation's `cancel`, for a family whose model owns the user-facing
 * Cancel button: the flag alone is not a cancel — nothing rotates the token, the
 * stopped RPC stays current, and it commits over the load the user just stopped.
 */
export declare function installFetch<TArgs, TResult>(self: FetchSkeletonHost, opts: InstallFetchOptions<TArgs, TResult>): () => void;
export {};
