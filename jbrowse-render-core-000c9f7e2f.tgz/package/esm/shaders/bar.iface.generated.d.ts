import type { VertexAttributeLayout, ShaderBinding } from '@jbrowse/render-core/hal';
export declare const BINDINGS: readonly ShaderBinding[];
export declare const VERTS_PER_INSTANCE = 6;
export declare const UNIFORMS_SIZE_BYTES = 32;
export declare const UNIFORM_OFFSET_F32: {
    readonly bpRangeX: 0;
    readonly zero: 3;
    readonly canvasWidth: 4;
    readonly canvasHeight: 5;
};
export declare const UNIFORM_OFFSET_U32: {
    readonly color: 6;
};
export interface Uniforms {
    bpRangeX: [number, number, number];
    zero: number;
    canvasWidth: number;
    canvasHeight: number;
    color: number;
}
export declare function writeUniforms(buf: ArrayBuffer, uniforms: Uniforms): void;
export declare const INSTANCE_STRIDE_BYTES = 12;
export declare const INSTANCE_STRIDE_WORDS = 3;
export declare const INSTANCE_OFFSET_F32: {
    readonly y: 2;
};
export declare const INSTANCE_OFFSET_U32: {
    readonly x: 0;
    readonly x2: 1;
};
export declare const VERTEX_ATTRIBUTES: readonly VertexAttributeLayout[];
export interface InstanceArrays {
    x: ArrayLike<number>;
    x2: ArrayLike<number>;
    y: ArrayLike<number>;
}
export declare function packInstances(arrays: InstanceArrays, numInstances: number, buf?: ArrayBuffer): ArrayBuffer;
export declare function getInstanceX(u32: Uint32Array, i: number): number;
export declare function setInstanceX(u32: Uint32Array, i: number, v: number): void;
export declare function getInstanceX2(u32: Uint32Array, i: number): number;
export declare function setInstanceX2(u32: Uint32Array, i: number, v: number): void;
export declare function getInstanceY(f32: Float32Array, i: number): number;
export declare function setInstanceY(f32: Float32Array, i: number, v: number): void;
