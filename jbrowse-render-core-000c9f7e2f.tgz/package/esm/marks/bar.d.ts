import * as shader from '../shaders/bar.generated.ts';
import type { BlockClipResult } from '../blockClipUtils.ts';
import type { ClipContext2D } from '../canvas2dUtils.ts';
import type { InstancePass } from '../instancePass.ts';
import type { RenderBlock } from '../renderBlock.ts';
export { shader as barShader };
/**
 * The `bar` shape's channels: a box from `x` to `x2` in absolute bp, `y` tall
 * as a fraction of the canvas height, grown up from the bottom. One value per
 * instance, read off the payload as parallel arrays.
 */
export interface BarEncoding<Payload> {
    x: (payload: Payload) => ArrayLike<number>;
    x2: (payload: Payload) => ArrayLike<number>;
    y: (payload: Payload) => ArrayLike<number>;
}
export interface BarFrame {
    canvasWidth: number;
    canvasHeight: number;
}
export interface BarContext2D extends ClipContext2D {
    fillStyle: string | CanvasGradient | CanvasPattern;
    fillRect(x: number, y: number, w: number, h: number): void;
}
export declare const BAR_PASS = "bar";
/** The pass that draws every bar of one region, packed from its channels. */
export declare function barPass<Payload>(encoding: BarEncoding<Payload>): InstancePass<Payload>;
/** The uniforms one clipped block draws its bars with; `color` is packed ABGR. */
export declare function barUniforms(block: RenderBlock, clip: BlockClipResult, frame: BarFrame & {
    color: number;
}): shader.Uniforms;
/**
 * The Canvas2D twin of the shader, and so also the SVG export. A sub-pixel
 * bar widens to 1px so it still paints, which is what `extendToMinWidthX`
 * does on the GPU side.
 */
export declare function paintBars<Payload>(ctx: BarContext2D, regions: ReadonlyMap<number, Payload>, blocks: RenderBlock[], frame: BarFrame & {
    color: string;
}, encoding: BarEncoding<Payload>): void;
