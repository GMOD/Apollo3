import type { LegendItem, LegendSection } from '@jbrowse/core/ui/legendSpec';
export type { LegendItem, LegendMark, LegendSection, LegendSpec, LegendSwatch, } from '@jbrowse/core/ui/legendSpec';
declare const FloatingLegend: ({ items, sections, title, onDismiss, onDismissSection, onItemClick, maxItems, maxWidth, top, }: {
    items?: LegendItem[];
    sections?: LegendSection[];
    title?: string;
    onDismiss?: () => void;
    onDismissSection?: (id: string) => void;
    onItemClick?: (item: LegendItem, section: LegendSection) => void;
    maxItems?: number;
    maxWidth?: number;
    top?: number;
}) => import("react").JSX.Element | null;
export default FloatingLegend;
