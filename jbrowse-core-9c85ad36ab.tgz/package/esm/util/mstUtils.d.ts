import type PluginManager from '../PluginManager.ts';
import type { AbstractDisplayModel, AbstractSessionModel, AbstractTrackModel, AbstractViewModel, TypeTestedByPredicate } from './types/index.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function findParentThat(node: IAnyStateTreeNode, predicate: (thing: IAnyStateTreeNode) => boolean): import("@jbrowse/mobx-state-tree").IStateTreeNode<IAnyStateTreeNode> | (object & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IAnyComplexType>);
export declare function findParentThatIs<T extends (a: IAnyStateTreeNode) => boolean>(node: IAnyStateTreeNode, predicate: T): TypeTestedByPredicate<T>;
/**
 * #api core/util
 * Returns the JBrowse session model for any node in the state tree. Throws if
 * the node has no session ancestor.
 */
export declare function getSession(node: IAnyStateTreeNode): AbstractSessionModel;
/**
 * #api core/util
 * Returns the view model that contains the given node. Throws if the node has no
 * containing view.
 */
export declare function getContainingView(node: IAnyStateTreeNode): AbstractViewModel;
/**
 * #api core/util
 * Returns the track model that contains the given node. Throws if the node has
 * no containing track.
 */
export declare function getContainingTrack(node: IAnyStateTreeNode): AbstractTrackModel;
/**
 * #api core/util
 * Returns the display model that contains the given node. Throws if the node has
 * no containing display.
 */
export declare function getContainingDisplay(node: IAnyStateTreeNode): AbstractDisplayModel;
/**
 * #api core/util
 * Resolve user-authored refName text against the assembly of the view
 * containing `node` — the one normalization layer, which resolves aliases and
 * casing together. Falls back to the input when the assembly is absent or its
 * aliases have not loaded.
 *
 * Keyed off the VIEW's assembly rather than the track's, because the view is
 * what the comparison is against: displayed regions, loaded regions and blocks
 * all carry the refNames the view laid out.
 *
 * Reach for this wherever a refName a *person* wrote is about to be compared
 * against regions, features or blocks, which carry the assembly's canonical
 * name. A refName a display copied off a region is canonical already and needs
 * nothing; one that arrived in a session spec, a config slot or a URL is
 * whatever the author read out of the location box.
 *
 * Skipping it fails silently and, worse, assembly-dependently: `chr12` matches
 * on an assembly canonicalized `chr12` and matches nothing on one canonicalized
 * `12`, so the same spec key works on one config and quietly does nothing on
 * the next, with no error for anyone to act on.
 *
 * `initialized` gates the call rather than a try/catch, because
 * `getCanonicalRefName` THROWS before the alias file has loaded — and the
 * getters that read user specs run from the first render.
 */
export declare function canonicalizeViewRefName(node: IAnyStateTreeNode, refName: string): string;
/**
 * #api core/util
 * Returns the MST environment for a node, which carries the `pluginManager`.
 */
export declare function getEnv(obj: IAnyStateTreeNode): {
    pluginManager: PluginManager;
};
export declare function hashCode(str: string): number;
export declare function objectHash(obj: object): string;
