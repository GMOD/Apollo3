export interface GuardedStorage {
    /**
     * Whether there is a store to persist to at all — the first two failures
     * above, both of which are decided once for the page.
     *
     * Every accessor is safe without asking; what this answers is the different
     * question of whether persistence is *real*. With no store, a write is
     * dropped and the matching read answers the default, so a caller that
     * round-trips a value through a key (rather than merely saving one) has to
     * know, or it reads back its own default and calls it the stored value.
     */
    available: () => boolean;
    /** The raw string stored at `key`, or undefined if absent or unreadable. */
    getItem: (key: string) => string | undefined;
    /**
     * Returns whether the store took the value. Nearly every caller ignores that
     * — a setting that could not be persisted is not worth interrupting anyone
     * over — but a caller that reads the key back to learn the current value
     * needs to know that the read will not reflect this write.
     */
    setItem: (key: string, value: string) => boolean;
    /** Returns whether the store took the removal; see {@link setItem}. */
    removeItem: (key: string) => boolean;
}
export declare const guardedLocalStorage: GuardedStorage;
export declare const guardedSessionStorage: GuardedStorage;
