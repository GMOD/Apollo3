import QuickLRU from '../util/QuickLRU/index.ts';
import type PluginManager from '../PluginManager.ts';
import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
import type RpcManager from '../rpc/RpcManager.ts';
import type { Feature, Region } from '../util/index.ts';
import type { RpcStatus } from '../util/progress.ts';
import type { RefNameAliases, RefNameMaps } from './refNameMaps.ts';
import type { IAnyType, Instance } from '@jbrowse/mobx-state-tree';
export { getSequenceAdapterConfig } from './getSequenceAdapterConfig.ts';
export { buildRefNameMaps } from './refNameMaps.ts';
export { lookupGeneticCodeId } from './geneticCodes.ts';
export type { RefNameAliases, RefNameMaps } from './refNameMaps.ts';
type AdapterConf = Record<string, unknown>;
export interface BasicRegion {
    start: number;
    end: number;
    refName: string;
    assemblyName: string;
}
/**
 * #stateModel Assembly
 */
export default function assemblyFactory(assemblyConfigType: IAnyType, pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
}, {
    /**
     * #volatile
     */
    error: unknown;
    /**
     * #volatile
     */
    loadingP: Promise<void> | undefined;
    adapterLoads: QuickLRU<string, Promise<RefNameAliases>>;
    /**
     * #volatile
     */
    volatileRegions: BasicRegion[] | undefined;
    /**
     * #volatile
     */
    refNameAliases: RefNameAliases | undefined;
    /**
     * #volatile
     * Maps canonical refName -> sequence adapter refName (in FASTA).
     * These may differ when refNameAliases with override:true remap names.
     */
    canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
    /**
     * #volatile
     */
    cytobands: Feature[] | undefined;
    /**
     * #volatile
     * refName -> NCBI genetic-code id loaded from `geneticCodesLocation`;
     * merged with (and overridden by) the inline `geneticCodes` config slot
     */
    loadedGeneticCodes: Record<string, number> | undefined;
    /**
     * #volatile
     * Precomputed in loadPre to avoid expensive synchronous computation
     * when MobX triggers the autorun after setLoaded
     */
    lowerCaseRefNameAliases: RefNameAliases | undefined;
    /**
     * #volatile
     * What the in-flight load is doing ("Downloading chromosome sizes"), for a
     * view that is showing a spinner while it waits. Same split as
     * BaseDisplayModel's status fields, so the same LoadingProgress UI
     * renders both.
     */
    statusMessage: string | undefined;
    /**
     * #volatile
     * Fraction in [0,1] when the load reports determinate progress
     */
    statusProgress: number | undefined;
} & {
    /**
     * #method
     */
    getConf(arg: string): any;
} & {
    /**
     * #getter
     */
    readonly name: string;
    /**
     * #getter
     */
    readonly aliases: string[];
    /**
     * #getter
     */
    readonly displayName: string;
    /**
     * #getter
     */
    readonly refNameColors: string[];
} & {
    /**
     * #getter
     */
    readonly allAliases: string[];
    /**
     * #method
     */
    hasName(name: string): boolean;
} & {
    /**
     * #action
     * Records what the in-flight load is doing. Its own actions block (rather
     * than sitting next to setLoaded) so loadPre can hand `self.setStatus` to
     * the adapters as a plain callback: it fires after awaits, outside the
     * action that started the load, and a volatile write there has to go
     * through an action of its own.
     */
    setStatus(status?: RpcStatus): void;
} & {
    /**
     * #action
     * Applies all load-time state in a single transaction so dependent
     * autoruns fire once, with the precomputed lowercase/name lookups already
     * in place by the time refNameAliases becomes observable.
     */
    setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: RefNameMaps & {
        regions: Region[];
        cytobands: Feature[];
        geneticCodes: Record<string, number>;
    }): void;
    /**
     * #action
     */
    setError(e: unknown): void;
    /**
     * #action
     */
    setLoadingP(p?: Promise<void>): void;
    /**
     * #action
     */
    loadPre(): Promise<void>;
} & {
    /**
     * #action
     * Resolves once regions + refNameAliases are set, and rejects with the
     * load failure. Idempotent: concurrent callers share one attempt, and a
     * failed attempt is discarded so the next call retries.
     *
     * The rejection is the authoritative signal for a caller that awaits it.
     * `self.error` mirrors it for reactive consumers only (the UI renders it),
     * and must not be consulted after an await: a concurrent retry clears it,
     * so an awaiter reading it can see a cleared error and mistake a failed
     * load for a successful one.
     */
    load(): Promise<void>;
} & {
    afterAttach(): void;
} & {
    /**
     * #getter
     */
    readonly initialized: boolean;
    /**
     * #getter
     */
    readonly regions: BasicRegion[] | undefined;
    /**
     * #getter
     * note: lowerCaseRefNameAliases not included here: this allows the list
     * of refnames to be just the "normal casing", but things like
     * getCanonicalRefName can resolve a lower-case name if needed
     */
    readonly allRefNames: string[] | undefined;
    /**
     * #getter
     */
    readonly rpcManager: RpcManager;
} & {
    /**
     * #getter
     */
    readonly refNames: string[] | undefined;
} & {
    /**
     * #getter
     * memoized refName -> first region index, so getRefNameColor is O(1)
     * instead of an O(n) indexOf per call (matters for assemblies with many
     * contigs rendered in overview scalebars/rulers)
     */
    readonly refNameToIndex: Map<string, number> | undefined;
} & {
    /**
     * #method
     * Returns the canonical refName for a given alias or refName.
     * Note: The canonical name may differ from what's in the FASTA file when
     * refNameAliases with override:true are configured. To get the name that
     * matches the FASTA file, use getSeqAdapterRefName().
     */
    getCanonicalRefName(refName: string): string | undefined;
    /**
     * #method
     */
    getRefNameColor(refName: string): string | undefined;
    /**
     * #method
     * NCBI genetic-code (translation table) id for a refName, from the
     * assembly's `geneticCodes` config map (e.g. a mitochondrial contig = 2).
     * Falls back to the standard code (1) for unlisted refNames.
     */
    getGeneticCodeId(refName: string): number;
    /**
     * #method
     * Given a canonical refName, returns the refName used by the sequence
     * adapter (what's in the FASTA file). Falls back to the input if no
     * mapping exists.
     */
    getSeqAdapterRefName(canonicalRefName: string): string;
} & {
    /**
     * #method
     * Returns canonical refName, falling back to input if not found.
     * See getCanonicalRefName() for details.
     */
    getCanonicalRefName2(refName: string): string;
    /**
     * #method
     */
    isValidRefName(refName: string): boolean;
} & {
    /**
     * #method
     * get Map of `canonical-name -> adapter-specific-name`, memoized per
     * adapter config so concurrent callers share one load
     *
     * The load reports progress (the adapter's index download, or for an
     * in-memory adapter the whole file) through the `statusCallback` of
     * whichever caller started it. The others await it silently, and that is
     * deliberate rather than a gap worth plumbing around: the callers sharing
     * an entry are almost always the N displayed regions of ONE display, so
     * their callbacks all write into that display's aggregated status bar and
     * the first one is already reporting on behalf of the rest. The costs of
     * getting this "right" — a listener set per key, registration, and
     * deregistration on settle — buy visibility only for a second display on
     * the same file, and for a first caller torn down mid-load, which is a
     * no-op rather than a hazard because the callbacks are `isAlive`-guarded
     * at the display end.
     *
     * If that ever stops being enough, the fix is not a subscription list
     * bolted on here: it is for the assembly to hold the in-flight status as
     * observable state that consumers read, which is what this model is
     * already made of.
     */
    getRefNameMapForAdapter(adapterConf: AdapterConf, options: BaseOptions): Promise<RefNameAliases>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type AssemblyModel = ReturnType<typeof assemblyFactory>;
export type Assembly = Instance<AssemblyModel>;
