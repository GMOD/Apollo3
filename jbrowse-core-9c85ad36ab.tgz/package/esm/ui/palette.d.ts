/** A resolved color and the three shades MUI-shaped consumers expect. */
export interface ColorQuad {
    main: string;
    light: string;
    dark: string;
    contrastText: string;
}
/**
 * What a theme may supply for an augmentable color: a bare CSS string, a
 * `{ main }` object, or a full MUI-style shade map (`{ 300, 500, 700 }`).
 */
export type ColorInput = string | ShadeInput;
export interface ShadeInput {
    main?: string;
    light?: string;
    dark?: string;
    contrastText?: string;
    300?: string;
    500?: string;
    700?: string;
}
/**
 * `[null, f1, f2, f3, f-3, f-2, f-1]`. Slot 0 is unused so positive frames read
 * as `.at(1/2/3)` and negative frames fall out of JS negative-index semantics.
 */
export type FrameTuple<T> = [
    null,
    T | undefined,
    T | undefined,
    T | undefined,
    T | undefined,
    T | undefined,
    T | undefined
];
export type BaseKey = 'A' | 'C' | 'G' | 'T' | 'N';
export interface AlignmentFill {
    /** LR (→ ←): a normal, concordant proper pair */
    pairLR: string;
    /** RL (← →): mates point away from each other */
    pairRL: string;
    /** LL (→ →): both mates on the forward strand */
    pairLL: string;
    /** RR (← ←): both mates on the reverse strand */
    pairRR: string;
}
export declare function lighten(color: string, coefficient: number): string;
export declare function darken(color: string, coefficient: number): string;
/** Restate a color at a given opacity, as `rgba(r, g, b, a)`. */
export declare function alpha(color: string, value: number): string;
/** WCAG relative luminance, truncated to three digits the way MUI does. */
export declare function getLuminance(color: string): number;
export declare function getContrastRatio(foreground: string, background: string): number;
export declare function getContrastText(background: string): "#fff" | "rgba(0, 0, 0, 0.87)";
/**
 * Expand a color into its four shades. A shade map supplies `light`/`dark`
 * directly from its 300/700 entries, anything else derives them by tonal
 * offset, and `contrastText` is chosen by contrast ratio against `main`.
 */
export declare function augmentColor(input: ColorInput): ColorQuad;
export declare const grey: {
    50: string;
    100: string;
    200: string;
    300: string;
    400: string;
    500: string;
    600: string;
    700: string;
    800: string;
    900: string;
};
export interface NeutralTokens {
    text: {
        primary: string;
        secondary: string;
        disabled: string;
    };
    background: {
        paper: string;
        default: string;
    };
    divider: string;
    common: {
        black: string;
        white: string;
    };
    grey: typeof grey;
    action: {
        active: string;
        hover: string;
        hoverOpacity: number;
        selected: string;
        selectedOpacity: number;
        disabled: string;
        disabledBackground: string;
        disabledOpacity: number;
        focus: string;
        focusOpacity: number;
        activatedOpacity: number;
    };
}
/**
 * The four states a UI conveys with color rather than with words. Not domain
 * colors — nothing renders a feature in `warning.main` — but the styling
 * layer's, and JBrowse's own rather than borrowed from Material UI at read
 * time, for the same reason every other color here is.
 */
export interface SemanticColors {
    error: ColorQuad;
    warning: ColorQuad;
    info: ColorQuad;
    success: ColorQuad;
}
export declare const colorFwdStrandNotProper = "#ECC8C8";
export declare const colorRevStrandNotProper = "#BEBED8";
/** #color alignments-strand | Forward strand | Read maps to the forward strand */
export declare const colorFwdStrand = "#EC8B8B";
/** #color alignments-strand | Reverse strand | Read maps to the reverse strand */
export declare const colorRevStrand = "#8F8FD8";
export declare const colorFwdMissingMate = "#D11919";
export declare const colorRevMissingMate = "#1919D1";
export declare const colorFwdDiffChr = "#000";
export declare const colorRevDiffChr = "#969696";
/** #color alignments-pair-orientation | LR (→ ←, normal proper pair) | Concordant */
export declare const colorPairLR = "#d3d3d3";
export declare const colorPairLRDark = "#8a8a8a";
/** #color alignments-pair-orientation | RL (← →, mates point away from each other) | Abnormal orientation */
export declare const colorPairRL = "#0099bb";
/** #color alignments-pair-orientation | LL (→ →, both mates forward strand) | Abnormal orientation */
export declare const colorPairLL = "#4d9a4d";
/** #color alignments-pair-orientation | RR (← ←, both mates reverse strand) | Abnormal orientation */
export declare const colorPairRR = "#5555bb";
export declare const colorNostrand = "#c8c8c8";
/**
 * #color alignments-pair-orientation | Inter-chromosomal | Mate maps to a different chromosome; colored distinctly rather than by orientation
 * #color alignments-insert-size | Mate on a different chromosome | Suggests an inter-chromosomal event
 */
export declare const colorInterchrom = "#6e4b3a";
/** #color alignments-insert-size | Insert larger than expected | Suggests a deletion spanning the pair */
export declare const colorLongInsert = "#ff0000";
/** #color alignments-insert-size | Insert smaller than expected | Suggests an insertion between the pair */
export declare const colorShortInsert = "#f582c0";
export declare const colorUnmappedMate = "#b05a20";
export declare const colorUnknown = "#808080";
export declare const colorLongreadRevFwd = "#6688ee";
export declare const colorLongreadInv = "#7755bb";
/** #color alignments-pair-orientation | Split paired-end read (inverted) | A paired read's supplementary segment maps opposite-strand to its primary, so the junction is inverted — an inversion or an inverted duplication */
export declare const colorSplitReadInversion = "#9b30b0";
export declare const colorSupplementary = "#f0b878";
export declare const tagColorPalette: string[];
/**
 * #color theme-colors | Feature (default) | A feature with no color of its own — no `color` slot, no BED itemRgb
 *
 * What an uncolored feature is painted. Lives here rather than in the display
 * that draws most of them because it is not one display's default: the
 * single-feature variant display resolves it through `plugins/canvas`, and the
 * multi-sample variant display's lane bakes it into the color array its worker
 * ships. Two copies of a color two displays are supposed to agree on is exactly
 * the "never a fallback copy" this module exists to prevent.
 */
export declare const featureDefaultColor = "goldenrod";
/** #color theme-methylation | methylated5mC | 5-methylcytosine, methylated */
export declare const methylated5mC = "#ff0000";
/** #color theme-methylation | unmethylated5mC | 5-methylcytosine, unmethylated */
export declare const unmethylated5mC = "#0000ff";
/** #color theme-methylation | methylated5hmC | 5-hydroxymethylcytosine, methylated */
export declare const methylated5hmC = "#ffc0cb";
/** Plain string colors that a theme may override wholesale. */
export interface StringColors {
    /** Stop codon in gene/CDS tracks */
    stopCodon: string;
    /** Start codon in gene/CDS tracks */
    startCodon: string;
    /** MAF codon view: the species' amino acid differs from the reference */
    codonNonsynonymous: string;
    /** MAF codon view: the codon differs but the amino acid does not */
    codonSynonymous: string;
    /** MAF codon view: a stop codon */
    codonStop: string;
    /** Coverage histogram fill */
    coverage: string;
    /** Insertion markers in alignments */
    insertion: string;
    /** Soft-clipped bases (clipped bases retained in the read) */
    softclip: string;
    /** Skipped regions, such as introns in RNA-seq reads */
    skip: string;
    /** Hard-clipped bases (clipped bases removed from the read) */
    hardclip: string;
    /** Deletion markers in alignments */
    deletion: string;
    /** Base modifications on the forward strand */
    modificationFwd: string;
    /** Base modifications on the reverse strand */
    modificationRev: string;
    /** SNP bases muted when show-modifications coloring is on */
    mutedSnpBase: string;
    /** MAF bridged-row fill where a species has no alignment */
    missingData: string;
    /** Minor vertical gridlines behind the genome */
    gridlineMinor: string;
    /** Major vertical gridlines behind the genome */
    gridlineMajor: string;
    /** Hover shading over a single feature */
    featureHover: string;
    /** Hover shading over a feature group, e.g. a linked-read chain */
    featureHoverStrong: string;
    /** Border accent around the click-selected feature */
    featureSelected: string;
    /** Feature description labels, e.g. gene descriptions */
    featureDescription: string;
}
/**
 * Every color JBrowse renders, resolved. Plain strings throughout, so this
 * crosses the RPC worker boundary as itself rather than as arguments something
 * on the far side has to rebuild.
 */
export interface JBrowsePalette extends StringColors, NeutralTokens, SemanticColors {
    mode: 'light' | 'dark';
    primary: ColorQuad;
    secondary: ColorQuad;
    tertiary: ColorQuad;
    quaternary: ColorQuad;
    highlight: ColorQuad;
    textHighlight: ColorQuad;
    bases: Record<BaseKey, ColorQuad>;
    frames: FrameTuple<ColorQuad>;
    framesCDS: FrameTuple<ColorQuad>;
    alignmentFill: AlignmentFill;
}
/**
 * The palette half of what a theme may declare. Structurally compatible with
 * MUI's `PaletteOptions`, which is what the config `theme` slot carries, so a
 * config theme is assignable here without a cast.
 */
export interface PaletteInput extends Partial<StringColors> {
    mode?: 'light' | 'dark';
    primary?: ShadeInput;
    secondary?: ShadeInput;
    tertiary?: ShadeInput;
    quaternary?: ShadeInput;
    highlight?: ShadeInput;
    textHighlight?: ShadeInput;
    error?: ShadeInput;
    warning?: ShadeInput;
    info?: ShadeInput;
    success?: ShadeInput;
    bases?: Partial<Record<BaseKey, ShadeInput>>;
    frames?: FrameTuple<ShadeInput>;
    framesCDS?: FrameTuple<ShadeInput>;
    alignmentFill?: Partial<AlignmentFill>;
    text?: Partial<NeutralTokens['text']>;
    background?: Partial<NeutralTokens['background']>;
    divider?: string;
    common?: Partial<NeutralTokens['common']>;
    grey?: Partial<NeutralTokens['grey']>;
    action?: Partial<NeutralTokens['action']>;
}
/** A theme, as far as the palette is concerned. */
export interface ThemeInput {
    palette?: PaletteInput;
}
export declare const palettePresets: {
    default: {
        stopCodon?: string | undefined;
        startCodon?: string | undefined;
        codonNonsynonymous?: string | undefined;
        codonSynonymous?: string | undefined;
        codonStop?: string | undefined;
        coverage?: string | undefined;
        insertion?: string | undefined;
        softclip?: string | undefined;
        skip?: string | undefined;
        hardclip?: string | undefined;
        deletion?: string | undefined;
        modificationFwd?: string | undefined;
        modificationRev?: string | undefined;
        mutedSnpBase?: string | undefined;
        missingData?: string | undefined;
        gridlineMinor?: string | undefined;
        gridlineMajor?: string | undefined;
        featureHover?: string | undefined;
        featureHoverStrong?: string | undefined;
        featureSelected?: string | undefined;
        featureDescription?: string | undefined;
        mode?: 'light' | 'dark';
        primary?: ShadeInput;
        secondary?: ShadeInput;
        tertiary?: ShadeInput;
        quaternary?: ShadeInput;
        highlight?: ShadeInput;
        textHighlight?: ShadeInput;
        error?: ShadeInput;
        warning?: ShadeInput;
        info?: ShadeInput;
        success?: ShadeInput;
        bases?: Partial<Record<BaseKey, ShadeInput>>;
        frames?: FrameTuple<ShadeInput>;
        framesCDS?: FrameTuple<ShadeInput>;
        alignmentFill?: Partial<AlignmentFill>;
        text?: Partial<NeutralTokens['text']>;
        background?: Partial<NeutralTokens['background']>;
        divider?: string;
        common?: Partial<NeutralTokens['common']>;
        grey?: Partial<NeutralTokens['grey']>;
        action?: Partial<NeutralTokens['action']>;
    };
    lightStock: {
        stopCodon?: string | undefined;
        startCodon?: string | undefined;
        codonNonsynonymous?: string | undefined;
        codonSynonymous?: string | undefined;
        codonStop?: string | undefined;
        coverage?: string | undefined;
        insertion?: string | undefined;
        softclip?: string | undefined;
        skip?: string | undefined;
        hardclip?: string | undefined;
        deletion?: string | undefined;
        modificationFwd?: string | undefined;
        modificationRev?: string | undefined;
        mutedSnpBase?: string | undefined;
        missingData?: string | undefined;
        gridlineMinor?: string | undefined;
        gridlineMajor?: string | undefined;
        featureHover?: string | undefined;
        featureHoverStrong?: string | undefined;
        featureSelected?: string | undefined;
        featureDescription?: string | undefined;
        mode?: 'light' | 'dark';
        primary?: ShadeInput;
        secondary?: ShadeInput;
        tertiary?: ShadeInput;
        quaternary?: ShadeInput;
        highlight?: ShadeInput;
        textHighlight?: ShadeInput;
        error?: ShadeInput;
        warning?: ShadeInput;
        info?: ShadeInput;
        success?: ShadeInput;
        bases?: Partial<Record<BaseKey, ShadeInput>>;
        frames?: FrameTuple<ShadeInput>;
        framesCDS?: FrameTuple<ShadeInput>;
        alignmentFill?: Partial<AlignmentFill>;
        text?: Partial<NeutralTokens['text']>;
        background?: Partial<NeutralTokens['background']>;
        divider?: string;
        common?: Partial<NeutralTokens['common']>;
        grey?: Partial<NeutralTokens['grey']>;
        action?: Partial<NeutralTokens['action']>;
    };
    lightMinimal: {
        stopCodon?: string | undefined;
        startCodon?: string | undefined;
        codonNonsynonymous?: string | undefined;
        codonSynonymous?: string | undefined;
        codonStop?: string | undefined;
        coverage?: string | undefined;
        insertion?: string | undefined;
        softclip?: string | undefined;
        skip?: string | undefined;
        hardclip?: string | undefined;
        deletion?: string | undefined;
        modificationFwd?: string | undefined;
        modificationRev?: string | undefined;
        mutedSnpBase?: string | undefined;
        missingData?: string | undefined;
        gridlineMinor?: string | undefined;
        gridlineMajor?: string | undefined;
        featureHover?: string | undefined;
        featureHoverStrong?: string | undefined;
        featureSelected?: string | undefined;
        featureDescription?: string | undefined;
        mode?: 'light' | 'dark';
        quaternary?: ShadeInput;
        highlight?: ShadeInput;
        textHighlight?: ShadeInput;
        error?: ShadeInput;
        warning?: ShadeInput;
        info?: ShadeInput;
        success?: ShadeInput;
        bases?: Partial<Record<BaseKey, ShadeInput>>;
        frames?: FrameTuple<ShadeInput>;
        framesCDS?: FrameTuple<ShadeInput>;
        alignmentFill?: Partial<AlignmentFill>;
        text?: Partial<NeutralTokens['text']>;
        background?: Partial<NeutralTokens['background']>;
        divider?: string;
        common?: Partial<NeutralTokens['common']>;
        grey?: Partial<NeutralTokens['grey']>;
        action?: Partial<NeutralTokens['action']>;
        primary: {
            main: string;
        };
        secondary: {
            main: string;
        };
        tertiary: {
            main: string;
        };
    };
    darkMinimal: {
        stopCodon?: string | undefined;
        startCodon?: string | undefined;
        codonNonsynonymous?: string | undefined;
        codonSynonymous?: string | undefined;
        codonStop?: string | undefined;
        coverage?: string | undefined;
        insertion?: string | undefined;
        softclip?: string | undefined;
        skip?: string | undefined;
        hardclip?: string | undefined;
        deletion?: string | undefined;
        modificationFwd?: string | undefined;
        modificationRev?: string | undefined;
        mutedSnpBase?: string | undefined;
        missingData?: string | undefined;
        gridlineMinor?: string | undefined;
        gridlineMajor?: string | undefined;
        featureHover?: string | undefined;
        featureHoverStrong?: string | undefined;
        featureSelected?: string | undefined;
        featureDescription?: string | undefined;
        quaternary?: ShadeInput;
        highlight?: ShadeInput;
        textHighlight?: ShadeInput;
        error?: ShadeInput;
        warning?: ShadeInput;
        info?: ShadeInput;
        success?: ShadeInput;
        bases?: Partial<Record<BaseKey, ShadeInput>>;
        frames?: FrameTuple<ShadeInput>;
        framesCDS?: FrameTuple<ShadeInput>;
        alignmentFill?: Partial<AlignmentFill>;
        text?: Partial<NeutralTokens['text']>;
        background?: Partial<NeutralTokens['background']>;
        divider?: string;
        common?: Partial<NeutralTokens['common']>;
        grey?: Partial<NeutralTokens['grey']>;
        action?: Partial<NeutralTokens['action']>;
        mode: "dark";
        primary: {
            main: string;
        };
        secondary: {
            main: string;
        };
        tertiary: {
            main: string;
        };
    };
    darkStock: {
        stopCodon?: string | undefined;
        startCodon?: string | undefined;
        codonNonsynonymous?: string | undefined;
        codonSynonymous?: string | undefined;
        codonStop?: string | undefined;
        coverage?: string | undefined;
        insertion?: string | undefined;
        softclip?: string | undefined;
        skip?: string | undefined;
        hardclip?: string | undefined;
        deletion?: string | undefined;
        modificationFwd?: string | undefined;
        modificationRev?: string | undefined;
        mutedSnpBase?: string | undefined;
        missingData?: string | undefined;
        gridlineMinor?: string | undefined;
        gridlineMajor?: string | undefined;
        featureHover?: string | undefined;
        featureHoverStrong?: string | undefined;
        featureSelected?: string | undefined;
        featureDescription?: string | undefined;
        primary?: ShadeInput;
        secondary?: ShadeInput;
        tertiary?: ShadeInput;
        quaternary?: ShadeInput;
        highlight?: ShadeInput;
        textHighlight?: ShadeInput;
        error?: ShadeInput;
        warning?: ShadeInput;
        info?: ShadeInput;
        success?: ShadeInput;
        bases?: Partial<Record<BaseKey, ShadeInput>>;
        frames?: FrameTuple<ShadeInput>;
        framesCDS?: FrameTuple<ShadeInput>;
        alignmentFill?: Partial<AlignmentFill>;
        text?: Partial<NeutralTokens['text']>;
        background?: Partial<NeutralTokens['background']>;
        divider?: string;
        common?: Partial<NeutralTokens['common']>;
        grey?: Partial<NeutralTokens['grey']>;
        action?: Partial<NeutralTokens['action']>;
        mode: "dark";
    };
};
/**
 * What `resolvePalette` reads. Structurally the minimum of the public
 * `SerializableThemeArgs` (declared in `theme.ts`, where the MUI `ThemeOptions`
 * type is available), so a caller passes the public type straight in and this
 * module still imports no toolkit.
 */
export interface PaletteArgs {
    configTheme?: ThemeInput;
    themeName?: string;
    extraThemes?: Record<string, ThemeInput>;
}
/**
 * Build the palette for a set of theme arguments.
 *
 * Only the `default` theme draws from `configTheme`. Every other named theme is
 * a fixed preset and intentionally ignores it, which is what the picker entry
 * "Default (from config)" means. Do not "fix" that.
 */
export declare function resolvePalette(args?: PaletteArgs): JBrowsePalette;
