import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
export interface SettingRowOptions {
    helpText?: string;
    subLabel?: string;
    disabled?: boolean;
    disabledHelpText?: string;
    keepMenuOpen?: boolean;
}
/** #menuBuilder checkboxItem | one checkbox setting row */
export declare function checkboxItem(label: string, checked: boolean, onToggle: () => void, opts?: SettingRowOptions): CheckboxMenuItem;
/** #menuBuilder radioItem | one radio setting row; the singular of `radioItems` */
export declare function radioItem(label: string, checked: boolean, onClick: () => void, opts?: SettingRowOptions): RadioMenuItem;
export interface RadioOption<T extends string> {
    value: T;
    label: string;
    subLabel?: string;
    helpText?: string;
}
/** #menuBuilder radioItems | a radio group, one row per option */
export declare function radioItems<T extends string>(options: readonly RadioOption<T>[], current: T | undefined, setMode: (m: T) => void): RadioMenuItem[];
