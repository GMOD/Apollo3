import { RemoteFileWithRangeCache } from '../../util/io/index.ts';
import type { AnyReactComponentType, UriLocation } from '../../util/types/index.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type React from 'react';
/**
 * #stateModel BaseInternetAccountModel
 * #category internetAccount
 */
export declare const InternetAccount: import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    /**
     * #property
     */
    configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
}, {
    /**
     * #getter
     */
    readonly name: string;
    /**
     * #getter
     */
    readonly description: string;
    /**
     * #getter
     */
    readonly internetAccountId: string;
    /**
     * #getter
     */
    readonly authHeader: string;
    /**
     * #getter
     */
    readonly tokenType: string;
    /**
     * #getter
     */
    readonly domains: string[];
    /**
     * #getter
     * Can use this to customize what is displayed in fileSelector's toggle box
     */
    readonly toggleContents: React.ReactNode;
    /**
     * #getter
     * Can use this to customize what the fileSelector. It takes a prop called
     * `setLocation` that should be used to set a UriLocation
     */
    readonly SelectorComponent: AnyReactComponentType | undefined;
    /**
     * #getter
     * Can use this to add a label to the UrlChooser. Has no effect if a custom
     * SelectorComponent is supplied
     */
    readonly selectorLabel: string | undefined;
    /**
     * #getter
     * Whether the fileSelector offers this account as a source to pick. Turn it
     * off for an account that only ever matches by domain and has nothing of
     * its own to enter — HTTP Basic, whose ephemeral per-origin accounts would
     * otherwise pile up as toggles nobody asked for.
     */
    readonly showInFileSelector: boolean;
} & {
    /**
     * #method
     * Determine whether this internetAccount provides credentials for a URL
     * @param location  - UriLocation of resource
     * @returns true or false
     */
    handlesLocation(location: UriLocation): boolean;
    /**
     * #getter
     * The key used to store this internetAccount's token in sessionStorage
     */
    readonly tokenKey: string;
} & {
    /**
     * #action
     * Must be implemented by a model extending or composing this one. Pass the
     * user's token to `resolve`.
     * @param resolve - Pass the token to this function
     * @param reject - If there is an error getting the token, call this function
     */
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    /**
     * #action
     */
    storeToken(token: string): void;
    /**
     * #action
     */
    retrieveToken(): string | undefined;
    /**
     * #action
     * This can be used by an internetAccount to validate a token works before
     * it is used. This is run when preAuthorizationInformation is requested,
     * so it can be used to check that a token is valid before sending it to a
     * worker thread. It expects the token to be returned so that this action
     * can also be used to generate a new token (e.g. by using a refresh token)
     * if the original one was invalid. Should throw an error if a token is
     * invalid.
     *
     * @param token - Auth token
     * @param loc - UriLocation of the resource
     * @returns - Valid auth token
     */
    validateToken(token: string, _loc: UriLocation): Promise<string>;
} & {
    /**
     * #action
     * Clears the stored token. Also drops the in-memory cached promise so a
     * subsequent `getToken` re-prompts / re-derives rather than handing back
     * the token that was just invalidated.
     */
    removeToken(): void;
    /**
     * #action
     * Try to get the token from the location pre-auth, from local storage,
     * or from a previously cached promise. If token is not available, uses
     * `getTokenFromUser`.
     *
     * @param location - UriLocation of the resource
     * @returns A promise for the token
     */
    getToken(location?: UriLocation): Promise<string>;
} & {
    /**
     * #action
     */
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    /**
     * #action
     * Run a request with the current token and, only if it comes back 401, put
     * the token through `validateToken` and run it exactly once more. This is
     * how every account's fetcher reaches a resource.
     *
     * @param loc - UriLocation of the resource
     * @param run - issues the request with a given token
     */
    fetchWithToken(loc: UriLocation | undefined, run: (token: string) => Promise<Response>): Promise<Response>;
    /**
     * #action
     * Gets the token and returns it along with the information needed to
     * create a new internetAccount.
     *
     * @param location - UriLocation of the resource
     * @returns
     */
    getPreAuthorizationInformation(location: UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        };
    }>;
} & {
    /**
     * #action
     * Get a fetch method that will add any needed authentication headers to
     * the request before sending it. If location is provided, it will be
     * checked to see if it includes a token in it pre-auth information.
     *
     * @param loc - UriLocation of the resource
     * @returns A function that can be used to fetch
     */
    getFetcher(loc?: UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    /**
     * #action
     * Gets a filehandle that uses a fetch that adds auth headers
     * @param location - UriLocation of the resource
     * @returns A filehandle
     */
    openLocation(location: UriLocation): RemoteFileWithRangeCache;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseInternetAccountStateModel = typeof InternetAccount;
export type BaseInternetAccountModel = Instance<BaseInternetAccountStateModel>;
