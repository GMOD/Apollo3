import type { FetchContext, FetchLifecycleHost } from './FetchMixin.ts';
import type { GateFetchState } from './regionTooLargeUtils.ts';
import type { RegionTooLargeResult } from '@jbrowse/core/rpc/byteBudget';
import type { StopTokenRotation } from '@jbrowse/core/util/createStopTokenRotation';
import type { FetchPhases } from '@jbrowse/core/util/fetchPhases';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * This family's spelling of the shared three-phase contract. The rules live on
 * {@link FetchPhases}; the comparative family names the same type over its own
 * context.
 *
 * `run` may answer the worker's refusal marker in place of a payload, which is
 * how the byte gate reaches this family: the RPC takes `resolvedByteLimit()`,
 * measures before it downloads, and the shared commit turns the marker into a
 * byte measurement and no display commit.
 */
export interface GlobalFetchPhases<TArgs, TResult> extends Omit<FetchPhases<TArgs, TResult, FetchContext>, 'run'> {
    run: (args: TArgs, ctx: FetchContext) => Promise<TResult | RegionTooLargeResult | undefined>;
}
export interface GlobalFetchHost extends IStateTreeNode, FetchLifecycleHost {
    fetchRotation: StopTokenRotation;
    fetchSignature: string | undefined;
    commitFetchResult: (commit: () => void, signature: string) => void;
    gateFetchState: () => GateFetchState;
    commitFetchBytes: (perRegionBytes: (number | undefined)[], issued: GateFetchState) => void;
}
export interface GlobalFetchAutorunHost extends GlobalFetchHost {
    reloadCounter: number;
    fetchCanceled: boolean;
    cancelFetch: () => void;
    fetchInert: boolean;
    awaitingPrerequisite: boolean;
    isMinimized: boolean;
    gateSkipsMeasuredViewport: boolean;
    loadedFetchSignature: string | undefined;
    regionTooLarge: boolean;
    host: {
        initialized: boolean;
    };
    scrollTop?: number;
    clearHoveredFeature: () => void;
}
/**
 * One fetch through the phases on demand: the same plan, rotation and lifecycle
 * the installed autorun runs, and **none of its gates** — a caller here is
 * asking for a round trip, not for the trigger's judgement about whether one is
 * owed. Returns the fetch's promise, or `undefined` for the one decline that is
 * the plan's rather than the skeleton's: no computable signature, or the
 * display's own `prepare` declining.
 *
 * The installed autorun is the production trigger; this is what a caller that
 * wants exactly one round trip and its promise drives — the per-display fetch
 * tests. It carried a copy of the family's gates until 2026-08-31, and that copy
 * is the drift the declaration over `installFetch` exists to close: it had no
 * reload override, no `initialized` term and no byte-gate skip, so the entry the
 * LD suite drove and the entry production runs disagreed about three of the four
 * gates while reading as the same thing. Gate behaviour belongs to
 * `installGlobalFetchAutorun.test.ts`, which drives the installed autorun.
 */
export declare function runGlobalFetchOnce<TArgs, TResult>(self: GlobalFetchHost, phases: GlobalFetchPhases<TArgs, TResult>): Promise<void> | undefined;
/**
 * Install the fetch for a `GlobalFetchMixin` display: the shared `installFetch`
 * skeleton — which owns the leading-edge debounce, the unconditional
 * `reloadCounter` read, the durable cancel gate, the freshness gate with its
 * reload override, and both contract checks — declared over this family's
 * signature machinery. A display supplies only its own `prepare` / `run` /
 * `commit`.
 *
 * What the declaration states, term by term:
 *
 * - **gate** — not initialized, minimized, or the byte-gate skip. The last one
 *   is not "don't fetch" but "don't fetch a viewport you have already
 *   measured": a blocked display still runs its fetch once per settled
 *   viewport, because the RPC's measurement is the only thing that releases the
 *   banner, and `gateSkipsMeasuredViewport` (whose own reads move with the
 *   viewport) is what keeps that to one. Each gate term is an observable that
 *   flips on the transition to wake on, which is what makes a gated decline
 *   safe — see ARCHITECTURE.md §"The global-fetch trigger list must be read
 *   unconditionally". Liveness is not a term here: `installFetch` checks it
 *   above every gate, because `host` is a parent walk and so is nearly every
 *   other gate in the tree.
 * - **fetchKey / committedKey** — `fetchSignature` (the display's
 *   `viewSignature` plus the serialized `rpcProps()` axis, so the viewport and
 *   every user setting are tracked wherever the compare runs) against the
 *   stamp `commitFetchResult` wrote. While `regionTooLarge` holds, the
 *   committed side reads as absent — the precedence the per-region family
 *   applies through `heldDataAnswers`, here spelled as a key: the banner is
 *   hiding that data and this fetch is the only re-measure. The
 *   skeleton's reload epoch is what makes Retry override this gate with
 *   nothing to clear — `GlobalFetchMixin.reload()` still drops the stamp so
 *   `dataCurrent` goes false and the overlay shows.
 * - **plan / lifecycle** — {@link globalFetchPlan}'s issue-time capture and
 *   measure-or-commit, over `FetchMixin`'s begin/end bookkeeping and the
 *   mixin's own rotation, so `cancelFetch` and the Cancel button reach the
 *   fetch this installs.
 *
 * `rpcProps()` loop hazard: unlike MultiRegion's `SettingsInvalidate` (which
 * clears data in a *separate, undelayed* autorun and so loops synchronously if
 * `rpcProps()` *returns* fetch-derived state — caught by `makeSettingsLoopGuard`),
 * this fetch reads the key and starts the round trip in the *same* debounced
 * body. A fetch-derived value in the payload here loops on the async-fetch
 * cadence (refetch → commit → key changes → reschedule after `delay` →
 * refetch), a slow network thrash rather than a synchronous freeze, so a
 * within-tick counter cannot distinguish it from legitimate rapid interaction.
 * The invariant is the same: `rpcProps()` must return only user-controlled
 * settings, never fetched data (see ARCHITECTURE.md §"rpcProps() loop trap").
 */
export declare function installGlobalFetchAutorun<TArgs, TResult>(self: GlobalFetchAutorunHost, opts: GlobalFetchPhases<TArgs, TResult> & {
    delay: number;
    name: string;
}): void;
