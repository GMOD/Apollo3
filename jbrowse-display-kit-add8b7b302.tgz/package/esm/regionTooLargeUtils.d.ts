/**
 * The span below which the density axis stops gating and the byte budget is
 * multiplied by {@link SUB_FLOOR_BYTE_BUDGET_FACTOR}. Compared only in
 * `aboveForceLoadFloor`.
 */
export declare const AUTO_FORCE_LOAD_BP = 20000;
/**
 * The byte budget's multiplier below {@link AUTO_FORCE_LOAD_BP}: what one index
 * bin costs on the deepest file in the repo. A policy dial —
 * agent-docs/reference/REGION_TOO_LARGE.md § "The sub-floor budget tier".
 */
export declare const SUB_FLOOR_BYTE_BUDGET_FACTOR = 2;
/**
 * The byte budget a gated display resolves when neither its own
 * `fetchSizeLimit` slot nor the measured adapter's declares one — the tightest
 * tier in the system, and the same number
 * `regionTooLargeConfigSchemaFields.fetchSizeLimit` defaults to. That table has
 * to keep its own literal (`scripts/gatedBudgets.ts` reads the number out of the
 * source), so `regionTooLargeUtils.test.ts` pins the two together.
 */
export declare const BASE_FETCH_SIZE_LIMIT = 1000000;
/** One measurement of what a fetch would cost, at the viewport it describes. */
export interface ByteEstimate {
    /** Never undefined: an unmeasurable fetch leaves the whole estimate unset. */
    bytes: number;
    /** The visible span at measurement, kept only to compare two measurements. */
    measuredSpanBp: number;
    /**
     * A materially smaller span came back materially unchanged, so "zoom in to
     * see features" cannot work for this file. Evidence, never predicted.
     */
    zoomIneffective: boolean;
}
/** What a measurement is about, captured before it is requested. */
export interface GateViewport {
    spanBp: number;
    /**
     * The measurement's identity: the stretch of genome on screen and the
     * settings it is asked under, which is what `gateMeasurementStale` compares.
     * `RegionTooLargeMixin.gateViewport` builds it and says why the settings are
     * in there.
     */
    key: string;
}
/** The gate as it stood when a fetch was issued; its result is judged by this. */
export interface GateFetchState {
    viewport: GateViewport | undefined;
    gated: boolean;
    /** `byteGateAdapterKey` at issue; undefined when the display never gates. */
    tierKey: string | undefined;
}
/** Everything a sequence of gate events moves. */
export interface GateState {
    byteEstimate: ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
    forceLoadTrack: boolean;
}
export type GateEvent = {
    kind: 'measurement';
    issued: GateFetchState;
    currentTierKey: string | undefined;
    /** absent when the fetch measured no bytes */
    bytes?: number;
    /**
     * The batch stopped early, so `bytes` is the max over whichever regions
     * landed first rather than over the region set. See `zoomIneffective`.
     */
    partial?: boolean;
} | {
    kind: 'invalidated';
} | {
    kind: 'forceLoad';
    approved: boolean;
}
/** changes nothing, so a walk over events can assert that it doesn't */
 | {
    kind: 'viewportMoved';
};
/**
 * The commit protocol, pure so `nextGateState.test.ts` can walk event
 * sequences: a measurement is judged by the tier it was issued against, a
 * fetch the gate sat out stamps no viewport, an absent `bytes` leaves the last
 * estimate alone, and an approval outlives an invalidation. Returns `prev`
 * itself when nothing moved.
 */
export declare function nextGateState(prev: GateState, event: GateEvent): GateState;
/**
 * Fold a fresh measurement into the stored one. `zoomIneffective` needs two
 * points: a span at most half the previous one whose bytes are still over 90%
 * of it. A zero baseline of span or bytes starts over.
 */
export declare function nextByteEstimate(previous: ByteEstimate | undefined, measurement: {
    bytes: number;
    viewport: GateViewport;
}, partial?: boolean): ByteEstimate;
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
/**
 * The gate's byte budget: the adapter's declared limit (a non-positive one
 * means no opinion), else the display's, else {@link BASE_FETCH_SIZE_LIMIT},
 * times {@link SUB_FLOOR_BYTE_BUDGET_FACTOR} below the floor. Force-load is not
 * a tier here; it bypasses the comparison.
 *
 * **A budget nobody declared falls back closed.** `configFetchSizeLimit` comes
 * from `getConf`, which answers `undefined` for a slot the composing display's
 * schema never declared — silently, as it always does. An undefined budget
 * propagates to `measureRegionBytes`, which returns `{}` and measures nothing,
 * so the gate is off with nothing to see. A wrongly-tight banner is visible,
 * diagnosable and has an escape on the banner itself; a wrongly-open gate is a
 * silent multi-GB download. It does not throw, because a schema-authoring slip
 * should not crash a display and the `undefined` surfaces far from the author.
 */
export declare function resolveByteLimit({ adapterFetchSizeLimit, configFetchSizeLimit, belowForceLoadFloor, }: {
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number | undefined;
    belowForceLoadFloor: boolean;
}): number;
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
    /** Which axis tripped; `zoomCanReleaseGate` branches on it. */
    axis?: 'bytes' | 'density';
}
/**
 * The comparison half of the verdict: bytes against the budget, then density.
 * Whether an axis may act is the caller's question — it passes `undefined` /
 * `false` for an axis that is off.
 */
export declare function evaluateRegionTooLarge({ estimatedFetchBytes, byteLimit, densityTooLarge, }: {
    estimatedFetchBytes?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
}): RegionTooLargeStatus;
/**
 * Whether the data a display already holds may answer this run, or whether the
 * gate outranks it.
 *
 * While `regionTooLarge` holds, every "already have it" gate is void — the
 * per-region family's `covered`, and the global family's committed signature,
 * which spells the same precedence as a key rather than through this function
 * (`installGlobalFetchAutorun`'s `committedKey` reads as absent while the
 * banner holds). Held data answers nothing while the banner hides it, and the
 * fetch is the only re-measure, so a return to a viewport whose data is still
 * loaded has to fetch or the banner can never be released.
 *
 * `held` is a thunk, so a caller's own short-circuit survives: the per-region
 * plan reads `isCacheValid` only for a block it already found covered, and
 * evaluating it eagerly would widen that autorun's dependency set.
 *
 * The one skip that outranks this is `gateSkipsMeasuredViewport`, applied by
 * both families above their fetch — without it a still-refused display spins on
 * the `fetchGeneration` bump.
 */
export declare function heldDataAnswers(gateBlocked: boolean, held: () => boolean): boolean;
