export interface OAuthWindowParams {
    internetAccountId: string;
    expectedState: string | undefined;
    exchangeAuthorizationCode: (code: string, redirectUri: string) => Promise<string>;
    storeToken: (token: string) => void;
}
export declare function parseOAuthError(text: string): {
    isInvalidGrant: boolean;
    statusText: string;
};
/**
 * Parses an OAuth redirect message event. Returns the token if the event
 * completes the flow, undefined if the event name doesn't match. Throws on
 * any OAuth error.
 */
export declare function finishOAuthWindow(event: MessageEvent, params: OAuthWindowParams): Promise<string | undefined>;
/**
 * Returns a promise that resolves to the token when the OAuth popup posts its
 * redirect back. The listener is self-contained and cleaned up when the
 * promise settles.
 */
export declare function waitForOAuthMessage(finish: (event: MessageEvent) => Promise<string | undefined>): Promise<string>;
