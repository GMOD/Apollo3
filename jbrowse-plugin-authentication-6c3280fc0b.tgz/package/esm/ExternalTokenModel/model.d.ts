import type { ExternalTokenInternetAccountConfigModel } from './configSchema.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel ExternalTokenInternetAccount
 * Internet account that authenticates requests with a user-supplied external
 * token, prompting for the token via a dialog and optionally validating it with
 * a HEAD request. See
 * [TokenEntryInternetAccount](../tokenentryinternetaccount) for the shared
 * behavior.
 */
declare const stateModelFactory: (configSchema: ExternalTokenInternetAccountConfigModel) => import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
}, "configuration" | "type"> & {
    type: import("@jbrowse/mobx-state-tree").ISimpleType<"ExternalTokenInternetAccount">;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>;
}, {
    readonly name: string;
    readonly description: string;
    readonly internetAccountId: string;
    readonly authHeader: string;
    readonly tokenType: string;
    readonly domains: string[];
    readonly toggleContents: React.ReactNode;
    readonly SelectorComponent: import("@jbrowse/core/util").AnyReactComponentType | undefined;
    readonly selectorLabel: string | undefined;
} & {
    handlesLocation(location: import("@jbrowse/core/util").UriLocation): boolean;
    readonly tokenKey: string;
} & {
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    storeToken(token: string): void;
    retrieveToken(): string | null;
    validateToken(token: string, _loc: import("@jbrowse/core/util").UriLocation): Promise<string>;
} & {
    removeToken(): void;
    getToken(location?: import("@jbrowse/core/util").UriLocation): Promise<string>;
} & {
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    getValidatedToken(loc?: import("@jbrowse/core/util").UriLocation): Promise<string>;
    getPreAuthorizationInformation(location: import("@jbrowse/core/util").UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: any;
        };
    }>;
} & {
    getFetcher(loc?: import("@jbrowse/core/util").UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    openLocation(location: import("@jbrowse/core/util").UriLocation): import("@jbrowse/core/util/io").RemoteFileWithRangeCache;
} & {
    readonly validateWithHEAD: boolean;
} & {
    getTokenFromUser(resolve: (token: string) => void, reject: (error: Error) => void): void;
    validateToken(token: string, location: import("@jbrowse/core/util").UriLocation): Promise<string>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default stateModelFactory;
export type ExternalTokenStateModel = ReturnType<typeof stateModelFactory>;
export type ExternalTokenModel = Instance<ExternalTokenStateModel>;
