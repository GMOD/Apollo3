import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #config HTTPBasicInternetAccount
 */
declare const HTTPBasicConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    /**
     * #slot
     */
    readonly tokenType: {
        readonly description: "a custom name for a token to include in the header";
        readonly type: "string";
        readonly defaultValue: "Basic";
    };
    /**
     * #slot
     */
    readonly validateWithHEAD: {
        readonly description: "validate the token with a HEAD request before using it";
        readonly type: "boolean";
        readonly defaultValue: true;
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly name: {
        readonly description: "descriptive name of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly description: {
        readonly description: "a description of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly authHeader: {
        readonly description: "request header for credentials";
        readonly type: "string";
        readonly defaultValue: "Authorization";
    };
    readonly tokenType: {
        readonly description: "a custom name for a token to include in the header";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly domains: {
        readonly description: "array of valid domains the url can contain to use this account";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>;
export type HTTPBasicInternetAccountConfigModel = typeof HTTPBasicConfigSchema;
export type HTTPBasicInternetAccountConfig = Instance<HTTPBasicInternetAccountConfigModel>;
export default HTTPBasicConfigSchema;
