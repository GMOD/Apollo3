import type { Pin } from '../configuration/promotableDefaults.ts';
import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
import type { RadioOption, SettingRowOptions } from './toggleMenuItems.ts';
export declare function promotableToggleItem({ label, checked, onToggle, pin, ...opts }: {
    label: string;
    checked: boolean;
    onToggle: () => void;
    pin: Pin;
} & SettingRowOptions): CheckboxMenuItem;
export declare function promotableRadioItem({ label, checked, onClick, pin, ...opts }: {
    label: string;
    checked: boolean;
    onClick: () => void;
    pin?: Pin;
} & SettingRowOptions): RadioMenuItem;
export declare function promotableRadioItems<T extends string>(options: readonly RadioOption<T>[], current: T | undefined, setMode: (m: T) => void, pin: (value: T) => Pin): RadioMenuItem[];
