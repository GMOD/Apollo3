/**
 * Bottom-right progress chip for work running while usable content is already on
 * screen: a refetch over stale geometry (dotplot, linear synteny), or a
 * background job that is not a fetch at all (clustering, via `DisplayChrome`).
 * It stays small and out of the way instead of masking the canvas the way the
 * full loading overlay would, and surfaces the statusCallback message plus a
 * determinate bar when the phase reports progress.
 *
 * Pure presentation — the caller owns the gate (its own `refetching` getter, or
 * the chrome's "a status is set while the phase is ready") and the containing
 * element owns the positioning context.
 *
 * It also owns the corner, unless `anchored={false}` says something else does.
 * That escape exists because on the LGV side the corner is shared: the chrome
 * anchors one box for both this and the display's control row, and a chip that
 * pins itself lands *under* that row rather than above it.
 */
declare const ProgressChip: ({ statusMessage, statusProgress, anchored, }: {
    statusMessage?: string;
    statusProgress?: number;
    /**
     * Pin to the bottom-right of the containing block (the default, and what a
     * caller dropping this into its own positioned box wants). Pass `false` where
     * something else already owns that corner and lays this out — `DisplayChrome`
     * shares it with the display's control row.
     */
    anchored?: boolean;
}) => import("react").JSX.Element;
export default ProgressChip;
