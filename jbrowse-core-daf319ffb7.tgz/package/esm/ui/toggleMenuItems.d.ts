import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
export interface SettingRowOptions {
    helpText?: string;
    subLabel?: string;
    disabled?: boolean;
    disabledHelpText?: string;
    keepMenuOpen?: boolean;
}
export declare function checkboxItem(label: string, checked: boolean, onToggle: () => void, opts?: SettingRowOptions): CheckboxMenuItem;
export declare function radioItem(label: string, checked: boolean, onClick: () => void, opts?: SettingRowOptions): RadioMenuItem;
export interface RadioOption<T extends string> {
    value: T;
    label: string;
    subLabel?: string;
    helpText?: string;
}
export declare function radioItems<T extends string>(options: readonly RadioOption<T>[], current: T | undefined, setMode: (m: T) => void): RadioMenuItem[];
