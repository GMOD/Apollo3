/**
 * Search-box visibility/orientation for a multi-view header, persisted per
 * *regime* (few vs many views) rather than under one global key — so the
 * "compact default" heuristic isn't permanently overridden by a choice the user
 * made in a differently-sized view.
 *
 * `prefix` names the view type ('lcv', 'bsv'), which is what keeps the two
 * headers' settings apart. It is a parameter rather than two copies of this
 * hook because the copies had already been written twice, comment included, and
 * a change to the regime threshold in one would not have reached the other.
 */
export declare function useSearchBoxPrefs(prefix: string, numViews: number): {
    showSearchBoxes: boolean;
    setShowSearchBoxes: (value: boolean | ((val: boolean) => boolean)) => void;
    sideBySide: boolean;
    setSideBySide: (value: boolean | ((val: boolean) => boolean)) => void;
};
export type SearchBoxPrefs = ReturnType<typeof useSearchBoxPrefs>;
