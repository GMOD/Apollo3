import { RemoteFile } from 'generic-filehandle2';
import type { FilehandleOptions, GenericFilehandle, ReadFileOptions, ReadFileTextOptions } from 'generic-filehandle2';
/**
 * Drop every chunk no read has touched for {@link CACHE_IDLE_TIMEOUT_MS}.
 *
 * Safe to call at any moment, including mid-fetch, and that is not an accident:
 * `getCachedRange` holds a strong local reference to every chunk it will
 * assemble from before its first await, precisely so that eviction underneath it
 * is harmless. A chunk dropped here that somebody still wants is re-fetched.
 *
 * Deliberately narrower than {@link clearCache}: it touches neither `inFlight`
 * nor `queue`, whose entries are by definition active, and it keeps `sizeCache`,
 * which is one number per URL and costs a round trip to re-derive.
 *
 * Exported so a caller can reclaim on its own schedule — a tab going hidden,
 * say — rather than only on the interval. The interval is what makes this work
 * for the case it exists for, though: an idle consumer is calling nothing, so a
 * lazy check inside `getCached` would never fire for exactly the reader who has
 * walked away.
 */
export declare function sweepIdleCache(): void;
export declare function clearCache(): void;
export declare class RemoteFileWithRangeCache extends RemoteFile {
    stat(): Promise<{
        size: number;
    }>;
    private fetchRange;
    private getCachedRange;
    /**
     * Bytes for a byte range, straight out of the chunk cache.
     *
     * `RemoteFile.read` would build the range header, call {@link fetch}, and
     * unwrap the `Response` it got back. Every one of those steps is a copy of
     * the whole range, and on a cache hit there is no network for them to hide
     * behind: measured warm, with the chunk cache fully populated, the
     * `Response` round trip was **69-77%** of the read (6.15ms vs 1.90ms at
     * 16MB, 0.36ms vs 0.08ms at 256KB).
     *
     * `fetch` below still caches, so anything that reaches this class by that
     * route — a caller setting its own range header — is unaffected. This is
     * the same cache, entered one layer lower.
     */
    read(length: number, position: number, opts?: FilehandleOptions): Promise<Uint8Array<ArrayBuffer>>;
    fetch(url: string | RequestInfo, init?: RequestInit): Promise<Response>;
}
/**
 * The same chunk cache, in front of any filehandle.
 *
 * `RemoteFileWithRangeCache` gets its cache by *being* a `RemoteFile`, so for
 * as long as that was the only entry point, local paths and blobs got no
 * caching at all — `openLocation` handed back a bare `LocalFile`/`BlobFile` and
 * every read went to disk. Nothing in the cache is about HTTP, so this wraps
 * whatever it is given instead.
 *
 * `key` namespaces this file's chunks in the module-global cache, so it has to
 * identify the underlying bytes: a path or a URL for something with a stable
 * name, and something instance-unique for a Blob, which has no name to key on.
 * Two wrappers sharing a key share chunks, which is right for two handles on
 * one path and wrong for two unrelated blobs.
 */
export declare class CachedFilehandle implements GenericFilehandle {
    private inner;
    private key;
    constructor(inner: GenericFilehandle, key: string);
    read(length: number, position: number, opts?: FilehandleOptions): Promise<Uint8Array<ArrayBuffer>>;
    readFile(options?: ReadFileOptions): Promise<Uint8Array<ArrayBuffer>>;
    readFile(options: ReadFileTextOptions): Promise<string>;
    stat(): Promise<import("generic-filehandle2").Stats>;
    close(): Promise<void>;
}
