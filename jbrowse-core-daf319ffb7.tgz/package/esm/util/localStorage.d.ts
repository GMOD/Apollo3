/** The raw string stored at `key`, or undefined if absent or unreadable. */
export declare function localStorageGetItem(key: string): string | undefined;
export declare function localStorageSetItem(key: string, value: string): void;
export declare function localStorageRemoveItem(key: string): void;
export declare function localStorageGetNumber(key: string, defaultVal: number): number;
export declare function localStorageGetJSON<T>(key: string, defaultVal: T): T;
/**
 * Writes `val` as JSON, except when it is null/undefined — those are skipped
 * rather than stored, so a tri-state setting whose "unset" value means "follow
 * the config" leaves whatever was there instead of pinning `null` over it.
 */
export declare function localStorageSetJSON(key: string, val: unknown): void;
export declare function localStorageGetBoolean(key: string, defaultVal: boolean): boolean;
export declare function localStorageSetBoolean(key: string, value: boolean): void;
export declare function localStorageSetNumber(key: string, value: number): void;
