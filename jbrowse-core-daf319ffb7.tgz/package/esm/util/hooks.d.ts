import type { RefObject } from 'react';
export declare function useFocusOnInteraction(ref: RefObject<HTMLElement | null>, onInteract: () => void): void;
export declare function useDebounce<T>(value: T, delay: number): T;
export declare function useWidthSetter(view: {
    setWidth: (arg: number) => void;
    id?: string;
}): RefObject<HTMLDivElement | null>;
/**
 * `useState` backed by a localStorage key.
 *
 * Originally https://usehooks.com/useLocalStorage/, which is per-instance: two
 * components on the same key each kept their own copy of it, so toggling a
 * setting in one BreakpointSplitView header left a second one open beside it
 * showing the old value until it remounted. Instances on a key now subscribe to
 * each other's writes, and to other tabs' — the thing the grid-bookmark widget
 * had to hand-roll a `storage` listener for.
 *
 * The store is read on every notify rather than cached, so nothing here can go
 * stale against a `localStorage.clear()`. Which also means a functional update
 * resolves against what is actually stored: two `setValue(v => …)` calls in one
 * handler used to keep only the second, because both resolved against the value
 * captured by the render that produced the setter.
 *
 * `enabled: false` keeps the value in component state only: nothing is read,
 * written or shared. Callers use it for a key that isn't meaningful yet (no
 * assembly chosen, so nothing to scope the key to).
 */
export declare function useLocalStorage<T>(key: string, initialValue: T, enabled?: boolean): readonly [T, (value: T | ((val: T) => T)) => void];
