import type PluginManager from '@jbrowse/core/PluginManager';
import type { BlobLocation } from '@jbrowse/core/util';
/**
 * Bytes for one browser-local file, keyed by the name a track config refers to
 * it by. `Blob`/`File` pass through; anything else (a `Uint8Array` from a
 * notebook kernel's binary channel, an `ArrayBuffer` from a fetch) is wrapped.
 */
export type LocalFileInput = Record<string, Blob | BufferSource>;
/**
 * Register in-memory bytes as browser-local files JBrowse can read, returning
 * the `name -> BlobLocation` map {@link resolveLocalFileUris} substitutes with.
 *
 * This is the escape from "the data has to be on a web server first". A
 * `BlobLocation` opens as a `BlobFile`, which serves byte ranges out of
 * `Blob.slice()` — so a bgzipped+tabixed file, a BAM with its `.bai`, or a
 * bigWig is *seeked into* exactly as if it were remote, and only the bytes the
 * current view needs are ever touched. That is the whole point of doing this
 * rather than inlining features into a config: a 200k-feature table is ~20MB of
 * JSON to serialize, ship, and hold in memory, while the same data as a tabix
 * file is a few MB the view reads a few KB of at a time.
 *
 * For hosts that hold their data in a process rather than at a URL — a notebook
 * kernel, an R session, a desktop app — this is the way in, and it needs no web
 * server, no CORS, and no temporary public bucket.
 */
export declare function registerLocalFiles(files: LocalFileInput): {
    [k: string]: BlobLocation;
};
/**
 * Fold newly-offered files into a controller's registered map, registering only
 * the names it has not seen. Registering is what mints the blobIds, so a host
 * re-stating its whole file set on every update — which is what a declarative
 * host does — pays for each file once rather than once per update.
 *
 * Only ever adds: a name already registered keeps its existing blob, because a
 * live track config points at that blobId and swapping it underneath would
 * leave the track reading bytes nothing else references.
 */
export declare function mergeLocalFiles(current: Record<string, BlobLocation>, files: LocalFileInput): {
    [x: string]: BlobLocation;
};
/**
 * Expand every shorthand adapter snapshot (`{ type, uri }`) in a config to the
 * canonical location keys its config schema declares, using that adapter type's
 * own `normalizeSnapshot` — the hook that exists so "downstream code can read
 * location keys without knowing each shorthand".
 *
 * {@link resolveLocalFileUris} has to run on the expanded form, and this is the
 * difference between `localFiles` working and silently doing nothing: the
 * shorthand puts `uri` on the *adapter*, so substituting there would replace
 * `{ type: 'BamAdapter', uri: 'x.bam' }` with a bare BlobLocation and take the
 * adapter's type with it. Expanding first moves the name onto `bamLocation`,
 * where it is a location node and substitution is what it looks like. The
 * expansion also derives the conventional index sibling (`.bai`/`.tbi`/`.crai`)
 * from the same string, so registering `x.bam` and `x.bam.bai` is enough and no
 * caller has to know which adapter wanted which file.
 *
 * Idempotent, and a no-op for an already-canonical config or an adapter type
 * that declares no shorthand.
 */
export declare function normalizeAdapterSnapshots<T>(config: T, pluginManager: PluginManager): T;
/**
 * Rewrite every `{ uri: <a registered name> }` in a track config to that file's
 * `BlobLocation`, in place of nothing else — unregistered URIs are left alone,
 * so a config can mix local and remote files freely.
 *
 * Runs on a config whose locations are already canonical, which is what
 * `guessTrackConf` (for a loose track spec) and {@link normalizeAdapterSnapshots}
 * (for a written-out one) each produce. So a host registers `peaks.bed.gz` and
 * `peaks.bed.gz.tbi` under their plain names, the config names both under
 * `bedGzLocation` and `index.location`, and this swaps both for blobs — index
 * and all, with no host-side knowledge of which adapter wanted which sibling.
 */
export declare function resolveLocalFileUris<T>(config: T, locations: Record<string, BlobLocation>): T;
