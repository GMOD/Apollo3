/**
 * Migrates old session and config snapshots to be compatible with the current
 * display type registrations. Handles display types that were removed or
 * renamed in the v4 rendering rearchitecture.
 *
 * Remapped display types (see `displayTypeMap` for the band settings each one
 * carries over):
 *   LinearPileupDisplay → LinearAlignmentsDisplay
 *   LinearSNPCoverageDisplay → LinearAlignmentsDisplay
 *   LinearReadArcsDisplay → LinearAlignmentsDisplay
 *   LinearReadCloudDisplay → LinearAlignmentsDisplay
 *   LinearFeatureDisplay → LinearBasicDisplay
 *
 * Also lifts the per-instance alignments settings a v4.3.0 session persisted
 * (`colorBySetting`, `filterBySetting`, `jexlFilters`, `trackMaxHeight`,
 * `hideMismatchesSetting`) into the config where they now live as slots — off
 * the nested `LinearAlignmentsDisplay` container's `PileupDisplay` /
 * `SNPCoverageDisplay` sub-nodes and off a flat old display alike, see
 * `extractAlignmentsInstanceSettings` — and routes the legacy per-instance
 * `heightPreConfig` display-height prop onto the `height` config slot — see
 * `extractInstanceHeight`.
 */
/**
 * Every display-instance key a session snapshot may still carry and have
 * honored, keyed by the display type it applies to — `*` for the ones any
 * display gets. A snapshot carrying one of these loads correctly, so `jbrowse
 * validate` reports it as stale rather than dead; that command reads this map
 * (through the generated config manifest) rather than keeping a copy that could
 * drift.
 *
 * Not every entry is lifted *here*. The two multi-sample variant displays lift
 * their own `jexlFilters` in the model's `preProcessSnapshot`, because the value
 * stays on the instance (under `jexlFiltersSetting`) rather than moving to a
 * config slot, which is the only shape this module handles. What decides
 * membership is whether the key still works, not which file makes it work.
 *
 * Keyed rather than flat because the same name means different things on
 * different displays: `jexlFilters` is lifted for the alignments display and,
 * differently, for the two variant ones, while on a LinearBasicDisplay — whose
 * own prop has always been `jexlFiltersSetting` — it is simply dead, and a flat
 * list would call that one supported.
 */
export declare const MIGRATED_DISPLAY_INSTANCE_KEYS: Record<string, string[]>;
/**
 * Walks a session snapshot and remaps old display types to their new names.
 * Handles displays nested inside views, tracks, and sessionTracks.
 */
export declare function migrateSessionSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
/**
 * Walks a config snapshot and remaps old display types in track definitions.
 * Config tracks have displays in their configuration (not in views).
 */
export declare function migrateConfigSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
