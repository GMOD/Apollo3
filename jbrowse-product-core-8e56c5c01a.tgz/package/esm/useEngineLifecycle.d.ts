import type { EmbeddedRoot } from './destroyViewState.ts';
export { useCreateOnce } from '@jbrowse/core/util/hooks';
/**
 * Destroy an engine when its component really unmounts — terminating its RPC
 * worker threads and stopping its autoruns.
 *
 * The lifecycle rule is {@link useFinalUnmount}'s, including why the obvious
 * `useEffect(() => () => destroyViewState(state), [state])` is wrong under
 * StrictMode; this only names what gets torn down. Pair it with
 * `useCreateOnce`, since the engine has to be the same one for the component's
 * whole life.
 */
export declare function useDestroyOnUnmount(viewState: EmbeddedRoot): void;
