import type { SessionSnapshot } from './sessionUrl.ts';
type OpenTracks = {
    configuration: {
        trackId: string;
    };
}[];
interface ObservedView {
    id?: string;
    coarseVisibleLocStrings?: string;
    views?: {
        coarseVisibleLocStrings?: string;
    }[];
    tracks?: OpenTracks;
    levels?: {
        tracks: OpenTracks;
    }[];
}
interface ObservedSession {
    name: string;
    views: ObservedView[];
    selection?: unknown;
}
interface ObservedRoot {
    session?: ObservedSession;
}
/** where one view is looking: a locstring, or one per panel for a comparative view */
export type ViewLocation = string | string[] | undefined;
export interface SessionObservers {
    /** fires with every view's visible region when the layout settles */
    onLocationChange?: (locations: ViewLocation[]) => void;
    /** fires with the serialized feature when one is selected in any view */
    onFeatureSelect?: (feature: unknown) => void;
    /**
     * fires with a plain-JSON snapshot of the layout the user built, in the shape
     * the `session` option takes — so "save this arrangement" is storing this
     * value and reopening it is passing it back
     */
    onSessionChange?: (session: SessionSnapshot) => void;
}
/**
 * The live session as a plain JSON snapshot, ready to hand straight back as a
 * product's `session` option (or its controller's `setSession`). The
 * uncompressed twin of `encodeSession`, for hosts that move JSON rather than
 * URLs — a notebook kernel, an R session, a "save this layout" button.
 *
 * Not a plain `getSnapshot`, and for the same reason `encodeSession` isn't:
 * display settings a user is *inheriting* from a promoted display-type default
 * live in their own browser, never in the session, so a raw snapshot replays
 * differently for whoever opens it.
 */
export declare function getSessionSnapshot(session: ObservedSession): SessionSnapshot;
/**
 * Wire the read-backs a host asked for, returning one disposer for all of them.
 */
export declare function observeSession(root: ObservedRoot, { onLocationChange, onFeatureSelect, onSessionChange }: SessionObservers): () => void;
export {};
