import type { SessionWithDrawerWidgets } from '@jbrowse/core/util';
/**
 * The drawer's chrome: the paper it sits on and the handle that resizes it.
 * Focus tracking is left to the caller through `ref`, since only the app shell
 * has a focused-view concept to wire it to.
 */
declare const Drawer: ({ session, children, ref, }: {
    session: SessionWithDrawerWidgets;
    children: React.ReactNode;
    ref?: React.Ref<HTMLDivElement>;
}) => import("react").JSX.Element;
export default Drawer;
