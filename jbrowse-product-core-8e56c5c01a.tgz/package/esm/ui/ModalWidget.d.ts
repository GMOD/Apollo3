import type { SessionWithWidgets } from '@jbrowse/core/util';
/**
 * Renders the session's visible widget in a modal dialog rather than a drawer.
 * `onClose` is caller-owned: in the app the modal is a pop-out of the drawer and
 * closing returns the widget to it, while in embedded products the modal is the
 * only widget surface and closing must dismiss the widget outright.
 */
declare const ModalWidget: ({ session, onClose, }: {
    session: SessionWithWidgets;
    onClose: () => void;
}) => import("react").JSX.Element | null;
export default ModalWidget;
