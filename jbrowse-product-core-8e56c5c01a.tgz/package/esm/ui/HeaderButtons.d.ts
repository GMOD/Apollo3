interface HeaderButtonsProps {
    conf: Record<string, unknown>;
    hideUris?: boolean;
    /**
     * `<displayType>.<slot>` for each value the copied config inherited from a
     * session-wide display-type default rather than from the config itself
     */
    fromDisplayTypeDefaults?: string[];
    setShowRefNames: (show: boolean) => void;
}
declare function HeaderButtons({ conf, hideUris, fromDisplayTypeDefaults, setShowRefNames, }: HeaderButtonsProps): import("react").JSX.Element;
export default HeaderButtons;
