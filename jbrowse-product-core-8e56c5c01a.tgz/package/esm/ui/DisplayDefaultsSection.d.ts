import type PluginManager from '@jbrowse/core/PluginManager';
export interface DisplayDefaultsSession {
    getDisplayTypeDefaults: () => {
        displayType: string;
        slot: string;
        value: unknown;
    }[];
    setDisplayTypeDefault: (displayType: string, slot: string, value: unknown) => void;
}
/**
 * The inventory of session-wide display-type defaults: every value the user has
 * pinned from a track menu, what it overrides, and a button to clear one.
 *
 * The pin is easy to set and, until this, hard to find again. A pinned default
 * shows on the track-selector badge of any **open** track it moves — but one
 * affecting nothing currently open, one promoted to a value equal to the slot's
 * base, and one that no longer resolves at all (a stale value the cascade
 * refuses, or a display type whose plugin is gone) appear nowhere. The only
 * place that listed them was the "Reset preferences to defaults" confirmation,
 * which is a destructive dialog to have to open in order to read something.
 *
 * The empty state is deliberate rather than rendering nothing: it is the one
 * place the app says the capability exists to someone who has never used it.
 *
 * **The slot keeps its schema name**, while the display type gets its authored
 * one. A slot has no menu label to borrow — which row a setting is offered on is
 * a menu fact and declaring the slot promotable is a schema fact, and nothing
 * joins them (that split is why `promotableSlotsWithoutPin` has to walk a built
 * menu at all). A raw slot name is also what the config editor labels its fields
 * with, so the two surfaces agree.
 */
declare const DisplayDefaultsSection: ({ session, pluginManager, }: {
    session: DisplayDefaultsSession;
    pluginManager: PluginManager;
}) => import("react").JSX.Element;
export default DisplayDefaultsSection;
