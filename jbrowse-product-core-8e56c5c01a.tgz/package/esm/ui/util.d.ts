import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
export type AboutConfig = AnyConfigurationModel | Record<string, unknown>;
export interface AboutPanelProps {
    session: AbstractSessionModel;
    config: AboutConfig;
}
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-extraAboutPanel': ComponentList<AboutPanelProps>;
        /** #extensionPoint Core-replaceAbout | sync | Replace or wrap a track's About dialog body */
        'Core-replaceAbout': ComponentSlot<AboutPanelProps>;
        'Core-customizeAbout': {
            args: {
                config: Record<string, unknown>;
            };
            result: {
                config: {
                    metadata?: Record<string, unknown>;
                    [key: string]: unknown;
                };
            };
            props: AboutPanelProps;
        };
    }
}
/**
 * Build what a track's About dialog shows: the base config merged with session-
 * and track-level `formatAbout` overrides and passed through the
 * `Core-customizeAbout` extension point, plus the resolved `hideUris`.
 *
 * Both `formatAbout` slots are two-tier and resolve here together, so the
 * dialog reads one thing rather than re-deriving half the rule at the call
 * site. They fold differently on purpose: `config` is a merge the track can win
 * key-by-key, `hideUris` is an OR a track cannot turn back off.
 */
export declare function getAboutDialogConfig({ config, session, pluginManager, }: {
    config: AboutConfig;
    session: AbstractSessionModel;
    pluginManager: PluginManager;
}): {
    config: {
        metadata?: Record<string, unknown>;
        [key: string]: unknown;
    };
    hideUris: boolean;
};
