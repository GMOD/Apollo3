import type { AboutPanelProps } from './util.ts';
export default function AboutDialog({ config, session, handleClose, }: AboutPanelProps & {
    handleClose: () => void;
}): import("react").JSX.Element;
