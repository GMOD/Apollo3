import type { AboutPanelProps } from './util.ts';
declare const FileInfoPanel: ({ config, session, }: AboutPanelProps) => import("react").JSX.Element | null;
export default FileInfoPanel;
