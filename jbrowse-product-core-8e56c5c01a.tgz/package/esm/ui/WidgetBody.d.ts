import type { SessionWithWidgets, Widget } from '@jbrowse/core/util';
/**
 * Renders one widget: resolve its React component, run it through the
 * `Core-replaceWidget` fold, and contain both its lazy chunk and its errors.
 *
 * Only the chrome around a widget differs between surfaces — the drawer's
 * resizable paper and header, the modal's dialog — so this is the part all of
 * them share, spelled once. The error boundary in particular was previously
 * only on the drawer path: popping the same widget out to a modal turned a
 * widget that throws during render from a banner in the widget's own area into
 * an unhandled throw that took the app down with it.
 */
declare const WidgetBody: ({ session, widget, toolbarHeight, }: {
    session: SessionWithWidgets;
    widget: Widget;
    toolbarHeight?: number;
}) => import("react").JSX.Element;
export default WidgetBody;
