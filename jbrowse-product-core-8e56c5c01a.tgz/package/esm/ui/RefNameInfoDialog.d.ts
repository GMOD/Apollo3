import type { AboutPanelProps } from './util.ts';
declare const RefNameInfoDialog: ({ config, session, onClose, }: AboutPanelProps & {
    onClose: () => void;
}) => import("react").JSX.Element;
export default RefNameInfoDialog;
