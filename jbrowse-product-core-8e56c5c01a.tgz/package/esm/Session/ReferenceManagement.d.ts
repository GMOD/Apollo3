/** MST props, views, actions, etc related to managing connections */
import type PluginManager from '@jbrowse/core/PluginManager';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
export interface ReferringNode {
    node: IAnyStateTreeNode;
    key: string;
}
/**
 * #stateModel ReferenceManagementSessionMixin
 */
export declare function ReferenceManagementSessionMixin(_pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #method
     * Walk the tree once and map each requested trackId to the nodes holding a
     * `types.reference` that resolves to it (a view's track entry, a config
     * editor widget). Track configs are matched by trackId, not identity, so a
     * frozen base and its hydrated MST node compare equal.
     */
    getReferringMultiple(trackIds: string[]): Map<string, ReferringNode[]>;
} & {
    /**
     * #method
     * The nodes currently referring to `trackId` (see getReferringMultiple).
     */
    getReferring(trackId: string): ReferringNode[];
} & {
    /**
     * #action
     * Remove `trackId` from every view referring to it and close any config
     * editor widget open on it. Runs immediately: the walk that produced
     * `referring` has finished, so mutating those views here is safe.
     */
    dereferenceTrack(trackId: string, referring: ReferringNode[]): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
/** Session mixin MST type for a session that manages multiple views */
export type SessionWithReferenceManagementType = ReturnType<typeof ReferenceManagementSessionMixin>;
/** Instance of a session with MST reference management (`getReferring()`, `dereferenceTrack()`)  */
export type SessionWithReferenceManagement = Instance<SessionWithReferenceManagementType>;
/** Type guard for SessionWithReferenceManagement */
export declare function isSessionWithReferenceManagement(thing: IAnyStateTreeNode): thing is SessionWithReferenceManagement;
