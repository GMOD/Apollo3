import type PluginManager from '@jbrowse/core/PluginManager';
import type { IAnyModelType, SnapshotIn, SnapshotOut } from '@jbrowse/mobx-state-tree';
/**
 * Apply the `Core-extendSession` extension point and drop the legacy
 * object-shaped `connectionInstances` from incoming snapshots (the schema
 * changed from an object to an array, so old snapshots must be filtered out,
 * xref https://github.com/GMOD/jbrowse-components/issues/1903).
 *
 * Shared by the web session (`finalizeWebSession`) and the desktop session
 * factory so the extension point + migration live in one place.
 */
export declare function finalizeSession<T extends IAnyModelType>(pluginManager: PluginManager, sessionModel: T): import("@jbrowse/mobx-state-tree").ISnapshotProcessor<T, Omit<SnapshotIn<T> & {
    connectionInstances?: unknown;
}, "connectionInstances">, Omit<SnapshotOut<T> & {
    connectionInstances?: unknown;
}, "connectionInstances">>;
