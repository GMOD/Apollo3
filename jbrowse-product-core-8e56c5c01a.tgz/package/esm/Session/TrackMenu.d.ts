import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { BaseTrackConfig } from '@jbrowse/core/pluggableElementTypes';
import type { MenuItem } from '@jbrowse/core/ui';
import type { DialogComponentType } from '@jbrowse/core/util';
import type { TrackActionView } from '@jbrowse/core/util/types';
type TrackCopySnapshot = {
    trackId: string;
    name: string;
    category?: unknown;
    displays?: {
        type: string;
        displayId: string;
    }[];
} & Record<string, unknown>;
/**
 * Clone a track config for "Copy track": snapshots the config, appends a unique
 * timestamp suffix to trackId (so it doesn't collide with the original), tags
 * " (copy)" on the name, and regenerates each displayId to the canonical
 * `${trackId}-${type}` form baseTrackConfig auto-injects — keeping them unique
 * (displayId is a types.identifier, so a collision would crash MST).
 */
export declare function copyTrackSnapshot(config: BaseTrackConfig, opts: {
    clearCategory: boolean;
}): TrackCopySnapshot;
interface TrackActionSession<C> {
    editConfiguration: (config: AnyConfigurationModel | {
        trackId: string;
    }, opts?: {
        expandedDisplayId?: string;
    }) => void;
    publishTrackConf: (conf: C) => unknown;
    deleteTrackConf: (conf: AnyConfigurationModel) => void;
    resetTrackConfiguration?: (trackId: string) => void;
    /**
     * Declared here, though only the copy guard below reads it, so a session that
     * loses the list loses the guard *loudly*. `namesTemporaryAssembly` takes an
     * `unknown` session and answers false for one that holds no such list, which
     * is right for a caller that genuinely has none and wrong for one that let it
     * drop — and that second case is a copy action silently offered again.
     *
     * `unknown[]`, the spelling `AbstractSessionModel` already uses, and not the
     * `{ name?: string }[]` the guard narrows to: that one is a weak type, so a
     * real MST array of assembly configs — whose element type is an index
     * signature that declares no `name` — shares no property with it and TS
     * rejects the assignment. The shape belongs in the guard, which is the only
     * thing that reads it.
     */
    temporaryAssemblies?: unknown[];
}
/**
 * The shared Settings / Copy / Copy-and-open / Delete track actions. Each
 * product supplies `makeCopy` (its own session-track/category rules) and
 * `canEdit`; reference sequence tracks can't be copied or deleted. When
 * `isSessionOverride` is set the track is a session edit shadowing an
 * admin-owned config track, so the final action resets it instead of deleting.
 */
export declare function trackActionItems<C extends {
    trackId: string;
}>({ session, config, view, canEdit, isSessionOverride, makeCopy, }: {
    session: TrackActionSession<C>;
    config: BaseTrackConfig;
    view?: TrackActionView;
    canEdit: boolean;
    isSessionOverride?: boolean;
    makeCopy: () => C;
}): MenuItem[];
interface SessionWithDialog {
    queueDialog: (cb: (done: () => void) => [DialogComponentType, Record<string, unknown>]) => void;
}
type TrackConfig = AnyConfigurationModel | Record<string, unknown>;
/** "About track" menu item, shared by every product's track menu */
export declare function aboutTrackMenuItem(session: SessionWithDialog, config: TrackConfig): MenuItem;
/**
 * plugin-contributed per-track items (`Core-extraTrackMenuItems`), surfaced in
 * both the hierarchical selector and the in-view label menu so plugins reach
 * every track menu consistently
 */
export declare function pluginExtraTrackItems(pluginManager: PluginManager, session: SessionWithDialog, config: AnyConfigurationModel, view?: TrackActionView): MenuItem[];
/**
 * flattened track menu (About + raw actions) for the hierarchical track selector
 */
export declare function trackListMenuItems(session: SessionWithDialog, config: TrackConfig, actions: MenuItem[]): MenuItem[];
/**
 * track menu with an "About track" item and a "Track actions" submenu, for the
 * in-view track label menu
 */
export declare function trackActionMenuItems(session: SessionWithDialog, config: TrackConfig, actions: MenuItem[]): MenuItem[];
/**
 * #stateModel TrackMenuItemsSessionMixin
 *
 * The two track-menu wrappers (`getTrackListMenuItems` for the hierarchical
 * selector, `getTrackActionMenuItems` for the in-view label menu) shared by the
 * full web and desktop sessions. Both are pure functions of `getTrackActions`,
 * which each session supplies (web gates on edit rights; desktop adds indexing).
 */
export declare function TrackMenuItemsSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #method
     * flattened menu items for use in hierarchical track selector
     */
    getTrackListMenuItems(config: BaseTrackConfig, view?: TrackActionView): MenuItem[];
    /**
     * #method
     * track menu with About + "Track actions" submenu for the in-view label
     */
    getTrackActionMenuItems({ config, view, }: {
        config: BaseTrackConfig;
        view?: TrackActionView;
    }): MenuItem[];
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export {};
