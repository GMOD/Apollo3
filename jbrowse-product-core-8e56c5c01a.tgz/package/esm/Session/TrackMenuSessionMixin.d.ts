import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { MenuItem } from '@jbrowse/core/ui';
import type { TrackActionView } from '@jbrowse/core/util/types';
/**
 * #stateModel TrackMenuSessionMixin
 *
 * The minimal track menus used by the embedded react views, which have no
 * track-editing actions to offer: just "About track" plus any plugin-contributed
 * items (`Core-extraTrackMenuItems`). Mirrors the shape of the full
 * `TrackMenuItemsSessionMixin` so both menu surfaces stay consistent across
 * products, minus the Settings/Copy/Delete actions.
 */
export declare function TrackMenuSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #method
     * flattened menu items for use in hierarchical track selector
     */
    getTrackListMenuItems(config: AnyConfigurationModel, view?: TrackActionView): MenuItem[];
    /**
     * #method
     */
    getTrackActionMenuItems({ config, view, }: {
        config: AnyConfigurationModel;
        view?: TrackActionView;
    }): MenuItem[];
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
