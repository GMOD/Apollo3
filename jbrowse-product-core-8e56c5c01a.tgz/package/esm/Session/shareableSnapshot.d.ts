import type { AbstractSessionModel } from '@jbrowse/core/util';
/**
 * The session snapshot to hand to anyone else — a share link, an exported
 * `session.json`, a desktop→web export. Snapshotting and baking are one call so
 * the pair can't be split: a bare `getSnapshot(session)` is never a correct
 * outgoing snapshot (see `bakeSessionCascades`), and three of the four
 * boundaries were spelling the two steps out identically.
 *
 * The fourth (desktop `ExportToWebDialog`) bakes a *transformed* snapshot from
 * `planWebExport`, so it calls `bakeSessionCascades` directly.
 */
export declare function getShareableSessionSnapshot(session: AbstractSessionModel): Record<string, unknown>;
/**
 * Everything an outgoing snapshot has to resolve because the live session
 * resolves it at read time against state that is staying behind.
 *
 * Two such cascades, and they have nothing to do with each other — promoted
 * display-type defaults are per-track rendering, workspaces intent is the
 * session's layout mode. What they share is only this: both live partly in the
 * sender's own browser, so a raw `getSnapshot` records neither, and the
 * recipient silently resolves their own.
 *
 * They get one entry point rather than a call each because the failure of a
 * boundary that performs half of them is invisible at that boundary — the
 * export succeeds, and what is missing only shows up on someone else's screen.
 * Adding a third cascade should mean editing this function, not auditing four
 * call sites.
 */
export declare function bakeSessionCascades(session: AbstractSessionModel, snapshot: Record<string, unknown>): Record<string, unknown>;
/**
 * `getComputedStyle` for the promotable-default cascade.
 *
 * A track that "follows" a session-wide promoted display-type default holds no
 * value of its own — its rendered value is resolved at read time from the
 * promoted display-type defaults in `preferencesOverrides`, which are personal,
 * localStorage-backed, and deliberately never serialized into a shared session.
 * So a raw `getSnapshot(session)` records a track as at-default even when the
 * sender is looking at a promoted value, and the recipient (who lacks the sender's
 * preferences) sees something different. This flattens the live cascade into a
 * self-contained snapshot:
 *
 * Every slot an open display *inherits* from a promoted default (i.e.
 * `getDisplayTypeDefaultChanges` — non-customized, differs from base) is baked
 * into that track's config layer: its own config for a user-added or connection
 * track, else a `trackConfigDeltas` entry against the admin base (see
 * `ownTrackConfig`). So the concrete value travels with the document, and
 * because it lands in the track's config the recipient reads it as *customized*
 * — a customized value is the top of the cascade, so their own promoted defaults
 * never get consulted for it.
 *
 * **What this deliberately does not cover**, and the reason there is no flag
 * here: a slot the sender was viewing at its *base* value. Nothing is baked for
 * it (the value equals base, and `stripDefault` drops it from the snapshot
 * regardless), so a recipient who has promoted something else resolves it from
 * their own cascade and sees their value. There is no value that can express "I
 * deliberately saw the default" — at-base and unset are byte-identical once
 * stripped. That case used to be covered by stamping a per-display
 * `ignorePromotedDefaults` on every open display, which cost a second
 * shape-aware walk that had to stay in step with `openPromotableDisplays` by
 * hand, and permanently detached received tracks from the recipient's own pins
 * until they clicked "use this default" on each one. A promoted default is
 * personal and local — the same as the theme a session is viewed in, which this
 * function has never baked either.
 *
 * The live session is untouched; a modified deep copy of `snapshot` is returned.
 * Tracks the sender never opened carry no display state to resolve, so they're
 * left to pick up the recipient's defaults when opened — matching "export the
 * actual state of the (open) tracks".
 *
 * Reach is `openPromotableDisplays` — literally the same walk the cascade's own
 * "apply to open tracks" uses, so the two can't drift. It recurses into a
 * composite view's `views` array (breakpoint-split, the linear-comparative /
 * synteny family), which holds child views rather than tracks of its own —
 * `LGVSyntenyDisplay` is only reachable that way, and before the recursion a
 * shared session containing one rendered differently for the recipient.
 */
export declare function bakePromotedDefaultsIntoSnapshot(session: AbstractSessionModel, snapshot: Record<string, unknown>): Record<string, unknown>;
