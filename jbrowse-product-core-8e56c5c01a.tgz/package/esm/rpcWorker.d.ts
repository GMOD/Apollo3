import { RpcServer } from '@jbrowse/core/util/librpc';
import type { PluginConstructor } from '@jbrowse/core/Plugin';
import type { LoadedPlugin } from '@jbrowse/core/PluginLoader';
declare global {
    interface Window {
        rpcServer?: RpcServer;
    }
}
type RpcFunc = (args: unknown) => Promise<unknown>;
/**
 * Wire the method's `statusCallback` to the status channel the driver opened
 * for this call — and to nothing at all when it opened none.
 *
 * The `channel` is the driver's statement of whether anyone is listening
 * (`WebWorkerHandle.call`), so a method run without one has to see the
 * `undefined` its caller passed. Injecting a callback regardless made every
 * "no statusCallback" branch in the worker unreachable: the byte reporter an
 * adapter hands its reader, the emit `createProgressReporter` gates, and the
 * postMessage each of those cost to reach a main-thread listener that dropped
 * it.
 *
 * `channel` is transport bookkeeping and comes back OFF here, the mirror of
 * `BaseRpcDriver.call` stripping `statusCallback` on the way out. It used to
 * ride through into every worker method's arguments, where nothing read it and
 * `RpcExecuteArgs<M>` did not declare it — a key the main-thread driver never
 * adds, so the two drivers handed `execute` different bags. `rpcDriverParity`
 * is what says so.
 *
 * Exported for its test and not from the package barrel: `initializeWorker` is
 * the only thing a product's worker entry calls, and the branch here is a claim
 * about the driver on the other side of postMessage that nothing else asserts.
 */
export declare function wrapForRpc(func: RpcFunc): (args: unknown) => Promise<unknown>;
export declare function initializeWorker(corePlugins: PluginConstructor[], opts: {
    fetchESM?: (url: string) => Promise<LoadedPlugin>;
    fetchCJS?: (url: string) => Promise<LoadedPlugin>;
}): Promise<void>;
export {};
