export type AssemblyConfig = Record<string, unknown>;
export interface TextSearchAdapterConfig {
    textSearchAdapterId: string;
    [key: string]: unknown;
}
type SearchAdapters = TextSearchAdapterConfig[] | undefined;
/**
 * The shapes an assembly can take, discriminated at resolve time: a sequence
 * file URL (`'.../hg38.fa.gz'`, `.2bit`, ...) built into an assembly via
 * `makeAssembly`; a hub name (`'hg38'`, `'GCF_...'`) fetched from jbrowse.org;
 * a full hub config (as `fetchHub` returns); or a bare assembly config (e.g.
 * from `makeAssembly`) — the latter two both being plain config objects.
 */
export type AssemblyInput = string | AssemblyConfig;
export interface ResolvedAssembly {
    assembly: AssemblyConfig;
    /** whatever search adapters the hub this came from carried */
    aggregateTextSearchAdapters?: SearchAdapters;
}
export interface ResolvedAssemblies {
    assemblies: AssemblyConfig[];
    /** whatever search adapters the resolved hubs carried, merged */
    aggregateTextSearchAdapters?: SearchAdapters;
}
/** One assembly in any of the four accepted shapes. */
export declare function resolveAssembly(input: AssemblyInput): Promise<ResolvedAssembly>;
/**
 * Resolve a whole list of assembly inputs, so a multi-assembly product takes
 * the same vocabulary the single-view one does — `['hg38', 'mm39']` as readily
 * as two hand-written configs.
 *
 * Exported because the resolution is async and `createApp` is not: an engine
 * that resolved its own genomes would have to hand back a controller whose
 * `viewState` is undefined until the fetches land, which is most of what makes
 * the single-view controller four times the size. A host builds its options
 * asynchronously already (runtime plugins), so this belongs in that step.
 *
 * Without it every host reimplements it — jbrowse-anywidget carried a
 * line-for-line Python translation of core's hubUrl/fetchHub/addRelativeUris,
 * GenArk regex and all, purely because the multi-view product could not take a
 * hub name.
 */
export declare function resolveAssemblies(inputs: AssemblyInput[]): Promise<ResolvedAssemblies>;
export {};
