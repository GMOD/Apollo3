import type { SessionWithMultipleViews } from '../Session/index.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { MenuItem } from '@jbrowse/core/ui';
import type { DialogComponentType } from '@jbrowse/core/util';
interface RootWithDefaultSession {
    setDefaultSession: () => void;
}
export declare function newSessionMenuItem(root: RootWithDefaultSession): MenuItem;
export declare function importSessionMenuItem(): MenuItem;
export declare function exportSessionMenuItem(): MenuItem;
export declare function openTrackMenuItem(): MenuItem;
export declare function openConnectionMenuItem(): MenuItem;
export declare function pluginStoreMenuItem(): MenuItem;
export declare function preferencesMenuItem(pluginManager: PluginManager, PreferencesDialog: DialogComponentType): MenuItem;
interface HistoryManager {
    canUndo: boolean;
    canRedo: boolean;
    undo(): void;
    redo(): void;
}
export declare function undoMenuItem(history: HistoryManager): MenuItem;
export declare function redoMenuItem(history: HistoryManager): MenuItem;
export declare function workspacesMenuItem(session: SessionWithMultipleViews | undefined): MenuItem;
export {};
