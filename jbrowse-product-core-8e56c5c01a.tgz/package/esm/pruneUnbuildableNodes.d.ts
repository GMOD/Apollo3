import type PluginManager from '@jbrowse/core/PluginManager';
/**
 * A session snapshot that arrives from somewhere else — a share link, a desktop
 * "export to web" URL, a session.json — can name a pluggable type this build has
 * no plugin for. Every such collection is `types.map`/`types.array` over a bare
 * `pluggableMstType` union with no dispatcher, so one entry the union cannot
 * match throws `No type is applicable for the union` out of the `cast` in
 * `setSession` — outside the try that `filterSessionInPlace` sits in. The whole
 * session is lost, and jbrowse-web's fallback then advises the recipient to ask
 * for a link made with the Share button, which is often exactly what they were
 * sent.
 *
 * Two routes reach it and neither is exotic. A desktop export carries session
 * state built from desktop's own core plugins — `blat` registers
 * `UcscResultsWidget`, and every BLAT or in-silico PCR search leaves one in the
 * drawer — which jbrowse-web does not have (see
 * `scripts/check-core-plugin-sets.ts` for the exact relation between the
 * products' lists). And a runtime plugin that fails to load is already
 * tolerated: `notifyPluginLoadFailures` says the session opens without it, which
 * was untrue for any session actually using its types.
 *
 * So the type is dropped and the session opens. `dropped` is what the caller
 * tells the user, which is the only part of this a person can act on.
 *
 * **A node is dropped only when both tests fail**: its `type` names no
 * registered element, AND the real MST union refuses the snapshot. The second
 * test is what keeps a renamed type alive — a DisplayType can declare `aliases`,
 * and a model's own `preProcessSnapshot` can rewrite the type literal
 * (`LinearMultiSampleVariantDisplay` does both for the old
 * `MultiLinearVariantDisplay`), neither of which the registry's names show. The
 * first test is what keeps this from quietly swallowing a *malformed* snapshot
 * of a type this build does have: that still throws, exactly as before, because
 * a silent drop there would hide a real bug behind a message about plugins.
 */
type PrunedGroup = 'widget' | 'view' | 'track' | 'display';
export interface UnbuildableNode {
    group: PrunedGroup;
    type: string;
    cascade?: true;
}
/**
 * Drops the session-snapshot nodes whose pluggable type this plugin manager
 * cannot build, returning the snapshot unchanged (by identity) when there are
 * none — which is every session this build produced itself.
 */
export declare function pruneUnbuildableNodes(snapshot: Record<string, unknown>, pluginManager: PluginManager): {
    snapshot: Record<string, unknown>;
    dropped: UnbuildableNode[];
};
/**
 * The user-facing summary of one prune, or undefined when nothing was dropped.
 * Names the missing types rather than counting nodes: the plugin a person has to
 * install is the actionable half, and one missing display type can take several
 * nodes with it.
 */
export declare function describeUnbuildableNodes(dropped: UnbuildableNode[]): string | undefined;
export {};
