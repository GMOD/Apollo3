import type { LinearGenomeViewModel } from './LinearGenomeView/index.ts';
export declare const LinearGenomeView: {
    (props: {
        model: LinearGenomeViewModel;
    }): import("react").JSX.Element;
    displayName: string;
};
export declare const SearchBox: {
    (props: {
        model: LinearGenomeViewModel;
        showHelp?: boolean;
        minWidth?: number;
        maxWidth?: number;
        style?: React.CSSProperties;
    }): import("react").JSX.Element;
    displayName: string;
};
export declare const ZoomControls: {
    (props: {
        model: LinearGenomeViewModel;
    }): import("react").JSX.Element;
    displayName: string;
};
