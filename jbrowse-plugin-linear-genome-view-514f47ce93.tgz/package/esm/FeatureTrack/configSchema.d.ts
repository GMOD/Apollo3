import type PluginManager from '@jbrowse/core/PluginManager';
/**
 * #config FeatureTrack
 * #category track
 * used for basic gene and feature tracks, generally used with LinearBasicDisplay
 *
 * #example
 * A minimal hand-authored entry in the top-level `tracks` array — `adapter`
 * points at the data file, and the track opens with a `LinearBasicDisplay`:
 * ```js
 * {
 *   type: 'FeatureTrack',
 *   trackId: 'genes',
 *   name: 'Genes',
 *   assemblyNames: ['hg38'],
 *   adapter: {
 *     type: 'Gff3TabixAdapter',
 *     uri: 'https://example.com/genes.sorted.gff.gz',
 *   },
 * }
 * ```
 *
 * #example
 * The same track, colored. Rather than writing out the full `displays` array,
 * you can put appearance settings in a `displayDefaults` object — JBrowse works
 * out which display they belong to and applies them for you (here, the track's
 * `LinearBasicDisplay`), so you don't have to know display names. A `jexl:`
 * value gives per-feature coloring:
 * ```js
 * {
 *   type: 'FeatureTrack',
 *   trackId: 'genes',
 *   name: 'Genes',
 *   assemblyNames: ['hg38'],
 *   adapter: {
 *     type: 'Gff3TabixAdapter',
 *     uri: 'https://example.com/genes.sorted.gff.gz',
 *   },
 *   displayDefaults: { color: "jexl:feature.type=='CDS'?'red':'blue'" },
 * }
 * ```
 */
declare const configSchema: (pluginManager: PluginManager) => import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly name: {
        readonly description: "descriptive name of the track, falls back to the trackId when unset";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly assemblyNames: {
        readonly description: "name of the assembly (or assemblies) track belongs to";
        readonly type: "stringArray";
        readonly defaultValue: readonly ["assemblyName"];
    };
    readonly description: {
        readonly description: "a description of the track";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly category: {
        readonly description: "the category and sub-categories of a track";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
    readonly metadata: {
        readonly type: "frozen";
        readonly description: "anything to add about this track";
        readonly defaultValue: {};
    };
    readonly adapter: import("@jbrowse/mobx-state-tree").IAnyType;
    readonly textSearching: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly indexingAttributes: {
            readonly type: "stringArray";
            readonly description: "list of which feature attributes to index for text searching";
            readonly defaultValue: readonly ["Name", "ID", "symbol"];
        };
        readonly indexingFeatureTypesToExclude: {
            readonly type: "stringArray";
            readonly description: "list of feature types to exclude in text search index";
            readonly defaultValue: readonly ["CDS", "exon"];
        };
        readonly textSearchAdapter: import("@jbrowse/mobx-state-tree").IAnyType;
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly displays: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    readonly formatDetails: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly feature: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the feature details";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        readonly subfeatures: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the subfeatures of a feature";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        readonly depth: {
            readonly type: "maybeNumber";
            readonly description: "levels of subfeature the formatDetails.subfeatures callback runs on, default 2";
        };
        readonly maxDepth: {
            readonly type: "maybeNumber";
            readonly description: "hide subfeatures nested deeper than this, default no limit";
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly formatAbout: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly config: {
            readonly type: "frozen";
            readonly description: "formats configuration object in about dialog";
            readonly defaultValue: {};
            readonly contextVariable: ["config"];
        };
        readonly hideUris: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "trackId">>, "trackId">>;
export default configSchema;
