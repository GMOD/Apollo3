import type { LinearGenomeViewModel } from './model.ts';
export declare const Header: {
    (props: {
        model: LinearGenomeViewModel;
    }): import("react").JSX.Element;
    displayName: string;
};
export declare const MiniControls: {
    (props: {
        model: LinearGenomeViewModel;
    }): import("react").JSX.Element;
    displayName: string;
};
