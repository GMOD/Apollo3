import type { LinearGenomeViewModel } from './model.ts';
import type { BpOffset } from './types.ts';
import type { MenuItem } from '@jbrowse/core/ui';
/**
 * The scroll-to-zoom toggle, shared by the view menu and the header's zoom menu
 * so the two can't drift apart in label or wording.
 *
 * Both places earn it. The zoom menu is where someone already fiddling with
 * zoom will look, and it is where this belongs on the merits; the view menu is
 * the only one of the two that survives `hideHeader`, since MiniControls
 * renders `menuItems()` and not the header's zoom controls.
 *
 * Writes a *session* preference, not view state — every wheel-zoom view in the
 * app follows it (see BaseSession's `scrollZoom`).
 */
export declare function scrollZoomMenuItem(self: LinearGenomeViewModel): MenuItem;
/**
 * Build the main view menu items
 */
export declare function buildMenuItems(self: LinearGenomeViewModel): MenuItem[];
/**
 * Build rubberband selection menu items. `launchItems` are the plugin-supplied
 * things a selection can start (`rubberBandLaunchMenuItems()`); they collect
 * under one "Launch" submenu so the menu stays three actions plus a group
 * however many plugins are loaded, and vanish entirely when none apply.
 */
export declare function buildRubberBandMenuItems(self: LinearGenomeViewModel, launchItems: MenuItem[]): MenuItem[];
/**
 * Build rubberband click menu items (single click on rubberband area)
 */
export declare function buildRubberbandClickMenuItems(self: LinearGenomeViewModel, clickOffset: BpOffset): MenuItem[];
