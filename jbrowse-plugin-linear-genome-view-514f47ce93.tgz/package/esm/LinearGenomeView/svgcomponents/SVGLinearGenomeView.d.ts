import type { LinearGenomeViewModel } from '../index.ts';
import type { ExportSvgOptions } from '../types.ts';
type LGV = LinearGenomeViewModel;
export declare function renderToSvg(model: LGV, opts: ExportSvgOptions): Promise<string>;
export {};
