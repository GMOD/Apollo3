import type { LinearGenomeViewModel } from '../index.ts';
import type { TrackLabelMode } from '../types.ts';
import type { SvgDisplayResult } from './util.ts';
import type { ReactNode } from 'react';
export default function SVGView({ view, displayResults, header, fontSize, textHeight, trackLabels, trackLabelOffset, contentTop, tracksHeight, showGridlines, leftBuffer, legendWidth, }: {
    view: LinearGenomeViewModel;
    displayResults: SvgDisplayResult[];
    header: ReactNode;
    fontSize: number;
    textHeight: number;
    trackLabels: TrackLabelMode;
    trackLabelOffset: number;
    contentTop: number;
    tracksHeight: number;
    showGridlines: boolean;
    leftBuffer?: number;
    legendWidth?: number;
}): import("react").JSX.Element;
