import type { LinearGenomeViewModel } from '../index.ts';
export default function SVGRowHeader({ view, fontSize, rulerHeight, showAssemblyName, showScalebar, }: {
    view: LinearGenomeViewModel;
    fontSize: number;
    rulerHeight: number;
    showAssemblyName?: boolean;
    showScalebar?: boolean;
}): import("react").JSX.Element;
