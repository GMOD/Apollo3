import type { LinearGenomeViewModel } from '../index.ts';
import type { TrackLabelMode } from '../types.ts';
import type React from 'react';
/** What a figure's shape is, where JBrowse has no opinion of its own. */
export interface ViewSvgFigureOptions {
    fontSize?: number;
    rulerHeight?: number;
    trackLabels?: TrackLabelMode;
    showGridlines?: boolean;
    /** the capped bar labelled with the span, above the ruler */
    showScalebar?: boolean;
    /**
     * Paint each display's heavy layer to a canvas and embed a PNG instead of
     * emitting vector elements. The point of an inline figure is usually the
     * opposite, but a hundred-thousand-read pileup is a lot of DOM.
     */
    rasterizeLayers?: boolean;
    /** gutter on each side, for content drawn outside the genome area */
    margin?: number;
    /** a named theme, as the export dialog's picker passes */
    themeName?: string;
}
export interface ViewSvgFigureResult {
    /**
     * The figure, ready to render. Frozen against the snapshot it was built from
     * (see the note above), so re-rendering the component that holds it cannot
     * make its chrome disagree with its track bodies.
     */
    figure: React.ReactNode;
    /**
     * Dimensions of the figure, for a host reserving its space — of the *last*
     * one drawn while a redraw is in flight, since a reservation that went
     * undefined between figures would collapse the box and walk the page.
     */
    width: number | undefined;
    height: number | undefined;
    /** the locus it is a picture of, for a caption */
    locstring: string | undefined;
    /**
     * Names of visible tracks left out, because their display type implements no
     * `renderSvg`. Not an error — a third-party display that has skipped a
     * substantial extra implementation should cost its own track a place in the
     * figure rather than cost the whole export — but not nothing either, since a
     * figure quietly one track short is indistinguishable afterwards from a figure
     * of a view that had one fewer. Say it somewhere.
     */
    skipped: string[];
    error: unknown;
    isLoading: boolean;
}
/**
 * A live SVG figure of a linear genome view, redrawn as the view settles
 * somewhere new.
 *
 * ```tsx
 * const { figure, isLoading, skipped } = useViewSvgFigure(view)
 * return <div>{figure}</div>
 * ```
 *
 * The data is the display's own — whatever it has already fetched for the
 * screen — so a figure costs no requests.
 *
 * `useFetch` under it, which is what discards a redraw that lands after the pan
 * that overtook it, and what makes a theme change *clear* the figure while a pan
 * only replaces it: a key change drops the stale data, where a refetch under the
 * same key would leave it up. Both are right. A figure the reader panned away
 * from is still a legible picture of somewhere; one baked in the other mode is
 * light-grey feature labels on a white page.
 */
export declare function useViewSvgFigure(view: LinearGenomeViewModel, { fontSize, rulerHeight, trackLabels, showGridlines, showScalebar, rasterizeLayers, margin, themeName, }?: ViewSvgFigureOptions): ViewSvgFigureResult;
