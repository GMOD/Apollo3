import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function SVGRuler({ model, rulerHeight, }: {
    model: LGV;
    rulerHeight: number;
}): import("react").JSX.Element;
export {};
