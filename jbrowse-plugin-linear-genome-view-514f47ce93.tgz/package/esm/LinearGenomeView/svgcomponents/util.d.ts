import type { TrackLabelMode } from '../types.ts';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { AbstractSessionModel } from '@jbrowse/core/util';
import type { ReactNode } from 'react';
interface TrackHeights {
    displays: {
        height: number;
    }[];
}
export interface SvgDisplayResult {
    track: {
        configuration: AnyConfigurationModel;
        displays: {
            height: number;
        }[];
    };
    result: ReactNode;
}
export declare const trackSpacing = 2;
export declare function gridlineTickXs(model: {
    staticBlocksTranslateX: number;
    gridlineTicks: {
        major: boolean;
        x: number;
    }[];
}): {
    dx: number;
    major: number[];
    minor: number[];
};
export declare function vlinePath(xs: number[], y1: number, y2: number): string;
export declare function labelInkHeight(fontSize: number): number;
/**
 * Baseline y for a label whose ink box should start at `topY` — roughly what
 * `dominantBaseline="hanging"` asks the renderer for, but resolved here.
 *
 * Not a renderer-compatibility workaround (`dominant-baseline` is well
 * supported, and SvgCanvas emits it on every feature label it writes). The
 * point is that this file already *models* the ink box, in LABEL_INK_EM /
 * LABEL_DESCENT_EM, and reserves vertical space from that model —
 * `getHeaderLayout` budgets `labelInkHeight(fontSize)` for the scalebar's bp
 * label, `defaultTextHeight` for an offset track label. A label placed with
 * `hanging` is instead positioned by the renderer's own notion of the font's
 * ascent, so the space reserved and the space used come from two different
 * models that merely happen to agree closely at the sizes we ship. Resolving
 * the baseline from the same constants makes them one model, which is what lets
 * util.test.ts check placement against reservation at all.
 */
export declare function labelBaselineFromTop(topY: number, fontSize: number): number;
export declare function defaultTextHeight(fontSize: number): number;
export declare function offsetLabelBaselineY(textHeight: number, fontSize: number): number;
export declare function insetLabelBaselineY(fontSize: number): number;
export declare function getRowHeaderLayout({ fontSize, showScalebar, }: {
    fontSize: number;
    showScalebar: boolean;
}): {
    scalebarLineY: number | undefined;
    assemblyLabelBaselineY: number;
    bandHeight: number;
};
export declare function getHeaderLayout({ fontSize, showCytobands, rulerHeight, }: {
    fontSize: number;
    showCytobands: boolean;
    rulerHeight: number;
}): {
    assemblyLabelBaselineY: number;
    cytobandTop: number;
    scalebarLineY: number;
    rulerTop: number;
    tracksTop: number;
};
export declare const RULER_MAJOR_TICK = 5;
export declare const RULER_MINOR_TICK = 3;
export declare const RULER_TICK_FONT_SIZE = 11;
export declare function getRulerLayout(rulerHeight: number): {
    tickTopY: number;
    numbersBaselineY: number;
};
export declare const refNameLabelBoxHeight: number;
export declare const refNameLabelBaselineY: number;
export declare function labelOffset(trackLabels: TrackLabelMode, textHeight: number): number;
export declare const TRACK_LABEL_GAP = 40;
export declare function trackLabelLeftOffset({ tracks, trackLabels, fontSize, fontFamily, session, }: {
    tracks: {
        configuration: AnyConfigurationModel;
    }[];
    trackLabels: TrackLabelMode;
    fontSize: number;
    fontFamily?: string;
    session: AbstractSessionModel;
}): number;
export declare function trackBoxHeight(track: TrackHeights, textOffset: number): number;
export declare function trackBoxOffsets(tracks: TrackHeights[], textOffset: number): number[];
export declare function totalHeight(tracks: TrackHeights[], textHeight: number, trackLabels: TrackLabelMode): number;
export {};
