import type { LinearGenomeViewModel } from './model.ts';
/**
 * Sets up keyboard shortcuts for the LinearGenomeView
 * - Ctrl/Cmd + ArrowLeft: slide left
 * - Ctrl/Cmd + ArrowRight: slide right
 * - Ctrl/Cmd + ArrowUp: zoom in
 * - Ctrl/Cmd + ArrowDown: zoom out
 */
export declare function setupKeyboardHandler(self: LinearGenomeViewModel): void;
