import BaseResult from '@jbrowse/core/TextSearch/BaseResults';
import type { MenuItem, RecentLocation } from '@jbrowse/core/ui';
/**
 * What a navigated result is worth remembering as. The display string is what
 * the row shows; the location is what reopening it opens, and is absent for a
 * freehand query, whose label is the searchable thing. Paired with the
 * `BaseResult` the menu rebuilds below so the round trip stays visible in one
 * place: a row replayed through it records the same pair it came from.
 */
export declare function recentLocationOf(option: BaseResult): RecentLocation;
export declare function recentLocationsMenu({ recentLocations, onNavigate, onClear, }: {
    recentLocations: RecentLocation[];
    onNavigate: (option: BaseResult) => void;
    onClear: () => void;
}): MenuItem[];
