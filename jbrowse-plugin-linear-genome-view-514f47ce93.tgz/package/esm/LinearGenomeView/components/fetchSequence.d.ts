import type { StatusCallback } from '@jbrowse/core/util';
import type { StopToken } from '@jbrowse/core/util/stopToken';
import type { Region } from '@jbrowse/core/util/types';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function fetchSequence(model: IAnyStateTreeNode, regions: Region[], opts?: {
    stopToken?: StopToken;
    statusCallback?: StatusCallback;
}): Promise<import("@jbrowse/core/util").Feature[]>;
