import type { LinearGenomeViewModel } from '../../index.ts';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
export default function SearchResultsDialog({ model, assemblyName, searchQuery, searchResults, handleClose, }: {
    model: LinearGenomeViewModel;
    assemblyName: string;
    searchQuery: string;
    searchResults: BaseResult[];
    handleClose: () => void;
}): import("react").JSX.Element;
