import type { Assembly } from '@jbrowse/core/assemblyManager/assembly';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
export { getHighlightColor, highlightKey } from '@jbrowse/core/util/highlights';
export declare const elidedBlockStyles: {
    readonly backgroundColor: '#999';
    readonly backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 1px, rgba(255,255,255,.5) 1px, rgba(255,255,255,.5) 3px)';
};
export type Cytoband = ReturnType<typeof getCytobands>[number];
export declare function getCytobands(assembly: Assembly | undefined, refName: string): {
    refName: string;
    start: number;
    end: number;
    type: string;
    name: string | undefined;
}[];
/**
 * The bp under a pixel of the overview strip. The strip spans the whole view,
 * but the overview *layout* is laid out in the pixels after the chromosome-name
 * gutter (cytobandOffset), so a press or hover on that gutter sits left of the
 * layout's own origin. `pxToBp` extrapolates there rather than refusing, and
 * every overview reader took it at face value: the hover and rubberband labels
 * read out an impossible "ctgA:-12,345,678", and a click did nothing at all,
 * silently, because `centerAt` cannot resolve a coordinate that is in no region.
 * Clamping into the layout's own span makes all three name the genome's start,
 * which is what the gutter is adjacent to.
 */
export declare function overviewPxToBp(overview: ViewLayout, px: number, cytobandOffset: number): import("@jbrowse/core/util/Base1DUtils").PxToBpResult;
export declare function shouldSwapTracks(lastSwapY: number | undefined, currentY: number, movingDown: boolean): boolean;
