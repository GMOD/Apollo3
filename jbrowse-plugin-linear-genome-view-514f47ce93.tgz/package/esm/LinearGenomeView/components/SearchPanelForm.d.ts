import type { ReactNode } from 'react';
export default function SearchPanelForm({ onSubmit, handleClose, submitDisabled, submitText, actions, children, }: {
    onSubmit: () => void;
    handleClose: () => void;
    submitDisabled: boolean;
    submitText?: string;
    actions?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
