import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
/**
 * The track label's warning for a file whose reference names have nothing in
 * common with the assembly's — the commonest data-configuration mistake in
 * JBrowse, and until now a silent one: the track draws nothing and reads
 * exactly like a track with no features in view.
 *
 * The label rather than the display chrome, deliberately. The chrome's states
 * are `displayPhase`'s, which are mutually exclusive and two of which replace
 * the display's subtree; a mismatch is neither an error to retry nor a phase to
 * be in, and routing it through `model.error` would put a red banner and a dead
 * Retry over a track that, if the check is ever wrong, is drawing fine. This
 * sits next to the track's own close/minimize buttons, costs the display
 * nothing, and reaches every track type at once.
 *
 * The tooltip is the summary and the dialog is the disclosure — a hover nobody
 * performs is not a way of telling someone their data is misconfigured.
 */
declare const TrackLabelRefNameWarning: ({ track, }: {
    track: BaseTrackModel;
}) => import("react").JSX.Element | null;
export default TrackLabelRefNameWarning;
