import type { LinearGenomeViewModel } from '../index.ts';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
/**
 * The "you are here" connector: a trapezoid joining the visible region's extent
 * in the overview (top edge) to that same extent in the main view (bottom
 * edge). Both edges come from one pixel extent, so they always describe the
 * same regions — including elided ones.
 *
 * @param overviewOffsetPx - pixels the overview is shifted right of the main
 * view's origin. In the interactive view the overview clears the chromosome-
 * name gap (cytobandOffset); in SVG export it is flush (0).
 * @param exportSvg - serialize explicit fill/stroke attributes (the split the
 * `getFill/StrokeProps` helpers exist for) instead of the on-screen CSS class,
 * which wouldn't survive into a standalone exported SVG.
 */
declare const OverviewScalebarPolygon: ({ model, overview, overviewOffsetPx, exportSvg, }: {
    model: LinearGenomeViewModel;
    overview: ViewLayout;
    overviewOffsetPx?: number;
    exportSvg?: boolean;
}) => import("react").JSX.Element | null;
export default OverviewScalebarPolygon;
