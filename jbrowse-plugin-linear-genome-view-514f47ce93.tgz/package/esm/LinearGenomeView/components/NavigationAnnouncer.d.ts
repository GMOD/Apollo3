import type { LinearGenomeViewModel } from '../index.ts';
/**
 * The one thing that tells a screen-reader user a pan, a zoom or a search
 * actually moved the view: a polite live region restating where the view now is.
 *
 * **It reads `coarseVisibleLocStrings`, never `visibleLocStrings`**, and that is
 * the whole design. The fine one changes on every `offsetPx` write — every frame
 * of a drag, a wheel zoom or a keyboard slide — and a live region driven by it
 * queues an utterance per frame, which does not merely say too much: it makes
 * the screen reader unusable for as long as the drag lasts, because polite
 * announcements are a queue rather than a latest-value. The coarse blocks are
 * already the view's settled signal, published by a `delay: 500` autorun
 * (`setupCoarseDynamicBlocksAutorun`) and flushed synchronously by `moveTo` so a
 * discrete jump — a search, a bookmark, `navToLocString` — announces at once
 * instead of 500ms later. Both properties are what this needs, so this adds no
 * timer of its own; if the debounce ever moves, this moves with it.
 *
 * Its own observer so the view container does not re-render when the locus
 * settles: this component is a text node with no children, and the container
 * mounts every track.
 *
 * The region is rendered with its text from the first render rather than being
 * filled after mount. A live region whose content is present when the node is
 * inserted is generally not announced (the region has to exist before the
 * change), so in practice a freshly-mounted view says nothing; where a reader
 * does announce it, "chr1:1..1,000" as the view appears is a fair thing to hear,
 * and it is one utterance per view rather than one per frame.
 */
declare const NavigationAnnouncer: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default NavigationAnnouncer;
