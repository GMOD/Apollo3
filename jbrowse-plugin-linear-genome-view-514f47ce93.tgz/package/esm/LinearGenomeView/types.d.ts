import type { LinearGenomeViewStateModel } from './model.ts';
import type { HighlightType } from '@jbrowse/core/util/highlights';
import type { TrackInit } from '@jbrowse/core/util/tracks';
import type { SnapshotIn } from '@jbrowse/mobx-state-tree';
export interface BpOffset {
    refName?: string;
    index: number;
    offset: number;
    start?: number;
    end?: number;
    coord?: number;
    reversed?: boolean;
    assemblyName?: string;
    oob?: boolean;
}
export type TrackLabelMode = 'offset' | 'overlay' | 'left' | 'none';
export interface ExportSvgOptions {
    rasterizeLayers?: boolean;
    format?: 'svg' | 'png';
    filename?: string;
    Wrapper?: React.FC<{
        children: React.ReactNode;
    }>;
    fontSize?: number;
    rulerHeight?: number;
    textHeight?: number;
    trackLabels?: TrackLabelMode;
    themeName?: string;
    fontFamily?: string;
    showGridlines?: boolean;
    createCanvas?: (width: number, height: number) => HTMLCanvasElement;
}
export type { HighlightType };
export interface NavLocation {
    refName: string;
    start?: number;
    end?: number;
    assemblyName?: string;
}
export interface VolatileGuide {
    xPos: number;
}
export interface InitState {
    /**
     * A locstring, or several separated by spaces to open a discontinuous view:
     * `'chr3:25,325,000-25,361,000 chr10:58,716,500-58,718,500'`. Multiple
     * regions are the only declarative way to frame something spread across loci
     * (a derivative allele against its sources, a gene's partners in a fusion) --
     * `displayedRegionNames` takes whole chromosomes, not intervals.
     */
    loc?: string;
    grow?: number;
    assembly: string;
    displayedRegionNames?: string[];
    tracks?: TrackInit[];
    tracklist?: boolean;
    nav?: boolean;
    highlight?: (string | HighlightType)[];
}
export type LinearGenomeViewLaunchProps = Partial<Omit<SnapshotIn<LinearGenomeViewStateModel>, keyof InitState | 'id' | 'type' | 'init'>>;
