export declare const LABEL_WIDTH = 100;
/**
 * The bp coordinate under a vertical guide, drawn just above the top of the
 * guide line so it covers neither the line nor the cursor hovering the scalebar
 * the line starts at.
 *
 * A zero-height anchor marks that spot in the flow (`stickyTop` pins it to the
 * scalebar it rides once that scrolls away) but the label itself portals to the
 * body: sitting above the guide means sitting above the top of the tracks
 * container, and that container's `contain: layout` traps its children in a
 * stacking context the sticky LGV header (z-index 850, opaque background)
 * paints over. So the anchor's viewport position is measured and the label
 * placed at fixed coordinates outside it.
 *
 * Deliberately not a MUI Tooltip: it is permanently open and re-renders on
 * every pan frame, and an open popper re-runs its whole modifier chain (~17
 * getBoundingClientRect calls) on every render of its parent, since MUI's
 * `BasePopper` calls `forceUpdate()` from a dep-less effect. Here the anchor is
 * measured once per hover, not per mousemove — only `coordX` changes as the
 * mouse moves, and that needs no measurement.
 */
export declare function GuideLabel({ coordX, viewWidth, stickyTop, children, }: {
    coordX: number;
    viewWidth: number;
    stickyTop: number | undefined;
    children: React.ReactNode;
}): import("react").JSX.Element;
/**
 * The bp coordinates of a rubberband selection, one label just outside each edge
 * of the span. Renders inside the span, so the edges are its own box. A label
 * with no room outside its edge flips inside instead, which is why the span it
 * has to fit in is a prop.
 */
export declare function SpanEdgeLabels({ stickyTop, left, right, insideLeft, insideRight, }: {
    stickyTop: number | undefined;
    left: React.ReactNode;
    right: React.ReactNode;
    insideLeft: boolean;
    insideRight: boolean;
}): import("react").JSX.Element;
