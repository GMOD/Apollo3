/**
 * The selection band of a rubberband drag, with its bp coordinates at the edges
 * and an optional size in the middle. Callers format their own text, since a
 * single view reads one coordinate per edge and the multi-level rubberband reads
 * one per level.
 */
export default function RubberbandSpan({ left, width, viewWidth, stickyTop, leftLabel, rightLabel, size, }: {
    left: number;
    width: number;
    viewWidth: number;
    stickyTop: number | undefined;
    leftLabel: React.ReactNode;
    rightLabel: React.ReactNode;
    size?: React.ReactNode;
}): import("react").JSX.Element;
