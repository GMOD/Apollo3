import type { HeightMode } from './heightMode.ts';
import type { ResolvableDisplay } from '@jbrowse/core/configuration';
import type { MenuItem } from '@jbrowse/core/ui';
export type HeightModeMenuModel = ResolvableDisplay & {
    heightMode: HeightMode;
    setHeightMode: (mode: HeightMode) => void;
};
export declare function heightModeMenuItems(model: HeightModeMenuModel, noun: string): MenuItem[];
