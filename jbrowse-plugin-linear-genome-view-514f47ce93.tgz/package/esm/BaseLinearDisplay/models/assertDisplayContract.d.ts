import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Dev-only check of the display contracts that no type expresses and whose
 * violation is silent. No-op in production.
 *
 * Called once per display from **whichever fetch foundation installed its
 * autoruns** — `MultiRegionDisplayMixin`'s `afterAttach` for the per-region
 * family, `installGlobalFetchAutorun` for the global one. It was per-region
 * only until 2026-08, which left the family with *fewer* safety nets
 * unchecked: HiC and LD both define `rpcProps()`, `installGlobalFetchAutorun`
 * serializes it into the autorun's trigger list, and an `rpcProps` declared in
 * `.actions()` there fails exactly the same way — reads register no
 * dependency, so a settings change stops invalidating — with no
 * `makeSettingsLoopGuard` on that side to catch anything either.
 *
 * `installedBy` names the caller so the double-install message can describe the
 * right thing; the WeakSet is shared, which is correct — a display composes one
 * fetch foundation, so reaching here twice is the bug regardless of which.
 *
 * ARCHITECTURAL_LIMITS.md §"Ordering is the contract" asks for exactly this —
 * "each order becomes explicit data … `makeSettingsLoopGuard` is this move
 * already applied to the `rpcProps` loop trap. Generalize it." That doc's "Now
 * checked" list is the authoritative account of which contracts report
 * themselves and which are still silent; don't restate the split here, because
 * this comment said "four places" against a heading that said five and a list
 * that held six.
 *
 * Every message names the fix, not just the symptom — the failure modes here
 * cost hours precisely because the symptom (a wedged display, a stale cache)
 * points nowhere near the cause.
 */
export declare function assertDisplayContract(self: IAnyStateTreeNode, installedBy?: string): void;
/** What one run of a global display's fetch autorun did. */
export type FetchAutorunOutcome = 
/** the display's own gate opened and `fetch()` ran */
'fetched'
/** the gate stayed shut, so this run did nothing */
 | 'declined'
/** the byte gate skipped the run before the display's gate was consulted */
 | 'gated';
interface RetryContractHost {
    reloadCounter: number;
    loadingSuppressed: boolean;
}
/**
 * Dev-only check that a display's `reload()` can actually reach a fetch — the
 * retry contract, which `DisplayErrorBar` depends on and which no type can
 * state. No-op in production.
 *
 * **The button is the contract.** `DisplayErrorBar`'s only action is
 * `model.reload()`, so every state that can raise the error bar has to be one
 * `reload()` actually undoes; otherwise the button is present, looks live, and
 * does nothing. It has failed three times, and the shape this catches is the one
 * that recurs on its own: a `shouldFetch` gate that goes false the moment data
 * lands. `GlobalFetchMixin.reload()` clears the error and bumps `reloadCounter`,
 * `installGlobalFetchAutorun` reads that counter unconditionally so the autorun
 * re-runs — and then the gate declines, because from its point of view nothing
 * has changed. Arc shipped exactly that: `shouldFetch: () => !dataCurrent`, with
 * the error clearing on click and no arcs ever coming back. Its `reload()`
 * override drops `loadedRegionSignature` so `dataCurrent` goes false, which is
 * the fix this message asks for.
 *
 * Detected at the moment it happens rather than statically, because the relation
 * between `reload()` and `shouldFetch` is semantic: a run that follows a
 * `reloadCounter` bump and declines to fetch IS the dead button.
 *
 * The one legitimate decline is a display deliberately not fetching at all — LD
 * with the triangle off, whose `reload()` correctly does nothing because there
 * is nothing to load. That is already a named state: `loadingSuppressed`, which
 * the loading scrim reads for the same reason, so the exemption is not a second
 * thing to remember. A display that suppresses the scrim and still wants the
 * retry checked has the two questions genuinely apart and should say so here.
 *
 * **Everything it reads is `untracked`.** It runs inside the fetch autorun, so a
 * tracked read of `loadingSuppressed` would put that observable in the autorun's
 * dependency set in dev and not in production — a display whose fetch re-fires
 * only in development, which is worse than the bug being checked for.
 */
export declare function makeRetryContractCheck(self: IAnyStateTreeNode & RetryContractHost): (outcome: FetchAutorunOutcome) => void;
export {};
