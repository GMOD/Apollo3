import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
/**
 * #stateModel TrackHeightMixin
 * #category display
 * #crossCuttingMixin Internal vertical scroll. `scrollableHeight` (default `Infinity` = doesn't scroll). Brings the clamped `setScrollTop` and the autorun that re-clamps when content shrinks
 *
 * The display height is stored directly on the `height` config slot (drag-resize
 * writes it via `setSlot`), so it survives a track being unticked and reticked —
 * the config node outlives the ephemeral display instance. Displays with an
 * auto-fit mode declare `height` as a `maybeNumber` slot (default `undefined`)
 * and override the `height` getter to fall back to their computed content
 * height when unset.
 *
 * It also owns the **internal vertical scroll** every canvas display that
 * scrolls its own content shares: the `scrollTop` volatile, a `setScrollTop`
 * clamped against the overridable `scrollableHeight` hook, and the autorun that
 * re-clamps when the content shrinks. Four displays (alignments, canvas, MAF,
 * multi-sample variants) each carried their own copy of the last two, with four
 * copies of the same "a virtual-scrolled canvas has no overflow container to
 * self-correct" paragraph; a display now opts into all of it by overriding one
 * getter.
 */
export default function TrackHeightMixin<TConf extends {
    configuration: AnyConfigurationModel;
} = {
    configuration: AnyConfigurationModel;
}>(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     */
    scrollTop: number;
    /**
     * #volatile
     * True for the duration of a height drag, set by the track container's
     * resize handle. A display whose row geometry is a function of the track
     * height restretches every row per animation frame, and can use this to
     * sit an expensive per-frame layer out of the drag (MAF's dense per-base
     * letter overlay is a Canvas2D pass that scales with rows x columns).
     *
     * Lives here rather than per display because the handle that knows the
     * drag has started is the shared one next to `resizeHeight`. Displays
     * with their own handles (MAF's band handles) set it directly.
     */
    resizing: boolean;
} & {
    readonly height: number;
    /**
     * #getter
     * Overridable hook: how far this display's content can scroll past its
     * viewport, in px. `Infinity` (the default) means "this display doesn't
     * scroll internally" — `setScrollTop` then never clamps and the re-clamp
     * autorun below is inert, so a non-scrolling display pays nothing and,
     * crucially, never evaluates a getter that would read view geometry.
     *
     * A display that scrolls a canvas overrides this with `max(0, contentHeight
     * - viewportHeight)`, and gets the clamped setter plus the shrink autorun
     * for free. It is the single "does it scroll, and by how much" answer: the
     * wheel handler (`useVirtualScrollWheel`) and `VerticalScrollbar` read the
     * same getter.
     */
    readonly scrollableHeight: number;
    /**
     * #getter
     * Whether this display offers the fixed/grow/fit vocabulary at all, or
     * only the drag-resizable `height` slot above. False here; `HeightModeMixin`
     * overrides it to true, and `types.compose` resolves the collision to the
     * later argument — which is exactly what makes it a usable compose-order
     * probe, the same way `measuresBytesInFetch` is for the canvas size gate.
     *
     * That probe is the point. `HeightModeMixin` also overrides `height` and
     * `resizeHeight`, and composing it FIRST silently hands both back to this
     * mixin: grow mode stops working with no error anywhere, and the two
     * `height` getters agree in fixed mode, so no *value* can tell the orders
     * apart. A flag that differs by construction can. Read back in
     * `HeightModeMixin`'s `afterAttach`.
     */
    readonly supportsHeightModes: boolean;
} & {
    /**
     * #action
     * Clamped into `[0, scrollableHeight]`, so no caller has to remember the
     * bound. Unbounded for a display that leaves `scrollableHeight` at its
     * `Infinity` default.
     */
    setScrollTop(scrollTop: number): void;
    /**
     * #action
     */
    setResizing(arg: boolean): void;
    /**
     * #action
     */
    setHeight(displayHeight: number): number;
    /**
     * #action
     */
    resizeHeight(distance: number): number;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
