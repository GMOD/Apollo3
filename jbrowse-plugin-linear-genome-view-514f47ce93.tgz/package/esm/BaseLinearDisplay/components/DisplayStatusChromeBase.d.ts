import type { TooLargeMessageModel } from '../../shared/TooLargeMessage.tsx';
import type { DisplayBackgroundProgressModel } from './DisplayBackgroundProgress.tsx';
import type { DisplayErrorBarModel } from './DisplayErrorBar.tsx';
import type { DisplayLoadingOverlayModel } from './DisplayLoadingOverlay.tsx';
import type { DisplayChromeOverlays } from '@jbrowse/display-ui';
import type { DisplayStatusPhase } from '@jbrowse/render-core/displayPhase';
import type { ComponentPropsWithRef, ReactNode } from 'react';
export type StatusChromeModel = DisplayErrorBarModel & TooLargeMessageModel & DisplayLoadingOverlayModel & DisplayBackgroundProgressModel & {
    configuration: {
        displayId: string;
    };
};
export type DisplayStatusChromeBaseProps = {
    model: StatusChromeModel;
    /**
     * The display's own mutually-exclusive state, ranked by
     * `computeDisplayStatusPhase`. Never re-derived here — this component only
     * branches on it, so a display and its chrome can't disagree.
     */
    phase: DisplayStatusPhase;
    /**
     * First paint: `painted` for a GPU display, arc's own `painted` for SVG.
     * Drives the published `data-display-drawn` and the loading overlay's
     * anti-flash suppression while there is nothing on screen to flash over.
     *
     * **`painted`, not the raw `canvasDrawn`.** A display showing a deliberate
     * static placeholder instead of a canvas never mounts one, so `canvasDrawn`
     * cannot flip and `data-display-drawn` reported `"false"` for the display's
     * whole life — which is what `PENDING_DISPLAYS` selects on, so a zoomed-out
     * reference sequence track timed out every `waitForDisplaysDone` on the page.
     * See `RenderLifecycleMixin.painted`.
     */
    drawn: boolean;
    overlays: DisplayChromeOverlays;
    /**
     * The display type's stable `data-testid`. **Required** — it used to be
     * optional, and the displays that omitted it leaned on a second wrapper
     * element (`DisplayContainer`) to emit an id instead, which is how the repo
     * ended up with three testid shapes and a test-infra union to match them.
     *
     * Pass the base name only. It used to gain `-done` on paint; readiness is
     * `data-display-drawn` / `data-display-phase` now (ADR-065), so a consumer
     * that wants "this display type, painted" composes the two —
     * `displayPainted(base)` from `@jbrowse/capture`.
     */
    testid: string;
    children?: ReactNode;
} & Omit<ComponentPropsWithRef<'div'>, 'children'>;
export default function DisplayStatusChromeBase({ model, phase, drawn, overlays, testid, style, children, ...divProps }: DisplayStatusChromeBaseProps): import("react").JSX.Element;
