import { RemoteFileWithRangeCache } from '@jbrowse/core/util/io';
import type { RequestInitWithMetadata } from './model.tsx';
import type { Stats } from 'generic-filehandle2';
export declare class GoogleDriveFile extends RemoteFileWithRangeCache {
    private statsPromise;
    fetch(input: RequestInfo, opts?: RequestInitWithMetadata): Promise<Response>;
    stat(): Promise<Stats>;
}
