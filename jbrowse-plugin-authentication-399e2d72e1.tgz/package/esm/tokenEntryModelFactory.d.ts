import type { AnyConfigurationSchemaType } from '@jbrowse/core/configuration';
import type { UriLocation } from '@jbrowse/core/util/types';
import type React from 'react';
type TokenEntryForm = React.FC<{
    internetAccountId: string;
    handleClose: (token?: string) => void;
}>;
/**
 * #stateModel TokenEntryInternetAccount
 * Shared base for internet accounts whose token is supplied by the user through
 * a dialog (HTTP Basic, external token). Such accounts differ only in their
 * discriminating `type` and the dialog form used to collect the token, both
 * passed here. Not registered on its own — see HTTPBasicInternetAccount and
 * ExternalTokenInternetAccount.
 */
export declare function tokenEntryModelFactory<Type extends string>(modelName: string, typeName: Type, configSchema: AnyConfigurationSchemaType, LoginForm: TokenEntryForm): import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
}, "configuration" | "type"> & {
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<Type>;
    /**
     * #property
     */
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<AnyConfigurationSchemaType>;
}, {
    readonly name: string;
    readonly description: string;
    readonly internetAccountId: string;
    readonly authHeader: string;
    readonly tokenType: string;
    readonly domains: string[];
    readonly toggleContents: React.ReactNode;
    readonly SelectorComponent: import("@jbrowse/core/util").AnyReactComponentType | undefined;
    readonly selectorLabel: string | undefined;
} & {
    handlesLocation(location: UriLocation): boolean;
    readonly tokenKey: string;
} & {
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    storeToken(token: string): void;
    retrieveToken(): string | null;
    validateToken(token: string, _loc: UriLocation): Promise<string>;
} & {
    removeToken(): void;
    getToken(location?: UriLocation): Promise<string>;
} & {
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    getValidatedToken(loc?: UriLocation): Promise<string>;
    getPreAuthorizationInformation(location: UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        };
    }>;
} & {
    getFetcher(loc?: UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    openLocation(location: UriLocation): import("@jbrowse/core/util/io").RemoteFileWithRangeCache;
} & {
    /**
     * #getter
     * validate the token with a HEAD request before it is used
     */
    readonly validateWithHEAD: boolean;
} & {
    /**
     * #action
     * Prompt the user for a token via the account's dialog form, resolving
     * with the entered token or rejecting if the user cancels.
     */
    getTokenFromUser(resolve: (token: string) => void, reject: (error: Error) => void): void;
    /**
     * #action
     * Optionally validate the token with a HEAD request before use, per the
     * `validateWithHEAD` config slot.
     */
    validateToken(token: string, location: UriLocation): Promise<string>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export {};
