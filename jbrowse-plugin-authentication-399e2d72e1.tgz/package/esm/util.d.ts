export declare function getResponseError({ response, reason, statusText, }: {
    response: Response;
    reason?: string;
    statusText?: string;
}): Promise<string>;
export declare function getError(response: Response): Promise<string>;
