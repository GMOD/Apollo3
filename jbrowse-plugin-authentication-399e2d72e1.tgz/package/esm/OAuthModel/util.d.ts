export interface OAuthWindowParams {
    internetAccountId: string;
    expectedState: string | undefined;
    exchangeAuthorizationCode: (code: string, redirectUri: string) => Promise<string>;
    storeToken: (token: string) => void;
}
export declare function parseOAuthError(text: string): {
    isInvalidGrant: boolean;
    statusText: string;
};
/**
 * Completes the flow from the URL the provider redirected back to. Returns the
 * token, or undefined if the redirect carries neither a token, a code, nor an
 * error. Throws on any OAuth error.
 */
export declare function finishOAuthRedirect(redirectUri: string, params: OAuthWindowParams): Promise<string | undefined>;
/**
 * Parses an OAuth redirect message event. Returns the token if the event
 * completes the flow, undefined if the event isn't this account's redirect.
 * Throws on any OAuth error.
 */
export declare function finishOAuthWindow(event: MessageEvent, params: OAuthWindowParams): Promise<string | undefined>;
/**
 * Returns a promise that resolves to the token when the OAuth popup posts its
 * redirect back. The listener is self-contained and cleaned up when the
 * promise settles.
 */
export declare function waitForOAuthMessage(finish: (event: MessageEvent) => Promise<string | undefined>): Promise<string>;
