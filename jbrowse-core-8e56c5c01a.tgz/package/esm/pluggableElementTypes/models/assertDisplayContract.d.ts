import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Dev-only check that a display's fetch foundation attached it exactly once —
 * the one ordering contract here that is a *state* rather than a declaration,
 * so no selector can reach it. No-op in production.
 *
 * Called once per display from **whichever fetch foundation installed its
 * autoruns** — `MultiRegionDisplayMixin`'s `afterAttach` for the per-region
 * family, `installGlobalFetchAutorun` for the global one,
 * `installComparativeFetchAutorun` for the comparative one. Landing here twice
 * for one node means every autorun that foundation installs is installed twice:
 * double fetches, double clears, and nothing anywhere says so.
 *
 * The named cause is a display that chains to `super` in its own `afterAttach`
 * — our MST fork auto-chains lifecycle hooks, so the explicit call re-enters the
 * foundation's hook. **That cause is a declaration and could be a lint selector;
 * this check is not, because it is not the only cause**: composing two fetch
 * foundations onto one display, or calling an installer from a display that
 * already composes the mixin, arrives here the same way, through a composition
 * assembled across files that no single one of them spells out. So the message
 * leads with the common cause and then describes the state, not the syntax.
 *
 * `installedBy` names the caller so the message can describe the right thing;
 * the WeakSet is shared, which is correct — a display composes one fetch
 * foundation, so reaching here twice is the bug regardless of which.
 *
 * ARCHITECTURAL_LIMITS.md §"Ordering is the contract" is the authoritative
 * account of which contracts report themselves at runtime, which are lint
 * selectors and which are still silent; don't restate the split here, because
 * this comment said "four places" against a heading that said five and a list
 * that held six.
 *
 * Every message names the fix, not just the symptom — the failure modes here
 * cost hours precisely because the symptom (a wedged display, a stale cache)
 * points nowhere near the cause.
 */
export declare function assertDisplayContract(self: IAnyStateTreeNode, installedBy?: string): void;
/** What one run of a display's fetch autorun did. */
export type FetchAutorunOutcome = 
/** the display's own gate opened and a fetch started */
'fetched'
/** the gate stayed shut, so this run did nothing */
 | 'declined'
/** a foundation gate skipped the run before the display's own was consulted */
 | 'gated'
/**
 * The run stopped on something that re-wakes this autorun by itself, so it
 * answers nothing either way — the same deferral `awaitingPrerequisite` gets,
 * reached from inside the foundation rather than declared by the display. The
 * per-region family's in-flight-fetch skip is the case: `reload()` signals the
 * running fetch's stop token but `activeStopToken` clears in `runFetch`'s
 * finally, so the very next run can still see `isLoading` — and that fetch
 * ending bumps `fetchGeneration`, which the autorun tracks. Consuming the bump
 * there would answer the retry with a run that predates it.
 */
 | 'deferred';
interface RetryContractHost {
    reloadCounter: number;
    fetchInert: boolean;
    /**
     * Optional: the comparative family has no two-stage fetch, so nothing there
     * declares it. A family that grows one declares it and gets the deferral.
     */
    awaitingPrerequisite?: boolean;
}
/** Called by `FetchMixin.runFetch`. Dev-only. */
export declare function noteFetchStarted(self: object): void;
/** Reads and clears the flag above, so each check starts from a known state. */
export declare function takeFetchStarted(self: object): boolean;
/**
 * Dev-only check that a display's `reload()` can actually reach a fetch — the
 * retry contract, which `DisplayErrorBar` depends on and which no type can
 * state. No-op in production.
 *
 * **The button is the contract.** `DisplayErrorBar`'s only action is
 * `model.reload()`, so every state that can raise the error bar has to be one
 * `reload()` actually undoes; otherwise the button is present, looks live, and
 * does nothing. It has failed three times, and the shape this catches is the one
 * that recurs on its own: a gate that goes shut the moment data lands.
 * `GlobalFetchMixin.reload()` clears the error and bumps `reloadCounter`,
 * `installGlobalFetchAutorun` reads that counter unconditionally so the autorun
 * re-runs — and then the gate declines, because from its point of view nothing
 * has changed. Arc shipped exactly that: a `prepare` declining on `dataCurrent`,
 * with the error clearing on click and no arcs ever coming back. Its `reload()`
 * override drops `loadedRegionSignature` so `dataCurrent` goes false, which is
 * the fix this message asks for.
 *
 * Detected at the moment it happens rather than statically, because the relation
 * between `reload()` and the gate is semantic: a run that follows a
 * `reloadCounter` bump and declines to fetch IS the dead button.
 *
 * **The bump is the only thing that arms this**, so a `reload()` override that
 * neither bumps nor chains to super turns the whole check off for its display —
 * silently, and for as long as nobody reads the override. Canvas shipped in that
 * shape, which is two of the most-used displays in the product. What watches for
 * the next one is `MultiRegionDisplayMixin`'s `reloadReachesCounter.test.ts`,
 * which reads every `reload()` in the tree.
 *
 * **Both fetch foundations install it**, and what counts as the gate differs.
 * The global family's `prepare()` returns the fetch's args or `undefined`, so
 * its run classifies itself. The per-region family's gate is block coverage — a
 * `reload()` that invalidates nothing leaves `needed` empty — plus the
 * `fetchNeeded` override, which can decline inside an async body the foundation
 * cannot read a return value from. So `MultiRegionDisplayMixin` classifies on
 * whether the override reached `runFetch`, which every one of the nine does in
 * its synchronous prefix. An override that awaits before fetching would read as a
 * decline; there is no such override, and one added later gets a false report
 * rather than a silent gap, which is the right way round.
 *
 * **A fetch also answers the retry on its own** (`noteFetchStarted`), because
 * `reload()` may reach one without an autorun run in between: canvas's clears and
 * calls `fetchNeeded` directly rather than waiting out the 600ms debounce, and
 * the autorun's next run then finds the blocks covered.
 *
 * A display deliberately not fetching at all is the one exempt decline — LD with
 * the triangle off, whose `reload()` correctly does nothing because there is
 * nothing to load. That is already a named state: `fetchInert`, which the
 * loading scrim reads for the same reason, so the exemption is not a second
 * thing to remember. A display that suppresses the scrim and still wants the
 * retry checked has the two questions genuinely apart and should say so here.
 *
 * `awaitingPrerequisite` is not a second exemption — it is a *deferral*, and the
 * difference is the point. A two-stage `reload()` bumps the counter, wakes a
 * prerequisite fetch in another autorun, and declines here only until that
 * lands. HiC is the case: the contacts autorun runs first and declines because
 * `effectiveResolution` is still undefined, and the header arriving a moment
 * later wakes it again through the tracked read that declined. So the bump is
 * left outstanding instead of consumed, and the run after the prerequisite
 * lands is the one that has to reach a fetch — if it declines too, the report
 * lands then. A display cannot spend its retry on a decline it called
 * preliminary, which is what an exemption here would have let it do.
 * `fetchInert` is the wrong thing for HiC to say in any case, because it
 * does want the scrim while the header is re-read.
 *
 * Both flags are read off the node, and both are declared once on `FetchMixin`
 * — the one mixin all three display foundations compose. Neither foundation
 * passes them in: the global family's three phases are autorun options because
 * that is what they are, and these two are properties of the
 * display, which is why an earlier arrangement that made this one an option
 * there and a getter on the per-region mixin had one concept in two spellings.
 *
 * **The predicate has to be strictly narrower than the gate's own decline to be
 * a deferral at all.** One that restates the gate's negation makes every decline a
 * deferred one, so no run is ever judged and the display has opted out — an
 * exemption by another name. HiC's is that shape, because its gate and its
 * prerequisite are the same condition, and what covers HiC's retry instead is
 * `LinearHicDisplay/infoFetchFailure.test.ts`. Say so at any call site that
 * lands there, and pick a narrower predicate wherever one exists.
 *
 * **Everything it reads is `untracked`.** It runs inside the fetch autorun, so a
 * tracked read of `fetchInert` — or of whatever `awaitingPrerequisite`
 * reaches — would put that observable in the autorun's dependency set in dev and
 * not in production, a display whose fetch re-fires only in development, which
 * is worse than the bug being checked for.
 */
export declare function makeRetryContractCheck(self: IAnyStateTreeNode & RetryContractHost): (outcome: FetchAutorunOutcome) => void;
export {};
