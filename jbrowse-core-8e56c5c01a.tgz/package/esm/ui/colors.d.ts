declare const category10: string[];
declare const set1: string[];
export declare const paletteColors: {
    category10: string[];
    dark2: string[];
    ggplot2Colors3: string[];
    ggplot2Colors4: string[];
    ggplot2Colors5: string[];
    ggplot2Colors6: string[];
    set1: string[];
    set2: string[];
    tableau10: string[];
};
/**
 * Deterministic non-negative 32-bit hash of a string.
 */
export declare function hashString(str: string): number;
/**
 * Stable category10 color for a sequence name, via `hashString`.
 *
 * Kept as a published export; in-tree, prefer {@link refNameColor}, which hands
 * the palette out by position where the caller knows the assembly's chromosome
 * order and only hashes where it does not.
 */
export declare function getQueryColor(queryName: string): string;
/** The palette color for a chromosome at `position` in its assembly. */
export declare function refNamePaletteColorAt(position: number): string;
/**
 * The color a refName paints, BY POSITION IN THE ASSEMBLY where the caller
 * knows its chromosome order.
 *
 * Handing the palette out rather than hashing into it is what stops a genome
 * painting two of its own chromosomes the same color: nine slots means ten or
 * more chromosomes re-use one, and by the birthday bound long before that. On
 * hg38 the hash puts chr1, chr12, chr21 and chrY on one color.
 *
 * `position` is undefined for the case the order genuinely is not available —
 * an assembly still loading, or a refName the assembly does not list (a
 * scaffold under an alias). There a stable arbitrary color beats no color, so
 * it falls back to the hash.
 */
export declare function refNameColor(name: string, position: number | undefined): string;
export { category10, set1 };
