/** Which question about a region set a byte budget asks. */
export type ByteEstimateScope = 'largestRegion' | 'wholeRequest';
/**
 * What a fetch RPC answers **instead of a payload** when a region is over
 * budget on either axis. Every in-fetch-gated RPC returns
 * `Payload | RegionTooLargeResult`, so "was this region refused" is one shape
 * rather than a per-RPC convention — see {@link isRegionRefused}.
 */
export interface RegionTooLargeResult {
    regionTooLarge: true;
    featureCount?: number;
    bytes?: number;
}
/**
 * Whether a fetch answered "refused" rather than data for this region.
 *
 * **The one test, because the answer decides what `loadedRegions` may claim.**
 * A refused region stored nothing, so marking it loaded over the span the fetch
 * asked for makes the viewport read as covered against data that does not exist
 * — the plan then reports `covered`, nothing refetches, and nothing
 * re-measures. That is invisible on a region fetched for the first time (the
 * data map is empty and the display notices) and permanent on one the reader
 * already had data for, which is every region they zoomed out from.
 *
 * So the fan-out helpers and the displays that fold the gate into their own RPC
 * both ask here, rather than each spelling out `'regionTooLarge' in result`.
 */
export declare function isRegionRefused(result: unknown): result is RegionTooLargeResult;
/** Undefined, never 0, when no region could be measured. */
export declare function largestRegionBytes(perRegion: (number | undefined)[]): number | undefined;
/** A non-positive declared limit means "no opinion" (htsget reports 0). */
export declare function adapterByteLimit(declared: unknown, fallback: number): number;
export declare function overByteBudget(bytes: number | undefined, byteLimit: number | undefined): bytes is number;
