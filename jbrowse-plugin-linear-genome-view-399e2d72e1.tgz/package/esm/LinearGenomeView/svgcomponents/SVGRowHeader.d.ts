import type { LinearGenomeViewModel } from '../index.ts';
export default function SVGRowHeader({ view, fontSize, rulerHeight, showAssemblyName, }: {
    view: LinearGenomeViewModel;
    fontSize: number;
    rulerHeight: number;
    showAssemblyName?: boolean;
}): import("react").JSX.Element;
