import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
/**
 * Rendering-agnostic foundation for any display holding a single global
 * (non-regional) dataset. Owns the *fetch* concern only — no GPU rendering — so
 * it is shared by GPU global displays (via GlobalDataDisplayMixin) AND
 * main-thread SVG ones (the arc displays), which compose it directly. That's the
 * whole reason it's split out from GlobalDataDisplayMixin: fetch (cancellation,
 * staleness, region-too-large, reload, the svgReady export gate) is orthogonal
 * to how the display paints, so a non-GPU display shouldn't have to drag in
 * RenderLifecycleMixin to get it.
 *
 * Composes:
 *   - RegionTooLargeMixin (regionTooLarge, force-load, …)
 *   - FetchMixin (runFetch, cancelFetch, isLoading, error, statusMessage,
 *                 fetchGeneration)
 *
 * Installs no autoruns — each display owns its fetch trigger, sharing the
 * `installGlobalFetchAutorun` skeleton. `displayPhase` lives in
 * GlobalDataDisplayMixin, not here, because it reads `renderError` from
 * RenderLifecycleMixin — the one genuinely GPU-only piece. A non-GPU composer
 * (arc) defines its own one-line `displayPhase` over the same shared
 * `computeDisplayPhase`, passing `renderError: undefined`.
 *
 * #stateModel GlobalFetchMixin
 * #displayFoundationDef The same single-global fetch foundation without the render lifecycle, so a non-GPU display that paints main-thread SVG does not drag it in.
 * #category display
 */
export default function GlobalFetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{}, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly measuresBytesInFetch: boolean;
    readonly measuresBytesPreFlight: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("../../index.ts").GateViewport | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
    gateFetchState(): import("../../index.ts").GateFetchState;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number;
        viewport: import("../../index.ts").GateViewport;
    }): void;
    setGateMeasuredViewport(viewport: import("../../index.ts").GateViewport): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: import("./FetchMixin.ts").FetchContext): Promise<boolean>;
} & {
    afterAttach(): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly loadingSuppressed: boolean;
    readonly awaitingPrerequisite: boolean;
    readonly rpcPropsCacheKey: string;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    flushStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
    makeStatusCallback(isCurrent: () => boolean): import("@jbrowse/core/util").StatusCallback;
} & {
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: import("./FetchMixin.ts").FetchContext) => Promise<void>) => Promise<void>;
} & {
    /**
     * #volatile
     * Bumped by `reload()` to retrigger a global display's fetch autorun.
     * Each display reads `void self.reloadCounter` in its `afterAttach` fetch
     * autorun so a user-initiated reload re-runs the fetch even when no
     * viewport/setting changed.
     */
    reloadCounter: number;
} & {
    /**
     * #getter
     * The containing LinearGenomeView, typed once so no consumer repeats the
     * `getContainingView` cast. Same getter, same name, as
     * `MultiRegionDisplayMixin`'s — declared in both rather than hoisted into
     * the `RegionTooLargeMixin` they share, because that mixin is named for
     * the byte gate and a display composes exactly one of these two families,
     * so the pair can never shadow each other. See the note there for why the
     * name is `lgv` and not `view`.
     */
    readonly lgv: LinearGenomeViewModel;
    /**
     * #getter
     * This family's answer to the shared freshness question every display
     * foundation must answer: the held data corresponds to what is on screen
     * right now — fetched, and fetched *for this viewport*. The mixin owns no
     * data state, so a global display must express it; the two in tree do so
     * differently (HiC and LD add their own "data arrived" term to
     * `StaleViewportRescaleMixin`'s `viewportFresh` snapshot compare, arc
     * compares a region signature via `isDataCurrent`), which is exactly what
     * the hook is for.
     *
     * Default false, so a display that forgets the override never exports —
     * a hung export is diagnosable, a stale one silently ships wrong pixels.
     */
    readonly dataCurrent: boolean;
    /**
     * #getter
     * Overridable hook (default false): a subclass returns true to mark an
     * extra terminal state where off-screen export can proceed with no loaded
     * data (mirrors `MultiRegionDisplayMixin.svgReadyExtraTerminal`).
     */
    readonly svgReadyExtraTerminal: boolean;
} & {
    /**
     * #getter
     * Policy single-sourced in `computeSvgReady`; this family supplies only
     * its `dataCurrent` predicate. Note it requires the dataset to actually be
     * current, NOT merely "not currently fetching": the fetch trigger is a
     * debounced `afterAttach` autorun, so at export time `isLoading` can still
     * be false with no data yet — a `displayPhase !== 'loading'` test would
     * then capture an empty render. Never gates on `canvasDrawn`, which an
     * off-screen export never sets. Off-screen renderers gate on it via
     * `awaitSvgReady(model)`.
     */
    readonly svgReady: boolean;
} & {
    /**
     * #action
     * Satisfies the `reload` contract `DisplayChrome` (and the arc SVG chrome)
     * require of every display. Clears any error and bumps `reloadCounter` so
     * the display's fetch autorun re-runs. A subclass whose reload needs extra
     * teardown can override and chain.
     */
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalFetchMixinType = ReturnType<typeof GlobalFetchMixin>;
