import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { IAutorunOptions } from 'mobx';
/**
 * Install an autorun on a display whose body only runs once the containing LGV
 * is initialized (measured width + ready assemblies). Centralizes the
 * `if (!view.initialized) return` guard every LGV-display autorun needs: before
 * init, view-derived getters like `view.width` throw by design, so a body that
 * reads them must not run yet. `initialized` is observable, so the body re-runs
 * automatically the moment the view becomes ready. The view is passed in so
 * callers don't re-fetch it.
 */
export declare function autorunOnReadyView(self: IAnyStateTreeNode, fn: (view: LinearGenomeViewModel) => void, opts?: IAutorunOptions): void;
/**
 * Run `clear` whenever the containing view's `displayedRegions` reference
 * changes (chromosome navigation, region reorder, etc). Use for state keyed by
 * `displayedRegionIndex` that intentionally survives `clearAllRpcData` —
 * chromosome navigation reuses indices, so an entry left over from chr1 would
 * silently apply to chr2 (canvas's `densityStatsPerRegion` is the canonical
 * case). Plugins whose entire per-region data clears through
 * `clearDisplaySpecificData` don't need this — the per-region family's own
 * `DisplayedRegionsChange` autorun already covers them.
 */
export declare function onDisplayedRegionsChange(self: IAnyStateTreeNode, clear: () => void, name?: string): void;
/**
 * Dev-only feedback-loop guard for the (undelayed) `SettingsInvalidate` autorun.
 * The classic `rpcProps()` trap (ARCHITECTURE.md §"rpcProps() loop trap") puts a
 * fetch-derived value in `rpcProps()`, so the autorun that reads it and clears
 * fetched data re-invalidates itself — MobX runs it until its 100-iteration
 * convergence guard throws a cryptic "Reaction doesn't converge". Call this at
 * the top of the body's mutating section: it throws a message naming the actual
 * cause the first time the body re-fires far more times in one synchronous tick
 * than any real settings change could, and — because it throws *before* the
 * `clearAllRpcData()` that perpetuates the cycle — that iteration's invalidating
 * mutation never runs, breaking the loop. No-op in production. (The debounced
 * `installGlobalFetchAutorun` variant loops on the async-fetch cadence, not
 * synchronously, so this within-tick counter does not catch it — that hazard is
 * documented at the call site instead.)
 */
export declare function makeSettingsLoopGuard(name: string): () => void;
