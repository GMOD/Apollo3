import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
import type { FetchContext } from './FetchMixin.ts';
import type { IndexedRegion } from './planRegionFetch.ts';
import type { Region } from '@jbrowse/core/util';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
export type { FetchContext } from './FetchMixin.ts';
export { autorunOnReadyView, makeSettingsLoopGuard, onDisplayedRegionsChange, } from './displayAutoruns.ts';
export { callEachRegion, fetchAllRegions, fetchEachRegion, } from './fetchEachRegion.ts';
export { isBlockCovered, planRegionFetch } from './planRegionFetch.ts';
/**
 * #stateModel MultiRegionDisplayMixin
 * #displayFoundationDef Per-region fetch + render: the fetch autoruns, `rpcProps()` refetch wiring, and byte gating. The common case.
 * #category display
 *
 * Per-region fetch lifecycle for LGV-based GPU displays. Installs the fetch
 * autoruns in `afterAttach` and exposes overridable hooks (`fetchNeeded`,
 * `rpcProps`, `isCacheValid`, `measuresBytesPreFlight`) plus the `fetchRegions`
 * / `loadedRegions` machinery.
 */
export default function MultiRegionDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{}, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly measuresBytesInFetch: boolean;
    readonly measuresBytesPreFlight: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("../../index.ts").GateViewport | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
    gateFetchState(): import("../../index.ts").GateFetchState;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number;
        viewport: import("../../index.ts").GateViewport;
    }): void;
    setGateMeasuredViewport(viewport: import("../../index.ts").GateViewport): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: FetchContext): Promise<boolean>;
} & {
    afterAttach(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
    readonly rendersCanvas: boolean;
    readonly paintInert: boolean;
} & {
    readonly painted: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly loadingSuppressed: boolean;
    readonly awaitingPrerequisite: boolean;
    readonly rpcPropsCacheKey: string;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    flushStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
    makeStatusCallback(isCurrent: () => boolean): import("@jbrowse/core/util").StatusCallback;
} & {
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    /**
     * #volatile
     * regions whose data has been fetched and committed, keyed by
     * displayedRegionIndex; populated only after the fetch work callback
     * returns
     */
    loadedRegions: import("mobx").ObservableMap<number, Region>;
    /**
     * #volatile
     * Bumped by `reload()` and read unconditionally by the fetch autorun,
     * so a user retry re-runs the body even where nothing else moved. The
     * base `reload()` also clears `loadedRegions`, which is what normally
     * re-fires it — the counter is the half that survives a `reload()`
     * override that forgets to invalidate, which is the dead button
     * `makeRetryContractCheck` reports. Same name and same role as
     * `GlobalFetchMixin`'s, so the two families read alike.
     */
    reloadCounter: number;
} & {
    /**
     * #getter
     * The containing LinearGenomeView, typed once for every display in this
     * family so no consumer repeats the `getContainingView` cast — the cast
     * `getContainingView` needs (it is view-type-agnostic) but which this
     * mixin has already committed to, since everything below reads
     * `visibleRegions` / `bufferedVisibleRegions` / `bpPerPx` off it.
     *
     * Three displays had each invented this getter under two names before it
     * was hoisted (`view` on HiC and Manhattan, `lgv` on MAF) while ~35 other
     * sites repeated the cast inline. `lgv` rather than `view` because a
     * display's containing view is not always an LGV — the comparative
     * displays' `view` is a synteny or dotplot view — so the name says which
     * one this is.
     *
     * Components and structural helpers keep calling `getContainingView`:
     * they take duck-typed model shapes that deliberately don't carry the
     * whole MST instance type, so there is no `lgv` on them to read.
     */
    readonly lgv: LinearGenomeViewModel;
    /**
     * #getter
     * The CSS width of this display's on-screen canvas, in px — and the
     * `canvasWidth` its `renderState` must carry, since the two have to
     * agree or the bp→px mapping is scaled against a box it doesn't fill.
     *
     * `trackWidthPx`, **not** `view.width`: `TrackRenderingContainer` insets
     * the rendering component by the 2px track outline under
     * `contain: strict`, so a `view.width`-wide canvas overhangs its own
     * container and the browser clips the overhang away. It renders almost
     * identically, which is why MAF drifted onto `view.width` uncaught.
     *
     * A getter rather than a note on each display, because the choice was
     * being made by copying a neighbour out of four plausible view getters —
     * `width` (the viewport), this one, and `totalWidthPx` /
     * `totalWidthPxWithoutBorders` (the *content* width, which the global
     * family's heatmaps legitimately want: a different question, not a
     * different answer). `no-restricted-syntax` bans the underlying read
     * everywhere but this line, since a second spelling agrees until it
     * doesn't.
     *
     * SVG export is the one exception: the export shell has no outline, so
     * `renderSvg` overrides `canvasWidth` with the shell's own width (see
     * `LgvSvgBodyProps`).
     */
    readonly canvasWidthPx: number;
    /**
     * #getter
     * The render-lifecycle precondition for every LGV display (overrides
     * `RenderLifecycleMixin`'s default-true hook): don't run the upload/render
     * callbacks until the view is measured. Before that, `renderBlocks` →
     * `visibleRegions` → `view.width` throws by design, and the render
     * autorun's catch would show that as a GPU render-error banner. Gating here
     * — once, for all of them — is what lets a display's `renderState` be a
     * plain resolved getter and its render callback gate only on its own data.
     * The render-lifecycle twin of `autorunOnReadyView`.
     */
    readonly canRender: boolean;
    /**
     * #getter
     * true when every visible block lies within an already-fetched region —
     * i.e. the viewport shows data we actually loaded, not the stale fringe
     * left after a zoom-out/pan. Drives the loading overlay through the
     * pre-refetch debounce. Spatial only; see CLAUDE.md for why this is exact
     * and for the resolution-staleness gap.
     */
    readonly viewportWithinLoadedData: boolean;
    /**
     * #getter
     * Overridable hook (default false): a subclass returns true to mark an
     * extra terminal state where off-screen export can proceed with no loaded
     * data. Sequence sets it when zoomed past base resolution — it renders a
     * static "zoom in" message and fetches nothing, so `svgReady` would
     * otherwise never resolve.
     */
    readonly svgReadyExtraTerminal: boolean;
    /**
     * #getter
     * Fills `RenderLifecycleMixin`'s `paintInert` hook — see there for why a
     * failed fetch has to read as finished to the consumers outside the
     * display. The global family declares the identical override.
     */
    readonly paintInert: boolean;
    /**
     * #getter
     * Overridable hook (default false): whether a searchable feature layout
     * currently exists. Any display defining a feature-lookup method
     * (`searchFeatureByID`, `getFeatureById`) must override it, so callers can
     * tell "laid out, but off-display" from "no layout exists yet" — a
     * distinction only the display can make. See
     * plugins/linear-genome-view/src/BaseLinearDisplay/CLAUDE.md §"Four
     * readiness axes".
     */
    readonly layoutReady: boolean;
    /**
     * #getter
     * Shared cached view for every LGV-based GPU display. A single
     * displayedRegion may produce multiple render blocks (shared GPU
     * buffer, different scissor clips on screen). Plugins that want to
     * suppress rendering in certain states (e.g. no domain yet) can
     * override this getter to return [] — the autorun lifecycle will
     * then issue an empty-blocks render that clears the canvas.
     */
    readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
} & {
    /**
     * #getter
     * This family's answer to the shared freshness question every display
     * foundation must answer (`dataCurrent`): the held data corresponds to
     * what is on screen right now. Here that is spatial — every visible block
     * lies within a fetched region — plus `loadedRegions.size`, which rules
     * out the vacuously-true empty viewport. Regions stream in one at a time,
     * so this (not "the first datum arrived") is what keeps a
     * multi-region/whole-genome export complete.
     *
     * Distinct from `viewportWithinLoadedData`, which is the raw coverage
     * predicate the fetch autorun and the loading overlay use.
     */
    readonly dataCurrent: boolean;
} & {
    /**
     * #getter
     * true once an off-screen (SVG) export can safely read this display's
     * data. Policy single-sourced in `computeSvgReady`; this family supplies
     * only its `dataCurrent` predicate. Off-screen renderers gate on it via
     * `awaitSvgReady(model)` instead of inlining the condition.
     */
    readonly svgReady: boolean;
    /**
     * #getter
     * The display's mutually-exclusive visual state, mapped in
     * `foundationDisplayPhase` — every foundation calls it and supplies only
     * its staleness argument, so a term added to `computeLoadingTerm`
     * reaches all three without being wired three times.
     *
     * This family's argument is spatial: `loading` also covers stale data
     * (viewport past loaded) still on screen through the pre-refetch
     * debounce. A thunk, so a suppressed or already-loading display doesn't
     * subscribe to viewport churn.
     *
     * A subclass customizes this through `loadingSuppressed` (FetchMixin),
     * never by overriding the getter — see that hook.
     */
    readonly displayPhase: DisplayPhase;
} & {
    /**
     * #action
     * Action wrapper so callers after async boundaries stay in MST strict
     * mode.
     */
    setLoadedRegion(displayedRegionIndex: number, region: Region): void;
    /**
     * #action
     * no-op base — subclasses override to clear rpcDataMap etc.
     */
    clearDisplaySpecificData(): void;
} & {
    /**
     * #action
     * full reset: cancels fetch, clears error, loadedRegions,
     * display-specific data, and the canvas-drawn flag. The too-large gate is
     * derived (a pure function of the cached estimate × viewport), so it needs
     * no explicit clear here — the fetch autorun re-measures at the new
     * viewport and the verdict follows.
     */
    clearAllRpcData(): void;
    /**
     * #action
     * Default reload: full reset. Subclasses with extra teardown can
     * override (and chain to `clearAllRpcData` directly if needed).
     *
     * An override must reach this counter, by chaining to super or by
     * bumping it. Missing it doesn't break the retry, which the
     * `clearAllRpcData` call drives; it turns the dev-only retry check off
     * for that display, silently. Both overrides in the tree chain now —
     * `MultiSampleVariantBaseModel` always did, canvas's `LinearBasicDisplay`
     * did not, and that took `LinearVariantDisplay` with it — and
     * `reloadReachesCounter.test.ts` reads every `reload()` in the tree
     * rather than leaving the next one to this paragraph.
     */
    reload(): void;
} & {
    /**
     * #action
     * Overridable hook (no-op base): override to call
     * `this.fetchRegions(needed, async ctx => { ... })`.
     */
    fetchNeeded(_needed: IndexedRegion[]): void;
} & {
    /**
     * #method
     * Overridable hook: return `false` to force re-fetch at the current
     * zoom (wiggle uses this for zoom-level changes).
     */
    isCacheValid(_displayedRegionIndex: number): boolean;
} & {
    /**
     * #action
     * Run a per-region fetch with byte-estimate gating. Marks regions as
     * loaded only AFTER the work callback has populated display-specific
     * data (rpcDataMap, cellData, etc) so the GPU upload autorun sees
     * committed data when it observes loadedRegions.
     */
    fetchRegions(needed: IndexedRegion[], work: (ctx: FetchContext) => Promise<void>): Promise<void>;
} & {
    /**
     * #action
     * installs the fetch-lifecycle autoruns (DisplayedRegionsChange,
     * FetchVisibleRegions, SettingsInvalidate,
     * ClearBlockingStateOnViewportChange)
     */
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type MultiRegionDisplayMixinType = ReturnType<typeof MultiRegionDisplayMixin>;
