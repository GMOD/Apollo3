import type { CoverageBandBuffers } from './coverageBandBuffers.ts';
import type { InstancePass } from './instancePass.ts';
export { coverageBandBuffers } from './coverageBandBuffers.ts';
export type { CoverageBandBuffers } from './coverageBandBuffers.ts';
export declare const COVERAGE_BAND_UNIFORMS_SIZE_BYTES = 112;
/**
 * The fifth buffer, base modifications stacked in the same bars. Separate
 * because only one producer emits it — a MAF alignment carries no modification
 * calls — and a display that has no mod data must not have to ship an empty
 * buffer to satisfy the shape.
 */
export interface CoverageBandModBuffer {
    modCovPackedBuffer: ArrayBuffer;
}
/**
 * One draw layer of the coverage band, and the id of the GPU pass that draws it.
 *
 * The band is the same five marks wherever it appears — a display either has a
 * layer's data or does not, and no display reorders them.
 */
export type CoverageLayerId = 'coverage' | 'snpCov' | 'modCov' | 'interbase' | 'indicator';
/**
 * The band's z-order, back to front: the depth bars, the SNP slices stacked
 * inside them, the modification slices stacked on those, the interbase histogram
 * hanging from the band top, and its indicator triangles above that.
 *
 * The order is load-bearing rather than cosmetic — the interbase bars hang down
 * over the lower half the depth bars grow up into, so the two overlap at any
 * real depth — and it is one fact, so it is stated once here and every backend
 * of every display iterates it. It was stated per backend per display, which is
 * how "MAF drew its band in a different order on the fallback" was a screenshot
 * to catch rather than a compile error.
 *
 * What stays per display is the GATING, which genuinely differs: MAF has no
 * `showInterbaseIndicators` setting and no modification data at all.
 */
export declare const COVERAGE_BAND_LAYER_ORDER: readonly CoverageLayerId[];
/**
 * Whatever a display attaches to each band layer — a GPU pass, a Canvas2D
 * painter, a gate — resolved into paint order.
 *
 * The argument is exhaustive over `CoverageLayerId`, so a layer added to the
 * order above is a compile error in every display until it is wired. `undefined`
 * is how a display says it has no such layer (MAF carries no modification
 * calls); it is dropped rather than drawn empty, which keeps a display that has
 * no data for a layer from having to ship an empty buffer to satisfy the shape.
 */
export declare function orderCoverageBandLayers<T>(byId: Record<CoverageLayerId, T | undefined>): (T & ({} | null))[];
export declare const COVERAGE_BAR_PASS: InstancePass<Pick<CoverageBandBuffers, 'coveragePackedBuffer'>>;
export declare const COVERAGE_SNP_PASS: InstancePass<Pick<CoverageBandBuffers, 'snpPackedBuffer'>>;
export declare const COVERAGE_MOD_PASS: InstancePass<CoverageBandModBuffer>;
export declare const COVERAGE_INTERBASE_PASS: InstancePass<Pick<CoverageBandBuffers, 'interbasePackedBuffer'>>;
export declare const COVERAGE_INDICATOR_PASS: InstancePass<Pick<CoverageBandBuffers, 'indicatorPackedBuffer'>>;
/** Palette slots the band paints by name, each a packed ABGR u32. */
export interface CoverageBandColors {
    coverage: number;
    baseA: number;
    baseC: number;
    baseG: number;
    baseT: number;
    baseN: number;
    insertionIndicator: number;
    softclipIndicator: number;
    hardclipIndicator: number;
}
/**
 * Everything the band's UBO holds that a caller actually decides. `hpZero` is
 * absent because it is not one: it is a fixed sentinel the HP math needs — see
 * `writeCoverageBandUniforms`.
 */
export interface CoverageBandUniformValues {
    /** HP-split viewport start + visible span; keep `bpLen` POSITIVE and flip via `reversed`. */
    bpHi: number;
    bpLo: number;
    bpLen: number;
    /** The span clip [-1,1] covers horizontally — a block's scissored width, not the canvas. */
    canvasW: number;
    canvasH: number;
    reversed: boolean;
    /** Band box in CSS px: its height, the scalebar-label inset, and its top edge on the canvas. */
    covHeight: number;
    covYOffset: number;
    covTop: number;
    /** The region's own peak depth, which is what the buffers' `relDepth` is a fraction of. */
    regionMaxDepth: number;
    /** The display's autoscaled depth domain. `undefined` max = not resolved yet. */
    domainMin: number;
    domainMax: number | undefined;
    /** 0 = linear, 1 = log2, 2 = symlog, matching wiggle-core's SCALE_TYPE_*. */
    scaleType: number;
    symlogConstant: number;
    binSize: number;
    /** `interbaseBarHeightPx` — the one rule the draw, the hit test and this share. */
    interbaseHeight: number;
    snpMinFrequency: number;
    colors: CoverageBandColors;
}
/**
 * Fill the coverage band's uniform buffer. Total-write (the generated packer),
 * so a field left out is a compile error rather than last frame's value.
 *
 * `hpZero` is derived here rather than at each call site because getting it
 * wrong is a silently wrong band, not a broken one: it MUST be 0, since the HP
 * math materializes +inf as `1/hpZero` to stop the compiler folding the hi/lo
 * split it exists to preserve.
 */
export declare function writeCoverageBandUniforms(buf: ArrayBuffer, v: CoverageBandUniformValues): void;
