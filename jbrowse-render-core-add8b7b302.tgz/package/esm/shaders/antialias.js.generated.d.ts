export declare function aaPx(dpr: number): number;
export declare function aaHalfPx(dpr: number): number;
export declare function aaRamp(signedInk: number, widthPx: number): number;
export declare function edgeCoverage(signedInkCssPx: number, dpr: number): number;
