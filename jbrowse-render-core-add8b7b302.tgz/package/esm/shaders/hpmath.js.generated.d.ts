export declare function snapBoxHeightPx(heightPx: number): number;
export declare function snapBoxTopPx(topY: number, heightPx: number, scrollY: number): number;
export declare function snapBoxCenterYPx(centerY: number, heightPx: number, scrollY: number): number;
export declare function extendToMinWidthPx(x1: number, x2: number, minWidth: number): number;
