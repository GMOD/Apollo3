import type { VertexAttributeLayout, ShaderBinding } from '@jbrowse/render-core/hal';
export declare const BINDINGS: readonly ShaderBinding[];
export declare const VERTS_PER_INSTANCE = 6;
export declare const UNIFORMS_SIZE_BYTES = 112;
export declare const UNIFORM_OFFSET_F32: {
    readonly bpHi: 0;
    readonly bpLo: 1;
    readonly bpLen: 2;
    readonly hpZero: 3;
    readonly canvasW: 4;
    readonly canvasH: 5;
    readonly covHeight: 6;
    readonly covYOffset: 7;
    readonly covTop: 8;
    readonly regionMaxDepth: 9;
    readonly depthDomainMax: 10;
    readonly depthDomainMin: 11;
    readonly coverageSymlogConstant: 12;
    readonly binSize: 13;
    readonly interbaseHeight: 14;
    readonly snpMinFreq: 15;
    readonly reversed: 16;
};
export declare const UNIFORM_OFFSET_U32: {
    readonly colorCoverage: 18;
    readonly colorBaseA: 19;
    readonly colorBaseC: 20;
    readonly colorBaseG: 21;
    readonly colorBaseT: 22;
    readonly colorBaseN: 23;
    readonly colorInsertionIndicator: 24;
    readonly colorSoftclipIndicator: 25;
    readonly colorHardclipIndicator: 26;
};
export declare const UNIFORM_OFFSET_I32: {
    readonly coverageScaleType: 17;
};
export interface Uniforms {
    bpHi: number;
    bpLo: number;
    bpLen: number;
    hpZero: number;
    canvasW: number;
    canvasH: number;
    covHeight: number;
    covYOffset: number;
    covTop: number;
    regionMaxDepth: number;
    depthDomainMax: number;
    depthDomainMin: number;
    coverageSymlogConstant: number;
    binSize: number;
    interbaseHeight: number;
    snpMinFreq: number;
    reversed: number;
    coverageScaleType: number;
    colorCoverage: number;
    colorBaseA: number;
    colorBaseC: number;
    colorBaseG: number;
    colorBaseT: number;
    colorBaseN: number;
    colorInsertionIndicator: number;
    colorSoftclipIndicator: number;
    colorHardclipIndicator: number;
}
export declare function writeUniforms(buf: ArrayBuffer, uniforms: Uniforms): void;
export declare const INSTANCE_STRIDE_BYTES = 16;
export declare const INSTANCE_STRIDE_WORDS = 4;
export declare const INSTANCE_OFFSET_F32: {
    readonly yOffset: 1;
    readonly segHeight: 2;
    readonly colorType: 3;
};
export declare const INSTANCE_OFFSET_U32: {
    readonly position: 0;
};
export declare const VERTEX_ATTRIBUTES: readonly VertexAttributeLayout[];
export interface InstanceArrays {
    position: ArrayLike<number>;
    yOffset: ArrayLike<number>;
    segHeight: ArrayLike<number>;
    colorType: ArrayLike<number>;
}
export declare function packInstances(arrays: InstanceArrays, numInstances: number, buf?: ArrayBuffer): ArrayBuffer;
export declare function getInstancePosition(u32: Uint32Array, i: number): number;
export declare function setInstancePosition(u32: Uint32Array, i: number, v: number): void;
export declare function getInstanceYOffset(f32: Float32Array, i: number): number;
export declare function setInstanceYOffset(f32: Float32Array, i: number, v: number): void;
export declare function getInstanceSegHeight(f32: Float32Array, i: number): number;
export declare function setInstanceSegHeight(f32: Float32Array, i: number, v: number): void;
export declare function getInstanceColorType(f32: Float32Array, i: number): number;
export declare function setInstanceColorType(f32: Float32Array, i: number, v: number): void;
