export declare const RAMP_LUT_ENTRIES = 256;
