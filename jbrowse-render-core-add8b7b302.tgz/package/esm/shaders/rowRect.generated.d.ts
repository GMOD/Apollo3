export declare const MIN_DRAWN_ROW_PX = 1;
export declare const MULTI_ROW_MIN_CELL_PX = 2;
