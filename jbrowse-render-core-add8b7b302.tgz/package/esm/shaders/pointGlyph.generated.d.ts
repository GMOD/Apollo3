export declare const SMALL_POINT_MAX_DIAMETER = 3;
