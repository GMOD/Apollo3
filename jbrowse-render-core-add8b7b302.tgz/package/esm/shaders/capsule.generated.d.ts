export declare const CAPSULE_MIN_LEN_PX = 0.0001;
