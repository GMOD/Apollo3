/**
 * A contract family — the `<family>` in the `[jbrowse <family> contract]`
 * prefix every contract check in the tree reports under.
 * `config/jest/console.js` matches `\w+`, so a new one reaches the test gate
 * without touching it.
 */
export type ContractFamily = 'display' | 'session' | 'figure';
export interface ContractReport {
    family: ContractFamily;
    message: string;
    /** what armed the channel, so a host can say why it is showing this */
    armedBy: string;
}
/**
 * Whether the checks should run at all.
 *
 * Read it where a check costs something to run — the `MutationObserver` a live
 * figure installs, the per-frame payload walk in `installUpload`. A check whose
 * cost is a `WeakSet` lookup should run unconditionally and report through
 * {@link reportContractViolation} instead, so that arming the channel late
 * still surfaces what it found.
 */
export declare function contractReportsOn(): boolean;
/**
 * Turn the channel on in a production build, saying what turned it on.
 *
 * The reason is not decoration: a notification that appears in an app the
 * reader did not build has to answer "why am I seeing this" in its own text, or
 * it reads as the app being broken rather than as a plugin being under
 * development. First caller wins, so the earliest evidence is the one quoted.
 */
export declare function enableContractReports(reason: string): void;
/**
 * Where a host puts contract violations that reach a user — a session
 * notification in the apps. Installing one drains whatever was found before the
 * host existed, and the disposer only clears the sink it installed, so a
 * session torn down after its replacement was built does not take the live
 * one's sink with it.
 */
export declare function setContractReportSink(fn: (report: ContractReport) => void): () => void;
/**
 * Report a violation of an ordering contract no type can state.
 *
 * In tree this is the `console.error` it has always been, and the jest gate is
 * what listens. Out of tree it is the only thing that reaches a plugin author
 * at all: their display runs in a production build of somebody's app, which
 * strips nothing here, and a violation surfaces the moment anything arms the
 * channel — a `localStorage` flag, a plugin loaded from localhost, or a site
 * whose config asks for it.
 *
 * `agent-docs/reference/ARCHITECTURAL_LIMITS.md` §"Ordering is the contract" is
 * the register of what reports here.
 */
export declare function reportContractViolation(family: ContractFamily, message: string): void;
