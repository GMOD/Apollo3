import Plugin from '@jbrowse/core/Plugin';
import type PluginManager from '@jbrowse/core/PluginManager';
export { getOrCreateJobsListWidget } from './getOrCreateJobsListWidget.ts';
export type { JobInput, JobsListModel } from './JobsListWidget/model.ts';
export type { JobState } from './JobsListWidget/jobModel.ts';
export default class JobsManagementPlugin extends Plugin {
    name: string;
    install(pluginManager: PluginManager): void;
    configure(pluginManager: PluginManager): void;
}
