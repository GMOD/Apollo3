import type { Instance } from '@jbrowse/mobx-state-tree';
export type JobState = 'running' | 'queued' | 'finished' | 'aborted';
export interface JobFields {
    state: JobState;
    statusMessage?: string;
    progressPct?: number;
    cancelCallback: () => void;
}
/**
 * #stateModel
 * #internal desktop text-indexing queue internals — kept out of the website docs
 * #category widget
 *
 * Created standalone by `JobsListModel` and held in its volatile list rather
 * than attached under it — nothing here belongs in a saved session.
 */
export declare const Job: import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
}, JobFields & {
    /**
     * #action
     * A key that is present is written, so `{statusMessage: undefined}` clears
     * the message and `{}` touches nothing.
     */
    update(fields: Partial<JobFields>): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type JobModel = Instance<typeof Job>;
