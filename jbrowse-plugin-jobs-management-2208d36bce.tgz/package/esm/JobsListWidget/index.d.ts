import type PluginManager from '@jbrowse/core/PluginManager';
export declare const configSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
export default function JobsListWidgetF(pluginManager: PluginManager): void;
