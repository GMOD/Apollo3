import type { JobModel } from '../jobModel.ts';
import type { ReactNode } from 'react';
declare const JobsSection: ({ title, jobs, emptyText, renderCard, onClear, }: {
    title: string;
    jobs: JobModel[];
    emptyText: string;
    renderCard: (job: JobModel) => ReactNode;
    onClear?: () => void;
}) => import("react").JSX.Element;
export default JobsSection;
