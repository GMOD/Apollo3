import type { JobModel } from '../jobModel.ts';
declare const JobCard: ({ job }: {
    job: JobModel;
}) => import("react").JSX.Element;
export default JobCard;
