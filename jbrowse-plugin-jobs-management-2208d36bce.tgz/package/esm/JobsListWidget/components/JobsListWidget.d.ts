import type { JobsListModel } from '../model.ts';
declare const JobsListWidget: ({ model, }: {
    model: JobsListModel;
}) => import("react").JSX.Element;
export default JobsListWidget;
