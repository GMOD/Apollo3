import type { JobModel } from '../jobModel.ts';
declare const CurrentJobCard: ({ job, }: {
    job: JobModel;
}) => import("react").JSX.Element;
export default CurrentJobCard;
