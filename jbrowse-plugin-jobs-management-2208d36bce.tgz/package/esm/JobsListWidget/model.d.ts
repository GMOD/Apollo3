import type { JobFields, JobState } from './jobModel.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { Instance } from '@jbrowse/mobx-state-tree';
export interface JobInput extends Partial<JobFields> {
    name: string;
    state: JobState;
}
/**
 * #stateModel JobsListModel
 * #internal desktop text-indexing queue internals — kept out of the website docs
 * #category widget
 */
export declare function stateModelFactory(_pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ILiteralType<"JobsListWidget">;
}, {
    /**
     * #volatile
     * Volatile like the `jobsQueue` it mirrors: persisted, a session saved
     * mid-index came back with a permanent "Running" card whose Cancel called
     * the default no-op, and a "Queued" card in no queue.
     */
    jobs: import("mobx").IObservableArray<import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }> & JobFields & {
        update(fields: Partial<JobFields>): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }, JobFields & {
        update(fields: Partial<JobFields>): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
} & {
    /**
     * #action
     * Files a job under `state`, or moves the one already named that and
     * refreshes whatever fields came with it. A job runs, finishes and is
     * retried under one name, so this is the only way a card is filed.
     */
    addJob({ name, ...fields }: JobInput): import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }> & JobFields & {
        update(fields: Partial<JobFields>): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }, JobFields & {
        update(fields: Partial<JobFields>): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    /**
     * #action
     * A phase carrying no fraction clears the old one rather than leaving
     * the bar where the last phase left it.
     */
    updateJobStatus(name: string, statusMessage?: string, pct?: number): void;
    /**
     * #action
     */
    clearJobs(state: JobState): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type JobsListStateModel = ReturnType<typeof stateModelFactory>;
export type JobsListModel = Instance<JobsListStateModel>;
