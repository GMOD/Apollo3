import type { AssemblyManager, ParsedLocString } from '@jbrowse/core/util';
import type { BaseBlock, ContentBlock } from '@jbrowse/core/util/blockTypes';
import type { Region } from '@jbrowse/core/util/types';
export declare function expandRegion(start: number, end: number, grow: number, minBound?: number, maxBound?: number): {
    start: number;
    end: number;
};
export declare function makeOverviewTicks(start: number, end: number, bpPerPx: number, reversed?: boolean): {
    genomicCoord: number;
    offsetPx: number;
}[];
export interface Tick {
    type: 'major' | 'minor';
    base: number;
}
export declare function makeTicks(start: number, end: number, bpPerPx: number, emitMajor?: boolean, emitMinor?: boolean): Tick[];
export declare function getBlockRefName(block: BaseBlock): string | undefined;
export declare function showRefNameLabels<T>(blocks: T[], getRefName: (block: T) => string | undefined): boolean[];
export declare function stickyBlockIndex(blocks: BaseBlock[], offsetPx: number): number;
export interface ScalebarRefNameLabel {
    key: string;
    refName: string;
    displayedRegionIndex: number;
    transform: number;
    maxWidth: number;
    paddingLeft: number;
    text: string;
}
export declare function getScalebarRefNameLabels({ blocks, offsetPx, regionEndPx, prefix, }: {
    blocks: BaseBlock[];
    offsetPx: number;
    regionEndPx: Map<number, number>;
    prefix: string | undefined;
}): {
    labels: ScalebarRefNameLabel[];
    showPrefixFallback: boolean;
};
export declare function regionMoveActions(idx: number, numRegions: number): {
    canMoveLeft: boolean;
    canMoveRight: boolean;
    canMoveFarLeft: boolean;
    canMoveFarRight: boolean;
};
export declare function withRegionMoved(regions: Region[], from: number, to: number): Region[];
export declare function withRegionRemoved(regions: Region[], index: number): Region[];
export declare function withRegionReversed(regions: Region[], index: number): Region[];
export declare function labelFitsInBlock(leftPx: number, labelWidth: number, widthPx: number): boolean;
export declare const TICK_LABEL_FONT_SIZE = 11;
export declare function tickLabelWidth(label: string): number;
export declare const REF_NAME_LABEL_FONT_SIZE = 11;
export declare function overviewRefNameLabelWidth(refName: string): number;
export declare function makeOverviewTickLabels({ block, bpPerPx, refNameLabelPx, }: {
    block: {
        start: number;
        end: number;
        reversed?: boolean;
        widthPx: number;
    };
    bpPerPx: number;
    refNameLabelPx: number;
}): {
    genomicCoord: number;
    offsetPx: number;
    label: string;
}[];
export interface BlockRun {
    offsetPx: number;
    widthPx: number;
    start: number;
    end: number;
    reversed: boolean;
}
export declare function groupContiguousBlocks(blocks: BaseBlock[]): BlockRun[];
export declare function makeBlockTicks({ start, end, reversed, }: {
    start: number;
    end: number;
    reversed?: boolean;
}, bpPerPx: number, emitMajor?: boolean, emitMinor?: boolean): {
    type: 'major' | 'minor';
    base: number;
    x: number;
}[];
export declare function generateLocations({ regions, assemblyManager, assemblyName, grow, }: {
    regions: ParsedLocString[];
    assemblyManager: AssemblyManager;
    assemblyName?: string;
    grow?: number;
}): Promise<{
    refName: string;
    start?: number;
    end?: number;
    reversed?: boolean;
    assemblyName: string;
    parentRegion: import("@jbrowse/core/assemblyManager/assembly").BasicRegion;
}[]>;
export declare function parseLocStrings(input: string, assemblyName: string, isValidRefName: (str: string, assemblyName: string) => boolean): ParsedLocString[];
export declare function calculateVisibleLocStrings(contentBlocks: ContentBlock[]): string;
