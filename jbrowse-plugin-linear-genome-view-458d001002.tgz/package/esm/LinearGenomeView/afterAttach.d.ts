import type { LinearGenomeViewModel } from './model.ts';
export declare function setupInitAutorun(self: LinearGenomeViewModel): void;
export declare function doAfterAttach(self: LinearGenomeViewModel): void;
