import type { ComponentType } from 'react';
export interface SequenceSearchModel {
    assemblyNames: string[];
    showTrack: (trackId: string) => void;
}
export interface SequenceSearchModeProps {
    model: SequenceSearchModel;
    handleClose: () => void;
}
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'LinearGenomeView-sequenceSearchPanel': {
            args: ComponentType<SequenceSearchModeProps>;
            result: ComponentType<SequenceSearchModeProps>;
            props: SequenceSearchModeProps;
        };
        'LinearGenomeView-crisprGuidePanel': {
            args: ComponentType<SequenceSearchModeProps>;
            result: ComponentType<SequenceSearchModeProps>;
            props: SequenceSearchModeProps;
        };
        'LinearGenomeView-motifListPanel': {
            args: ComponentType<SequenceSearchModeProps>;
            result: ComponentType<SequenceSearchModeProps>;
            props: SequenceSearchModeProps;
        };
    }
}
export type SequenceSearchExtensionPoint = 'LinearGenomeView-sequenceSearchPanel' | 'LinearGenomeView-crisprGuidePanel' | 'LinearGenomeView-motifListPanel';
export declare function addReferenceScanTrack(model: SequenceSearchModel, args: {
    trackId: string;
    name: string;
    adapter: Record<string, unknown>;
}): void;
