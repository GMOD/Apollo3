export declare function unknownInitKeys(init: object): string[];
export declare function splitLaunchSpec(spec: object): {
    init: Record<string, unknown>;
    viewProps: Record<string, unknown>;
    unknown: string[];
};
