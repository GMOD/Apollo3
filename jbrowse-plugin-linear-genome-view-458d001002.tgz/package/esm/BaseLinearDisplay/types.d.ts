import type { ExportSvgOptions } from '../LinearGenomeView/types.ts';
import type TrackHeightMixin from './models/TrackHeightMixin.tsx';
import type { DisplayModel } from '@jbrowse/core/pluggableElementTypes/models';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type { ThemeOptions } from '@mui/material';
export type LinearDisplayModel = DisplayModel & Instance<ReturnType<typeof TrackHeightMixin>> & {
    prefersOffset?: boolean;
};
export interface Layout {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    name: string;
}
export type LayoutRecord = [number, number, number, number];
export interface ExportSvgDisplayOptions extends ExportSvgOptions {
    theme?: ThemeOptions;
    legendWidth?: number;
    createCanvas?: (width: number, height: number) => HTMLCanvasElement;
}
