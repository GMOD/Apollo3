export default function GlobalFetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{}, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
} & {
    readonly gateFoldedIntoFetch: boolean;
    readonly byteGateEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateVisibleBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly aboveForceLoadFloor: boolean;
    readonly byteGateExempt: boolean;
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
    resolvedByteLimit(): number | undefined;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    setByteEstimate(estimate: import("../../index.ts").ByteEstimate): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: {
        isStale: () => boolean;
    }): Promise<boolean>;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: import("./FetchMixin.ts").FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    reloadCounter: number;
} & {
    readonly dataCurrent: boolean;
    readonly svgReadyExtraTerminal: boolean;
} & {
    readonly svgReady: boolean;
} & {
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalFetchMixinType = ReturnType<typeof GlobalFetchMixin>;
