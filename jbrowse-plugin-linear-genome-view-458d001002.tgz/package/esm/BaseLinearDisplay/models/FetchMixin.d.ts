import type { RpcStatus } from '@jbrowse/core/util';
import type { StopToken } from '@jbrowse/core/util/stopToken';
export interface FetchContext {
    stopToken: StopToken;
    isStale: () => boolean;
}
export default function FetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    activeStopToken: StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, RpcStatus>;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: RpcStatus) => void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type FetchMixinType = ReturnType<typeof FetchMixin>;
