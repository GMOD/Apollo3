import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function serializeRpcProps(self: IAnyStateTreeNode & {
    rpcProps?: () => unknown;
}): string;
