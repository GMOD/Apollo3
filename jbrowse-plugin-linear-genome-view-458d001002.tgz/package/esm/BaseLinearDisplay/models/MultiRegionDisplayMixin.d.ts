import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
import type { FetchContext } from './FetchMixin.ts';
import type { Region } from '@jbrowse/core/util';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
import type { IAutorunOptions } from 'mobx';
export type { FetchContext } from './FetchMixin.ts';
export declare function isBlockCovered(loaded: Region | undefined, block: {
    refName: string;
    start: number;
    end: number;
}): boolean;
export default function MultiRegionDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{}, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
} & {
    readonly gateFoldedIntoFetch: boolean;
    readonly byteGateEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateVisibleBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly aboveForceLoadFloor: boolean;
    readonly byteGateExempt: boolean;
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
    resolvedByteLimit(): number | undefined;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    setByteEstimate(estimate: import("../../index.ts").ByteEstimate): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: {
        isStale: () => boolean;
    }): Promise<boolean>;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    loadedRegions: import("mobx").ObservableMap<number, Region>;
} & {
    readonly canRender: boolean;
    readonly isReady: boolean;
    readonly viewportWithinLoadedData: boolean;
    readonly dataCurrent: boolean;
    readonly svgReady: boolean;
    readonly svgReadyExtraTerminal: boolean;
    readonly layoutReady: boolean;
    readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
} & {
    readonly displayPhase: DisplayPhase;
    readonly rpcPropsCacheKey: string;
} & {
    setLoadedRegion(displayedRegionIndex: number, region: Region): void;
    clearDisplaySpecificData(): void;
} & {
    clearAllRpcData(): void;
    reload(): void;
    invalidateLoadedRegions(): void;
} & {
    fetchNeeded(_needed: {
        region: Region;
        displayedRegionIndex: number;
    }[]): void;
    onRegionTooLarge(): void;
} & {
    isCacheValid(_displayedRegionIndex: number): boolean;
} & {
    fetchRegions(needed: {
        region: Region;
        displayedRegionIndex: number;
    }[], work: (ctx: FetchContext) => Promise<void>): Promise<void>;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type MultiRegionDisplayMixinType = ReturnType<typeof MultiRegionDisplayMixin>;
export declare function autorunOnReadyView(self: IAnyStateTreeNode, fn: (view: LinearGenomeViewModel) => void, opts?: IAutorunOptions): void;
export declare function makeSettingsLoopGuard(name: string): () => void;
interface FetchEachRegionModel {
    fetchRegions: (needed: {
        region: Region;
        displayedRegionIndex: number;
    }[], work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
}
export declare function callEachRegion<R>(needed: {
    region: Region;
    displayedRegionIndex: number;
}[], ctx: FetchContext, call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>): Promise<{
    displayedRegionIndex: number;
    result: R;
}[]>;
export declare function fetchEachRegion<R>(self: FetchEachRegionModel, needed: {
    region: Region;
    displayedRegionIndex: number;
}[], opts: {
    call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
export declare function fetchAllRegions<R>(self: FetchEachRegionModel, needed: {
    region: Region;
    displayedRegionIndex: number;
}[], opts: {
    call: (regions: Region[], ctx: FetchContext) => Promise<R[]>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
export declare function onDisplayedRegionsChange(self: IAnyStateTreeNode, clear: () => void, name?: string): void;
