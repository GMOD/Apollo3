import type { LegendItem, LegendSection } from '@jbrowse/core/ui';
export type { LegendItem, LegendSection, LegendSpec } from '@jbrowse/core/ui';
declare const FloatingLegend: ({ items, sections, title, onDismiss, onDismissSection, maxItems, }: {
    items?: LegendItem[];
    sections?: LegendSection[];
    title?: string;
    onDismiss?: () => void;
    onDismissSection?: (id: string) => void;
    maxItems?: number;
}) => import("react").JSX.Element | null;
export default FloatingLegend;
