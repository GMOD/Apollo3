import type { TooLargeMessageModel } from '../../shared/TooLargeMessage.tsx';
import type { DisplayBackgroundProgressModel } from './DisplayBackgroundProgress.tsx';
import type { DisplayErrorBarModel } from './DisplayErrorBar.tsx';
import type { DisplayLoadingOverlayModel } from './DisplayLoadingOverlay.tsx';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
import type { RenderLifecycleModel } from '@jbrowse/render-core/useRenderingBackend';
import type { ComponentPropsWithRef, ReactNode } from 'react';
export type ChromeModel = {
    displayPhase: DisplayPhase;
    height: number;
    canvasDrawn: boolean;
} & DisplayErrorBarModel & TooLargeMessageModel & DisplayLoadingOverlayModel & DisplayBackgroundProgressModel;
interface CanvasHandle {
    canvasRef: (node: HTMLCanvasElement | null) => void;
    canvas: HTMLCanvasElement | null;
}
declare function DisplayChromeInner<B extends {
    dispose(): void;
}>({ model, factory, children, testid, style, ...divProps }: {
    model: ChromeModel & RenderLifecycleModel<B>;
    factory: (canvas: HTMLCanvasElement) => Promise<B>;
    children: (handle: CanvasHandle) => ReactNode;
    testid?: string;
} & Omit<ComponentPropsWithRef<'div'>, 'children'>): import("react").JSX.Element;
declare const DisplayChrome: typeof DisplayChromeInner;
export default DisplayChrome;
