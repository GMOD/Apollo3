export interface DisplayBackgroundProgressModel {
    statusMessage?: string;
    statusProgress?: number;
}
declare const DisplayBackgroundProgress: ({ model, visible, }: {
    model: DisplayBackgroundProgressModel;
    visible: boolean;
}) => import("react").JSX.Element | null;
export default DisplayBackgroundProgress;
