export declare const LABEL_WIDTH = 100;
export declare function GuideLabel({ coordX, viewWidth, stickyTop, children, }: {
    coordX: number;
    viewWidth: number;
    stickyTop: number | undefined;
    children: React.ReactNode;
}): import("react").JSX.Element;
export declare function SpanEdgeLabels({ stickyTop, left, right, insideLeft, insideRight, }: {
    stickyTop: number | undefined;
    left: React.ReactNode;
    right: React.ReactNode;
    insideLeft: boolean;
    insideRight: boolean;
}): import("react").JSX.Element;
