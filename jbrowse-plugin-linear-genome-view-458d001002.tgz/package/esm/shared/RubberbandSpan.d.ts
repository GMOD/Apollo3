export default function RubberbandSpan({ left, width, viewWidth, stickyTop, leftLabel, rightLabel, size, }: {
    left: number;
    width: number;
    viewWidth: number;
    stickyTop: number | undefined;
    leftLabel: React.ReactNode;
    rightLabel: React.ReactNode;
    size?: React.ReactNode;
}): import("react").JSX.Element;
