export declare const AUTO_FORCE_LOAD_BP = 20000;
export declare function getDisplayStr(totalBytes: number): string;
export interface ByteEstimate {
    bytes: number | undefined;
    measuredSpanBp: number;
}
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
export declare function resolveByteLimit({ adapterFetchSizeLimit, configFetchSizeLimit, }: {
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number;
}): number;
export declare function rescaleByteEstimateToVisibleSpan({ byteEstimate, visibleBp, }: {
    byteEstimate: ByteEstimate | undefined;
    visibleBp: number;
}): number | undefined;
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
}
export declare const NOT_TOO_LARGE: RegionTooLargeStatus;
export declare function evaluateRegionTooLarge({ estimatedBytesForVisibleSpan, byteLimit, densityTooLarge, }: {
    estimatedBytesForVisibleSpan?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
}): RegionTooLargeStatus;
