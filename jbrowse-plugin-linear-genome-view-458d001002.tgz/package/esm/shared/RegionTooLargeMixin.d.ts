import type { ByteEstimate } from './regionTooLargeUtils.ts';
export default function RegionTooLargeMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    forceLoadTrack: boolean;
    byteEstimate: ByteEstimate | undefined;
} & {
    readonly gateFoldedIntoFetch: boolean;
    readonly byteGateEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateVisibleBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly aboveForceLoadFloor: boolean;
    readonly byteGateExempt: boolean;
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
    resolvedByteLimit(): number | undefined;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    setByteEstimate(estimate: ByteEstimate): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: {
        isStale: () => boolean;
    }): Promise<boolean>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
