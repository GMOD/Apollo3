import { Connection, ConnectionManager, ConnectionOptions, createConnection, getConnectionManager } from 'typeorm';

export class Database {
  private connectionManager: ConnectionManager;

  constructor() {
    this.connectionManager = getConnectionManager();
  }

  public async getConnection(name: string): Promise<Connection> {
    const CONNECTION_NAME: string = name;
    let connection: Connection;
    const hasConnection = this.connectionManager.has(CONNECTION_NAME);
    if (hasConnection) {
      connection = this.connectionManager.get(CONNECTION_NAME);
      if (!connection.isConnected) {
        connection = await connection.connect();
      }
    } else {
        const connectionManager = new ConnectionManager();
        // TODO: Read values from property file
        const connection = connectionManager.create({
            type: "mysql",
            host: "localhost",
            port: 3306,
            username: 'apollo',
            password: 'apollo123',
            database: 'apollo-production'
            });
        await connection.connect(); 
        return connection;
    }
  }
}

