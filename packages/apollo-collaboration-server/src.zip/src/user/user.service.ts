import { HttpStatus, Injectable } from '@nestjs/common';
import { from } from 'rxjs';
import { Database } from 'src/utils/database';
import { serviceresponse } from 'src/database/serviceresponse';
import { Connection } from 'typeorm';

@Injectable()
export class UserService extends Error {
    
    async getAllUsers(): Promise<any> {
        console.log('Calling getAllUsers()');
        const connectionName = 'default';
        const database = new Database();
        try {
            const dbConn: Connection = await database.getConnection(connectionName);
            if (dbConn.isConnected) {
                return dbConn.manager.query('SELECT first_name from grails_user');
            } else {
                console.error('No connection to database');
                return null;
            }    
        } catch(error) {
            console.error('Error : ' + error);
            return null;
        }
     }


    async getAllUsersAsClass(): Promise<serviceresponse> {
        console.log('Starting getMoi()');
        const connectionName = 'default';
        const database = new Database();
        try {
            const dbConn: Connection = await database.getConnection(connectionName);
            if (dbConn.isConnected) {
                console.log('Tee kysely');
                const ret = dbConn.manager.query('SELECT first_name from grails_user');
                let retu = new serviceresponse();
                retu.setHttpResponseStatus('HttpStatus.OK');
                retu.setResult(ret);
                return retu;
                // return {
                //     statusCode: HttpStatus.OK,
                //     ret
                //   };            
                // return dbConn.manager.query('SELECT first_name from grails_user'); 
            } else {
                console.error('ELSE VIRHE');
                return null;
            }    
        } catch(error) {
            // console.warn('CATCH VIRHE:' + error);
            let retu = new serviceresponse();
            retu.setHttpResponseStatus('HttpStatus.VIRHE');
            retu.setResult(null);
            return retu;

            // return null;
        }
     }

    
}
