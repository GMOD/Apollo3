import { Controller, Get, HttpStatus, Post, Request, Res, UseGuards } from '@nestjs/common';
import { UserService } from './user.service';
// import { Connection, getConnection, createConnection, ConnectionOptions } from 'typeorm';
// import { Database } from 'src/utils/database';
// import { resolve } from 'path/posix';
// import { rejects } from 'node:assert';

import { JwtAuthGuard } from './../utils/jwt-auth.guard';
import { Response } from 'express';
// import { response } from 'express';
// import { LocalAuthGuard } from './local-auth.guard';
//import { Request, Response } from 'express';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @UseGuards(JwtAuthGuard)
  @Get('/ok')
  async getOk() {
    const ret = await this.userService.getAllUsers();
    console.log(ret);
    // return [{ status: 'Status xxx', json: ret.getResult }]

    if (ret != null) {
      return ret.getResult();
    } else 
    return ret;
    return {
      statusCode: HttpStatus.BAD_REQUEST,
      message: 'Bad request'
    };

  }

  //constructor(private readonly userService: UserService, private readonly connection: Connection) {}
  //constructor(private readonly connection: Connection) {}
  // @UseGuards(LocalAuthGuard)
    // @Post('login')
    // async login(@Request() req) {
    //   return this.authService.login(req.user);
    // }
  
    // @UseGuards(JwtAuthGuard)
    // @Get('profile')
    // getProfile(@Request() req) {
    //   return req.user;
    // }
  
    @Get()
    async getUsers(@Res() response: Response) {
      let errorMessage;
      let returnValue;
      await this.userService.getAllUsers()
        .then(ret => {
          returnValue = ret;
          console.log(returnValue);
        })
        .catch((message) => {
            console.error('Service call failed : ' + message);
            errorMessage = message;
          });

      if (returnValue != null) {
        console.log('getUsers() returned OK');
        return response.status(HttpStatus.OK).json(returnValue);
      } else {
        console.error('getUsers() failed : ' + errorMessage);
        return response.status(HttpStatus.BAD_REQUEST).json({
          status: HttpStatus.BAD_REQUEST,
          message: errorMessage
        });  
      }

      // console.log('Starting getMoi()');
      // const connectionName = 'default';
      // const database = new Database();
      // const dbConn: Connection = await database.getConnection(connectionName);
      // console.log('0 Tultiin userin getMoi 11. yhteys auki: ' + dbConn.isConnected);
      // let vas = dbConn.manager.query('SELECT first_name from grails_user');
      // console.log('Vastaus : ');
      // console.log(vas);
      // if (1 > 0) return vas;
    }

    /*
    @Get()
    async getMoi() {
      console.log('Tultiin userin getMoi 1');
      const connectionName = 'default';
      const database = new Database();
      const dbConn: Connection = await database.getConnection(connectionName);
      //dbConn.connect();
      console.log('0 Tultiin userin getMoi 11. yhteys auki: ' + dbConn.isConnected);
      let vas = dbConn.manager.query('SELECT first_name from grails_user');
      // console.log('Vastaus : ');
      // console.log(vas);
      // if (1 > 0) return vas;

  
      // const dbConn: Connection = await database.getConnection(connectionName);
      // const MspRepository = dbConn.getRepository(Msp);
      // await MspRepository.delete(mspId);

      // let p = new Promise((resolve, rejects) => {
      //   let a = 1 + 1;
      //   if (a=2) {
      //     resolve('Success');
      //   } else {
      //     rejects('Failed');
      //   }
      // });

      // p.then((message) => {
      //   console.log('Nyt onnistui ' + message)
      // }).catch((message) => {
      //   console.log('Epaonnistui ')
      // });

      let prom = new Promise((resolve, rejects) => {
        try {
          let val = dbConn.manager.query('SELECT first_name from grails_user');
          resolve(val)
        } catch (error) {
          rejects('Kysely ei onnistunut')
        };
      });


      prom.then((val) => {
        console.log('Tehtiin kysely oikein!');
        return val;
      }).catch((message) => {
        console.log('2 Epaonnistui ')
      });

      // let val = dbConn.query('select 1 + 1 as solution');
      console.log('Tulos');
      // let val = dbConn.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
      //   if (error) throw error;
      //   console.log('The solution is: ', results[0].solution);
      //   });
        // console.log('Tulos=%s', val);
        // if (dbConn.isConnected) dbConn.close();

        // console.log('Onko yhteys auki:' + dbConn.isConnected);
        // console.log('Tultiin userin 3');

    //   console.log('Tultiin userin getMoi 12');
    //   //let connection: Connection;
    // //   connection = getConnection(db_config.name);
    // const connection: ConnectionOptions = {
    //     name: 'testi',
    //     type: "mysql",
    //     host: "localhost",
    //     port: 3306,
    //     username: "apollo",
    //     password: "apollo123",
    //     database: "apollo-production",
    //     // name: databaseName,
     //     synchronize: false
    //   };
  
    //   try {
    //     console.log('Tultiin userin getMoi 2');
    //     let ali = getConnection('testi');
    //     //getConnection(connection.name);
    //     console.log('Tultiin userin getMoi 3');
    //   } catch (error) {
    //     console.error('Tultiin userin getMoi CATCH error=%s', error);
    //   }
    //   console.log('Tultiin userin getMoi 4');
    //   let muu = createConnection(connection);
    //   console.log('Tultiin userin getMoi 5');
    //   console.log(muu);

      // Connection connection = require('Connection');
      // var mysql      = require('mysql');
      //   var connection1 = mysql.createConnection({
      //   host     : 'localhost:3306',
      //   user     : 'apollo',
      //   password : 'apollo123',
      //   database : 'apollo-production'
      //   });
      //   console.log('Tultiin userin 1');
      //   connection1.connect();
      //   console.log('Tultiin userin 2');
      //   connection1.query('SELECT 1 + 1 AS solution', function (error, results, fields) {
      //   if (error) throw error;
      //   console.log('The solution is: ', results[0].solution);
      //   });
      //   console.log('Tultiin userin 3');
        
      //   connection.end();
        console.log('Tultiin userin 4');
      return 'Moikkaa123 User';
    }
*/

}
function InjectConnection() {
  throw new Error('Function not implemented.');
}

