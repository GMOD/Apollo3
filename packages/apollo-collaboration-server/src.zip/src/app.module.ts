import { Module } from '@nestjs/common';
import { AuthenticateModule } from './authenticate/authenticate.module';
import { UserModule } from './user/user.module';
import { DatabaseModule } from './database/database.module';
import { Connection } from 'typeorm';


@Module({
  imports: [AuthenticateModule, UserModule],
})
export class AppModule {}
