import { Controller, Get, HttpStatus, Post, Request, UseGuards } from '@nestjs/common';
import { AuthenticateService } from './authenticate.service';
import { JwtAuthGuard } from './../utils/jwt-auth.guard';
import { LocalAuthGuard } from './../utils/local-auth.guard';

@Controller('auth')
export class AuthenticateController {

    constructor(private readonly authService: AuthenticateService) {}

    @UseGuards(LocalAuthGuard)
    @Post('login')
    async login(@Request() req) {
      return this.authService.login(req.user);
    }
  
    @UseGuards(JwtAuthGuard)
    @Get('profile')
    getProfile(@Request() req) {
      return req.user;
    }
  
    @Get()
    getMoi() {
      console.log('Tultiin getMoi');
      return {
        statusCode: HttpStatus.OK,
        message: 'User fetched successfully'
      };
    }
  
    // @Get(':id')
    // async readUser(@Param('id') id: number) {
    //   const data =  await this.usersService.read(id);
    //   return {
    //     statusCode: HttpStatus.OK,
    //     message: 'User fetched successfully',
    //     data,
    //   };
    // }

}
