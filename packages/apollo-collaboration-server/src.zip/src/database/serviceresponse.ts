export class serviceresponse {
    private result: object;
    private httpresponse: string;


    constructor() {
      this.httpresponse = "";
      this.result = null;
    }

    getResult() {
      return this.result;
  }

    setResult(result: object) {
        this.result = result;
    }
    setHttpResponseStatus(status: string) {
      this.httpresponse = status;
  }
}