/**
 * The span below which the **density** axis stops gating. `aboveForceLoadFloor`
 * on `RegionTooLargeMixin` is the only comparison against it.
 *
 * **On the byte axis it is a budget tier, not a floor** — see
 * {@link SUB_FLOOR_BYTE_BUDGET_FACTOR}. Why, and the measurements that decided
 * it: agent-docs/reference/REGION_TOO_LARGE.md § "The sub-floor budget tier".
 */
export declare const AUTO_FORCE_LOAD_BP = 20000;
/**
 * How much the byte budget is multiplied by below {@link AUTO_FORCE_LOAD_BP}.
 * The gate keeps asking down there — a tier, not an off-switch — but against a
 * larger number, because at gene scale the user navigated to this locus
 * deliberately.
 *
 * A policy dial, not a derived constant: raise it if real tracks keep bannering
 * at a locus, lower it if a tab hangs. What it is sized against, and why a tier
 * rather than the old floor: agent-docs/reference/REGION_TOO_LARGE.md § "The
 * sub-floor budget tier".
 */
export declare const SUB_FLOOR_BYTE_BUDGET_FACTOR = 2;
/**
 * One measurement of what a fetch would cost, taken at the viewport it
 * describes. **There is no second, derived byte number** — there used to be
 * (`estimatedBytesForVisibleSpan`, this one scaled by `visibleBp /
 * measuredSpanBp`) and the scaling was fiction: index estimates are quoted in
 * whole blocks, so they do not follow span, and the model under-reported by up
 * to three orders of magnitude on real files (see {@link AUTO_FORCE_LOAD_BP}).
 * The gate re-measures when the viewport moves under it instead — see
 * `RegionTooLargeMixin` §"Measurement follows the viewport".
 */
export interface ByteEstimate {
    /**
     * Undefined is not representable: an adapter quoting no estimate leaves the
     * whole {@link ByteEstimate} unset, so "unmeasurable" and "not measured yet"
     * are one state. `0` is a real measurement — a region with no index chunks.
     */
    bytes: number;
    /**
     * The **visible** span this measurement was taken at, captured before the
     * round trip. Nothing divides by it any more; it is kept because two
     * consecutive measurements at two spans are the only evidence anyone has about
     * whether zooming shrinks this file's fetch ({@link zoomIneffective}).
     *
     * Not the span `bytes` covers: a display measures the regions it is about to
     * fetch, which for the `MultiRegionDisplayMixin` family are
     * `bufferedVisibleRegions` — half a screen each side, so twice the visible
     * span. The number the banner quotes is therefore the whole download rather
     * than the on-screen slice of it, which is the honest thing to ask permission
     * for.
     */
    measuredSpanBp: number;
    /**
     * The user zoomed in materially and the estimate did not fall — so this file
     * quotes the same blocks however far they go, and "zoom in to see features" is
     * advice that cannot work. Drives `zoomCanReleaseGate`, which is what the
     * banner offers a way out from.
     *
     * **Measured, never predicted.** False on a first measurement, because one
     * point is not evidence; set by {@link nextByteEstimate} when a later
     * measurement at a materially smaller span comes back materially unchanged,
     * and cleared again the moment one does fall. Predicting it instead would mean
     * sampling the index at a ladder of sub-spans up front, which costs 18x the
     * one call on a whole-genome region set (2.4s against 133ms, measured
     * 2026-08-06) to answer a question only a blocked track ever asks.
     */
    zoomIneffective: boolean;
}
/** What a measurement is about, captured before it is requested. */
export interface GateViewport {
    spanBp: number;
    key: string;
}
/**
 * The gate as it was when a fetch was issued, since both fields move during the
 * round trip and its results are judged against neither's live value.
 */
export interface GateFetchState {
    viewport: GateViewport | undefined;
    gated: boolean;
}
/**
 * Fold a fresh measurement into the stored one, carrying across the only thing
 * the stored one knows that the fresh one can't: whether zooming has been shown
 * not to help. See {@link ByteEstimate.zoomIneffective}.
 *
 * Deliberately a pure function rather than logic inside `setByteEstimate`, so
 * the "two points make the evidence" rule is testable without a model, and so
 * the thresholds sit next to the measurements that chose them.
 */
export declare function nextByteEstimate(previous: ByteEstimate | undefined, measurement: {
    bytes: number;
    viewport: GateViewport;
}): ByteEstimate;
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
/**
 * Resolve the effective byte budget: the adapter's self-reported limit, else the
 * display's configured default, times {@link SUB_FLOOR_BYTE_BUDGET_FACTOR} when
 * the span is below {@link AUTO_FORCE_LOAD_BP}. A non-positive adapter limit
 * means "no opinion" (e.g. htsget/no-index adapters report 0) and is skipped —
 * without this guard a 0 would gate every request as too-large, and a negative
 * sentinel (-1) would survive `|| undefined` (truthy) and do the same.
 *
 * All three inputs are read on the main thread (`gateByteLimit`), so the banner
 * and the worker budget resolve one number. There is deliberately no force-load
 * tier: force-load is a boolean "render this track regardless" (`gateExempt`),
 * not a raised ceiling
 * (agent-docs/architecture-decision-records/adr-074-force-load-is-one-boolean-per-track.md).
 * The span tier is not that ceiling wearing a hat: it is static rather than
 * derived from a measurement, single-axis by construction, and never expires.
 */
export declare function resolveByteLimit({ adapterFetchSizeLimit, configFetchSizeLimit, belowForceLoadFloor, }: {
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number;
    belowForceLoadFloor: boolean;
}): number;
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
    /**
     * Which axis tripped, absent when nothing did. Not a second spelling of
     * `reason` — `zoomCanReleaseGate` has to branch on it, because the two axes
     * answer "would zooming in help?" differently and only one of them can
     * honestly say no. Screen density is features ÷ pixels, so it falls with
     * `bpPerPx` whatever the file looks like; bytes come in whole index blocks
     * and may not fall at all ({@link ByteEstimate.zoomIneffective}). Matching on
     * the reason string instead would tie the banner's logic to its wording.
     */
    axis?: 'bytes' | 'density';
}
/**
 * The comparison half of the verdict: which axis is over budget, and the banner
 * text for it. Bytes take precedence over density for both.
 *
 * Deliberately knows nothing about *whether* each axis applies — force-load, the
 * opt-in, and the `AUTO_FORCE_LOAD_BP` floor on the density axis live in
 * `gateActive` / `densityGateActive` on `RegionTooLargeMixin`, which are also
 * what stop the pre-flight RPC and the worker budgets. Those ask "may this axis
 * gate?", this one asks "does it?" — so each caller passes `undefined` / `false`
 * for an axis that is off rather than restating why.
 */
export declare function evaluateRegionTooLarge({ estimatedFetchBytes, byteLimit, densityTooLarge, }: {
    estimatedFetchBytes?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
}): RegionTooLargeStatus;
