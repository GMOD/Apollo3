import type { IndexedRegion } from './planRegionFetch.ts';
import type { Region } from '@jbrowse/core/util';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * What the per-region fetch autoruns read and call. Duck-typed rather than the
 * mixin's own `Instance` type: `MultiRegionDisplayMixin` composes this
 * installer, so a nominal type would be circular, and naming the members here
 * is also the list of what the autoruns are allowed to touch.
 */
export interface PerRegionFetchHost extends IStateTreeNode {
    error: unknown;
    fetchCanceled: boolean;
    fetchGeneration: number;
    reloadCounter: number;
    isLoading: boolean;
    fetchInert: boolean;
    awaitingPrerequisite: boolean;
    gateSkipsMeasuredViewport: boolean;
    /** read by the hover-clear reaction, which the too-large banner also fires */
    regionTooLarge: boolean;
    loadedRegions: {
        get: (displayedRegionIndex: number) => Region | undefined;
    };
    rpcPropsCacheKey: string;
    isCacheValid: (displayedRegionIndex: number) => boolean;
    fetchNeeded: (needed: IndexedRegion[]) => void;
    setError: (error?: unknown) => void;
    clearAllRpcData: () => void;
    clearByteEstimate: () => void;
    clearHoveredFeature: () => void;
}
/**
 * Install the per-region fetch lifecycle: `DisplayedRegionsChange`,
 * `FetchVisibleRegions`, `SettingsInvalidate`,
 * `ClearBlockingStateOnViewportChange`, and the stored-hover clear.
 *
 * The third fetch-family installer, beside `installGlobalFetchAutorun` and
 * `installComparativeFetchAutorun`. It is a function rather than an inline
 * `afterAttach` body for the reason those two are: **what this file decides is
 * the MobX dependency set**, and that is the half no pure function can express.
 * `planRegionFetch` owns the decision; this owns which reads are tracked, which
 * are `untracked` perf guards, and which sit behind a thunk so an early bail-out
 * does not subscribe to the viewport. `installPerRegionFetchAutoruns.test.ts`
 * is what fails when one of those moves.
 */
export declare function installPerRegionFetchAutoruns(self: PerRegionFetchHost): void;
