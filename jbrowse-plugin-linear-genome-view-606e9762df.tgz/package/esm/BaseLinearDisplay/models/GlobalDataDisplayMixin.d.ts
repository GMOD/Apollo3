import type { FetchContext } from './FetchMixin.ts';
import type { FetchPhases } from '@jbrowse/core/util/fetchPhases';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
export type { FetchContext } from './FetchMixin.ts';
export { type GlobalFetchMixinType, default as GlobalFetchMixin, } from './GlobalFetchMixin.ts';
/**
 * Mixin for GPU displays that hold a single global (non-regional) dataset —
 * HiC contact matrix, LD triangle, variant matrix, etc.
 *
 * `GlobalFetchMixin` (the rendering-agnostic fetch foundation) + RenderLifecycleMixin
 * (attachRenderingBackend, renderNow, renderError, …) + the GPU `displayPhase`.
 *
 * Unlike MultiRegionDisplayMixin, it owns no per-region state and installs no
 * autoruns. Fetch triggering is left to the display's own afterAttach autorun so
 * each display can express its own trigger conditions (HiC: viewport change; LD:
 * viewport + showLDTriangle + etc). The shared skeleton of that autorun lives in
 * `installGlobalFetchAutorun` (below) — a display supplies only its own
 * `prepare` / `run` / `commit` phases.
 *
 * #stateModel GlobalDataDisplayMixin
 * #displayFoundationDef One non-regional dataset with no per-region partitioning, plus the GPU render lifecycle. Installs no fetch autoruns; the display adds its own via `installGlobalFetchAutorun`.
 * #category display
 */
export default function GlobalDataDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<Omit<{}, never>, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly measuresBytesInFetch: boolean;
    readonly measuresBytesPreFlight: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("../../index.ts").GateViewport | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
    gateFetchState(): import("../../index.ts").GateFetchState;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number;
        viewport: import("../../index.ts").GateViewport;
    }): void;
    setGateMeasuredViewport(viewport: import("../../index.ts").GateViewport): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    commitByteMeasurement({ viewport, gated, bytes, }: {
        viewport: import("../../index.ts").GateViewport;
        gated: boolean;
        bytes?: number;
    }): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: FetchContext): Promise<boolean>;
} & {
    afterAttach(): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    reloadCounter: number;
    statusWindow: import("@jbrowse/core/util").StatusWindow;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
} & {
    fetchRotation: {
        begin(): import("@jbrowse/core/util").ActiveFetch;
        cancel: () => void;
        dispose(): void;
    };
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly fetchInert: boolean;
    readonly awaitingPrerequisite: boolean;
    readonly rpcPropsCacheKey: string;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
} & {
    stopActiveFetch(): void;
    openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
} & {
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    readonly lgv: import("../../index.ts").LinearGenomeViewModel;
    readonly dataCurrent: boolean;
} & {
    readonly svgReady: boolean;
} & {
    reload(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
    readonly rendersCanvas: boolean;
    readonly paintInert: boolean;
} & {
    readonly painted: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    /**
     * #getter
     * Same render-lifecycle precondition as MultiRegionDisplayMixin (overrides
     * `RenderLifecycleMixin`'s default-true hook): a global display's
     * `renderState` is still sized off view geometry (`totalWidthPx`,
     * `dynamicBlocks`), which throws before the view is measured. Gating the
     * autorun pair here keeps that out of every display's callbacks.
     */
    readonly canRender: boolean;
    /**
     * #getter
     * Fills `RenderLifecycleMixin`'s `paintInert` hook — see there for why a
     * failed fetch has to read as finished to the consumers outside the
     * display. The per-region family declares the identical override.
     */
    readonly paintInert: boolean;
} & {
    /**
     * #getter
     * The display's mutually-exclusive visual state, mapped in
     * `foundationDisplayPhase` — every foundation calls it and supplies only
     * its staleness argument, so a term added to `computeLoadingTerm` reaches
     * all three without being wired three times.
     *
     * This family's argument is the constant `true`, deliberately: a global
     * display keeps the last frame up through a refetch (worker output is
     * genomic, so the stale frame draws correctly under the live view
     * transform), so a pan or zoom shows no scrim
     * beyond the `isLoading` window. The pre-first-paint scrim it *does* want
     * — the gap between mount and `isLoading` going true, which on HiC is the
     * `CoreGetInfo` round-trip its first fetch waits on — is
     * `computeLoadingTerm`'s shared `rendersCanvas && !canvasDrawn` term, not
     * anything this family spells out.
     *
     * It lives here rather than in `GlobalFetchMixin` because the phase reads
     * `renderError`, which is `RenderLifecycleMixin`'s.
     */
    readonly displayPhase: DisplayPhase;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalDataDisplayMixinType = ReturnType<typeof GlobalDataDisplayMixin>;
/**
 * This family's spelling of the shared three-phase contract, over
 * `FetchMixin.runFetch` and its `FetchContext`. The rules live on
 * {@link FetchPhases}; the comparative family names the same type over its own
 * context.
 */
export type GlobalFetchPhases<TArgs, TResult> = FetchPhases<TArgs, TResult, FetchContext>;
interface GlobalFetchHost extends IStateTreeNode {
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
}
interface GlobalFetchAutorunHost extends GlobalFetchHost {
    isMinimized: boolean;
    reloadCounter: number;
    fetchInert: boolean;
    awaitingPrerequisite: boolean;
    rpcPropsCacheKey: string;
    gateSkipsMeasuredViewport: boolean;
}
/**
 * One fetch through the phases: prepare, then `run` under `FetchMixin.runFetch`
 * (which owns cancellation, the error and the loading flag), then commit while
 * still current. Returns the fetch's promise, or `undefined` when `prepare`
 * declined — so the autorun below can say which happened, and a caller that
 * wants one round trip on demand can await it.
 */
export declare function runGlobalFetch<TArgs, TResult>(self: GlobalFetchHost, { prepare, run, commit }: GlobalFetchPhases<TArgs, TResult>): Promise<void> | undefined;
/**
 * Install the fetch-trigger autorun for a `GlobalDataDisplayMixin` display.
 *
 * Unlike `MultiRegionDisplayMixin` (which installs its five fetch autoruns for
 * you), this mixin installs none — each global display owns its trigger. But
 * every global trigger shares the same skeleton: track the viewport,
 * minimize/expand, the `rpcProps()` cache key and `reloadCounter` so any of them
 * refires the fetch, then debounce. This helper owns that skeleton so a display
 * supplies only its own `prepare` / `run` / `commit`.
 *
 * Runs through `autorunOnReadyView`, so the body never reads a throwing view
 * getter (`dynamicBlocks`, `width`) before the view is initialized, and
 * re-runs automatically once it is. `prepare` inherits that: it is reached only
 * on a ready view, so a composer restating `view.initialized` is restating the
 * skeleton.
 *
 * **What `prepare` adds to the dependency set.** Everything it reads, since it
 * runs synchronously in the autorun body — which for the two displays that used
 * to bail out inside an MST action (MobX runs those untracked) means the
 * viewport pair and the block list join the set. Both were already in it
 * transitively: `dynamicBlocks` above is a computed over `offsetPx`, `bpPerPx`
 * and `width`, so any move that a direct read would catch has already
 * invalidated it. Arc reads `staticBlocks` in its `prepare` on top of that, and
 * static blocks are quantized from the same pair, so it fires on a subset of the
 * runs `dynamicBlocks` already causes. What a `prepare` must NOT do is move a
 * trigger read of its own under a bail-out — that is the failure the trigger
 * list above exists for.
 *
 * `rpcProps()` loop hazard: unlike MultiRegion's `SettingsInvalidate` (which
 * clears data in a *separate, undelayed* autorun and so loops synchronously if
 * `rpcProps()` *returns* fetch-derived state — caught by `makeSettingsLoopGuard`),
 * this autorun reads the key and starts the fetch in the *same* debounced body.
 * A fetch-derived value in the payload here loops on the async-fetch cadence
 * (refetch → commit → key changes → reschedule after `delay` → refetch), a slow
 * network thrash rather than a synchronous freeze, so a within-tick counter
 * cannot distinguish it from legitimate rapid interaction. The invariant is the
 * same: `rpcProps()` must return only user-controlled settings, never fetched
 * data (see ARCHITECTURE.md §"rpcProps() loop trap").
 */
export declare function installGlobalFetchAutorun<TArgs, TResult>(self: GlobalFetchAutorunHost, opts: GlobalFetchPhases<TArgs, TResult> & {
    delay: number;
    name: string;
}): void;
