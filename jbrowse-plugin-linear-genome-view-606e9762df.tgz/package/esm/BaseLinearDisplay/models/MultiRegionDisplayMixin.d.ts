import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
import type { IndexedRegion } from './planRegionFetch.ts';
import type { LoadedRegion, RegionFetchContext } from './regionCommit.ts';
import type { Assembly } from '@jbrowse/core/assemblyManager/assembly';
import type { Region } from '@jbrowse/core/util';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
export type { FetchContext } from './FetchMixin.ts';
export { autorunOnReadyView, makeSettingsLoopGuard, onDisplayedRegionsChange, } from './displayAutoruns.ts';
export { callEachRegion, fetchAllRegions, fetchEachRegion, } from './fetchEachRegion.ts';
export { isBlockCovered, planRegionFetch } from './planRegionFetch.ts';
export type { LoadedRegion, RegionFetchContext } from './regionCommit.ts';
/**
 * #stateModel MultiRegionDisplayMixin
 * #displayFoundationDef Per-region fetch + render: the fetch autoruns, `rpcProps()` refetch wiring, and byte gating. The common case.
 * #category display
 *
 * Per-region fetch lifecycle for LGV-based GPU displays. Installs the fetch
 * autoruns in `afterAttach` and exposes overridable hooks (`fetchNeeded`,
 * `rpcProps`, `regionFetchKey`, `regionHasData`, `measuresBytesPreFlight`) plus
 * the `fetchRegions` / `loadedRegions` machinery.
 */
export default function MultiRegionDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{}, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly measuresBytesInFetch: boolean;
    readonly measuresBytesPreFlight: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("../../index.ts").GateViewport | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
    gateFetchState(): import("../../index.ts").GateFetchState;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number;
        viewport: import("../../index.ts").GateViewport;
    }): void;
    setGateMeasuredViewport(viewport: import("../../index.ts").GateViewport): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    commitByteMeasurement({ viewport, gated, bytes, }: {
        viewport: import("../../index.ts").GateViewport;
        gated: boolean;
        bytes?: number;
    }): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: import("./FetchMixin.ts").FetchContext): Promise<boolean>;
} & {
    afterAttach(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
    readonly rendersCanvas: boolean;
    readonly paintInert: boolean;
} & {
    readonly painted: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    reloadCounter: number;
    statusWindow: import("@jbrowse/core/util").StatusWindow;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
} & {
    fetchRotation: {
        begin(): import("@jbrowse/core/util").ActiveFetch;
        cancel: () => void;
        dispose(): void;
    };
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly fetchInert: boolean;
    readonly awaitingPrerequisite: boolean;
    readonly rpcPropsCacheKey: string;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
} & {
    stopActiveFetch(): void;
    openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
} & {
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: import("./FetchMixin.ts").FetchContext) => Promise<void>) => Promise<void>;
} & {
    /**
     * #volatile
     * regions whose data has been fetched and committed, keyed by
     * displayedRegionIndex; populated only after the fetch work callback
     * returns
     */
    loadedRegions: import("mobx").ObservableMap<number, LoadedRegion>;
} & {
    /**
     * #getter
     * The containing LinearGenomeView, typed once for every display in this
     * family so no consumer repeats the `getContainingView` cast — the cast
     * `getContainingView` needs (it is view-type-agnostic) but which this
     * mixin has already committed to, since everything below reads
     * `visibleRegions` / `bufferedVisibleRegions` / `bpPerPx` off it.
     *
     * Three displays had each invented this getter under two names before it
     * was hoisted (`view` on HiC and Manhattan, `lgv` on MAF) while ~35 other
     * sites repeated the cast inline. `lgv` rather than `view` because a
     * display's containing view is not always an LGV — the comparative
     * displays' `view` is a synteny or dotplot view — so the name says which
     * one this is.
     *
     * Components and structural helpers keep calling `getContainingView`:
     * they take duck-typed model shapes that deliberately don't carry the
     * whole MST instance type, so there is no `lgv` on them to read.
     */
    readonly lgv: LinearGenomeViewModel;
    /**
     * #getter
     * The CSS width of this display's on-screen canvas, in px — and the
     * `canvasWidth` its `renderState` must carry, since the two have to
     * agree or the bp→px mapping is scaled against a box it doesn't fill.
     *
     * `trackWidthPx`, **not** `view.width`: `TrackRenderingContainer` insets
     * the rendering component by the 2px track outline under
     * `contain: strict`, so a `view.width`-wide canvas overhangs its own
     * container and the browser clips the overhang away. It renders almost
     * identically, which is why MAF drifted onto `view.width` uncaught.
     *
     * A getter rather than a note on each display, because the choice was
     * being made by copying a neighbour out of four plausible view getters —
     * `width` (the viewport), this one, and `totalWidthPx` /
     * `totalWidthPxWithoutBorders` (the *content* width, which the global
     * family's heatmaps legitimately want: a different question, not a
     * different answer). `no-restricted-syntax` bans the underlying read
     * everywhere but this line, since a second spelling agrees until it
     * doesn't.
     *
     * SVG export is the one exception: the export shell has no outline, so
     * `renderSvg` overrides `canvasWidth` with the shell's own width (see
     * `LgvSvgBodyProps`).
     */
    readonly canvasWidthPx: number;
    /**
     * #getter
     * The render-lifecycle precondition for every LGV display (overrides
     * `RenderLifecycleMixin`'s default-true hook): don't run the upload/render
     * callbacks until the view is measured. Before that, `renderBlocks` →
     * `visibleRegions` → `view.width` throws by design, and the render
     * autorun's catch would show that as a GPU render-error banner. Gating here
     * — once, for all of them — is what lets a display's `renderState` be a
     * plain resolved getter and its render callback gate only on its own data.
     * The render-lifecycle twin of `autorunOnReadyView`.
     */
    readonly canRender: boolean;
    /**
     * #getter
     * true when every visible block lies within an already-fetched region —
     * i.e. the viewport shows data we actually loaded, not the stale fringe
     * left after a zoom-out/pan. Drives the loading overlay through the
     * pre-refetch debounce. Spatial only; see CLAUDE.md for why this is exact
     * and for the resolution-staleness gap.
     */
    readonly viewportWithinLoadedData: boolean;
    /**
     * #getter
     * Fills `RenderLifecycleMixin`'s `paintInert` hook — see there for why a
     * failed fetch has to read as finished to the consumers outside the
     * display. The global family declares the identical override.
     */
    readonly paintInert: boolean;
    /**
     * #getter
     * Overridable hook (default false): whether a searchable feature layout
     * currently exists. Any display defining a feature-lookup method
     * (`searchFeatureByID`, `getFeatureById`) must override it, so callers can
     * tell "laid out, but off-display" from "no layout exists yet" — a
     * distinction only the display can make. See
     * plugins/linear-genome-view/src/BaseLinearDisplay/CLAUDE.md §"Four
     * readiness axes".
     */
    readonly layoutReady: boolean;
    /**
     * #getter
     * Overridable hook (default `''`): what a fetch issued right now would
     * produce for a region, as a string — the display's per-region content
     * axis. `fetchRegions` captures it before it issues the RPC and stamps
     * it beside the loaded region; `isCacheValid` refetches a region whose
     * stamp no longer matches. Wiggle returns `String(view.bpPerPx)`
     * (adr-008), canvas the peptide-overlay threshold, the variant matrix
     * its zoom in matrix mode only.
     *
     * NOT an `rpcProps()` field: this invalidates one region's held data
     * where `rpcProps` invalidates all of it, and a zoom-swinging value in
     * the RPC payload blanks the display at the force-load floor — see
     * REGION_TOO_LARGE.md §"How the verdict is built".
     *
     * A getter, so the observables it reads register as dependencies of
     * `FetchVisibleRegions`; MobX runs an action untracked and the autorun
     * would keep a stale answer.
     */
    readonly regionFetchKey: string;
    /**
     * #method
     * Overridable hook (default true): whether the display can actually
     * draw what this region is marked loaded over. Two different displays
     * want it for two different reasons, and both are real:
     *
     * - **The reader-side check of the write-side rule.** `loadedRegions` is
     *   written where the payload is stored (`RegionFetchContext`), so an
     *   entry with nothing behind it means that rule was broken somewhere.
     *   Answering off the data map costs a lookup and decides which way the
     *   break fails: a refetch, or a viewport that reads as covered against
     *   data nobody has and never asks again. Both canvas displays.
     * - **Which of several held payloads answers.** MAF caches a summary
     *   tier and a detail tier side by side under one
     *   `displayedRegionIndex`, so crossing the threshold inside an
     *   already-loaded region changes which map has to answer — something
     *   the coverage bounds cannot see at all.
     *
     * Separate from `regionFetchKey` on purpose: for MAF a key would refetch
     * the summary on every zoom back out, since both tiers are still held.
     * And the mixin cannot see a display's data map, so a key that changed
     * when data arrived would be the `rpcProps()` loop in different clothes.
     *
     * **The fail-open default is load-bearing, not an omission.** A
     * byte-gate refusal never marks a region loaded (the commit sits beside
     * the store and skips refused results), so "marked loaded with nothing
     * behind it" is unreachable from the gate — the one path that stamps
     * without storing is sequence's legitimately-empty-region answer, and a
     * store-derived default there would refetch forever: stamp, store
     * nothing, read uncovered, fetch again. `true` is what lets "this fetch
     * completed and there is genuinely nothing here" be a terminal state.
     *
     * A view, not an action, for the reason `regionFetchKey` is a getter.
     */
    regionHasData(_displayedRegionIndex: number): boolean;
    /**
     * #getter
     * Shared cached view for every LGV-based GPU display. A single
     * displayedRegion may produce multiple render blocks (shared GPU
     * buffer, different scissor clips on screen). Plugins that want to
     * suppress rendering in certain states (e.g. no domain yet) can
     * override this getter to return [] — the autorun lifecycle will
     * then issue an empty-blocks render that clears the canvas.
     */
    readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
} & {
    /**
     * #getter
     * This family's answer to the shared freshness question every display
     * foundation must answer (`dataCurrent`): the held data corresponds to
     * what is on screen right now. Here that is spatial — every visible block
     * lies within a fetched region — plus `loadedRegions.size`, which rules
     * out the vacuously-true empty viewport. Regions stream in one at a time,
     * so this (not "the first datum arrived") is what keeps a
     * multi-region/whole-genome export complete.
     *
     * Distinct from `viewportWithinLoadedData`, which is the raw coverage
     * predicate the fetch autorun and the loading overlay use.
     */
    readonly dataCurrent: boolean;
    /**
     * #getter
     * The assembly the data in hand came from, once it can answer about
     * refNames — `undefined` before that.
     *
     * Off the first LOADED region rather than the view's displayed ones,
     * which is the distinction that makes it belong here: a display holding
     * fetched data is asking about the assembly THAT data is on, and the
     * view's regions can already have moved on.
     *
     * The `initialized` gate is why this returns the assembly rather than
     * its name. `getCanonicalRefName2` and `refNameToIndex` answer WRONGLY
     * rather than throwing before the aliases land — identity, and a miss —
     * so a caller that skips the gate gets a plausible answer and no signal.
     * Handing back `undefined` until it can answer is what makes the caller
     * write its fallback.
     */
    readonly loadedAssembly: Assembly | undefined;
} & {
    /**
     * #getter
     * true once an off-screen (SVG) export can safely read this display's
     * data. Policy single-sourced in `computeSvgReady`; this family supplies
     * only its `dataCurrent` predicate. Off-screen renderers gate on it via
     * `awaitSvgReady(model)` instead of inlining the condition.
     */
    readonly svgReady: boolean;
    /**
     * #getter
     * The display's mutually-exclusive visual state, mapped in
     * `foundationDisplayPhase` — every foundation calls it and supplies only
     * its staleness argument, so a term added to `computeLoadingTerm`
     * reaches all three without being wired three times.
     *
     * This family's argument is spatial: `loading` also covers stale data
     * (viewport past loaded) still on screen through the pre-refetch
     * debounce. A thunk, so a suppressed or already-loading display doesn't
     * subscribe to viewport churn.
     *
     * A subclass customizes this through `fetchInert` (FetchMixin),
     * never by overriding the getter — see that hook.
     */
    readonly displayPhase: DisplayPhase;
} & {
    /**
     * #action
     * The raw write behind `ctx.commitRegion`, and **not what a fetch should
     * call**: a display naming its own span is the bug this family spent a
     * release on, and going through the context is what makes that
     * inexpressible — see {@link RegionFetchContext}. Direct callers are
     * tests staging an already-loaded display.
     *
     * An action so callers after an async boundary stay in MST strict mode.
     * Stamps the region with the fetch key its data came back under.
     * `fetchRegions` passes the key it captured before issuing the RPC; the
     * default reads it *now*, which is right for a caller holding the region
     * already and wrong for anything resuming after an await, where the
     * viewport may have moved under the fetch.
     */
    setLoadedRegion(displayedRegionIndex: number, region: Region, fetchKey?: string): void;
    /**
     * #action
     * Forget one region — for a display pruning what has scrolled off
     * screen.
     */
    dropLoadedRegion(displayedRegionIndex: number): void;
    /**
     * #action
     * no-op base — subclasses override to clear rpcDataMap etc.
     */
    clearDisplaySpecificData(): void;
} & {
    /**
     * #action
     * full reset: cancels fetch, clears error, loadedRegions,
     * display-specific data, and the canvas-drawn flag. The too-large gate is
     * derived (a pure function of the cached estimate × viewport), so it needs
     * no explicit clear here — the fetch autorun re-measures at the new
     * viewport and the verdict follows.
     */
    clearAllRpcData(): void;
    /**
     * #action
     * Default reload: full reset. Subclasses with extra teardown can
     * override (and chain to `clearAllRpcData` directly if needed).
     *
     * An override must reach this counter, by chaining to super or by
     * bumping it. Missing it doesn't break the retry, which the
     * `clearAllRpcData` call drives; it turns the dev-only retry check off
     * for that display, silently. Both overrides in the tree chain now —
     * `MultiSampleVariantBaseModel` always did, canvas's `LinearBasicDisplay`
     * did not, and that took `LinearVariantDisplay` with it — and
     * `reloadReachesCounter.test.ts` reads every `reload()` in the tree
     * rather than leaving the next one to this paragraph.
     */
    reload(): void;
} & {
    /**
     * #action
     * Overridable hook (no-op base): override to call
     * `this.fetchRegions(needed, async ctx => { ... })`.
     */
    fetchNeeded(_needed: IndexedRegion[]): void;
} & {
    /**
     * #method
     * Whether the data held for a region still answers the current view.
     * Not a hook a display fills: a display states its rule as
     * `regionFetchKey` (what a fetch now would produce) and `regionHasData`
     * (did the last one store anything), and this compares the key against
     * the one the region was fetched under. A subclass that changes what it
     * fetches spells the change in the key, and one that forgets gets a
     * redundant fetch rather than a cached answer for a zoom the data was
     * never fetched at.
     *
     * The stamp is read `untracked` for the reason `FetchVisibleRegions`
     * reads `loadedRegions` untracked: that autorun is what writes it, and
     * the `fetchGeneration` bump at fetch end is the re-trigger.
     */
    isCacheValid(displayedRegionIndex: number): boolean;
} & {
    /**
     * #action
     * Run a per-region fetch with byte-estimate gating. The work callback
     * calls `ctx.commitRegion` as it stores each region's payload, which is
     * what marks it loaded — see {@link RegionFetchContext} for why this
     * function no longer does that itself. The fan-out helpers
     * (`fetchEachRegion`, `fetchAllRegions`) make the call for the displays
     * that use them.
     *
     * The fetch key is captured here, at issue, and carried into every
     * commit — never re-read after the await. `ctx.isStale()` trips on a
     * newer fetch or a cancel, not on a viewport that moved under a fetch
     * that is still current, so a key read at commit time would stamp this
     * data with a zoom it was not fetched at.
     */
    fetchRegions(needed: IndexedRegion[], work: (ctx: RegionFetchContext) => Promise<void>): Promise<void>;
} & {
    /**
     * #action
     * installs the fetch-lifecycle autoruns (DisplayedRegionsChange,
     * FetchVisibleRegions, SettingsInvalidate,
     * ClearBlockingStateOnViewportChange)
     */
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type MultiRegionDisplayMixinType = ReturnType<typeof MultiRegionDisplayMixin>;
