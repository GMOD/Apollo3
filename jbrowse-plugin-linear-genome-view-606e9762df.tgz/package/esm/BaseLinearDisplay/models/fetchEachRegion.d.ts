import type { FetchContext } from './FetchMixin.ts';
import type { IndexedRegion } from './planRegionFetch.ts';
import type { RegionFetchContext } from './regionCommit.ts';
import type { Region } from '@jbrowse/core/util';
interface FetchEachRegionModel {
    fetchRegions: (needed: IndexedRegion[], work: (ctx: RegionFetchContext) => Promise<void>) => Promise<void>;
}
/**
 * The per-region fan-out on its own, without the `fetchRegions` wrapper: issue
 * `call` for every needed region in parallel and return the results paired with
 * their `displayedRegionIndex`, in `needed` order. Callers get one collected
 * array to commit from, which is what a cross-region decision needs (MAF picks
 * the sample set from whichever region actually discovered samples).
 *
 * Use this only inside a `fetchRegions` work callback you already own — it does
 * no staleness checking of its own, because the *caller* decides the
 * granularity: {@link fetchEachRegion} guards per region so an early result
 * still commits, while a display that commits atomically guards once around the
 * whole batch. Prefer `fetchEachRegion` unless you need the collected array or
 * a concurrent side-fetch under the same stop token.
 */
export declare function callEachRegion<R>(needed: IndexedRegion[], ctx: FetchContext, call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>): Promise<{
    displayedRegionIndex: number;
    result: R;
}[]>;
/**
 * Run one RPC `call` per needed region, in parallel, under a single
 * stale-guarded `fetchRegions` wrapper. Centralizes the fan-out plus the two
 * `ctx.isStale()` guards every per-region display repeated by hand: skip a
 * region's commit, and skip the post-fetch step, once the user has moved on.
 * Forgetting either guard is a stale-data write, so this is a correctness
 * primitive as much as a dedup.
 *
 * `call` keeps the literal RPC method name at the call site, so its typed args
 * (`RpcCallArgs<M>`) and return (`RpcCallReturn<M>`) survive — `R` is inferred
 * from `call` and flows into `onResult` with no cast. The helper owns the
 * control flow; the display still owns its typed payload, into which it injects
 * `statusCallback: ctx.statusCallback` — the ctx `call` is handed, which is that
 * region's own status slot, so the parallel per-region fetches aggregate into
 * one bar instead of clobbering each other.
 * A display whose fetch genuinely diverges — canvas (prune + fold a too-large
 * result), MAF (a concurrent annotation fetch + a cross-region sample pick),
 * alignments (chain payload) — keeps its own `fetchNeeded` and calls
 * `fetchRegions` directly. MAF and alignments then reach for
 * {@link callEachRegion} for the fan-out; `LinearBasicDisplay` does not, and
 * should not — its per-region call already returns the `displayedRegionIndex`
 * inside its own result shape, so the pairing `callEachRegion` exists to provide
 * would be a second wrapper to unwrap. Its plain `Promise.all` is the right
 * answer there, and the single `ctx.isStale()` around the batch is deliberate:
 * it commits the batch's gate measurements atomically.
 */
export declare function fetchEachRegion<R>(self: FetchEachRegionModel, needed: IndexedRegion[], opts: {
    call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
/**
 * Batched counterpart to {@link fetchEachRegion}: hands every needed region to
 * a single RPC `call`, which returns one result per region aligned to the input
 * order (`results[i]` ↔ `needed[i]`). Use when the adapter serves all regions in
 * one pass more efficiently than N independent calls — e.g. BigWig coalesces
 * adjacent on-disk blocks across region boundaries (`getFeaturesAsArraysMulti`),
 * which the per-region fan-out can't exploit; collapsed-intron views (many small
 * regions on one refName) benefit most. The single `ctx.isStale()` guard is the
 * same correctness primitive as the per-region helper — a moved-on viewport
 * skips both the commit and the post-fetch step. `call` keeps the literal RPC
 * method name at the call site so its typed args/return survive and `R` flows
 * into `onResult` with no cast.
 */
export declare function fetchAllRegions<R>(self: FetchEachRegionModel, needed: IndexedRegion[], opts: {
    call: (regions: Region[], ctx: FetchContext) => Promise<R[]>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
export {};
