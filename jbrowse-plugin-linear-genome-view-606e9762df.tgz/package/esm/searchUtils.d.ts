import type { LinearGenomeViewModel } from './LinearGenomeView/index.ts';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
import type TextSearchManager from '@jbrowse/core/TextSearch/TextSearchManager';
import type { Assembly } from '@jbrowse/core/assemblyManager/assembly';
import type { SearchType } from '@jbrowse/core/data_adapters/BaseAdapter';
import type { AbstractSessionModel } from '@jbrowse/core/util';
import type { StopToken } from '@jbrowse/core/util/stopToken';
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'LinearGenomeView-searchResultSelected': {
            args: undefined;
            result: undefined | Promise<void>;
            props: {
                session: AbstractSessionModel;
                /** the search result that was selected */
                result: BaseResult;
                model: LinearGenomeViewModel;
                assemblyName: string;
            };
        };
    }
}
export declare function navigateToSelectedOption({ option, model, assemblyName, }: {
    option: BaseResult;
    model: LinearGenomeViewModel;
    assemblyName: string;
}): Promise<void>;
export declare function navToOption({ option, model, assemblyName, grow, }: {
    model: LinearGenomeViewModel;
    option: BaseResult;
    assemblyName: string;
    grow?: number;
}): Promise<void>;
export declare class SearchResultsNotFoundError extends Error {
    name: string;
}
export declare function notifySearchFailure(session: AbstractSessionModel, e: unknown): void;
export declare function handleSelectedRegion({ input, model, assemblyName, grow, }: {
    input: string;
    model: LinearGenomeViewModel;
    assemblyName: string;
    grow?: number;
}): Promise<boolean>;
export declare function checkRef(str: string, isRef: (name: string) => boolean): boolean;
export declare function fetchResults({ queryString, searchType, assemblyName, textSearchManager, assembly, stopToken, }: {
    queryString: string;
    assemblyName: string;
    searchType?: SearchType;
    textSearchManager?: TextSearchManager;
    assembly?: Assembly;
    stopToken?: StopToken;
}): Promise<BaseResult[]>;
export declare function splitLast(str: string, split: string): [string, string];
