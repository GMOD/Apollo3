import PluggableElementBase from './PluggableElementBase.ts';
import type PluginManager from '../PluginManager.ts';
import type { RpcExecuteReturn } from '../rpc/RpcRegistry.ts';
import type { Region } from '../util/index.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { StopToken } from '../util/stopToken.ts';
import type { UriLocation } from '../util/types/index.ts';
export type RpcMethodConstructor = new (pm: PluginManager) => RpcMethodType;
export interface RenameRegionsArgs {
    assemblyName?: string;
    regions?: Region[];
    stopToken?: StopToken;
    adapterConfig: Record<string, unknown>;
    sessionId: string;
    statusCallback?: StatusCallback;
}
export interface RenameRegionArgs {
    region: Region;
    adapterConfig: Record<string, unknown>;
    sessionId: string;
}
export declare function convertFileHandleLocations(obj: unknown, blobMap: Record<string, File>): void;
export default abstract class RpcMethodType<MethodName extends string = string> extends PluggableElementBase {
    pluginManager: PluginManager;
    constructor(pluginManager: PluginManager);
    serializeArguments(args: object, rpcDriverClassName: string): Promise<Record<string, unknown>>;
    protected renameRegions<T extends RenameRegionsArgs>(args: T): Promise<T>;
    serializeNewAuthArguments(loc: UriLocation, _rpcDriverClassName: string): Promise<UriLocation>;
    deserializeArguments<T>(args: T & {
        blobMap?: Record<string, File>;
    }, _rpcDriverClassName: string): Promise<T>;
    abstract execute(serializedArgs: unknown, rpcDriverClassName: string): Promise<RpcExecuteReturn<MethodName>>;
    deserializeReturn(serializedReturn: unknown, _args: unknown, _rpcDriverClassName: string): Promise<unknown>;
    private augmentLocationObjects;
}
