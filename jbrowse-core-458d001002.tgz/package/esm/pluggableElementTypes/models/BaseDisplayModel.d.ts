import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { MenuItem } from '../../ui/index.ts';
import type { RpcStatus } from '../../util/progress.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type React from 'react';
export declare const BaseDisplay: import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
} & {
    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
    readonly parentDisplay: {
        type?: string;
        effectiveRpcDriverName?: string;
    } | undefined;
} & {
    readonly RenderingComponent: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
            ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
            ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        onHorizontalScroll?: (distance: number) => void;
        blockState?: Record<string, unknown>;
    }>;
    readonly DisplayBlurb: React.FC<{
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
            ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
            ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }> | null;
    readonly adapterConfig: any;
    readonly isMinimized: boolean;
    readonly effectiveRpcDriverName: any;
} & {
    renderingProps(): {
        displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
            ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: any;
            readonly isMinimized: boolean;
            readonly effectiveRpcDriverName: any;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
            ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
            readonly parentDisplay: {
                type?: string;
                effectiveRpcDriverName?: string;
            } | undefined;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    rpcDriverName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
                    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("../../util/index.ts").AbstractTrackModel;
                    readonly parentDisplay: {
                        type?: string;
                        effectiveRpcDriverName?: string;
                    } | undefined;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: any;
            readonly isMinimized: boolean;
            readonly effectiveRpcDriverName: any;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    };
    readonly DisplayMessageComponent: undefined | React.FC<any>;
    trackMenuItems(): MenuItem[];
} & {
    setIgnorePromotedDefaults(flag: boolean): void;
    setStatusMessage(status?: RpcStatus): void;
    setError(error?: unknown): void;
    setRpcDriverName(rpcDriverName: string): void;
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseDisplayStateModel = typeof BaseDisplay;
export type BaseDisplayModel = Instance<BaseDisplayStateModel>;
export interface DisplayModel extends BaseDisplayModel {
    configuration: AnyConfigurationModel & {
        displayId: string;
    };
    getPortableSettings?: (newDisplayId?: string) => Record<string, unknown> | undefined;
}
