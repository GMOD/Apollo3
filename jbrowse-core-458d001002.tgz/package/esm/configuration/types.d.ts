import type { FileLocation } from '../util/types/index.ts';
import type { ConfigurationSchemaOptions, ConfigurationSchemaType } from './configurationSchema.ts';
import type { ISimpleType, IStateTreeNode, Instance, SnapshotOut } from '@jbrowse/mobx-state-tree';
export type GetOptions<SCHEMA> = SCHEMA extends ConfigurationSchemaType<any, infer OPTIONS> ? OPTIONS : never;
export type GetBase<SCHEMA> = SCHEMA extends undefined ? never : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<undefined, any> ? undefined : GetOptions<SCHEMA> extends ConfigurationSchemaOptions<infer BASE extends AnyConfigurationSchemaType, any> ? BASE : never;
export type GetExplicitIdentifier<SCHEMA> = GetOptions<SCHEMA> extends ConfigurationSchemaOptions<any, infer EXPLICIT_IDENTIFIER extends string> ? EXPLICIT_IDENTIFIER : never;
export type GetInheritedIdentifier<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<any, any> ? GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? GetInheritedIdentifier<GetBase<SCHEMA>> : never) : never;
export type ConfigurationSchemaForModel<MODEL> = MODEL extends IStateTreeNode<infer SCHEMA extends AnyConfigurationSchemaType> ? SCHEMA : never;
export type ConfigurationSlotName<SCHEMA> = SCHEMA extends undefined ? never : SCHEMA extends ConfigurationSchemaType<infer D, any> ? (keyof D & string) | GetExplicitIdentifier<SCHEMA> | (GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotName<GetBase<SCHEMA>> : never) : never;
type SlotValueResolvedFromDef<DEF> = DEF extends {
    promotedBase: unknown;
} ? Exclude<SlotValueRawFromDef<DEF>, undefined> : SlotValueRawFromDef<DEF>;
type SlotValueRawFromDef<DEF> = DEF extends AnyConfigurationSchemaType ? AnyConfigurationSnapshot : DEF extends {
    model: ISimpleType<infer T extends string>;
} ? DEF extends {
    type: 'maybeStringEnum';
} ? T | undefined : T : DEF extends {
    type: 'stringArray';
} ? string[] : DEF extends {
    type: 'stringArrayMap';
} ? Record<string, string[]> : DEF extends {
    type: 'numberMap';
} ? Record<string, number> : DEF extends {
    type: 'fileLocation';
} ? FileLocation : DEF extends {
    type: 'maybeNumber';
} ? number | undefined : DEF extends {
    type: 'maybeBoolean';
} ? boolean | undefined : DEF extends {
    type: 'maybeColor';
} ? string | undefined : DEF extends {
    type: 'number' | 'integer';
} ? number : DEF extends {
    type: 'boolean';
} ? boolean : DEF extends {
    type: 'string' | 'text' | 'color';
} ? string : DEF extends {
    defaultValue: infer V;
} ? [V] extends [boolean] ? boolean : [V] extends [string] ? string : [V] extends [number] ? number : any : any;
export type ConfigurationSlotValue<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueRawFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValue<GetBase<SCHEMA>, K> : any : any;
export type ConfigurationSlotValueResolved<SCHEMA, K extends string> = SCHEMA extends ConfigurationSchemaType<infer D, any> ? K extends keyof D ? SlotValueResolvedFromDef<D[K]> : GetBase<SCHEMA> extends ConfigurationSchemaType<any, any> ? ConfigurationSlotValueResolved<GetBase<SCHEMA>, K> : any : any;
export type AnyConfigurationSchemaType = ConfigurationSchemaType<any, any>;
export type AnyConfigurationModel = Instance<AnyConfigurationSchemaType>;
export type AnyConfigurationSnapshot = SnapshotOut<AnyConfigurationModel>;
export type AnyConfiguration = AnyConfigurationModel | AnyConfigurationSnapshot;
export {};
