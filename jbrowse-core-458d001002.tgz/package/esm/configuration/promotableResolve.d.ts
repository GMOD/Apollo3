import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationModel } from './types.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export type PromotableDisplay = IAnyStateTreeNode & {
    type: string;
    configuration: AnyConfigurationModel;
    ignorePromotedDefaults: boolean;
    setIgnorePromotedDefaults: (flag: boolean) => void;
};
export declare function storedSlotValue(self: PromotableDisplay, slot: string): unknown;
export declare function isUsableValue(def: ConfigSlotDefinition, value: unknown): boolean;
interface SlotResolutionTiers {
    base: unknown;
    promoted: unknown;
}
export type SlotResolution = (SlotResolutionTiers & {
    callback: false;
    customized: boolean;
    value: unknown;
}) | (SlotResolutionTiers & {
    callback: true;
    customized: true;
    evaluate: () => unknown;
});
export declare function resolveSlot(self: PromotableDisplay, slot: string, args?: Record<string, unknown>): SlotResolution;
export {};
