import type { JexlInstance } from '../util/jexlStrings.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
export interface ConfigSlotDefinition {
    description?: string;
    model?: IAnyType;
    type: string;
    defaultValue: unknown;
    contextVariable?: string[];
    advanced?: boolean;
    promotable?: boolean;
    promotedBase?: unknown;
    validate?: (value: unknown) => boolean;
}
export default function ConfigSlot({ model, type, defaultValue, promotable, promotedBase, }: ConfigSlotDefinition): import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>, [undefined]>;
export declare function toCallbackValue(value: unknown): string;
export declare function toFixedValue(value: unknown, type: string, defaultValue: unknown, jexl: JexlInstance): unknown;
