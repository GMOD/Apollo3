import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationSchemaType, GetInheritedIdentifier } from './types.ts';
import type { IAnyType, IType, ReferenceIdentifier, SnapshotIn, SnapshotOut } from '@jbrowse/mobx-state-tree';
export type { AnyConfigurationModel, AnyConfigurationSchemaType, } from './types.ts';
export interface ConfigurationSchemaDefinition {
    [n: string]: ConfigSlotDefinition | ConfigurationSchemaDefinition | string | number | IAnyType;
}
export interface ConfigurationSchemaOptions<BASE_SCHEMA extends AnyConfigurationSchemaType | undefined, EXPLICIT_IDENTIFIER extends string | undefined> {
    explicitlyTyped?: boolean;
    explicitIdentifier?: EXPLICIT_IDENTIFIER;
    implicitIdentifier?: string | boolean;
    baseConfiguration?: BASE_SCHEMA;
    actions?: (self: unknown) => any;
    views?: (self: unknown) => any;
    extend?: (self: unknown) => any;
    preProcessSnapshot?: (snapshot: Record<string, unknown>) => Record<string, unknown>;
}
declare function makeConfigurationSchemaModel<DEFINITION extends ConfigurationSchemaDefinition, OPTIONS extends ConfigurationSchemaOptions<any, any>>(modelName: string, schemaDefinition: DEFINITION, options: OPTIONS): import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<Record<string, any>, {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
export interface ConfigurationSchemaType<DEFINITION extends ConfigurationSchemaDefinition, OPTIONS extends ConfigurationSchemaOptions<any, any>> extends ReturnType<typeof makeConfigurationSchemaModel<DEFINITION, OPTIONS>> {
    type: string;
}
export declare function ConfigurationSchema<const DEFINITION extends ConfigurationSchemaDefinition, BASE_SCHEMA extends AnyConfigurationSchemaType | undefined = undefined, EXPLICIT_IDENTIFIER extends string | undefined = undefined>(modelName: string, inputSchemaDefinition: DEFINITION, inputOptions?: ConfigurationSchemaOptions<BASE_SCHEMA, EXPLICIT_IDENTIFIER>): ConfigurationSchemaType<DEFINITION, ConfigurationSchemaOptions<BASE_SCHEMA, EXPLICIT_IDENTIFIER>>;
export declare function TrackConfigurationReference(schemaType: IAnyType): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
export declare function DisplayConfigurationReference(schemaType: IAnyType): import("@jbrowse/mobx-state-tree").ITypeUnion<any, any, any>;
type IsAny<T> = 0 extends 1 & T ? true : false;
type ConfigReferenceInstance<SCHEMA extends AnyConfigurationSchemaType> = (SCHEMA extends ConfigurationSchemaType<infer D, any> ? IsAny<D> extends true ? any : SCHEMA['Type'] : SCHEMA['Type']) & {
    [K in GetInheritedIdentifier<SCHEMA>]: string;
};
export type IConfigurationReference<SCHEMA extends AnyConfigurationSchemaType> = Omit<IType<ReferenceIdentifier | SnapshotIn<SCHEMA>, ReferenceIdentifier | SnapshotOut<SCHEMA>, ConfigReferenceInstance<SCHEMA>>, 'Type'> & {
    readonly Type: ConfigReferenceInstance<SCHEMA>;
};
export declare function ConfigurationReference<SCHEMATYPE extends AnyConfigurationSchemaType>(schemaType: SCHEMATYPE): IConfigurationReference<SCHEMATYPE>;
