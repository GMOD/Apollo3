import QuickLRU from '../util/QuickLRU/index.ts';
import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type { BaseTextSearchAdapter, BaseTextSearchArgs } from '../data_adapters/BaseAdapter/index.ts';
import type BaseResult from './BaseResults.ts';
export interface SearchScope {
    assemblyName: string;
}
export default class TextSearchManager {
    pluginManager: PluginManager;
    adapterCache: QuickLRU<string, BaseTextSearchAdapter>;
    constructor(pluginManager: PluginManager);
    clearCache(): void;
    loadTextSearchAdapters(searchScope: SearchScope): Promise<BaseTextSearchAdapter[]>;
    relevantAdapters({ assemblyName }: SearchScope): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
    getAdaptersWithAssembly(assemblyName: string, confs: AnyConfigurationModel[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
    getTrackAdaptersWithAssembly(assemblyName: string, confs: AnyConfigurationModel[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
    search(args: BaseTextSearchArgs, searchScope: SearchScope): Promise<BaseResult[]>;
    sortResults({ results, args, }: {
        results: BaseResult[];
        args: BaseTextSearchArgs;
    }): Promise<BaseResult[]>;
}
