import type { RpcResult } from '../rpc/RpcServer.ts';
export declare function isRpcResult(value: unknown): value is RpcResult;
