import type { BaseOptions } from '../data_adapters/BaseAdapter/types.ts';
export declare function createSharedSetup<T>(run: (opts: BaseOptions) => Promise<T>): (opts?: BaseOptions) => Promise<T>;
