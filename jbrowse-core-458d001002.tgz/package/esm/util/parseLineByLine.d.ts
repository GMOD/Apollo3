import { IntervalTree } from './IntervalTree.ts';
import type { RpcStatus } from './progress.ts';
import type { StopToken } from './stopToken.ts';
export type StatusCallback = (arg: RpcStatus) => void;
export type LineCallback = (line: string, lineIndex: number) => boolean | undefined;
export declare function groupLinesByRef(buffer: Uint8Array, statusCallback?: StatusCallback): {
    headerLines: string[];
    linesByRef: Record<string, string[]>;
};
export declare function makeFeatureIntervalTreeMap<T extends {
    start: number;
    end: number;
}>(linesByRef: Record<string, string[]>, parse: (lines: string[], refName: string) => T[], parsingStatusMessage: string): {
    [k: string]: (statusCallback?: StatusCallback) => IntervalTree<T>;
};
export declare function parseLineByLine(buffer: Uint8Array, lineCallback: LineCallback, statusCallback?: StatusCallback, opts?: {
    label?: string;
    stopToken?: StopToken;
}): void;
