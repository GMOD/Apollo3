export declare function clampBandHeight(current: number, target: number): number;
