import type { StopToken, StopTokenChecker } from './stopToken.ts';
export declare function updateStatus<U>(msg: string, cb: StatusCallback | undefined, fn: () => U | Promise<U>, stopToken?: StopToken): Promise<U>;
export interface StatusWithProgress {
    message: string;
    current: number;
    total: number;
}
export type RpcStatus = string | StatusWithProgress;
export type StatusCallback = (status: RpcStatus) => void;
export declare function statusMessageText(status: RpcStatus | undefined): string | undefined;
export declare function statusFraction(status: RpcStatus | undefined): number | undefined;
export declare function createStatusThrottle(): {
    run(apply: () => void): void;
    reset(): void;
};
export declare function progressLabel(message: string | undefined, fraction: number | undefined): string;
export declare function statusProgressLabel(status: RpcStatus | undefined): string;
declare function downloadStatusReporter(statusCallback: StatusCallback | undefined, message: string): ((current: number, total?: number) => void) | undefined;
export declare function downloadStatus<T>(label: string, statusCallback: StatusCallback | undefined, fn: (onProgress: ReturnType<typeof downloadStatusReporter>) => T | Promise<T>): Promise<T>;
export declare function aggregateStatus(statuses: (RpcStatus | undefined)[]): RpcStatus | undefined;
export declare function createStatusFanOut(statusCallback: StatusCallback | undefined): () => StatusCallback;
export type ProgressReporter = (current?: number) => void;
export declare function createProgressReporter({ label, total, statusCallback, stopToken, stopTokenCheck, throttleMs, }: {
    label?: string;
    total?: number;
    statusCallback?: (status: RpcStatus) => void;
    stopToken?: StopToken;
    stopTokenCheck?: StopTokenChecker;
    throttleMs?: number;
}): ProgressReporter;
export declare function withProgress<T>({ label, total, statusCallback, stopToken, }: {
    label: string;
    total: number;
    statusCallback?: (status: RpcStatus) => void;
    stopToken?: StopToken;
}, fn: (report: ProgressReporter) => T | Promise<T>): Promise<T>;
export {};
