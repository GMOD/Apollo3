import type PluginManager from '../PluginManager.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { ComponentType } from 'react';
export interface AddTrackComponentModel extends IAnyStateTreeNode {
    assembly: string | undefined;
    setAssembly: (arg: string) => void;
    trackAdapterType: string | undefined;
    mixinData: Record<string, unknown>;
    setMixinData: (data: Record<string, unknown>) => void;
}
export interface AddTrackComponentProps {
    model: AddTrackComponentModel;
}
declare module '../PluginManager.ts' {
    interface ExtensionPointRegistry {
        'Core-addTrackComponent': {
            args: ComponentType<AddTrackComponentProps>;
            result: ComponentType<AddTrackComponentProps>;
            props: AddTrackComponentProps;
        };
    }
}
export declare function addAddTrackComponent(pluginManager: PluginManager, { adapterTypes, component, }: {
    adapterTypes: readonly string[];
    component: ComponentType<AddTrackComponentProps>;
}): void;
