import type { ErrorObject } from './serializeError/index.ts';
export interface RpcResult<T = unknown> {
    __rpcResult: true;
    value: T;
    transferables: Transferable[];
}
export declare function rpcResult<T>(value: T, transferables: Transferable[]): RpcResult<T>;
export declare function rpcResultWithArrayBuffers<T extends object>(value: T): RpcResult<T>;
type Procedure = (data: unknown) => Promise<unknown>;
interface RpcMessageData {
    method: string;
    uid: string;
    libRpc?: true;
    data: unknown;
}
export default class RpcServer {
    protected methods: Record<string, Procedure>;
    private self;
    constructor(methods: Record<string, Procedure>);
    handler(e: MessageEvent<RpcMessageData>): void;
    private post;
    protected reply(uid: string, response: unknown): void;
    protected throw(uid: string, error: ErrorObject | string): void;
    emit(eventName: string, data: unknown, transferables?: Transferable[]): void;
}
export {};
