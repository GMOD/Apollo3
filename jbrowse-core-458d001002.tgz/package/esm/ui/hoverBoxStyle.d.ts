import type { CSSProperties } from 'react';
export declare const hoverBoxStyle: CSSProperties;
