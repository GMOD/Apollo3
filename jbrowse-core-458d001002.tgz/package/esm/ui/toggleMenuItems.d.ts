import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
export declare function checkboxItem(label: string, checked: boolean, onToggle: () => void, opts?: {
    helpText?: string;
    subLabel?: string;
    disabled?: boolean;
    disabledHelpText?: string;
}): CheckboxMenuItem;
export declare function radioItems<T extends string>(options: readonly {
    value: T;
    label: string;
    subLabel?: string;
    helpText?: string;
}[], current: T | undefined, setMode: (m: T) => void): RadioMenuItem[];
