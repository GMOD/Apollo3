export interface MouseState {
    x: number;
    y: number;
    clientX: number;
    clientY: number;
}
export declare function useMouseTracking(ref: React.RefObject<HTMLDivElement | null>, onMove?: (state?: MouseState) => void): {
    mouseState: MouseState | undefined;
    handleMouseMove: (event: React.MouseEvent) => void;
    handleMouseLeave: () => void;
};
