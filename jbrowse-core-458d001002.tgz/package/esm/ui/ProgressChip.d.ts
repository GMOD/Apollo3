declare const ProgressChip: ({ statusMessage, statusProgress, }: {
    statusMessage?: string;
    statusProgress?: number;
}) => import("react").JSX.Element;
export default ProgressChip;
