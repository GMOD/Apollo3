import { BaseFeatureDataAdapter } from './BaseFeatureDataAdapter.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { NoAssemblyRegion } from '../../util/index.ts';
import type { RegionsAdapter } from '../BaseAdapter/index.ts';
import type { BaseOptions } from './types.ts';
export declare abstract class BaseSequenceAdapter<CONF extends AnyConfigurationModel = AnyConfigurationModel> extends BaseFeatureDataAdapter<CONF> implements RegionsAdapter {
    abstract getRegions(opts: BaseOptions): Promise<NoAssemblyRegion[]>;
    getSequence(region: NoAssemblyRegion, opts?: BaseOptions): Promise<string | undefined>;
}
