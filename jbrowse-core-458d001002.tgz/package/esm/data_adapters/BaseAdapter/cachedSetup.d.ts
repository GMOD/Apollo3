import type { BaseOptions } from './types.ts';
type OnProgress = (current: number, total?: number) => void;
export declare function cachedSetup<T>({ setup, label, }: {
    setup: (opts?: BaseOptions, onProgress?: OnProgress) => Promise<T>;
    label?: string;
}): (opts?: BaseOptions) => Promise<T>;
export {};
