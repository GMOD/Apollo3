export interface SvgExportable {
    svgReady: boolean;
    error: unknown;
    regionTooLarge: boolean;
}
export interface SvgReadyTerminals {
    error: unknown;
    regionTooLarge: boolean;
    extraTerminal: boolean;
}
export declare function computeSvgReady({ error, regionTooLarge, extraTerminal }: SvgReadyTerminals, dataCurrent: () => boolean): boolean;
export declare function awaitSvgReady(model: Pick<SvgExportable, 'svgReady'>): Promise<void>;
export declare function awaitViewInitialized(view: {
    initialized: boolean;
    error: unknown;
}): Promise<void>;
