import type PluginManager from '@jbrowse/core/PluginManager';
declare const configSchema: (pluginManager: PluginManager) => import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly name: {
        readonly description: "descriptive name of the track, falls back to the trackId when unset";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly assemblyNames: {
        readonly description: "name of the assembly (or assemblies) track belongs to";
        readonly type: "stringArray";
        readonly defaultValue: readonly ["assemblyName"];
    };
    readonly description: {
        readonly description: "a description of the track";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly category: {
        readonly description: "the category and sub-categories of a track";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
    readonly metadata: {
        readonly type: "frozen";
        readonly description: "anything to add about this track";
        readonly defaultValue: {};
    };
    readonly rpcDriverName: {
        readonly type: "string";
        readonly description: "RPC driver to use for this track. Leave empty to use the display-level or global default.";
        readonly defaultValue: "";
        readonly advanced: true;
    };
    readonly adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    readonly textSearching: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly indexingAttributes: {
            readonly type: "stringArray";
            readonly description: "list of which feature attributes to index for text searching";
            readonly defaultValue: readonly ["Name", "ID", "symbol"];
        };
        readonly indexingFeatureTypesToExclude: {
            readonly type: "stringArray";
            readonly description: "list of feature types to exclude in text search index";
            readonly defaultValue: readonly ["CDS", "exon"];
        };
        readonly textSearchAdapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly displays: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    readonly formatDetails: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly feature: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the feature details";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        readonly subfeatures: {
            readonly type: "frozen";
            readonly description: "adds extra fields to the subfeatures of a feature";
            readonly defaultValue: {};
            readonly contextVariable: ["feature"];
        };
        readonly depth: {
            readonly type: "number";
            readonly defaultValue: 2;
            readonly description: "depth of subfeatures to iterate the formatter on formatDetails.subfeatures (e.g. you may not want to format the exon/cds subfeatures, so limited to 2";
        };
        readonly maxDepth: {
            readonly type: "number";
            readonly defaultValue: 99999;
            readonly description: "Maximum depth to render subfeatures";
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly formatAbout: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly config: {
            readonly type: "frozen";
            readonly description: "formats configuration object in about dialog";
            readonly defaultValue: {};
            readonly contextVariable: ["config"];
        };
        readonly hideUris: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "trackId">>, "trackId">>;
export default configSchema;
