import type PluginManager from '@jbrowse/core/PluginManager';
export default function FeatureTrackF(pm: PluginManager): void;
