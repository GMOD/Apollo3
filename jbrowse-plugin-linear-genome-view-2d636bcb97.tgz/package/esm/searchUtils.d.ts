import type { LinearGenomeViewModel } from './LinearGenomeView/index.ts';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
import type TextSearchManager from '@jbrowse/core/TextSearch/TextSearchManager';
import type { SearchScope } from '@jbrowse/core/TextSearch/TextSearchManager';
import type { Assembly } from '@jbrowse/core/assemblyManager/assembly';
import type { SearchType } from '@jbrowse/core/data_adapters/BaseAdapter';
import type { AbstractSessionModel } from '@jbrowse/core/util';
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'LinearGenomeView-searchResultSelected': {
            args: undefined;
            result: undefined;
            props: {
                session: AbstractSessionModel;
                result: BaseResult;
                model: LinearGenomeViewModel;
                assemblyName: string;
            };
        };
    }
}
export declare function navigateToSelectedOption({ option, model, assemblyName, }: {
    option: BaseResult;
    model: LinearGenomeViewModel;
    assemblyName: string;
}): Promise<void>;
export declare function navToOption({ option, model, assemblyName, }: {
    model: LinearGenomeViewModel;
    option: BaseResult;
    assemblyName: string;
}): Promise<void>;
export declare class SearchResultsNotFoundError extends Error {
    name: string;
}
export declare function handleSelectedRegion({ input, model, assemblyName, grow, }: {
    input: string;
    model: LinearGenomeViewModel;
    assemblyName: string;
    grow?: number;
}): Promise<void>;
export declare function checkRef(str: string, isRef: (name: string) => boolean): boolean;
export declare function fetchResults({ queryString, searchType, searchScope, textSearchManager, assembly, }: {
    queryString: string;
    searchScope: SearchScope;
    searchType?: SearchType;
    textSearchManager?: TextSearchManager;
    assembly?: Assembly;
}): Promise<BaseResult[]>;
export declare function splitLast(str: string, split: string): [string, string];
