import type { AlertColor } from '@mui/material';
export default function BlockMsg({ message, severity, action, }: {
    message: string;
    severity?: AlertColor;
    action?: React.ReactNode;
}): import("react").JSX.Element;
