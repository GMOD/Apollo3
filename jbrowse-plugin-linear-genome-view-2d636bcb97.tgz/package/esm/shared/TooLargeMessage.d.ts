export interface TooLargeMessageModel {
    regionTooLargeReason: string;
    forceLoad: () => void;
}
declare const TooLargeMessage: ({ model, }: {
    model: TooLargeMessageModel;
}) => import("react").JSX.Element;
export default TooLargeMessage;
