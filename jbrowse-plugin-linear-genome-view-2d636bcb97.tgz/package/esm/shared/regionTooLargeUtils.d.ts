export declare function getDisplayStr(totalBytes: number): string;
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
export declare function resolveByteLimit({ userByteLimit, adapterFetchSizeLimit, configFetchSizeLimit, }: {
    userByteLimit?: number;
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number;
}): number;
export declare const FORCE_LOAD_HEADROOM = 1.5;
export declare function raiseLimitPast(estimate: number): number;
export declare function forceLoadByteLimit({ estimatedBytesForVisibleSpan, estimatedBytesForMeasuredSpan, }: {
    estimatedBytesForVisibleSpan?: number;
    estimatedBytesForMeasuredSpan?: number;
}): number | undefined;
export declare function rescaleByteEstimateToVisibleSpan({ estimatedBytesForMeasuredSpan, measuredSpanBp, visibleBp, }: {
    estimatedBytesForMeasuredSpan?: number;
    measuredSpanBp?: number;
    visibleBp: number;
}): number | undefined;
export declare function resolveForceLoadLimits({ estimatedBytesForVisibleSpan, estimatedBytesForMeasuredSpan, baselineByteLimit, densityGateActive, observedMaxDensity, configuredMaxDensity, }: {
    estimatedBytesForVisibleSpan?: number;
    estimatedBytesForMeasuredSpan?: number;
    baselineByteLimit: number;
    densityGateActive: boolean;
    observedMaxDensity: number;
    configuredMaxDensity: number;
}): {
    userByteLimit?: number;
    userFeatureDensityLimit?: number;
};
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
}
export declare function evaluateRegionTooLarge({ visibleBp, estimatedBytesForVisibleSpan, byteLimit, densityTooLarge, alwaysRender, }: {
    visibleBp: number;
    estimatedBytesForVisibleSpan?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
    alwaysRender?: boolean;
}): RegionTooLargeStatus;
