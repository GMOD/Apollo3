import type { RegionByteEstimate } from '@jbrowse/core/data_adapters/BaseAdapter/types';
export default function RegionTooLargeMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    userByteLimit: number | undefined;
    byteEstimate: RegionByteEstimate | undefined;
    measuredSpanBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLargeForDerivedGate: boolean;
    readonly configForceLoad: boolean;
} & {
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    regionCannotBeRenderedText(): "" | "Force load to see features";
} & {
    setByteEstimate(estimate?: RegionByteEstimate): void;
    raiseForceLoadLimits(estimate?: RegionByteEstimate): void;
    reload(): void;
} & {
    forceLoad(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
