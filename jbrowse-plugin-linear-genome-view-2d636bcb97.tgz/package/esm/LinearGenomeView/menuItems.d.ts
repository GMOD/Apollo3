import type { LinearGenomeViewModel } from './model.ts';
import type { BpOffset } from './types.ts';
import type { MenuItem } from '@jbrowse/core/ui';
export declare function buildMenuItems(self: LinearGenomeViewModel): MenuItem[];
export declare function buildRubberBandMenuItems(self: LinearGenomeViewModel): MenuItem[];
export declare function buildRubberbandClickMenuItems(self: LinearGenomeViewModel, clickOffset: BpOffset): MenuItem[];
