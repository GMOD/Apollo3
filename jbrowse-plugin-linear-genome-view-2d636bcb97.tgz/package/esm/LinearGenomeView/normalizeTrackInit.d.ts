import type { TrackInit } from './types.ts';
export declare function normalizeTrackInit(t: TrackInit): {
    trackId: string;
    trackSnapshot: Record<string, unknown>;
    displaySnapshot: {
        [x: string]: unknown;
    };
};
