export declare const ReturnToImportFormDialog: import("react").LazyExoticComponent<({ model, handleClose, }: {
    model: {
        clearView: () => void;
    };
    handleClose: () => void;
}) => import("react").JSX.Element>;
export declare const SequenceSearchDialog: import("react").LazyExoticComponent<({ model, handleClose, }: {
    model: {
        assemblyNames: string[];
        showTrack: (trackId: string) => void;
    };
    handleClose: () => void;
}) => import("react").JSX.Element>;
export declare const ExportSvgDialog: import("react").LazyExoticComponent<typeof import("./components/ExportSvgDialog.tsx").default>;
export declare const GetSequenceDialog: import("react").LazyExoticComponent<({ model, regions, handleClose, }: {
    model: import("@jbrowse/mobx-state-tree").IAnyStateTreeNode;
    regions: import("@jbrowse/core/util").Region[];
    handleClose: () => void;
}) => import("react").JSX.Element>;
