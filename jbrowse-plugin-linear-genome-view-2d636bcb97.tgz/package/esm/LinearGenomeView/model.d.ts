import type { BpOffset, ExportSvgOptions, HighlightType, InitState, NavLocation, VolatileGuide } from './types.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
import type { MenuItem } from '@jbrowse/core/ui';
import type { ParsedLocString } from '@jbrowse/core/util';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
import type { BlockSet, ContentBlock } from '@jbrowse/core/util/blockTypes';
import type { Region } from '@jbrowse/core/util/types';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type React from 'react';
export declare const AUTO_FORCE_LOAD_BP = 20000;
export declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "highlight" | "showHighlightChips"> & {
    highlight: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IType<HighlightType, HighlightType, HighlightType>>, [undefined]>;
    showHighlightChips: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "bpPerPx" | "colorByCDS" | "displayedRegions" | "hideHeader" | "hideHeaderOverview" | "hideNoTracksActive" | "id" | "init" | "labelsVisible" | "offsetPx" | "scalebarOnly" | "showCenterLine" | "showCytobands" | "showGridlines" | "showTrackOutlines" | "trackLabels" | "trackSelectorType" | "tracks" | "type"> & {
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
    offsetPx: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    bpPerPx: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    displayedRegions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Region[], Region[], Region[]>, [undefined]>;
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    hideHeader: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    hideHeaderOverview: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    hideNoTracksActive: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    trackSelectorType: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    showCenterLine: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showCytobands: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    trackLabels: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    showGridlines: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    labelsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    colorByCDS: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showTrackOutlines: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    scalebarOnly: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    init: import("@jbrowse/mobx-state-tree").IType<InitState | undefined, InitState | undefined, InitState | undefined>;
}, {
    width: number;
} & {
    menuItems(): MenuItem[];
} & {
    setDisplayName(name: string): void;
    setWidth(newWidth: number): void;
    setMinimized(flag: boolean): void;
} & {
    addToHighlights(highlight: HighlightType): void;
    setHighlight(highlight?: HighlightType[]): void;
    removeHighlight(highlight: HighlightType): void;
    updateHighlight(old: HighlightType, updates: Partial<HighlightType>): void;
    setShowHighlightChips(arg: boolean): void;
} & {
    afterAttach(): void;
} & {
    volatileWidth: number | undefined;
    minimumBlockWidth: number;
    draggingTrackId: undefined | string;
    lastTrackDragY: undefined | number;
    volatileError: unknown;
    trackRefs: Record<string, HTMLDivElement>;
    coarseDynamicBlocks: ContentBlock[];
    coarseTotalBp: number;
    coarseBpPerPx: number;
    leftOffset: undefined | BpOffset;
    rightOffset: undefined | BpOffset;
    isScalebarRefNameMenuOpen: boolean;
    scalebarRefNameClickPending: boolean;
    volatileGuides: VolatileGuide[];
} & {
    readonly scrollZoom: boolean;
    readonly pinnedTracks: any[];
    readonly unpinnedTracks: any[];
    readonly effectiveTrackLabels: any;
    readonly width: number;
    readonly trackWidthPx: number;
    readonly assemblyNames: string[];
    readonly assemblyDisplayNames: string[];
    readonly isTopLevelView: boolean;
    readonly stickyViewHeaders: boolean;
    readonly rubberbandTop: number;
    readonly pinnedTracksTop: number;
} & {
    readonly scalebarDisplayPrefix: string | undefined;
    MiniControlsComponent(): React.FC<any>;
    HeaderComponent(): React.FC<any>;
    readonly assembliesNotFound: string | undefined;
    readonly assemblyErrors: string;
    readonly assembliesInitialized: boolean;
    readonly initAssembly: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    readonly initialized: boolean;
    readonly hasDisplayedRegions: boolean;
    readonly loadingMessage: "Loading" | undefined;
    readonly hasSomethingToShow: boolean;
    readonly initPending: boolean;
    readonly showLoading: boolean;
    readonly showImportForm: boolean;
    readonly scalebarHeight: number;
    readonly headerHeight: number;
    trackHeight(track: (import("@jbrowse/mobx-state-tree").IMSTArray<import("@jbrowse/mobx-state-tree").IAnyType> & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>>)[number]): any;
    readonly trackHeights: number;
    readonly trackHeightsWithResizeHandles: number;
    readonly height: number;
    getTrackYOffset(trackId: string): number | undefined;
    trackSection(id: string): any[];
    readonly totalBp: number;
    readonly maxBpPerPx: number;
    readonly minBpPerPx: number;
    readonly error: unknown;
    readonly maxOffset: number;
    readonly minOffset: number;
    readonly displayedRegionsTotalPx: number;
    searchScope(assemblyName: string): {
        assemblyName: string;
        includeAggregateIndexes: boolean;
        tracks: import("@jbrowse/mobx-state-tree").IMSTArray<import("@jbrowse/mobx-state-tree").IAnyType> & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    };
    readonly trackMap: Map<any, any>;
    getTrack(id: string): any;
    getActiveDisplayId(trackId: string): string | undefined;
} & {
    setShowTrackOutlines(arg: boolean): void;
    setScrollZoom(flag: boolean): void;
    setColorByCDS(flag: boolean): void;
    setShowCytobands(flag: boolean): void;
    setWidth(newWidth: number): void;
    setError(error: unknown): void;
    setIsScalebarRefNameMenuOpen(isOpen: boolean): void;
    setScalebarRefNameClickPending(pending: boolean): void;
    setHideHeader(b: boolean): void;
    setHideHeaderOverview(b: boolean): void;
    setScalebarOnly(b: boolean): void;
    setHideNoTracksActive(b: boolean): void;
    setShowGridlines(b: boolean): void;
    setLabelsVisible(arg: boolean): void;
    setVolatileGuides(guides: VolatileGuide[]): void;
    scrollTo(offsetPx: number): number;
    zoomTo(bpPerPx: number, offset?: any): number;
    setOffsets(left?: BpOffset, right?: BpOffset): void;
    setSearchResults(searchResults: BaseResult[], searchQuery: string, assemblyName?: string): void;
    setNewView(bpPerPx: number, offsetPx: number): void;
    horizontallyFlip(): void;
    showTrack(trackId: string, initialSnapshot?: any, displayInitialSnapshot?: any): any;
    hideTrack(trackId: string): boolean;
} & {
    moveTrackDown(id: string): void;
    moveTrackUp(id: string): void;
    moveTrackToTop(id: string): void;
    moveTrackToBottom(id: string): void;
    moveTrack(movingId: string, targetId: string): void;
    toggleTrack(trackId: string): boolean;
    setTrackLabels(setting: 'overlapping' | 'offset' | 'hidden'): void;
    setShowCenterLine(b: boolean): void;
    setDisplayedRegions(regions: Region[]): void;
    activateTrackSelector(): import("@jbrowse/core/util").Widget;
    toggleTrackSelector(): import("@jbrowse/core/util").Widget;
    getSelectedRegions(leftOffset?: BpOffset, rightOffset?: BpOffset): {
        assemblyName: string;
        refName: string;
        start: number;
        end: number;
    }[];
    horizontalScroll(distance: number): number;
    showAllRegions(): void;
    showAllRegionsInAssembly(assemblyName?: string): void;
    setDraggingTrackId(idx?: string): void;
    setLastTrackDragY(y: number): void;
    onTrackDragOver(targetId: string, currentY: number): void;
    clearView(): void;
    setInit(arg?: InitState): void;
    exportSvg(opts?: ExportSvgOptions): Promise<void>;
} & {
    slide: (viewWidths: number) => void;
} & {
    zoom: (targetBpPerPx: number) => void;
    cancelZoomAnimation: () => void;
} & {
    readonly showsWholeChromosome: boolean;
    readonly canShowCytobands: boolean;
    readonly effectiveShowCytobands: boolean;
    readonly anyCytobandsExist: boolean;
    readonly cytobandOffset: number;
    readonly isTrackSelectorOpen: boolean;
} & {
    menuItems(): MenuItem[];
    readonly overviewLayout: ViewLayout;
} & {
    readonly staticBlocks: BlockSet;
    readonly dynamicBlocks: BlockSet;
    readonly overviewBlocks: import("@jbrowse/core/util/blockTypes").BaseBlock[];
    readonly overviewContentBlocksPxSpan: {
        leftPx: number;
        rightPx: number;
    } | undefined;
    readonly scalebarRegionEndPx: Map<number, number>;
    readonly gridlineTicks: {
        x: number;
        major: boolean;
    }[];
    readonly scalebarLabels: {
        x: number;
        label: string;
        key: string;
    }[];
    readonly totalWidthPx: number;
    readonly totalWidthPxWithoutBorders: number;
    readonly visibleBp: number;
    readonly visibleRegions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
        reversed: boolean | undefined;
        displayedRegionIndex: number;
        screenStartPx: number;
        screenEndPx: number;
    }[];
    readonly bufferedVisibleRegions: {
        region: {
            refName: string;
            start: number;
            end: number;
            assemblyName: string;
        };
        displayedRegionIndex: number;
    }[];
    readonly visibleLocStrings: string;
    readonly coarseVisibleLocStrings: string;
    readonly coarseTotalBpDisplayStr: string;
    readonly effectiveTotalBp: number;
    readonly effectiveTotalBpDisplayStr: string;
} & {
    setCoarseDynamicBlocks(blocks: BlockSet, bpPerPx: number): void;
} & {
    moveTo(start?: BpOffset, end?: BpOffset): void;
    navToLocString(input: string, optAssemblyName?: string, grow?: number): Promise<void>;
    navToLocations(regions: ParsedLocString[], assemblyName?: string, grow?: number): Promise<void>;
    navTo(query: NavLocation, grow?: number): void;
    navToMultiple(locations: NavLocation[], grow?: number): void;
} & {
    navToLocation(parsedLocString: ParsedLocString, assemblyName?: string, grow?: number): Promise<void>;
} & {
    rubberBandMenuItems(): MenuItem[];
    bpToPx({ refName, coord, displayedRegionIndex, }: {
        refName: string;
        coord: number;
        displayedRegionIndex?: number;
    }): {
        index: number;
        offsetPx: number;
    } | undefined;
    getHighlightCoords(region: {
        assemblyName?: string;
        refName: string;
        start: number;
        end: number;
    }): {
        width: number;
        left: number;
    } | undefined;
    getOverviewHighlightCoords(region: {
        assemblyName?: string;
        refName: string;
        start: number;
        end: number;
    }): {
        width: number;
        left: number;
    } | undefined;
    centerAt(coord: number, refName: string, displayedRegionIndex?: number): void;
    pxToBp(px: number): import("@jbrowse/core/util/Base1DUtils").PxToBpResult;
    readonly centerLineInfo: import("@jbrowse/core/util/Base1DUtils").PxToBpResult | undefined;
} & {
    rubberbandClickMenuItems(clickOffset: BpOffset): MenuItem[];
    highlightMenuItems(_highlight: HighlightType): MenuItem[];
} & {
    afterCreate(): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, {
    displayName: string | undefined;
    minimized: boolean;
    highlight: HighlightType[];
    showHighlightChips: boolean;
    id: string;
    type: string;
    offsetPx: number;
    bpPerPx: number;
    displayedRegions: Region[];
    tracks: any[];
    hideHeader: boolean;
    hideHeaderOverview: boolean;
    hideNoTracksActive: boolean;
    trackSelectorType: string;
    showGridlines: boolean;
    labelsVisible: boolean;
    scalebarOnly: boolean;
    init?: InitState | undefined;
    showCytobands?: false | undefined;
    trackLabels?: string | undefined;
    colorByCDS?: true | undefined;
    showTrackOutlines?: false | undefined;
}>;
export type LinearGenomeViewStateModel = ReturnType<typeof stateModelFactory>;
export type LinearGenomeViewModel = Instance<LinearGenomeViewStateModel>;
