import type { LinearGenomeViewModel } from './model.ts';
export declare const knownInitKeys: Set<string>;
export declare function setupInitAutorun(self: LinearGenomeViewModel): void;
export declare function doAfterAttach(self: LinearGenomeViewModel): void;
