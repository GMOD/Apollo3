import type { Assembly } from '@jbrowse/core/assemblyManager/assembly';
export { getHighlightColor, highlightKey } from '@jbrowse/core/util/highlights';
export declare const elidedBlockStyles: {
    readonly backgroundColor: '#999';
    readonly backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 1px, rgba(255,255,255,.5) 1px, rgba(255,255,255,.5) 3px)';
};
export type Cytoband = ReturnType<typeof getCytobands>[number];
export declare function getCytobands(assembly: Assembly | undefined, refName: string): {
    refName: string;
    start: number;
    end: number;
    type: string;
    name: string | undefined;
}[];
export declare function shouldSwapTracks(lastSwapY: number | undefined, currentY: number, movingDown: boolean): boolean;
