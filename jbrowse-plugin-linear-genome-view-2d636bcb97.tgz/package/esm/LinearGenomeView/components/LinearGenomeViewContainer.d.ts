import type { LinearGenomeViewModel } from '../index.ts';
declare const LinearGenomeViewContainer: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default LinearGenomeViewContainer;
