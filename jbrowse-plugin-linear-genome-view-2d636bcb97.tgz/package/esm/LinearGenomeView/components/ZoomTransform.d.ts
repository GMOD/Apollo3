import type { LinearGenomeViewModel } from '../index.ts';
import type { ReactNode } from 'react';
type LGV = LinearGenomeViewModel;
declare const ZoomTransform: ({ model, offset, children, }: {
    model: LGV;
    offset?: number;
    children: ReactNode;
}) => import("react").JSX.Element;
export default ZoomTransform;
