import type { LinearGenomeViewModel } from '../index.ts';
declare const MiniControls: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default MiniControls;
