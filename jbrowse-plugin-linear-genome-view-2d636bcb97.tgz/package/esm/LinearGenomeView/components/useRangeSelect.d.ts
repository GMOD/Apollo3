import type { LinearGenomeViewModel } from '../index.ts';
import type React from 'react';
interface AnchorPosition {
    offsetX: number;
    clientX: number;
    clientY: number;
    isClick: boolean;
}
export declare function useRangeSelect(ref: React.RefObject<HTMLDivElement | null>, model: LinearGenomeViewModel, shiftOnly?: boolean): {
    open: boolean;
    isClick: boolean | undefined;
    clickBpOffset: import("@jbrowse/core/util/Base1DUtils").PxToBpResult | undefined;
    guideX: number | undefined;
    rubberbandOn: boolean;
    mouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
    mouseMove: (event: React.MouseEvent<HTMLDivElement>) => void;
    mouseOut: () => void;
    handleClose: () => void;
    handleMenuItemClick: (callback: () => void) => void;
    anchorPosition: AnchorPosition | undefined;
    rubberband: {
        leftBpOffset: ReturnType<LinearGenomeViewModel['pxToBp']>;
        rightBpOffset: ReturnType<LinearGenomeViewModel['pxToBp']>;
        numOfBpSelected: number;
        width: number;
        left: number;
    } | undefined;
};
export {};
