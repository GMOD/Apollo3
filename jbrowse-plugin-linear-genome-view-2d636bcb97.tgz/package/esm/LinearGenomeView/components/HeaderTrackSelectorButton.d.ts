import type { LinearGenomeViewModel } from '../index.ts';
declare const HeaderTrackSelectorButton: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default HeaderTrackSelectorButton;
