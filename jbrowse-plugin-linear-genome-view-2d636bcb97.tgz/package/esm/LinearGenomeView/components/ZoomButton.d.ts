import type { LinearGenomeViewModel } from '../index.ts';
declare const ZoomButton: ({ model, direction, small, }: {
    model: LinearGenomeViewModel;
    direction: 'in' | 'out';
    small?: boolean;
}) => import("react").JSX.Element;
export default ZoomButton;
