import type { LinearGenomeViewModel } from '../model.ts';
import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
import type { MenuItem } from '@jbrowse/core/ui';
export declare function getTrackOrderSubMenu({ view, track, }: {
    view: LinearGenomeViewModel;
    track: BaseTrackModel;
}): MenuItem[];
