import type { LinearGenomeViewModel } from '../index.ts';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
type LGV = LinearGenomeViewModel;
declare const OverviewRubberband: ({ model, overview, ControlComponent, }: {
    model: LGV;
    overview: ViewLayout;
    ControlComponent?: React.ReactElement;
}) => import("react").JSX.Element;
export default OverviewRubberband;
