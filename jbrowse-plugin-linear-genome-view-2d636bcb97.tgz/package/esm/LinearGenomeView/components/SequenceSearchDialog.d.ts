declare const SequenceSearchDialog: ({ model, handleClose, }: {
    model: {
        assemblyNames: string[];
        showTrack: (trackId: string) => void;
    };
    handleClose: () => void;
}) => import("react").JSX.Element;
export default SequenceSearchDialog;
