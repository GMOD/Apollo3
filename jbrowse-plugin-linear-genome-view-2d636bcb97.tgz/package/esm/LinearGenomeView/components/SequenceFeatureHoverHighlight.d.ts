import type { LinearGenomeViewModel } from '../index.ts';
declare const SequenceFeatureHoverHighlight: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default SequenceFeatureHoverHighlight;
