import type { LinearGenomeViewModel } from '../index.ts';
import type { ContentBlock } from '@jbrowse/core/util/blockTypes';
declare const OverviewScalebarTickLabels: ({ block, model, refNameColor, showRefName, }: {
    model: LinearGenomeViewModel;
    block: ContentBlock;
    refNameColor: string | undefined;
    showRefName: boolean;
}) => import("react").JSX.Element[];
export default OverviewScalebarTickLabels;
