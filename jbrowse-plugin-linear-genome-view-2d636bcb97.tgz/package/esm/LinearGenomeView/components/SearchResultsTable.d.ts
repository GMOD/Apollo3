import type { LinearGenomeViewModel } from '../../index.ts';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
declare const SearchResultsTable: ({ searchResults, assemblyName: optAssemblyName, model, handleClose, }: {
    searchResults: BaseResult[];
    assemblyName?: string;
    model: LinearGenomeViewModel;
    handleClose: () => void;
}) => import("react").JSX.Element;
export default SearchResultsTable;
