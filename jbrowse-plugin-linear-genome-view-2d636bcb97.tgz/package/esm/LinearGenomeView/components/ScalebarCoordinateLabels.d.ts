import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const ScalebarCoordinateLabels: ({ model, }: {
    model: LGV;
}) => import("react").JSX.Element;
export default ScalebarCoordinateLabels;
