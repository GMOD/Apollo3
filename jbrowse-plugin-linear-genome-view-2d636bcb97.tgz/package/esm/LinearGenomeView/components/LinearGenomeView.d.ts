import type { LinearGenomeViewModel } from '../index.ts';
declare const LinearGenomeView: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default LinearGenomeView;
