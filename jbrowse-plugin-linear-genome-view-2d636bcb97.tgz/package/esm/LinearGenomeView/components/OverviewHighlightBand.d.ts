export default function OverviewHighlightBand({ coords, background, borderColor, tooltip, }: {
    coords: {
        left: number;
        width: number;
    };
    background: string;
    borderColor?: string;
    tooltip?: string;
}): import("react").JSX.Element;
