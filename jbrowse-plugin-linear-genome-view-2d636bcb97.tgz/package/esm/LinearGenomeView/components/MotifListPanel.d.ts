import type { SequenceSearchModeProps } from './searchModes.ts';
declare const MotifListPanel: ({ model, handleClose, }: SequenceSearchModeProps) => import("react").JSX.Element;
export default MotifListPanel;
