export interface SequenceSearchModel {
    assemblyNames: string[];
    showTrack: (trackId: string) => void;
}
export interface SequenceSearchModeProps {
    model: SequenceSearchModel;
    handleClose: () => void;
}
export declare function addReferenceScanTrack(model: SequenceSearchModel, args: {
    trackId: string;
    name: string;
    adapter: Record<string, unknown>;
}): void;
