import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
declare const TrackLabelDragHandle: ({ track, }: {
    track: BaseTrackModel;
}) => import("react").JSX.Element;
export default TrackLabelDragHandle;
