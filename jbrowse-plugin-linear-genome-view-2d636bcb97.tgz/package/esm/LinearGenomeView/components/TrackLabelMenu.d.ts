import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
declare const TrackLabelMenu: ({ track, }: {
    track: BaseTrackModel;
}) => import("react").JSX.Element;
export default TrackLabelMenu;
