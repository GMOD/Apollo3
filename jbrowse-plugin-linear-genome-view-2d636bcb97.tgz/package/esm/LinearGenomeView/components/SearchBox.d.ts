import type { LinearGenomeViewModel } from '../model.ts';
import type React from 'react';
declare const SearchBox: ({ model, showHelp, minWidth, maxWidth, style, }: {
    showHelp?: boolean;
    model: LinearGenomeViewModel;
    minWidth?: number;
    maxWidth?: number;
    style?: React.CSSProperties;
}) => React.JSX.Element;
export default SearchBox;
