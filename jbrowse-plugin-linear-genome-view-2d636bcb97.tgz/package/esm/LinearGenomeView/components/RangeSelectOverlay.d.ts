import type { LinearGenomeViewModel } from '../index.ts';
import type { useRangeSelect } from './useRangeSelect.ts';
type LGV = LinearGenomeViewModel;
declare const RangeSelectOverlay: ({ model, range, menuOffsetX, }: {
    model: LGV;
    range: ReturnType<typeof useRangeSelect>;
    menuOffsetX?: number;
}) => import("react").JSX.Element;
export default RangeSelectOverlay;
