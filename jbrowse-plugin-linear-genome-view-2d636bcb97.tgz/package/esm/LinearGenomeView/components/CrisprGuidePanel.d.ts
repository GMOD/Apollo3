import type { SequenceSearchModeProps } from './searchModes.ts';
declare const CrisprGuidePanel: ({ model, handleClose, }: SequenceSearchModeProps) => import("react").JSX.Element;
export default CrisprGuidePanel;
