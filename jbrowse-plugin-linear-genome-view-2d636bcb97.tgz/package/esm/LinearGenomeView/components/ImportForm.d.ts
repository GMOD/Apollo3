import type { LinearGenomeViewModel } from '../index.ts';
declare const LinearGenomeViewImportForm: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default LinearGenomeViewImportForm;
