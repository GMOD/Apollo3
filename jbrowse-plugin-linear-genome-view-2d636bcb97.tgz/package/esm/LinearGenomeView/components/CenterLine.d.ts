import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const CenterLine: ({ model }: {
    model: LGV;
}) => import("react").JSX.Element | null;
export default CenterLine;
