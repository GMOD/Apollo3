import type { ReactNode } from 'react';
export default function StrandCheckboxes({ searchForward, searchReverse, setSearchForward, setSearchReverse, children, }: {
    searchForward: boolean;
    searchReverse: boolean;
    setSearchForward: (arg: boolean) => void;
    setSearchReverse: (arg: boolean) => void;
    children?: ReactNode;
}): import("react").JSX.Element;
