import type { LinearGenomeViewModel } from '../index.ts';
import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
type LGV = LinearGenomeViewModel;
declare const TrackRenderingContainer: ({ model, track, }: {
    model: LGV;
    track: BaseTrackModel;
}) => import("react").JSX.Element;
export default TrackRenderingContainer;
