import type { MenuItem } from '@jbrowse/core/ui';
import type { Colord } from '@jbrowse/core/util/colord';
export default function HighlightChip({ color, label, tooltip, menuItems, }: {
    color: Colord;
    label?: string;
    tooltip?: string;
    menuItems: MenuItem[];
}): import("react").JSX.Element;
