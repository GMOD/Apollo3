import type { LinearGenomeViewModel } from '../model.ts';
import type { HighlightType } from '../types.ts';
type LGV = LinearGenomeViewModel;
declare const Highlight: ({ model, highlight, }: {
    model: LGV;
    highlight: HighlightType;
}) => import("react").JSX.Element | null;
export default Highlight;
