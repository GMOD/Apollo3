import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const Gridlines: ({ model, offset, }: {
    model: LGV;
    offset?: number;
}) => import("react").JSX.Element;
export default Gridlines;
