import type { LinearGenomeViewModel } from '../index.ts';
declare const HeaderZoomControls: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default HeaderZoomControls;
