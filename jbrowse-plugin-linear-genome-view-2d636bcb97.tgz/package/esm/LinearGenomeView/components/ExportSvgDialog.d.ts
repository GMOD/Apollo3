import type { TrackLabelMode } from '../types.ts';
import type { BaseExportSvgOptions } from '@jbrowse/core/ui';
export default function ExportSvgDialog({ model, handleClose, }: {
    model: {
        exportSvg(opts: BaseExportSvgOptions & {
            trackLabels: TrackLabelMode;
            showGridlines: boolean;
        }): Promise<void>;
    };
    handleClose: () => void;
}): import("react").JSX.Element;
