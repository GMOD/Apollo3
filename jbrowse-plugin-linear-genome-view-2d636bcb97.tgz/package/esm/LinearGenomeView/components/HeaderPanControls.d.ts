import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function HeaderPanControls({ model }: {
    model: LGV;
}): import("react").JSX.Element;
export {};
