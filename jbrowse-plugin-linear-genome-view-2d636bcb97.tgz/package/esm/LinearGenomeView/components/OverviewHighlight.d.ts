import type { LinearGenomeViewModel } from '../model.ts';
type LGV = LinearGenomeViewModel;
declare const OverviewHighlight: ({ model, }: {
    model: LGV;
}) => import("react").JSX.Element[] | null;
export default OverviewHighlight;
