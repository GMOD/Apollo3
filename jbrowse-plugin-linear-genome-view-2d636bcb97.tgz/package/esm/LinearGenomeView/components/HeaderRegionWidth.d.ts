import type { LinearGenomeViewModel } from '../index.ts';
declare const HeaderRegionWidth: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default HeaderRegionWidth;
