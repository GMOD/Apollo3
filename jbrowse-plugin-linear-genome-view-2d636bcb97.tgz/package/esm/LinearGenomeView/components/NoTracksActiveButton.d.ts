import type { LinearGenomeViewModel } from '../index.ts';
declare const NoTracksActiveButton: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element;
export default NoTracksActiveButton;
