import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
export declare const TrackLabelCloseButton: ({ track, }: {
    track: BaseTrackModel;
}) => import("react").JSX.Element;
export declare const TrackLabelMinimizeButton: ({ track }: {
    track: BaseTrackModel;
}) => import("react").JSX.Element;
