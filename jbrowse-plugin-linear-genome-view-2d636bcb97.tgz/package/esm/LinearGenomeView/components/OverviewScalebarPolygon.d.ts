import type { LinearGenomeViewModel } from '../index.ts';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
declare const OverviewScalebarPolygon: ({ model, overview, overviewOffsetPx, exportSvg, }: {
    model: LinearGenomeViewModel;
    overview: ViewLayout;
    overviewOffsetPx?: number;
    exportSvg?: boolean;
}) => import("react").JSX.Element | null;
export default OverviewScalebarPolygon;
