import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const TracksContainer: ({ children, model, }: {
    children: React.ReactNode;
    model: LGV;
}) => import("react").JSX.Element;
export default TracksContainer;
