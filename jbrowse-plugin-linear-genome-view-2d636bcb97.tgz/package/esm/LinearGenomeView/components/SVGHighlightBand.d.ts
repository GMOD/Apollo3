export default function SVGHighlightBand({ coords, height, color, label, labelColor, }: {
    coords: {
        left: number;
        width: number;
    };
    height: number;
    color: string;
    label?: string;
    labelColor: string;
}): import("react").JSX.Element;
