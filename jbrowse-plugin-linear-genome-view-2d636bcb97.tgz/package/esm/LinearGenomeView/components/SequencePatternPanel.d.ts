import type { SequenceSearchModeProps } from './searchModes.ts';
declare const SequencePatternPanel: ({ model, handleClose, }: SequenceSearchModeProps) => import("react").JSX.Element;
export default SequencePatternPanel;
