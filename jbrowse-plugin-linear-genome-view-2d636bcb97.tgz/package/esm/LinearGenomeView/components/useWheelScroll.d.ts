import type React from 'react';
interface GenomeViewModel {
    bpPerPx: number;
    scrollZoom?: boolean;
    zoomTo: (bpPerPx: number, offset?: number) => void;
    horizontalScroll: (delta: number) => void;
}
export declare function useWheelScroll(ref: React.RefObject<HTMLDivElement | null>, model: GenomeViewModel): void;
export {};
