import type { LinearGenomeViewModel } from '../index.ts';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
type LGV = LinearGenomeViewModel;
declare const OverviewRubberbandHoverTooltip: ({ model, guideX, overview, }: {
    model: LGV;
    guideX: number;
    overview: ViewLayout;
}) => import("react").JSX.Element;
export default OverviewRubberbandHoverTooltip;
