import type { LinearGenomeViewModel } from '../index.ts';
declare const HeaderClearHighlightButton: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element | null;
export default HeaderClearHighlightButton;
