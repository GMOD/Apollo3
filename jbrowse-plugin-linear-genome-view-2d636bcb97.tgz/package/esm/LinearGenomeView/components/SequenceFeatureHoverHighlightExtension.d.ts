import type PluginManager from '@jbrowse/core/PluginManager';
export default function SequenceFeatureHoverHighlightExtensionF(pluginManager: PluginManager): void;
