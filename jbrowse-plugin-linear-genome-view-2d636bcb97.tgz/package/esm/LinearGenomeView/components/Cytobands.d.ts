import type { Cytoband } from './util.ts';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
import type { ContentBlock } from '@jbrowse/core/util/blockTypes';
declare const Cytobands: ({ overview, block, cytobands, }: {
    overview: ViewLayout;
    cytobands: Cytoband[];
    block: ContentBlock;
}) => import("react").JSX.Element;
export default Cytobands;
