import type { LinearGenomeViewModel } from '../index.ts';
import type React from 'react';
type LGV = LinearGenomeViewModel;
interface ScalebarProps {
    model: LGV;
    style?: React.CSSProperties;
    className?: string;
}
declare const Scalebar: ({ model, style, className, }: ScalebarProps) => React.JSX.Element;
export default Scalebar;
