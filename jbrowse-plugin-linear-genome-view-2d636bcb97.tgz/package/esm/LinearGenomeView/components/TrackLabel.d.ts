import type { BaseTrackModel } from '@jbrowse/core/pluggableElementTypes/models';
declare const TrackLabel: ({ track, className, }: {
    track: BaseTrackModel;
    className?: string;
}) => import("react").JSX.Element;
export default TrackLabel;
