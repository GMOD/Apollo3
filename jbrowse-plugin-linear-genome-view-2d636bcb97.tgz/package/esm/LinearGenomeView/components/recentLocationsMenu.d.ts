import type { MenuItem } from '@jbrowse/core/ui';
export declare function recentLocationsMenu({ recentLocations, onNavigate, onClear, }: {
    recentLocations: string[];
    onNavigate: (loc: string) => void;
    onClear: () => void;
}): MenuItem[];
