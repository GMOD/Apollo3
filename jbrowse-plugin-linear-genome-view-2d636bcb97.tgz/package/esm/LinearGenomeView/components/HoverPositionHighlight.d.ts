import type { LinearGenomeViewModel } from '../model.ts';
export interface HoverHighlightPosition {
    refName: string;
    start: number;
    end: number;
    assemblyName?: string;
}
declare const HoverPositionHighlight: ({ model, position, }: {
    model: LinearGenomeViewModel;
    position: HoverHighlightPosition;
}) => import("react").JSX.Element | null;
export default HoverPositionHighlight;
