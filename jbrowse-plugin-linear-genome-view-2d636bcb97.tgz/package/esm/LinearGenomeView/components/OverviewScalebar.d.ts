import type { LinearGenomeViewModel } from '../index.ts';
import type { ReactNode } from 'react';
type LGV = LinearGenomeViewModel;
declare const OverviewScalebar: ({ model, children, }: {
    model: LGV;
    children: ReactNode;
}) => import("react").JSX.Element;
export default OverviewScalebar;
