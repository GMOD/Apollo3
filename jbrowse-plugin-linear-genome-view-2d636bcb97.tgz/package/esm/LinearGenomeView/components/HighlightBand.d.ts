export default function HighlightBand({ coords, background, label, children, }: {
    coords: {
        left: number;
        width: number;
    };
    background: string;
    label?: string;
    children?: React.ReactNode;
}): import("react").JSX.Element;
