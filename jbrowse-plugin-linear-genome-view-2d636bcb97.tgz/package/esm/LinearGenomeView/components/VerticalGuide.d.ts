import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const VerticalGuide: ({ model, coordX, }: {
    model: LGV;
    coordX: number;
}) => import("react").JSX.Element;
export default VerticalGuide;
