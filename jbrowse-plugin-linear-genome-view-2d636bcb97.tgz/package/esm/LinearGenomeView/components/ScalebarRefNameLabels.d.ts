import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const ScalebarRefNameLabels: ({ model, }: {
    model: LGV;
}) => import("react").JSX.Element;
export default ScalebarRefNameLabels;
