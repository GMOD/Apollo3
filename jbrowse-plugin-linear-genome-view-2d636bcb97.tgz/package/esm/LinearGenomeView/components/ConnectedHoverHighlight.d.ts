import type { LinearGenomeViewModel } from '../model.ts';
import type { HoverHighlightPosition } from './HoverPositionHighlight.tsx';
declare const ConnectedHoverHighlight: ({ model, getPosition, }: {
    model: LinearGenomeViewModel;
    getPosition: (widget: unknown, viewId: string) => HoverHighlightPosition | undefined;
}) => import("react").JSX.Element | null;
export default ConnectedHoverHighlight;
