import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
declare const Rubberband: ({ model, ControlComponent, }: {
    model: LGV;
    ControlComponent?: React.ReactElement;
}) => import("react").JSX.Element;
export default Rubberband;
