import type { LinearGenomeViewModel } from '../index.ts';
import type React from 'react';
export declare function useSideScroll(model: LinearGenomeViewModel): {
    mouseDown: (event: React.MouseEvent) => void;
    mouseUp: (event: React.MouseEvent) => void;
};
