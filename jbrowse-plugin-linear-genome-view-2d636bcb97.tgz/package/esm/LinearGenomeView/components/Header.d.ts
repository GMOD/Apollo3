import type { LinearGenomeViewModel } from '../index.ts';
declare const LinearGenomeViewHeader: ({ model, }: {
    model: LinearGenomeViewModel;
}) => import("react").JSX.Element | null;
export default LinearGenomeViewHeader;
