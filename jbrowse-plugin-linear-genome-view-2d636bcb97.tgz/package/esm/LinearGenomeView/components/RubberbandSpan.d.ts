interface Offset {
    coord: number;
    refName?: string;
    oob?: boolean;
}
export default function RubberbandSpan({ leftBpOffset, rightBpOffset, numOfBpSelected, left, width, top, sticky, }: {
    leftBpOffset: Offset;
    rightBpOffset: Offset;
    numOfBpSelected?: number;
    left: number;
    width: number;
    top?: number;
    sticky?: boolean;
}): import("react").JSX.Element;
export {};
