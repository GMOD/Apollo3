import type { LinearGenomeViewModel } from '../model.ts';
export default function RegionWidthEditorDialog({ model, handleClose, }: {
    model: LinearGenomeViewModel;
    handleClose: () => void;
}): import("react").JSX.Element;
