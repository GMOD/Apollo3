import type { Region } from '@jbrowse/core/util';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
declare const GetSequenceDialog: ({ model, regions, handleClose, }: {
    model: IAnyStateTreeNode;
    regions: Region[];
    handleClose: () => void;
}) => import("react").JSX.Element;
export default GetSequenceDialog;
