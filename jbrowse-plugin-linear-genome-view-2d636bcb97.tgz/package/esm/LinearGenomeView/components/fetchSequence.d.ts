import type { Region } from '@jbrowse/core/util/types';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export declare function fetchSequence(model: IAnyStateTreeNode, regions: Region[]): Promise<import("@jbrowse/core/util").Feature[]>;
