export declare const TrackOverlayPortal: ({ children, fallbackInline, }: {
    children: React.ReactNode;
    fallbackInline?: boolean;
}) => import("react").ReactNode;
