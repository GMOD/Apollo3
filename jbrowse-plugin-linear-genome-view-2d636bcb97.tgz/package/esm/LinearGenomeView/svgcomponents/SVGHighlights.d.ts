import type { LinearGenomeViewModel } from '../index.ts';
declare const SVGHighlights: ({ model, height, }: {
    model: LinearGenomeViewModel;
    height: number;
}) => (import("react").JSX.Element | null)[] | null;
export default SVGHighlights;
