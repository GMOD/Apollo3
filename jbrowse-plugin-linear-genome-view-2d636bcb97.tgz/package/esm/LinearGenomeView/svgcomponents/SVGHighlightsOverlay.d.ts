import type { LinearGenomeViewModel } from '../index.ts';
export default function SVGHighlightsOverlay({ model, tracksHeight, }: {
    model: LinearGenomeViewModel;
    tracksHeight: number;
}): import("react").JSX.Element;
