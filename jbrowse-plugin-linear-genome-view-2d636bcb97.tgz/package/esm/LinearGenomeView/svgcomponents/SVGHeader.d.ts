import type { LinearGenomeViewModel } from '../index.ts';
export default function SVGHeader({ model, fontSize, rulerHeight, }: {
    model: LinearGenomeViewModel;
    rulerHeight: number;
    fontSize: number;
}): import("react").JSX.Element | null;
