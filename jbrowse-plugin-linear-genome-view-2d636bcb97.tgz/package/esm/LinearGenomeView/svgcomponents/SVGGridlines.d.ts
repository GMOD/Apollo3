import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function SVGGridlines({ model, height, }: {
    model: LGV;
    height: number;
}): import("react").JSX.Element;
export {};
