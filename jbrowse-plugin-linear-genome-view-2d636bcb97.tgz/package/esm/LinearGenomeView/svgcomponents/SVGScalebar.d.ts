import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function SVGScalebar({ model, fontSize, }: {
    model: LGV;
    fontSize: number;
}): import("react").JSX.Element;
export {};
