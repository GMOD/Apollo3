import type { LinearGenomeViewModel } from '../index.ts';
import type { TrackLabelMode } from '../types.ts';
import type { SvgDisplayResult } from './util.ts';
type LGV = LinearGenomeViewModel;
export default function SVGTracks({ displayResults, model, textHeight, fontSize, trackLabels, trackLabelOffset, leftBuffer, legendWidth, }: {
    displayResults: SvgDisplayResult[];
    model: LGV;
    textHeight: number;
    fontSize: number;
    trackLabels?: TrackLabelMode;
    trackLabelOffset?: number;
    leftBuffer?: number;
    legendWidth?: number;
}): import("react").JSX.Element;
export {};
