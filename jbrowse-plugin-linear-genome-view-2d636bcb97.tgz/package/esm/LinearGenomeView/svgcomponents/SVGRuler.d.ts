import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function SVGRuler({ model, fontSize, rulerHeight, }: {
    model: LGV;
    fontSize: number;
    rulerHeight: number;
}): import("react").JSX.Element;
export {};
