import type { TrackLabelMode } from '../types.ts';
export default function SVGTrackLabel({ trackLabels, trackName, fontSize, trackLabelOffset, x, }: {
    trackName: string;
    trackLabels: TrackLabelMode;
    fontSize: number;
    trackLabelOffset: number;
    x: number;
}): import("react").JSX.Element | null;
