import type { LinearGenomeViewModel } from '../index.ts';
import type { ExportSvgOptions } from '../types.ts';
type LGV = LinearGenomeViewModel;
export declare function renderToSvg(model: LGV, opts: ExportSvgOptions): Promise<string>;
export { default as SVGGridlines } from './SVGGridlines.tsx';
export { default as SVGRuler } from './SVGRuler.tsx';
export { default as SVGTracks } from './SVGTracks.tsx';
export { default as SVGView } from './SVGView.tsx';
