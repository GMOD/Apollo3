import type { LinearGenomeViewModel } from '../index.ts';
import type { TrackLabelMode } from '../types.ts';
import type { SvgDisplayResult } from './util.ts';
export default function SVGView({ view, displayResults, fontSize, textHeight, trackLabels, trackLabelOffset, contentTop, rulerHeight, tracksHeight, showGridlines, leftBuffer, }: {
    view: LinearGenomeViewModel;
    displayResults: SvgDisplayResult[];
    fontSize: number;
    textHeight: number;
    trackLabels: TrackLabelMode;
    trackLabelOffset: number;
    contentTop: number;
    rulerHeight?: number;
    tracksHeight: number;
    showGridlines: boolean;
    leftBuffer?: number;
}): import("react").JSX.Element;
