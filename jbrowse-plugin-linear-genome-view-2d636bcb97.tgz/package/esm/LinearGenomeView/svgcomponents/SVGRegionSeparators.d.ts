import type { LinearGenomeViewModel } from '../index.ts';
type LGV = LinearGenomeViewModel;
export default function SVGRegionSeparators({ model, height, }: {
    height: number;
    model: LGV;
}): import("react").JSX.Element;
export {};
