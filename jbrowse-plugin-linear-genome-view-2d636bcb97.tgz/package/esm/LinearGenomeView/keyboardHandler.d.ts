import type { LinearGenomeViewModel } from './model.ts';
export declare function setupKeyboardHandler(self: LinearGenomeViewModel): void;
