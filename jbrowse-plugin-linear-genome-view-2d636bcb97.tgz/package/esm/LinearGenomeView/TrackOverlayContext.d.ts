export declare const TrackOverlayContext: import("react").Context<HTMLElement | null>;
