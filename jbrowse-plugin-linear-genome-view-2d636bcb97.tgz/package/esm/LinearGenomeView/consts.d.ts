export declare const HEADER_BAR_HEIGHT = 48;
export declare const HEADER_OVERVIEW_HEIGHT = 20;
export declare const SCALE_BAR_HEIGHT = 17;
export declare const SVG_SCALEBAR_CAP = 5;
export declare const RESIZE_HANDLE_HEIGHT = 3;
export declare const MINIMIZED_TRACK_HEIGHT = 20;
export declare const SPACING = 7;
export declare const WIDGET_HEIGHT = 32;
