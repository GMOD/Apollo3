import type { LinearGenomeViewModel } from './model.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export type SyncableViewAction = 'horizontalScroll' | 'zoomTo' | 'showTrack' | 'toggleTrack' | 'hideTrack' | 'setTrackLabels' | 'setShowCenterLine';
interface LinkableViews {
    linkViews: boolean;
    views: LinearGenomeViewModel[];
}
export declare function installLinkedViewSync(self: IAnyStateTreeNode & LinkableViews, syncActions: readonly SyncableViewAction[]): void;
export {};
