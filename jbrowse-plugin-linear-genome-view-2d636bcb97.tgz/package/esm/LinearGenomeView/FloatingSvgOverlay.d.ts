export declare const FloatingSvgOverlay: ({ width, height, children, }: {
    width: number;
    height: number;
    children: React.ReactNode;
}) => import("react").JSX.Element;
