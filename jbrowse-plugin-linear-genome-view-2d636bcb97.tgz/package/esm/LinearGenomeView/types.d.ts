import type { HighlightType } from '@jbrowse/core/util/highlights';
export interface BpOffset {
    refName?: string;
    index: number;
    offset: number;
    start?: number;
    end?: number;
    coord?: number;
    reversed?: boolean;
    assemblyName?: string;
    oob?: boolean;
}
export type TrackLabelMode = 'offset' | 'overlay' | 'left' | 'none';
export interface ExportSvgOptions {
    rasterizeLayers?: boolean;
    format?: 'svg' | 'png';
    filename?: string;
    Wrapper?: React.FC<{
        children: React.ReactNode;
    }>;
    fontSize?: number;
    rulerHeight?: number;
    textHeight?: number;
    trackLabels?: TrackLabelMode;
    themeName?: string;
    fontFamily?: string;
    showGridlines?: boolean;
    createCanvas?: (width: number, height: number) => HTMLCanvasElement;
}
export type { HighlightType };
export interface NavLocation {
    refName: string;
    start?: number;
    end?: number;
    assemblyName?: string;
}
export interface VolatileGuide {
    xPos: number;
}
export type TrackInit = string | {
    trackId: string;
    trackSnapshot?: Record<string, unknown>;
    displaySnapshot?: Record<string, unknown>;
    [key: string]: unknown;
};
export interface InitState {
    loc?: string;
    grow?: number;
    assembly: string;
    displayedRegionNames?: string[];
    tracks?: TrackInit[];
    tracklist?: boolean;
    nav?: boolean;
    highlight?: (string | HighlightType)[];
}
export interface LinearGenomeViewLaunchProps {
    showCenterLine?: boolean;
    trackLabels?: 'overlapping' | 'offset' | 'hidden';
    colorByCDS?: boolean;
    showHighlightChips?: boolean;
}
