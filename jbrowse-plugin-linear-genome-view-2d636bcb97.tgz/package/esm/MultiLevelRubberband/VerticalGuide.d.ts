import type { MultiLevelRubberbandModel } from './types.ts';
declare const VerticalGuide: ({ model, coordX, }: {
    model: MultiLevelRubberbandModel;
    coordX: number;
}) => import("react").JSX.Element;
export default VerticalGuide;
