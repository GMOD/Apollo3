import type { MultiLevelRubberbandModel } from './types.ts';
declare const MultiLevelRubberband: ({ model, ControlComponent, }: {
    model: MultiLevelRubberbandModel;
    ControlComponent?: React.ReactElement;
}) => import("react").JSX.Element;
export default MultiLevelRubberband;
