import type { MultiLevelRubberbandModel } from './types.ts';
import type React from 'react';
interface AnchorPosition {
    offsetX: number;
    clientX: number;
    clientY: number;
}
export declare function useRangeSelect(ref: React.RefObject<HTMLDivElement | null>, model: MultiLevelRubberbandModel): {
    open: boolean;
    rubberbandOn: boolean;
    guideX: number | undefined;
    anchorPosition: AnchorPosition | undefined;
    left: number;
    width: number;
    leftBpOffset: import("@jbrowse/core/util/Base1DUtils").PxToBpResult[];
    rightBpOffset: import("@jbrowse/core/util/Base1DUtils").PxToBpResult[];
    numOfBpSelected: number[];
    mouseDown: (event: React.MouseEvent<HTMLDivElement>) => void;
    mouseMove: (event: React.MouseEvent<HTMLDivElement>) => void;
    mouseOut: () => void;
    handleClose: () => void;
    handleMenuItemClick: (callback: () => void) => void;
};
export {};
