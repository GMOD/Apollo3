import type { LinearGenomeViewModel } from '../LinearGenomeView/model.ts';
import type { MenuItem } from '@jbrowse/core/ui';
export interface MultiLevelRubberbandModel {
    views: LinearGenomeViewModel[];
    rubberBandMenuItems: () => MenuItem[];
}
