import type { InitState, LinearGenomeViewLaunchProps } from '../LinearGenomeView/types.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { AbstractSessionModel } from '@jbrowse/core/util';
export type LaunchLinearGenomeViewArgs = Partial<InitState> & LinearGenomeViewLaunchProps & {
    session: AbstractSessionModel;
    id?: string;
};
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'LaunchView-LinearGenomeView': {
            args: LaunchLinearGenomeViewArgs;
            result: LaunchLinearGenomeViewArgs;
        };
    }
}
export default function LaunchLinearGenomeViewF(pluginManager: PluginManager): void;
