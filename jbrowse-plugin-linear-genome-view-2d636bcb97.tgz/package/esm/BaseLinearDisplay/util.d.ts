export declare function drawCanvasImageData(canvas: HTMLCanvasElement | null, imageData: ImageBitmap | undefined): boolean;
