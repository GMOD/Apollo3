import type { RegionByteEstimate } from '@jbrowse/core/data_adapters/BaseAdapter/types';
import type RpcManager from '@jbrowse/core/rpc/RpcManager';
export interface ByteEstimateConfig {
    adapterConfig: Record<string, unknown>;
    visibleBp: number;
}
export declare function checkByteEstimate(rpcManager: Pick<RpcManager, 'call'>, sessionId: string, regions: {
    refName: string;
    start: number;
    end: number;
    assemblyName: string;
}[], config: ByteEstimateConfig, ctx: {
    isStale: () => boolean;
}): Promise<RegionByteEstimate | undefined>;
