import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
export default function TrackHeightMixin<TConf extends {
    configuration: AnyConfigurationModel;
} = {
    configuration: AnyConfigurationModel;
}>(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    scrollTop: number;
} & {
    readonly height: number;
} & {
    setScrollTop(scrollTop: number): void;
    setHeight(displayHeight: number): number;
    resizeHeight(distance: number): number;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
