declare const baseLinearDisplayConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly maxFeatureScreenDensity: {
        readonly type: "number";
        readonly description: "maximum features per pixel before showing a \"too many features\" message, used if byte size estimates are not available";
        readonly defaultValue: 1;
        readonly advanced: true;
    };
    readonly fetchSizeLimit: {
        readonly type: "number";
        readonly defaultValue: 1000000;
        readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
        readonly advanced: true;
    };
    readonly forceLoad: {
        readonly type: "boolean";
        readonly defaultValue: false;
        readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
        readonly advanced: true;
    };
    readonly height: {
        readonly type: "number";
        readonly defaultValue: 100;
        readonly description: "default height for the track";
    };
    readonly mouseover: {
        readonly type: "string";
        readonly description: "text to display when the cursor hovers over a feature";
        readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
        readonly contextVariable: ["feature"];
    };
    readonly jexlFilters: {
        readonly type: "stringArray";
        readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
        readonly defaultValue: readonly ["get(feature,'gbkey')!='Src'"];
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>;
export default baseLinearDisplayConfigSchema;
