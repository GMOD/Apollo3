import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
import type { FetchContext } from './FetchMixin.ts';
import type { ByteEstimateConfig } from './fetchHelpers.ts';
import type { Region } from '@jbrowse/core/util';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
import type { IAutorunOptions } from 'mobx';
export { checkByteEstimate } from './fetchHelpers.ts';
export type { ByteEstimateConfig } from './fetchHelpers.ts';
export type { FetchContext } from './FetchMixin.ts';
export declare function isBlockCovered(loaded: Region | undefined, block: {
    refName: string;
    start: number;
    end: number;
}): boolean;
export default function MultiRegionDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{}, never>, never>, never>, {
    userByteLimit: number | undefined;
    byteEstimate: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate | undefined;
    measuredSpanBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLargeForDerivedGate: boolean;
    readonly configForceLoad: boolean;
} & {
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly tooLargeStatus: import("../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    regionCannotBeRenderedText(): "" | "Force load to see features";
} & {
    setByteEstimate(estimate?: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate): void;
    raiseForceLoadLimits(estimate?: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate): void;
    reload(): void;
} & {
    forceLoad(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: import("@jbrowse/render-core").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
    lastStatusMs: number;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    loadedRegions: import("mobx").ObservableMap<number, Region>;
} & {
    readonly isReady: boolean;
    readonly viewportWithinLoadedData: boolean;
    readonly svgReady: boolean;
    readonly svgReadyExtraTerminal: boolean;
    readonly layoutReady: boolean;
    readonly renderBlocks: import("@jbrowse/render-core").RenderBlock[];
} & {
    readonly displayPhase: DisplayPhase;
    readonly rpcPropsCacheKey: string;
} & {
    setLoadedRegion(displayedRegionIndex: number, region: Region): void;
    clearDisplaySpecificData(): void;
} & {
    clearAllRpcData(): void;
    reload(): void;
    invalidateLoadedRegions(): void;
} & {
    fetchNeeded(_needed: {
        region: Region;
        displayedRegionIndex: number;
    }[]): void;
    isCacheValid(_displayedRegionIndex: number): boolean;
    getByteEstimateConfig(): ByteEstimateConfig | null;
    onRegionTooLarge(): void;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
} & {
    fetchRegions(needed: {
        region: Region;
        displayedRegionIndex: number;
    }[], work: (ctx: FetchContext) => Promise<void>): Promise<void>;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type MultiRegionDisplayMixinType = ReturnType<typeof MultiRegionDisplayMixin>;
export declare function autorunOnReadyView(self: IAnyStateTreeNode, fn: (view: LinearGenomeViewModel) => void, opts?: IAutorunOptions): void;
export declare function makeSettingsLoopGuard(name: string): () => void;
interface FetchEachRegionModel {
    fetchRegions: (needed: {
        region: Region;
        displayedRegionIndex: number;
    }[], work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
}
export declare function fetchEachRegion<R>(self: FetchEachRegionModel, needed: {
    region: Region;
    displayedRegionIndex: number;
}[], opts: {
    call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
export declare function fetchAllRegions<R>(self: FetchEachRegionModel, needed: {
    region: Region;
    displayedRegionIndex: number;
}[], opts: {
    call: (regions: Region[], ctx: FetchContext) => Promise<R[]>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
export declare function onDisplayedRegionsChange(self: IAnyStateTreeNode, clear: () => void, name?: string): void;
