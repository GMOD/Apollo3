export default function StaleViewportRescaleMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    lastDrawnOffsetPx: number | undefined;
    lastDrawnBpPerPx: number | undefined;
} & {
    setLastDrawnViewport(offsetPx: number, bpPerPx: number): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type StaleViewportRescaleMixinType = ReturnType<typeof StaleViewportRescaleMixin>;
