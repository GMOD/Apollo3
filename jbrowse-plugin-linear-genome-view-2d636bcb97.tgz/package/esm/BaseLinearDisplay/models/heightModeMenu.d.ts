import type { HeightMode } from './heightMode.ts';
import type { PromotableDisplay } from '@jbrowse/core/configuration';
import type { MenuItem } from '@jbrowse/core/ui';
export type HeightModeMenuModel = PromotableDisplay & {
    heightMode: HeightMode;
    setHeightMode: (mode: HeightMode) => void;
};
export declare function heightModeMenuItems(model: HeightModeMenuModel, noun: string): MenuItem[];
export declare function getTrackSizingMenuItem(model: HeightModeMenuModel, noun: string, opts?: {
    disabled?: boolean;
    disabledHelpText?: string;
}): MenuItem;
