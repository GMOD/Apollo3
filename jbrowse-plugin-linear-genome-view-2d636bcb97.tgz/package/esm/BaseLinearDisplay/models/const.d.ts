export declare const MIN_DISPLAY_HEIGHT = 20;
