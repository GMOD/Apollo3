import type { HeightMode } from './heightMode.ts';
import type { PromotableDisplay } from '@jbrowse/core/configuration';
import type { IReactionDisposer } from 'mobx';
export default function HeightModeMixin<TConf extends PromotableDisplay = PromotableDisplay>(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    readonly heightMode: HeightMode;
    readonly fitTargetHeight: number;
} & {
    readonly autoHeight: boolean;
    readonly fitHeightToDisplay: boolean;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export declare function installGrowExitBake(self: {
    heightMode: HeightMode;
    autoHeight: boolean;
    grownHeight: number;
    fitTargetHeight: number;
    setHeight: (height: number) => number;
}, view: {
    initialized: boolean;
}): IReactionDisposer;
