import type { AnyConfigurationSchemaType } from '@jbrowse/core/configuration';
import type { TrackConfigChange } from '@jbrowse/core/util';
export default function PromotableDefaultsMixin(configSchema: AnyConfigurationSchemaType): import("@jbrowse/mobx-state-tree").IModelType<{
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<AnyConfigurationSchemaType>;
    ignorePromotedDefaults: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    setIgnorePromotedDefaults(flag: boolean): void;
} & {
    displayTypeDefaultChanges(): TrackConfigChange[];
} & {
    clearDisplayTypeDefaults(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
