export declare const HEIGHT_MODE_VALUES: readonly ['inherit', 'fixed', 'grow', 'fit'];
export type HeightMode = 'fixed' | 'grow' | 'fit';
export declare const GROW_MAX_HEIGHT = 800;
export declare function getHeightModeOptions(noun: string): {
    value: HeightMode;
    label: string;
}[];
