export default function GlobalFetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{}, never>, never>, {
    userByteLimit: number | undefined;
    byteEstimate: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate | undefined;
    measuredSpanBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLargeForDerivedGate: boolean;
    readonly configForceLoad: boolean;
} & {
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly tooLargeStatus: import("../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    regionCannotBeRenderedText(): "" | "Force load to see features";
} & {
    setByteEstimate(estimate?: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate): void;
    raiseForceLoadLimits(estimate?: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate): void;
    reload(): void;
} & {
    forceLoad(): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
    lastStatusMs: number;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: import("./FetchMixin.ts").FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    reloadCounter: number;
} & {
    readonly dataLoaded: boolean;
    readonly svgReadyExtraTerminal: boolean;
} & {
    readonly svgReady: boolean;
} & {
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalFetchMixinType = ReturnType<typeof GlobalFetchMixin>;
