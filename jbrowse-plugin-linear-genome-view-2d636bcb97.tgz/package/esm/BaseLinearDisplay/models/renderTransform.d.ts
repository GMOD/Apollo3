export interface RenderTransformInputs {
    lastDrawnOffsetPx: number | undefined;
    lastDrawnBpPerPx: number | undefined;
    viewOffsetPx: number;
    viewBpPerPx: number;
}
export interface RenderTransform {
    scale: number;
    viewOffsetX: number;
}
export declare function computeRenderTransform({ lastDrawnOffsetPx, lastDrawnBpPerPx, viewOffsetPx, viewBpPerPx, }: RenderTransformInputs): RenderTransform;
export declare function viewportMatchesLastDrawn({ lastDrawnOffsetPx, lastDrawnBpPerPx, viewOffsetPx, viewBpPerPx, }: RenderTransformInputs): boolean;
export declare function computeTriangleYScalar({ fitToHeight, displayHeight, triangleWidth, }: {
    fitToHeight: boolean;
    displayHeight: number;
    triangleWidth: number;
}): number;
