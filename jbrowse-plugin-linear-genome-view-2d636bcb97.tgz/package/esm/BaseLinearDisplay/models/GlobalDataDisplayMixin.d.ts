import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
export type { FetchContext } from './FetchMixin.ts';
export { type GlobalFetchMixinType, default as GlobalFetchMixin, } from './GlobalFetchMixin.ts';
export default function GlobalDataDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<Omit<{}, never>, never>, never>, never>, {
    userByteLimit: number | undefined;
    byteEstimate: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate | undefined;
    measuredSpanBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLargeForDerivedGate: boolean;
    readonly configForceLoad: boolean;
} & {
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly tooLargeStatus: import("../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    regionCannotBeRenderedText(): "" | "Force load to see features";
} & {
    setByteEstimate(estimate?: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate): void;
    raiseForceLoadLimits(estimate?: import("@jbrowse/core/data_adapters/BaseAdapter").RegionByteEstimate): void;
    reload(): void;
} & {
    forceLoad(): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
    lastStatusMs: number;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: import("./FetchMixin.ts").FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    reloadCounter: number;
} & {
    readonly dataLoaded: boolean;
    readonly svgReadyExtraTerminal: boolean;
} & {
    readonly svgReady: boolean;
} & {
    reload(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: import("@jbrowse/render-core").RenderingBackendCallbacks<B>): void;
} & {
    readonly rendersCanvas: boolean;
} & {
    readonly displayPhase: DisplayPhase;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalDataDisplayMixinType = ReturnType<typeof GlobalDataDisplayMixin>;
interface GlobalFetchAutorunHost extends IAnyStateTreeNode {
    isMinimized: boolean;
    reloadCounter: number;
    rpcProps?: () => unknown;
}
export declare function installGlobalFetchAutorun(self: GlobalFetchAutorunHost, opts: {
    shouldFetch: () => boolean;
    fetch: () => void;
    delay: number;
    name: string;
}): void;
