import type { AnyReactComponentType } from '@jbrowse/core/util';
declare const BaseLinearDisplay: (props: {
    model: {
        configuration: {
            displayId: string;
        };
        canvasDrawn?: boolean;
        DisplayMessageComponent: AnyReactComponentType;
    };
    children?: React.ReactNode;
}) => import("react").JSX.Element;
export default BaseLinearDisplay;
export { default as Tooltip } from './Tooltip.tsx';
export { default as BlockMsg } from '../../shared/BlockMsg.tsx';
