export interface DisplayErrorBarModel {
    error: unknown;
    reload: () => void;
}
declare const DisplayErrorBar: ({ model, }: {
    model: DisplayErrorBarModel;
}) => import("react").JSX.Element | null;
export default DisplayErrorBar;
