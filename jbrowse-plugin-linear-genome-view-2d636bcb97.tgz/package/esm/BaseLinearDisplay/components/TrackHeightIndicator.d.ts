import type { HeightMode } from '../models/heightMode.ts';
export default function TrackHeightIndicator({ heightMode, hasOverflow, scrollZoom, noun, onSetHeightMode, }: {
    heightMode: HeightMode;
    hasOverflow: boolean;
    scrollZoom: boolean;
    noun: string;
    onSetHeightMode: (mode: HeightMode) => void;
}): import("react").JSX.Element;
