export interface DisplayLoadingOverlayModel {
    statusMessage?: string;
    statusProgress?: number;
    fetchCanceled?: boolean;
    cancelFetchByUser?: () => void;
    reload?: () => void;
}
declare const DisplayLoadingOverlay: ({ model, visible, immediate, }: {
    model: DisplayLoadingOverlayModel;
    visible: boolean;
    immediate?: boolean;
}) => import("react").JSX.Element;
export default DisplayLoadingOverlay;
