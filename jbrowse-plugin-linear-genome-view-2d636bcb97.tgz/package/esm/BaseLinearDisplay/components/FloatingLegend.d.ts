export interface LegendItem {
    color?: string;
    label: string;
}
export interface LegendSection {
    id: string;
    title?: string;
    items: LegendItem[];
}
declare const FloatingLegend: ({ items, sections, title, onDismiss, onDismissSection, maxItems, }: {
    items?: LegendItem[];
    sections?: LegendSection[];
    title?: string;
    onDismiss?: () => void;
    onDismissSection?: (id: string) => void;
    maxItems?: number;
}) => import("react").JSX.Element | null;
export default FloatingLegend;
