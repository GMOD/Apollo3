declare const DisplayRenderErrorOverlay: ({ error, onRetry, height, }: {
    error: unknown;
    onRetry: () => void;
    height: number;
}) => import("react").JSX.Element;
export default DisplayRenderErrorOverlay;
