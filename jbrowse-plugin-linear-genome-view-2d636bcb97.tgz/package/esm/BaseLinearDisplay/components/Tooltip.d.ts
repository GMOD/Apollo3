import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { Feature } from '@jbrowse/core/util';
type Coord = [number, number];
interface TooltipModel {
    featureUnderMouse: Feature | undefined;
    configuration: AnyConfigurationModel;
}
declare const Tooltip: ({ model, clientMouseCoord, }: {
    model: TooltipModel;
    clientMouseCoord: Coord;
}) => import("react").JSX.Element | null;
export default Tooltip;
