import Plugin from '@jbrowse/core/Plugin';
import type PluginManager from '@jbrowse/core/PluginManager';
export default class LinearGenomeViewPlugin extends Plugin {
    name: string;
    exports: {
        BaseLinearDisplayComponent: (props: {
            model: {
                configuration: {
                    displayId: string;
                };
                canvasDrawn?: boolean;
                DisplayMessageComponent: import("@jbrowse/core/util").AnyReactComponentType;
            };
            children?: React.ReactNode;
        }) => import("react").JSX.Element;
        baseLinearDisplayConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly maxFeatureScreenDensity: {
                readonly type: "number";
                readonly description: "maximum features per pixel before showing a \"too many features\" message, used if byte size estimates are not available";
                readonly defaultValue: 1;
                readonly advanced: true;
            };
            readonly fetchSizeLimit: {
                readonly type: "number";
                readonly defaultValue: 1000000;
                readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
                readonly advanced: true;
            };
            readonly forceLoad: {
                readonly type: "boolean";
                readonly defaultValue: false;
                readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
                readonly advanced: true;
            };
            readonly height: {
                readonly type: "number";
                readonly defaultValue: 100;
                readonly description: "default height for the track";
            };
            readonly mouseover: {
                readonly type: "string";
                readonly description: "text to display when the cursor hovers over a feature";
                readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
                readonly contextVariable: ["feature"];
            };
            readonly jexlFilters: {
                readonly type: "stringArray";
                readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
                readonly defaultValue: readonly ["get(feature,'gbkey')!='Src'"];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>;
        SearchBox: ({ model, showHelp, minWidth, maxWidth, style, }: {
            showHelp?: boolean;
            model: import("./index.ts").LinearGenomeViewModel;
            minWidth?: number;
            maxWidth?: number;
            style?: React.CSSProperties;
        }) => import("react").JSX.Element;
        ZoomControls: ({ model, }: {
            model: import("./index.ts").LinearGenomeViewModel;
        }) => import("react").JSX.Element;
        LinearGenomeView: ({ model, }: {
            model: import("./index.ts").LinearGenomeViewModel;
        }) => import("react").JSX.Element;
    };
    configurationSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly trackLabels: {
            readonly type: "string";
            readonly defaultValue: "offset";
            readonly model: import("@jbrowse/mobx-state-tree").ISimpleType<"hidden" | "offset" | "overlapping">;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    install(pluginManager: PluginManager): void;
    configure(pluginManager: PluginManager): void;
}
export type { ExportSvgDisplayOptions, LayoutRecord, LegendItem, LegendSection, LinearDisplayModel, } from './BaseLinearDisplay/index.ts';
export { BaseLinearDisplayComponent, BlockMsg, DisplayChrome, DisplayErrorBar, DisplayLoadingOverlay, FetchMixin, FloatingLegend, GROW_MAX_HEIGHT, GlobalDataDisplayMixin, GlobalFetchMixin, HEIGHT_MODE_VALUES, HeightModeMixin, MIN_DISPLAY_HEIGHT, MultiRegionDisplayMixin, PromotableDefaultsMixin, RegionTooLargeMixin, StaleViewportRescaleMixin, TOO_MANY_FEATURES_REASON, TooLargeMessage, TrackHeightIndicator, TrackHeightMixin, autorunOnReadyView, baseLinearDisplayConfigSchema, bytesTooLargeReason, checkByteEstimate, computeRenderTransform, computeTriangleYScalar, drawCanvasImageData, evaluateRegionTooLarge, fetchAllRegions, fetchEachRegion, getDisplayStr, getHeightModeOptions, getTrackSizingMenuItem, heightModeMenuItems, installGlobalFetchAutorun, installGrowExitBake, onDisplayedRegionsChange, raiseLimitPast, resolveByteLimit, resolveForceLoadLimits, rescaleByteEstimateToVisibleSpan, forceLoadByteLimit, viewportMatchesLastDrawn, } from './BaseLinearDisplay/index.ts';
export type { ByteEstimateConfig, FetchContext, GlobalDataDisplayMixinType, HeightMode, HeightModeMenuModel, MultiRegionDisplayMixinType, RegionTooLargeStatus, RenderTransform, RenderTransformInputs, StaleViewportRescaleMixinType, } from './BaseLinearDisplay/index.ts';
export { computeDisplayPhase } from '@jbrowse/render-core/displayPhase';
export type { DisplayPhase, DisplayPhaseInputs, } from '@jbrowse/render-core/displayPhase';
export { AUTO_FORCE_LOAD_BP, HighlightBand, HighlightChip, type LinearGenomeViewModel, type LinearGenomeViewStateModel, OverviewHighlightBand, SVGHighlightBand, SearchBox, type SyncableViewAction, installLinkedViewSync, stateModelFactory as linearGenomeViewStateModelFactory, } from './LinearGenomeView/index.ts';
export { MultiLevelRubberband, type MultiLevelRubberbandModel, } from './MultiLevelRubberband/index.ts';
export { fetchResults } from './searchUtils.ts';
export { normalizeTrackInit } from './LinearGenomeView/normalizeTrackInit.ts';
export type { LaunchLinearGenomeViewArgs } from './LaunchLinearGenomeView/index.ts';
export type { BpOffset, ExportSvgOptions, HighlightType, InitState, NavLocation, TrackInit, TrackLabelMode, VolatileGuide, } from './LinearGenomeView/types.ts';
export { SVGGridlines, SVGRuler, SVGTracks, SVGView, renderToSvg, } from './LinearGenomeView/svgcomponents/SVGLinearGenomeView.tsx';
export { default as SVGHighlights } from './LinearGenomeView/svgcomponents/SVGHighlights.tsx';
export { default as SVGHighlightsOverlay } from './LinearGenomeView/svgcomponents/SVGHighlightsOverlay.tsx';
export { default as ExportSvgDialog } from './LinearGenomeView/components/ExportSvgDialog.tsx';
export { GetSequenceDialog } from './LinearGenomeView/lazyDialogs.ts';
export { default as ConnectedHoverHighlight } from './LinearGenomeView/components/ConnectedHoverHighlight.tsx';
export { default as HoverPositionHighlight } from './LinearGenomeView/components/HoverPositionHighlight.tsx';
export { TrackOverlayContext } from './LinearGenomeView/TrackOverlayContext.ts';
export { TrackOverlayPortal } from './LinearGenomeView/TrackOverlayPortal.tsx';
export { FloatingSvgOverlay } from './LinearGenomeView/FloatingSvgOverlay.tsx';
export type { HoverHighlightPosition } from './LinearGenomeView/components/HoverPositionHighlight.tsx';
export { SVGErrorBox, SvgChrome, SvgClipRect, } from '@jbrowse/core/svg/SvgExport';
export { awaitSvgReady } from '@jbrowse/core/svg/svgReady';
export type { SvgExportable } from '@jbrowse/core/svg/svgReady';
export { labelOffset, totalHeight, trackBoxHeight, trackLabelLeftOffset, } from './LinearGenomeView/svgcomponents/util.ts';
export type { SvgDisplayResult } from './LinearGenomeView/svgcomponents/util.ts';
