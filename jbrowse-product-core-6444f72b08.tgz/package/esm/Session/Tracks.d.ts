import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfiguration, AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel TracksManagerSessionMixin
 */
export declare function TracksManagerSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    focusedViewId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    highlightsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    heldForMissingPlugins: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<import("../pruneUnbuildableNodes.ts").HeldNode[] | undefined, import("../pruneUnbuildableNodes.ts").HeldNode[] | undefined, import("../pruneUnbuildableNodes.ts").HeldNode[] | undefined>, [undefined]>;
}, never>, never>, {
    selection: unknown;
    hovered: unknown;
    queueOfDialogs: [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>][];
    preferencesOverrides: import("mobx").ObservableMap<string, unknown>;
} & {
    readonly root: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        jbrowse: import("@jbrowse/mobx-state-tree").IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            unrecognizedReports: {
                report(session: unknown, name: string, handlerCount: number, fire: () => unknown): void;
                reportFor(session: unknown, name: string): {
                    handled: boolean;
                    claim?: Promise<void>;
                } | undefined;
            };
        } & {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            loadingAssembly(asmNames: string[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            readonly assemblyNamesList: string[];
            readonly configuredAssemblyNames: Set<string>;
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            settleAssemblyResolution(assemblyName: string): Promise<void>;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            requireAssembly(assemblyName: string): Promise<import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }> & {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<import("@jbrowse/mobx-state-tree").IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        jbrowse: import("@jbrowse/mobx-state-tree").IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            unrecognizedReports: {
                report(session: unknown, name: string, handlerCount: number, fire: () => unknown): void;
                reportFor(session: unknown, name: string): {
                    handled: boolean;
                    claim?: Promise<void>;
                } | undefined;
            };
        } & {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            loadingAssembly(asmNames: string[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            readonly assemblyNamesList: string[];
            readonly configuredAssemblyNames: Set<string>;
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            settleAssemblyResolution(assemblyName: string): Promise<void>;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            requireAssembly(assemblyName: string): Promise<import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
                statusSource: string | undefined;
                refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
                setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getAliasesForRefName(refName: string): string[];
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
                getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }, {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<import("@jbrowse/mobx-state-tree").IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
} & {
    readonly jbrowse: any;
    readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    readonly configuration: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>;
    readonly adminMode: boolean;
    readonly textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
} & {
    readonly assemblies: import("@jbrowse/core/assemblyManager").BaseAssemblyConfigModel[];
    readonly DialogComponent: import("@jbrowse/core/util").DialogComponentType | undefined;
    readonly DialogProps: Record<string, unknown> | undefined;
} & {
    getPreferenceDefault(key: string): unknown;
    getPreference(key: string): unknown;
    getDisplayTypeDefault(displayType: string, slot: string): unknown;
    getDisplayTypeDefaults(): {
        displayType: string;
        slot: string;
        value: unknown;
    }[];
    getPreferenceChanges(): import("@jbrowse/core/util").TrackConfigChange[];
} & {
    readonly animationMode: import("@jbrowse/core/util").AnimationMode;
    readonly scrollZoom: boolean;
    readonly numberGrouping: boolean;
} & {
    afterAttach(): void;
    setSelection(thing: unknown): void;
    clearSelection(): void;
    setHovered(thing: unknown): void;
    setHighlightsVisible(arg: boolean): void;
    revealHighlights(): void;
    setPreferenceOverride(key: string, value: unknown): void;
    clearPreferenceOverrides(): void;
    clearPreferenceOverride(key: string): void;
    resetPreferenceChange(path: string[]): void;
    setScrollZoom(flag: boolean): void;
    setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
    setName(str: string): void;
    setFocusedViewId(viewId: string | undefined): void;
    removeActiveDialog(): void;
    queueDialog(doneCallback: (doneCallback: () => void) => [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>]): void;
} & {
    snackbarMessages: import("mobx").IObservableArray<import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
    errorDialog: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined;
} & {
    readonly snackbarMessageSet: Map<string, import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
} & {
    notify(message: string, level?: import("@jbrowse/core/util").NotificationLevel, action?: import("@jbrowse/core/util").SnackAction | import("@jbrowse/core/util").SnackAction[]): void;
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: import("@jbrowse/core/util").SnackAction): void;
    setErrorDialog(state: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined): void;
    pushSnackbarMessage(message: string, level?: import("@jbrowse/core/util").NotificationLevel, actions?: import("@jbrowse/core/util").SnackAction[]): void;
    popSnackbarMessage(): import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage | undefined;
    removeSnackbarMessage(message: string): void;
} & {
    getReferringMultiple(trackIds: string[]): Map<string, import("./ReferenceManagement.ts").ReferringNode[]>;
} & {
    getReferring(trackId: string): import("./ReferenceManagement.ts").ReferringNode[];
} & {
    dereferenceTrack(trackId: string, referring: import("./ReferenceManagement.ts").ReferringNode[]): void;
} & {
    /**
     * #getter
     */
    readonly tracks: AnyConfigurationModel[];
} & {
    /**
     * #method
     * Config for one trackId — a track, assembly sequence, or connection
     * track — or undefined. Per-id reactive: every display resolves its
     * config through this (via TrackConfigurationReference) and subscribes
     * only to its own id, so one track's settings edit doesn't re-render the
     * others.
     */
    getTrackById(id: string): AnyConfigurationModel | undefined;
    /**
     * #method
     * Every track config the session can resolve, keyed by trackId. Prefer
     * the per-id reactive `getTrackById(id)`: reading this whole map
     * subscribes the caller to *every* track, so an edit to any one of them
     * wakes it — the reason internal display config resolution moved off
     * it. Kept for plugins that look up ids in a non-reactive context.
     *
     * @deprecated
     */
    getTracksById(): Record<string, AnyConfigurationModel>;
} & {
    /**
     * #action
     * Add a track config to *this session*.
     *
     * This mixin's session has no separate session-track store, so the
     * destination is the jbrowse config — which in the products that compose
     * it (desktop) is the single user's own file rather than something a
     * server hands other visitors, so the two scopes are the same place.
     * Defined here anyway so that every session has it: a feature standing a
     * track up on the user's behalf can then call one action everywhere
     * instead of asking which mixin it landed on.
     * `SessionTracksManagerSessionMixin` overrides it with the real
     * session-scoped store.
     */
    addSessionTrackConf(trackConf: AnyConfiguration): any;
    /**
     * #action
     * Add a track config wherever *this user's* catalog edits belong — the
     * "Add track" workflows, where an admin adding a track means to add it
     * for the whole site. `SessionTracksManagerSessionMixin` overrides it to
     * send a non-admin's to the session instead; here there is only the one
     * destination.
     *
     * Anything that is not an Add-track workflow wants
     * `addSessionTrackConf`: a track a feature stands up on the user's behalf
     * — a search result, a computed consensus, a reconstruction's labels — is
     * not a catalog entry, and publishing one writes it into the config.json
     * every visitor is served, once per click.
     */
    publishTrackConf(trackConf: AnyConfiguration): any;
    /**
     * #action
     * Deprecated alias of `addSessionTrackConf`. Call that, or
     * `publishTrackConf`, which say which destination they mean.
     *
     * @deprecated
     *
     * Kept because a prebuilt plugin bundle reaches this by name at runtime
     * and cannot be recompiled — `jbrowse-plugin-protein3d` calls it, and a
     * member lookup that stops resolving throws nothing at all
     * (`pluginFacingSessionApi.test.ts` is the guard). It now means the
     * session, which is the destination every such caller wanted: a track a
     * plugin stands up for one user is not a catalog entry. Nothing in tree
     * may call it — `no-restricted-syntax` says so.
     *
     * Spelled out rather than delegating through `this`, for the reason
     * `SessionTracks.addToSession` is a plain closure: an action whose return
     * type is inferred from a sibling's makes the pair circular.
     */
    addTrackConf(trackConf: AnyConfiguration): any;
    /**
     * #action
     * Persist edited track config back to the in-memory jbrowse config. The
     * session-tracks mixin overrides this so a non-admin's edits become a
     * shareable session-track override instead.
     */
    updateTrackConfiguration(trackConf: {
        trackId: string;
        [key: string]: unknown;
    }): void;
    /**
     * #action
     */
    deleteTrackConf(trackConf: AnyConfigurationModel): any;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
/** Session mixin MST type for a session that has tracks */
export type SessionWithTracksType = ReturnType<typeof TracksManagerSessionMixin>;
/** Instance of a session that has tracks */
export type SessionWithTracks = Instance<SessionWithTracksType>;
/** Type guard for SessionWithTracks */
export declare function isSessionWithTracks(thing: IAnyStateTreeNode): thing is SessionWithTracks;
