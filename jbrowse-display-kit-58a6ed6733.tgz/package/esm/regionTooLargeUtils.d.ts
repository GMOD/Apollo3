/**
 * The span below which the density axis stops gating and the byte budget is
 * multiplied by {@link SUB_FLOOR_BYTE_BUDGET_FACTOR}. Compared only in
 * `aboveForceLoadFloor`.
 */
export declare const AUTO_FORCE_LOAD_BP = 20000;
/**
 * The byte budget's multiplier below {@link AUTO_FORCE_LOAD_BP}: what one index
 * bin costs on the deepest file in the repo. A policy dial —
 * agent-docs/reference/REGION_TOO_LARGE.md § "The sub-floor budget tier".
 */
export declare const SUB_FLOOR_BYTE_BUDGET_FACTOR = 2;
/** One measurement of what a fetch would cost, at the viewport it describes. */
export interface ByteEstimate {
    /** Never undefined: an unmeasurable fetch leaves the whole estimate unset. */
    bytes: number;
    /** The visible span at measurement, kept only to compare two measurements. */
    measuredSpanBp: number;
    /**
     * A materially smaller span came back materially unchanged, so "zoom in to
     * see features" cannot work for this file. Evidence, never predicted.
     */
    zoomIneffective: boolean;
}
/** What a measurement is about, captured before it is requested. */
export interface GateViewport {
    spanBp: number;
    key: string;
}
/** The gate as it stood when a fetch was issued; its result is judged by this. */
export interface GateFetchState {
    viewport: GateViewport | undefined;
    gated: boolean;
    /** `byteGateAdapterKey` at issue; undefined when the display never gates. */
    tierKey: string | undefined;
}
/** Everything a sequence of gate events moves. */
export interface GateState {
    byteEstimate: ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
    forceLoadTrack: boolean;
}
export type GateEvent = {
    kind: 'measurement';
    issued: GateFetchState;
    currentTierKey: string | undefined;
    /** absent when the fetch measured no bytes */
    bytes?: number;
} | {
    kind: 'invalidated';
} | {
    kind: 'forceLoad';
    approved: boolean;
}
/** changes nothing, so a walk over events can assert that it doesn't */
 | {
    kind: 'viewportMoved';
};
/**
 * The commit protocol, pure so `nextGateState.test.ts` can walk event
 * sequences: a measurement is judged by the tier it was issued against, a
 * fetch the gate sat out stamps no viewport, an absent `bytes` leaves the last
 * estimate alone, and an approval outlives an invalidation. Returns `prev`
 * itself when nothing moved.
 */
export declare function nextGateState(prev: GateState, event: GateEvent): GateState;
/**
 * Fold a fresh measurement into the stored one. `zoomIneffective` needs two
 * points: a span at most half the previous one whose bytes are still over 90%
 * of it. A zero baseline of span or bytes starts over.
 */
export declare function nextByteEstimate(previous: ByteEstimate | undefined, measurement: {
    bytes: number;
    viewport: GateViewport;
}): ByteEstimate;
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
/**
 * The gate's byte budget: the adapter's declared limit (a non-positive one
 * means no opinion), else the display's, times
 * {@link SUB_FLOOR_BYTE_BUDGET_FACTOR} below the floor. Force-load is not a
 * tier here; it bypasses the comparison.
 */
export declare function resolveByteLimit({ adapterFetchSizeLimit, configFetchSizeLimit, belowForceLoadFloor, }: {
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number;
    belowForceLoadFloor: boolean;
}): number;
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
    /** Which axis tripped; `zoomCanReleaseGate` branches on it. */
    axis?: 'bytes' | 'density';
}
/**
 * The comparison half of the verdict: bytes against the budget, then density.
 * Whether an axis may act is the caller's question — it passes `undefined` /
 * `false` for an axis that is off.
 */
export declare function evaluateRegionTooLarge({ estimatedFetchBytes, byteLimit, densityTooLarge, }: {
    estimatedFetchBytes?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
}): RegionTooLargeStatus;
