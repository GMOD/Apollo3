import type { RegionTooLargeConfigModel } from './regionTooLargeConfigSchemaFields.ts';
import type { ByteEstimate, GateFetchState, GateViewport } from './regionTooLargeUtils.ts';
/** The whole of what `RegionTooLargeMixin` needs a composing display to be. */
export interface RegionTooLargeHost {
    configuration: RegionTooLargeConfigModel;
}
/**
 * The region-too-large gate: a display opts in by overriding `gateEnabled` and
 * passing `byteLimit: self.resolvedByteLimit()` to its fetch RPC. The RPC
 * measures the index before it downloads and answers a refusal when a region
 * is over budget; the fetch runners commit what it measured, and
 * `regionTooLarge` is derived from that last measurement. While the banner is
 * up the fetch runs once per settled viewport, which is the re-measure.
 * Composed by `MultiRegionDisplayMixin` and `GlobalFetchMixin`. The rules and
 * the numbers behind them: agent-docs/reference/REGION_TOO_LARGE.md.
 *
 * #stateModel RegionTooLargeMixin
 * #category display
 */
export default function RegionTooLargeMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     * The force-load button's track-wide approval. Volatile so it never
     * reaches a saved session; the `forceLoad` config slot is the durable form.
     */
    forceLoadTrack: boolean;
    /**
     * #volatile
     * The last byte measurement: bytes, the span they were taken at, and
     * whether zooming has been shown not to shrink them. Survives
     * `clearAllRpcData`; dropped on chromosome navigation and on a tier swap.
     */
    byteEstimate: ByteEstimate | undefined;
    /**
     * #volatile
     * The viewport key the gate last asked the adapter about, on either axis.
     * Separate from `byteEstimate` because a density refusal measures no bytes.
     */
    gateMeasuredViewportKey: string | undefined;
} & {
    /**
     * #getter
     * The opt-in. Overridden with a literal `true` by gated displays, and
     * `check-gated-adapter-budgets` insists on a literal: this mixin returns
     * early on it in an autorun and in `commitFetchBytes`.
     */
    readonly gateEnabled: boolean;
    /**
     * #getter
     * Whether the density axis applies. `CanvasFeatureGateMixin` contributes
     * `true` beside its measurement; byte-only displays leave it.
     */
    readonly densityGateEnabled: boolean;
    /**
     * #getter
     * The adapter config the gate measures — the one at `byteGateAdapterPath`.
     * Overridable for a display whose adapter config is synthesized rather
     * than read off the track.
     */
    readonly byteGateAdapterConfig: Record<string, unknown>;
    /**
     * #getter
     * The display's `fetchSizeLimit` slot, from `regionTooLargeConfigSchemaFields`.
     */
    readonly configuredFetchSizeLimit: number;
    /**
     * #getter
     * The density axis's verdict; canvas overrides it.
     */
    readonly densityTooLarge: boolean;
    /**
     * #getter
     * Where on the track config the measured adapter sits. A tiered display
     * overrides this one hook (MAF: `['adapter', 'summaryAdapter']` while
     * `showSummary`), and both the measurement and the budget follow it.
     */
    readonly byteGateAdapterPath: string[];
    /**
     * #getter
     * The measured adapter's own `fetchSizeLimit` slot, read off the live
     * track config rather than the `adapterConfig` snapshot, which omits
     * slots at their default.
     */
    readonly adapterFetchSizeLimit: number | undefined;
    /**
     * #getter
     * The declarative `forceLoad` slot.
     */
    readonly configForceLoad: boolean;
    /**
     * #getter
     * What a measurement taken now would be about: the span on screen and a
     * key for the stretch of genome it covers. Undefined until the view is
     * measured, and the mixin's only read of the view. Captured before the
     * fetch's round trip, never at commit.
     */
    readonly gateViewport: GateViewport | undefined;
} & {
    /**
     * #getter
     * Which tier the estimate is about, as a comparable string.
     */
    readonly byteGateAdapterKey: string;
    /**
     * #getter
     * Whether the span on screen is at or above `AUTO_FORCE_LOAD_BP`, the one
     * comparison against that constant. False on an unmeasured view.
     */
    readonly aboveForceLoadFloor: boolean;
    /**
     * #getter
     * Nothing may gate on either axis: the `forceLoad` slot or the button.
     */
    readonly gateExempt: boolean;
    /**
     * #getter
     * The stored estimate's bytes; undefined when nothing has been measured.
     */
    readonly estimatedFetchBytes: number | undefined;
    /**
     * #getter
     * Whether the last measurement is about a viewport the user has since
     * left. True before any measurement.
     */
    readonly gateMeasurementStale: boolean;
} & {
    /**
     * #getter
     * The byte budget: the adapter's limit, else the display's, doubled below
     * `AUTO_FORCE_LOAD_BP`. Read only through `resolvedByteLimit()`.
     */
    readonly gateByteLimit: number;
    /**
     * #getter
     * Whether the gate may act right now, on any axis: opted in, not exempt,
     * view measured. The view is read last, so an ungated display never
     * touches it.
     */
    readonly gateActive: boolean;
} & {
    /**
     * #getter
     * `gateActive` plus the density axis's own terms: the axis is on, and the
     * span is above the floor.
     */
    readonly densityGateActive: boolean;
    /**
     * #method
     * The budget the worker enforces and the banner compares against — the
     * one spelling of that pair. Undefined when the gate may not act.
     */
    resolvedByteLimit(): number | undefined;
    /**
     * #method
     * The gate as it stands for a fetch about to be issued. Calling it is the
     * capture, which is why it is a method.
     */
    gateFetchState(): GateFetchState;
} & {
    /**
     * #getter
     * The verdict and its banner text, from the stored estimate against
     * `resolvedByteLimit()` and the density axis when it may act.
     */
    readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
} & {
    /**
     * #getter
     */
    readonly regionTooLarge: boolean;
    /**
     * #getter
     * Banner text for the axis that tripped; empty when not too large.
     */
    readonly regionTooLargeReason: string;
    /**
     * #getter
     * Whether "zoom in to see features" is honest advice. Density always
     * releases on zoom; bytes only if the last zoom-in moved the estimate.
     */
    readonly zoomCanReleaseGate: boolean;
} & {
    /**
     * #getter
     * The skip both fetch skeletons apply: the banner is up and its
     * measurement already describes the viewport on screen.
     */
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    /**
     * #action
     * The bytes half of a measurement alone, for a test staging a display.
     * Production commits through `commitFetchBytes`.
     */
    setByteEstimate(measurement: {
        bytes: number;
        viewport: GateViewport;
    }): void;
    /**
     * #action
     * Drops the estimate and the viewport stamp. `forceLoadTrack` survives:
     * it is a track-wide approval.
     */
    clearByteEstimate(): void;
    /**
     * #action
     */
    setForceLoadTrack(flag: boolean): void;
    /**
     * #action
     * Overridden by the composing display.
     */
    reload(): void;
} & {
    /**
     * #action
     * The byte axis of a finished fetch, called by the fetch runners with the
     * `gateFetchState()` they captured at issue. Commits the per-region max;
     * an empty batch, or an ungated display, commits nothing.
     */
    commitFetchBytes(perRegionBytes: (number | undefined)[], issued: GateFetchState): void;
} & {
    /**
     * #action
     * The banner's button: exempt the track on both axes and refetch.
     */
    forceLoad(): void;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
