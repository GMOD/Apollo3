import type { RegionHost } from './regionHost.ts';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
/**
 * The one spelling of "which block set is this" every global display's
 * `viewSignature` builds on. Block keys encode `assembly:refName:start:end` (and
 * orientation), so the joined string moves exactly when the display would
 * refetch — a block entering, a zoom re-snap — and not on a scroll inside the
 * loaded blocks.
 */
export declare function blockKeySignature(blocks: {
    key: string;
}[]): string;
/**
 * **The** foundation for a display holding a single global (non-regional)
 * dataset — HiC's contact matrix, the LD triangle, both arc displays. One
 * foundation rather than the two this family carried until 2026-08-23:
 * `GlobalDataDisplayMixin` existed only to layer `RenderLifecycleMixin` on top
 * for the GPU composers, because arc paints main-thread SVG `<path>`s and
 * declined it — so the fetch foundation was split in two, and the three getters
 * on the upper half (`canRender`, `paintInert`, `displayPhase`) were reachable
 * only by whichever displays composed it. A display that composes this now gets
 * the whole answer, and arc pays five unused volatiles and two autoruns it
 * never installs (`attachRenderingBackend` is what installs them, and arc never
 * calls it) for the same table row as everyone else.
 *
 * Composes:
 *   - RegionTooLargeMixin (regionTooLarge, force-load, …)
 *   - RenderLifecycleMixin (attachRenderingBackend, renderNow, renderError, …)
 *   - FetchMixin (runFetch, cancelFetch, isLoading, error, statusMessage,
 *                 fetchGeneration)
 *
 * Installs no autoruns — each display owns its fetch trigger, sharing the
 * `installGlobalFetchAutorun` skeleton, to which it supplies only its own
 * `prepare` / `run` / `commit` phases.
 *
 * #stateModel GlobalFetchMixin
 * #displayFoundationDef One non-regional dataset with no per-region partitioning, plus the render lifecycle. Installs no fetch autoruns; the display adds its own via `installGlobalFetchAutorun`.
 * #category display
 */
export default function GlobalFetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{}, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("./regionTooLargeUtils.ts").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly byteGateAdapterPath: string[];
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("./regionTooLargeUtils.ts").GateViewport | undefined;
} & {
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
    gateFetchState(): import("./regionTooLargeUtils.ts").GateFetchState;
} & {
    readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number;
        viewport: import("./regionTooLargeUtils.ts").GateViewport;
    }): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("./regionTooLargeUtils.ts").GateFetchState): void;
} & {
    forceLoad(): void;
} & {
    afterAttach(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
    readonly rendersCanvas: boolean;
    readonly paintInert: boolean;
} & {
    readonly painted: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    reloadCounter: number;
    statusWindow: import("@jbrowse/core/util").StatusWindow;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
} & {
    fetchRotation: {
        begin(): import("@jbrowse/core/util").ActiveFetch;
        cancel: () => void;
        dispose(): void;
    };
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly fetchInert: boolean;
    readonly awaitingPrerequisite: boolean;
    readonly rpcPropsCacheKey: string;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
} & {
    stopActiveFetch(): void;
    openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
} & {
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    endFetch(current: boolean, stopToken: import("@jbrowse/core/util").StopToken): void;
} & {
    runFetch: (work: (ctx: import("@jbrowse/core/util/fetchContext").FetchContext) => Promise<void>) => Promise<void>;
} & {
    /**
     * #volatile
     * `fetchSignature` as it stood when the held data was committed — the
     * loaded half of this family's freshness compare. Written only by
     * `commitFetchResult` and cleared only by `reload`, so a display cannot
     * stamp data it did not fetch or forget to invalidate on retry; the data
     * itself stays display-owned (arc keeps stale arcs on screen under the
     * loading overlay, HiC keeps the stale matrix).
     */
    loadedFetchSignature: string | undefined;
} & {
    /**
     * #getter
     * The hosting view as the `RegionHost` contract — see `containingHost` for the cast it
     * owns, why the name is `host` and not `view`, and why both foundations
     * still declare the name over one body.
     */
    readonly host: RegionHost;
    /**
     * #getter
     * Overridable hook, the one freshness input a global display supplies:
     * the signature of what the current *view* calls for — its block set
     * (`blockKeySignature`) plus any view-derived fetch tier, like HiC's
     * binsize. `undefined` means "not computable yet" (view unmeasured, a
     * prerequisite header still in flight) and holds the fetch off.
     *
     * Settings are deliberately not the display's half: `fetchSignature`
     * below appends `rpcPropsCacheKey`, so a field added to `rpcProps()`
     * invalidates held data structurally. HiC hand-folded one settings term
     * in and would have silently missed the second.
     *
     * Default `undefined`, so a display that forgets the override never
     * fetches and never exports — hung is diagnosable, stale ships wrong
     * pixels.
     */
    readonly viewSignature: string | undefined;
} & {
    /**
     * #getter
     * No content block is on screen, so this display has nothing to fetch and
     * nothing to paint — see `viewportEmpty.ts` for the one viewport that
     * reaches it, how narrow that is, and why the state still has to be
     * terminal rather than a permanent scrim. Both foundations declare it over
     * that one expression, the same way they each declare `host` and
     * `paintInert`.
     */
    readonly viewportEmpty: boolean;
    /**
     * #getter
     * Overrides `RenderLifecycleMixin`'s default-true hook with the LGV
     * precondition both foundations share — see `foundationCanRender`.
     */
    readonly canRender: boolean;
    /**
     * #getter
     * Signature of the fetch the current view and settings call for — the
     * display's `viewSignature` plus the serialized `rpcProps()` axis. What
     * `runGlobalFetch` gates on, captures at issue, and stamps at commit.
     */
    readonly fetchSignature: string | undefined;
} & {
    /**
     * #getter
     * The shared freshness answer, now derived rather than a hook: data has
     * been committed (`loadedFetchSignature` is only ever written beside it)
     * and it was fetched for the current view and settings. A pan inside the
     * loaded blocks stays current; a block entering, a tier step, a settings
     * change or a `reload()` moves one side of the compare and refetches.
     */
    readonly dataCurrent: boolean;
} & {
    /**
     * #getter
     * Fills `RenderLifecycleMixin`'s `paintInert` hook — see there for why a
     * failed fetch has to read as finished to the consumers outside the
     * display, and `foundationPaintInert` for the second such state and why
     * both fetch families answer it through one function. Overridable, as the
     * hook is: a display with a third inert state of its own says so here.
     */
    readonly paintInert: boolean;
    /**
     * #getter
     * Policy single-sourced in `computeSvgReady`; this family supplies only
     * the freshness half, which `foundationSvgReady` reads as `dataCurrent`
     * or the vacuous currency of `viewportEmpty`. Note it requires the dataset
     * to actually be current, NOT merely "not currently fetching": the fetch
     * trigger is a debounced `afterAttach` autorun, so at export time
     * `isLoading` can still be false with no data yet — a
     * `displayPhase !== 'loading'` test would then capture an empty render.
     * Never gates on `canvasDrawn`, which an off-screen export never sets.
     * Off-screen renderers gate on it via `awaitSvgReady(model)`.
     */
    readonly svgReady: boolean;
    /**
     * #getter
     * The display's mutually-exclusive visual state, mapped in
     * `foundationDisplayPhase` — every foundation calls it and supplies only
     * its staleness argument, so a term added to `computeLoadingTerm` reaches
     * all of them without being wired twice.
     *
     * This family's argument is the constant `true`, deliberately: a global
     * display keeps the last frame up through a refetch (worker output is
     * genomic, so the stale frame draws correctly under the live view
     * transform), so a pan or zoom shows no scrim beyond the `isLoading`
     * window. The pre-first-paint scrim it *does* want — the gap between mount
     * and `isLoading` going true, which on HiC is the `CoreGetInfo` round trip
     * its first fetch waits on — is `computeLoadingTerm`'s shared
     * `rendersCanvas && !canvasDrawn` term, not anything this family spells
     * out.
     *
     * A display with no rendering backend narrows this to the backend-free
     * `DisplayStatusPhase` with `foundationDisplayStatusPhase`, which is what
     * arc does: it cannot reach `renderError`, and the narrower type is what
     * lets `DisplayStatusChrome` take it with neither a cast nor a dead
     * branch.
     */
    readonly displayPhase: DisplayPhase;
} & {
    /**
     * #action
     * The commit half of `runGlobalFetch`: run the display's own store in the
     * same transaction as the signature stamp, so no observer can see fresh
     * data under a stale signature or the reverse. Being the only writer of
     * `loadedFetchSignature` is what makes `dataCurrent` derivable — a
     * display cannot commit without stamping.
     */
    commitFetchResult(commit: () => void, signature: string): void;
    /**
     * #action
     * Satisfies the `reload` contract `DisplayChrome` (and the arc SVG chrome)
     * require of every display. Clears any error, drops the loaded signature
     * so `dataCurrent` goes false — `runGlobalFetch` gates on it, so a
     * counter bump alone would re-run the autorun into a decline (the dead
     * Retry button arc and HiC each fixed with their own override) — and
     * bumps `reloadCounter` so the fetch autorun re-runs. The data itself
     * survives, staying on screen under the loading overlay. A subclass whose
     * reload needs extra teardown can override and chain.
     */
    reload(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalFetchMixinType = ReturnType<typeof GlobalFetchMixin>;
