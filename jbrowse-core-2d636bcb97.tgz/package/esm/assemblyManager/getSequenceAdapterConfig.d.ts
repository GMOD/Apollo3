import type { Assembly } from './assembly.ts';
export declare function getSequenceAdapterConfig(assembly?: Pick<Assembly, 'configuration'>): Record<string, unknown> | undefined;
