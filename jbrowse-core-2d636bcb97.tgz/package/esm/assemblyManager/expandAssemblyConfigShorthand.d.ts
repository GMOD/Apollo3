import type PluginManager from '../PluginManager.ts';
export declare function expandAssemblySequenceAdapter(sequence: unknown, pluginManager: PluginManager): unknown;
