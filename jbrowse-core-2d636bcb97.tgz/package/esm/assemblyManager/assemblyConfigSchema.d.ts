import type PluginManager from '../PluginManager.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
export { expandAssemblySequenceAdapter } from './expandAssemblyConfigShorthand.ts';
declare function assemblyConfigSchema(pluginManager: PluginManager): import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    readonly aliases: {
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
        readonly description: "Other possible names for the assembly";
    };
    readonly sequence: import("../configuration/types.ts").AnyConfigurationSchemaType;
    readonly refNameColors: {
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
        readonly description: "Define custom colors for each reference sequence. Will cycle through this list if there are not enough colors for every sequence.";
    };
    readonly geneticCodes: {
        readonly type: "frozen";
        readonly defaultValue: {};
        readonly description: "Map of reference sequence name to NCBI genetic-code (translation table) id for sequences not using the standard code, e.g. { \"chrM\": 2 }";
    };
    readonly geneticCodesLocation: {
        readonly type: "fileLocation";
        readonly defaultValue: {
            readonly uri: "";
            readonly locationType: "UriLocation";
        };
        readonly description: "Optional TSV file of refName<TAB>geneticCodeId, an alternative to inlining the geneticCodes map";
    };
    readonly refNameAliases: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly cytobands: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly adapter: import("@jbrowse/mobx-state-tree").IAnyModelType;
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    readonly displayName: {
        readonly type: "string";
        readonly defaultValue: "";
        readonly description: "A human readable display name for the assembly e.g. \"Homo sapiens (hg38)\" while the assembly name may just be \"hg38\"";
    };
}, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "name">>;
export default assemblyConfigSchema;
export type BaseAssemblyConfigSchema = ReturnType<typeof assemblyConfigSchema>;
export type BaseAssemblyConfigModel = Instance<BaseAssemblyConfigSchema>;
