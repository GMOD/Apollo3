import type PluginManager from '../PluginManager.ts';
import type { FileLocation } from '../util/types/index.ts';
import type { RefNameAliases } from './refNameMaps.ts';
export declare function lookupGeneticCodeId(refName: string, refNameAliases: RefNameAliases | undefined, maps: Record<string, number>[]): number;
export declare function getGeneticCodesFromFile({ location, pluginManager, }: {
    location: FileLocation | undefined;
    pluginManager: PluginManager;
}): Promise<Record<string, number>>;
