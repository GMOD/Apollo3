import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
interface AdapterArgs {
    config: AnyConfigurationModel;
    pluginManager: PluginManager;
}
export declare function getRefNameAliases({ config, pluginManager, }: AdapterArgs): Promise<import("../data_adapters/BaseAdapter/BaseRefNameAliasAdapter.ts").Alias[]>;
export declare function getCytobands({ config, pluginManager }: AdapterArgs): Promise<import("../util/simpleFeature.ts").Feature[]>;
export declare function getAssemblyRegions({ config, pluginManager, }: AdapterArgs): Promise<import("../util/index.ts").NoAssemblyRegion[]>;
export {};
