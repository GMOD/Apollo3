import QuickLRU from '../util/QuickLRU/index.ts';
import type PluginManager from '../PluginManager.ts';
import type { BaseOptions } from '../data_adapters/BaseAdapter/index.ts';
import type RpcManager from '../rpc/RpcManager.ts';
import type { Feature, Region } from '../util/index.ts';
import type { RefNameAliases, RefNameMaps } from './refNameMaps.ts';
import type { IAnyType, Instance } from '@jbrowse/mobx-state-tree';
export { getSequenceAdapterConfig } from './getSequenceAdapterConfig.ts';
export { buildRefNameMaps } from './refNameMaps.ts';
export { lookupGeneticCodeId } from './geneticCodes.ts';
export type { RefNameAliases, RefNameMaps } from './refNameMaps.ts';
type AdapterConf = Record<string, unknown>;
export interface BasicRegion {
    start: number;
    end: number;
    refName: string;
    assemblyName: string;
}
export default function assemblyFactory(assemblyConfigType: IAnyType, pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
}, {
    error: unknown;
    loadingP: Promise<void> | undefined;
    adapterLoads: QuickLRU<string, Promise<RefNameAliases>>;
    volatileRegions: BasicRegion[] | undefined;
    refNameAliases: RefNameAliases | undefined;
    canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
    cytobands: Feature[] | undefined;
    loadedGeneticCodes: Record<string, number> | undefined;
    lowerCaseRefNameAliases: RefNameAliases | undefined;
} & {
    getConf(arg: string): any;
} & {
    readonly name: string;
    readonly aliases: string[];
    readonly displayName: string;
    readonly refNameColors: string[];
} & {
    readonly allAliases: string[];
    hasName(name: string): boolean;
} & {
    setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: RefNameMaps & {
        regions: Region[];
        cytobands: Feature[];
        geneticCodes: Record<string, number>;
    }): void;
    setError(e: unknown): void;
    setLoadingP(p?: Promise<void>): void;
    loadPre(): Promise<void>;
} & {
    load(): Promise<void>;
} & {
    afterAttach(): void;
} & {
    readonly initialized: boolean;
    readonly regions: BasicRegion[] | undefined;
    readonly allRefNames: string[] | undefined;
    readonly rpcManager: RpcManager;
} & {
    readonly refNames: string[] | undefined;
} & {
    readonly refNameToIndex: Map<string, number> | undefined;
} & {
    getCanonicalRefName(refName: string): string | undefined;
    getRefNameColor(refName: string): string | undefined;
    getGeneticCodeId(refName: string): number;
    getSeqAdapterRefName(canonicalRefName: string): string;
} & {
    getCanonicalRefName2(refName: string): string;
    isValidRefName(refName: string): boolean;
} & {
    getRefNameMapForAdapter(adapterConf: AdapterConf, options: BaseOptions): Promise<RefNameAliases>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type AssemblyModel = ReturnType<typeof assemblyFactory>;
export type Assembly = Instance<AssemblyModel>;
