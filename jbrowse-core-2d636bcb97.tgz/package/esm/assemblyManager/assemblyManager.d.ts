import type PluginManager from '../PluginManager.ts';
import type RpcManager from '../rpc/RpcManager.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { StopToken } from '../util/stopToken.ts';
import type { Assembly } from './assembly.ts';
import type { IAnyType } from '@jbrowse/mobx-state-tree';
type AdapterConf = Record<string, unknown>;
export interface AssemblyBaseOpts {
    stopToken?: StopToken;
    sessionId: string;
    statusCallback?: StatusCallback;
}
declare function assemblyManagerFactory(conf: IAnyType, pm: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
}, {
    readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
} & {
    getCanonicalAssemblyName(asmName: string): string | undefined;
    getDisplayName(asmName: string): string;
    get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    readonly assemblyNamesList: string[];
    readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>)[];
    readonly rpcManager: RpcManager;
} & {
    waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("./refNameMaps.ts").RefNameAliases>>;
        volatileRegions: import("./assembly.ts").BasicRegion[] | undefined;
        refNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("../util/simpleFeature.ts").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("./refNameMaps.ts").RefNameAliases | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("./refNameMaps.ts").RefNameMaps & {
            regions: import("../util/index.ts").Region[];
            cytobands: import("../util/simpleFeature.ts").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("./assembly.ts").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: RpcManager;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("../data_adapters/BaseAdapter/types.ts").BaseOptions): Promise<import("./refNameMaps.ts").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
    getRefNameMapForAdapter(adapterConf: AdapterConf, assemblyName: string | undefined, opts: AssemblyBaseOpts): Promise<import("./refNameMaps.ts").RefNameAliases>;
    isValidRefName(refName: string, assemblyName: string): boolean;
} & {
    afterAttach(): void;
    removeAssembly(asm: Assembly): void;
    addAssembly(configuration: any): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default assemblyManagerFactory;
