declare function PrerenderedCanvas(props: {
    width: number;
    height: number;
    highResolutionScaling?: number;
    style?: React.CSSProperties;
    imageData?: unknown;
    showSoftClip?: boolean;
    blockKey?: string;
}): import("react").JSX.Element;
export default PrerenderedCanvas;
