import type { Props as DialogComponentProps } from './Dialog.tsx';
import type { ButtonProps } from '@mui/material';
export interface SubmitDialogProps extends DialogComponentProps {
    onCancel: () => void;
    onSubmit: () => void;
    cancelText?: string;
    submitText?: string;
    submitDisabled?: boolean;
    submitColor?: ButtonProps['color'];
    submitStartIcon?: React.ReactNode;
    onReset?: () => void;
    resetText?: string;
}
declare const SubmitDialog: (props: SubmitDialogProps) => import("react").JSX.Element;
export default SubmitDialog;
