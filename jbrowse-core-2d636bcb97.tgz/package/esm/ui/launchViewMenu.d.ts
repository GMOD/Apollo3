import type { MenuItem } from './MenuTypes.ts';
export declare function pushLaunchViewMenuItem(items: MenuItem[], item: MenuItem): void;
