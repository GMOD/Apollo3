export declare const INLINE_MENU_ROW_WIDTH = 220;
export declare function ResetToDefaultButton({ disabled, title, onClick, }: {
    disabled: boolean;
    title?: string;
    onClick: () => void;
}): import("react").JSX.Element;
