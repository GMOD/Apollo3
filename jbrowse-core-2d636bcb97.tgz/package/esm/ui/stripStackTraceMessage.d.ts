export declare function stripStackTraceMessage(trace: string, message: string): string;
