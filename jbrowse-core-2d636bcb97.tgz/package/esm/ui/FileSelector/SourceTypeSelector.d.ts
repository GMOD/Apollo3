import type { BaseInternetAccountModel } from '../../pluggableElementTypes/index.ts';
export default function SourceTypeSelector({ value, shownAccounts, hiddenAccounts, onChange, onHiddenAccountSelect, }: {
    value: string;
    shownAccounts: BaseInternetAccountModel[];
    hiddenAccounts: BaseInternetAccountModel[];
    onChange: (event: React.MouseEvent, newValue: string | null) => void;
    onHiddenAccountSelect: (id: string) => void;
}): import("react").JSX.Element;
