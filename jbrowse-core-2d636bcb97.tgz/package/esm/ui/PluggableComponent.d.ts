import type PluginManager from '../PluginManager';
import type React from 'react';
declare const PluggableComponent: <P extends object>({ pluginManager, name, component: DefaultComponent, props, }: {
    pluginManager: PluginManager;
    name: string;
    component: React.ComponentType<P> | React.LazyExoticComponent<React.ComponentType<P>>;
    props: P;
}) => React.JSX.Element;
export default PluggableComponent;
