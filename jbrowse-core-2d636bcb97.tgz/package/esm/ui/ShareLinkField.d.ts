export default function ShareLinkField({ value, label, }: {
    value: string;
    label?: string;
}): import("react").JSX.Element;
