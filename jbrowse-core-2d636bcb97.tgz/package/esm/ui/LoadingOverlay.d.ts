export default function LoadingOverlay({ statusMessage, progress, isVisible, immediate, canceled, onCancel, onRetry, }: {
    statusMessage?: string;
    progress?: number;
    isVisible?: boolean;
    immediate?: boolean;
    canceled?: boolean;
    onCancel?: () => void;
    onRetry?: () => void;
}): import("react").JSX.Element | null;
