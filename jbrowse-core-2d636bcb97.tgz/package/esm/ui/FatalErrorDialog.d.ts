export default function FatalErrorDialog({ componentStack, error, onFactoryReset, resetButtonText, }: {
    componentStack?: string;
    error?: unknown;
    onFactoryReset: () => void;
    resetButtonText?: string;
}): import("react").JSX.Element;
