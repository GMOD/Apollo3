export declare function ColorPopover({ anchorEl, onChange, onClose, color, presetAlpha, }: {
    color: string;
    anchorEl: HTMLElement | null;
    onChange: (val: string) => void;
    onClose: () => void;
    presetAlpha?: number;
}): import("react").JSX.Element;
export default function ColorPicker({ onChange, color, presetAlpha, }: {
    color: string;
    onChange: (val: string) => void;
    presetAlpha?: number;
}): import("react").JSX.Element;
