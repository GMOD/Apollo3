import type { MenuItem } from '../Menu.tsx';
export default function EndAdornment({ showHelp, menuItems, }: {
    showHelp?: boolean;
    menuItems?: MenuItem[];
}): import("react").JSX.Element;
