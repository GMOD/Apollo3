export declare function useRecentLocations(assemblyName?: string): {
    recentLocations: string[];
    addRecentLocation: (loc: string) => void;
    clearRecentLocations: () => void;
};
