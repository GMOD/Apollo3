export declare function rewriteExternalAnchors(el: HTMLElement): void;
