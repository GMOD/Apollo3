import type { TypographyProps } from '@mui/material';
export default function LoadingProgress({ message, fraction, variant, barClassName, }: {
    message?: string;
    fraction?: number;
    variant?: TypographyProps['variant'];
    barClassName?: string;
}): import("react").JSX.Element;
