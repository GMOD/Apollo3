import type { AbstractSessionModel } from '../util/index.ts';
import type { ErrorDialogState, SnackbarMessage } from './SnackbarModel.tsx';
interface SnackbarSession extends AbstractSessionModel {
    snackbarMessages: SnackbarMessage[];
    popSnackbarMessage: () => void;
    errorDialog: ErrorDialogState | undefined;
    setErrorDialog: (state: ErrorDialogState | undefined) => void;
}
declare const Snackbar: ({ session, }: {
    session: SnackbarSession;
}) => import("react").JSX.Element;
export default Snackbar;
