export declare function parseError(str: string): {
    snapshotValue: unknown;
    message: string;
};
