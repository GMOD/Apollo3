import type { DisplayTypeDefaultControl } from '../configuration/promotableDefaults.ts';
import type { CheckboxMenuItem, RadioMenuItem } from './MenuTypes.ts';
export declare function promotableToggleItem({ label, helpText, checked, onToggle, displayTypeDefault, keepMenuOpen, }: {
    label: string;
    helpText?: string;
    checked: boolean;
    onToggle: () => void;
    displayTypeDefault: DisplayTypeDefaultControl;
    keepMenuOpen?: boolean;
}): CheckboxMenuItem;
export declare function promotableRadioItem({ label, subLabel, helpText, checked, onClick, displayTypeDefault, keepMenuOpen, }: {
    label: string;
    subLabel?: string;
    helpText?: string;
    checked: boolean;
    onClick: () => void;
    displayTypeDefault?: DisplayTypeDefaultControl;
    keepMenuOpen?: boolean;
}): RadioMenuItem;
