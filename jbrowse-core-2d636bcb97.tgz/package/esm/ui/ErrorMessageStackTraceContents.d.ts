export default function ErrorMessageStackTraceContents({ text, extra, }: {
    text: string;
    extra?: unknown;
}): import("react").JSX.Element;
