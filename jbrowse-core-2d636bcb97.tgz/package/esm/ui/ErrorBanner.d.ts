declare function ErrorBanner({ error, onReset, }: {
    error: unknown;
    onReset?: () => void;
}): import("react").JSX.Element;
export default ErrorBanner;
