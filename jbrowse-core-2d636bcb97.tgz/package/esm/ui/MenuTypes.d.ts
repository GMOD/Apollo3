export interface MenuDivider {
    priority?: number;
    type: 'divider';
}
export interface MenuSubHeader {
    type: 'subHeader';
    priority?: number;
    label: string;
}
export type MenuItemClickHandler = (...args: any[]) => void;
export interface BaseMenuItem {
    id?: string;
    label: React.ReactNode;
    priority?: number;
    subLabel?: string;
    icon?: React.ElementType;
    disabled?: boolean;
    helpText?: string;
    disabledHelpText?: string;
    keepMenuOpen?: boolean;
    endAdornment?: React.ReactNode;
}
export interface NormalMenuItem extends BaseMenuItem {
    type?: 'normal';
    onClick: MenuItemClickHandler;
}
export interface CheckboxMenuItem extends BaseMenuItem {
    type: 'checkbox';
    checked: boolean;
    onClick: MenuItemClickHandler;
}
export interface RadioMenuItem extends BaseMenuItem {
    type: 'radio';
    checked: boolean;
    onClick: MenuItemClickHandler;
}
export interface SubMenuItem extends BaseMenuItem {
    type?: 'subMenu';
    subMenu: MenuItem[];
}
export interface CustomMenuItem extends BaseMenuItem {
    type: 'custom';
    render: (onClose: () => void) => React.ReactNode;
}
export type ClickableMenuItem = NormalMenuItem | CheckboxMenuItem | RadioMenuItem;
export type MenuItem = MenuDivider | MenuSubHeader | NormalMenuItem | CheckboxMenuItem | RadioMenuItem | SubMenuItem | CustomMenuItem;
export type MenuItemsGetter = MenuItem[] | (() => MenuItem[]);
