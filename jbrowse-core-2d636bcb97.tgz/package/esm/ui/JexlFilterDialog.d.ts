import type { JexlInstance } from '../util/jexlStrings.ts';
declare const JexlFilterDialog: ({ filters, setFilters, handleClose, jexl, }: {
    filters?: string[];
    setFilters: (arg: string[]) => void;
    handleClose: () => void;
    jexl: JexlInstance;
}) => import("react").JSX.Element;
export default JexlFilterDialog;
