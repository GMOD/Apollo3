export default function LoadingDots(): import("react").JSX.Element;
