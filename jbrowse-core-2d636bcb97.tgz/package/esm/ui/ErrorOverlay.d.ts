export default function ErrorOverlay({ error, onRetry, width, height, }: {
    error: unknown;
    onRetry: () => void;
    width: number | string;
    height: number | string;
}): import("react").JSX.Element;
