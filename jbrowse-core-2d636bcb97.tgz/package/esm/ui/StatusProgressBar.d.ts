export default function StatusProgressBar({ fraction, className, style, }: {
    fraction?: number;
    className?: string;
    style?: React.CSSProperties;
}): import("react").JSX.Element;
