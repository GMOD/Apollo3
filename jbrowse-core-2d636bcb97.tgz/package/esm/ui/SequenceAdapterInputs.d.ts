import type { FormState } from '../util/assemblyConfigUtils.ts';
import type { FileLocation } from '../util/types/index.ts';
declare const SequenceAdapterInputs: ({ form, setForm, setPrimaryFile, setTwoBitFile, }: {
    form: FormState;
    setForm: (update: (prev: FormState) => FormState) => void;
    setPrimaryFile: (location: FileLocation) => void;
    setTwoBitFile: (location: FileLocation) => void;
}) => import("react").JSX.Element;
export default SequenceAdapterInputs;
