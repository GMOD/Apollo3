export declare function MenuItemEndDecoration({ type, checked, }: {
    type: 'checkbox' | 'radio';
    checked: boolean;
}): import("react").JSX.Element;
export declare function LoadingMenuItem(): import("react").JSX.Element;
export declare function ErrorMenuItem({ error }: {
    error: unknown;
}): import("react").JSX.Element;
