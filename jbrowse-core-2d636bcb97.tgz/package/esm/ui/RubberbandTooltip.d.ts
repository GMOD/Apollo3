export default function RubberbandTooltip({ anchorEl, side, text, }: {
    anchorEl: HTMLElement;
    side: 'left' | 'right';
    text: React.ReactNode;
}): import("react").JSX.Element;
