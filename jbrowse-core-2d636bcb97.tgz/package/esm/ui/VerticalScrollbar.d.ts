import type React from 'react';
export default function VerticalScrollbar({ scrollTop, setScrollTop, viewportHeight, contentHeight, controlsId, top, }: {
    scrollTop: number;
    setScrollTop: (n: number) => void;
    viewportHeight: number;
    contentHeight: number;
    controlsId: string;
    top?: number;
}): React.JSX.Element | null;
