import type { DisplayTypeDefaultControl } from '../configuration/promotableDefaults.ts';
import type { MenuItem } from './MenuTypes.ts';
import type { SliderScale } from './sliderScale.ts';
export declare function makeSizeMenu(opts: {
    label: string;
    title: string;
    getValue: () => number;
    isDefault: boolean;
    min?: number;
    max?: number;
    step?: number;
    unit?: string;
    scale?: SliderScale;
    format?: (n: number) => string;
    commitOnRelease?: boolean;
    onChange: (n: number) => void;
    onReset: () => void;
    displayTypeDefault?: DisplayTypeDefaultControl;
}): MenuItem;
