export default function RedErrorMessageBox({ children, }: {
    children: React.ReactNode;
}): import("react").JSX.Element;
