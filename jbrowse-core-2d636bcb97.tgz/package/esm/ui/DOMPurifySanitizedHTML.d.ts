export default function DOMPurifySanitizedHTML({ value, className, }: {
    value: string;
    className?: string;
}): import("react").JSX.Element;
