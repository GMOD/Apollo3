declare const ReturnToImportFormDialog: ({ model, handleClose, }: {
    model: {
        clearView: () => void;
    };
    handleClose: () => void;
}) => import("react").JSX.Element;
export default ReturnToImportFormDialog;
