export default function PopoverPicker({ color, onChange, presetAlpha, unset, }: {
    color: string;
    onChange: (color: string) => void;
    presetAlpha?: number;
    unset?: boolean;
}): import("react").JSX.Element;
