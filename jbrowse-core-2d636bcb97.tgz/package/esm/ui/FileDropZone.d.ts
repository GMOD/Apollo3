import type { ReactNode } from 'react';
export type Accept = Record<string, string[]>;
export interface FileRejection {
    file: File;
    errors: {
        code: string;
        message: string;
    }[];
}
export default function FileDropZone({ onDrop, accept, maxSize, multiple, message, children, className, }: {
    onDrop: (accepted: File[], rejected: FileRejection[]) => void;
    accept?: Accept;
    maxSize?: number;
    multiple?: boolean;
    message?: ReactNode;
    children?: ReactNode;
    className?: string;
}): import("react").JSX.Element;
