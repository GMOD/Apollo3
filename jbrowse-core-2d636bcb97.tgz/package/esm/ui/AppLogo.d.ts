import type { AnyConfigurationModel } from '../configuration/index.ts';
declare const Logo: ({ session, }: {
    session: {
        configuration: AnyConfigurationModel;
    };
}) => import("react").JSX.Element;
export default Logo;
