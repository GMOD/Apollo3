import type React from 'react';
declare function ResizeHandle({ onDrag, onDragStart, onDragEnd, vertical, bar, className: originalClassName, onPointerDown, ...props }: {
    onDrag: (distance: number) => void;
    onDragStart?: () => void;
    onDragEnd?: () => void;
    vertical?: boolean;
    bar?: boolean;
} & Omit<React.ComponentPropsWithoutRef<'div'>, 'onDrag' | 'onDragStart' | 'onDragEnd'>): React.JSX.Element;
export default ResizeHandle;
