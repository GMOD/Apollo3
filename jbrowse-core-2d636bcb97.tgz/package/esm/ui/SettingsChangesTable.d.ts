import type { TrackConfigChange } from '../util/trackConfigDelta.ts';
declare const SettingsChangesTable: ({ changes, onResetRow, }: {
    changes: TrackConfigChange[];
    onResetRow?: (change: TrackConfigChange) => void;
}) => import("react").JSX.Element;
export default SettingsChangesTable;
