export interface GradientStop {
    offset: string;
    color: string;
    opacity?: number;
}
export interface GradientLabel {
    text: string;
    position: 'start' | 'middle' | 'end';
}
export declare const GRADIENT_LEGEND_WIDTH = 120;
export declare const GRADIENT_LEGEND_HEIGHT = 40;
export declare const GRADIENT_LEGEND_SVG_AREA_WIDTH: number;
export default function SvgGradientLegend({ gradientId, stops, labels, title, x, y, width, height, barWidth, barHeight, padding, fontSize, }: {
    gradientId: string;
    stops: GradientStop[];
    labels: GradientLabel[];
    title?: string;
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    barWidth?: number;
    barHeight?: number;
    padding?: number;
    fontSize?: number;
}): import("react").JSX.Element;
