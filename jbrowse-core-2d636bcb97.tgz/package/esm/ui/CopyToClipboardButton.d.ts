import type { ButtonProps } from '@mui/material';
export default function CopyToClipboardButton({ value, children, copiedLabel, ...rest }: {
    value: string | (() => string);
    copiedLabel?: string;
} & Omit<ButtonProps, 'value'>): import("react").JSX.Element;
