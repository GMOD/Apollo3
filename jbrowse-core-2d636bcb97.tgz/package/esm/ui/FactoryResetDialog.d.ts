export default function FactoryResetDialog({ onClose, open, onFactoryReset, }: {
    onClose: () => void;
    open: boolean;
    onFactoryReset: () => void;
}): import("react").JSX.Element;
