import type { DialogProps } from '@mui/material';
export interface Props extends Omit<DialogProps, 'onClose'> {
    header?: React.ReactNode;
    titleNode?: React.ReactNode;
    onClose?: {
        bivarianceHack(event: object, reason: 'backdropClick' | 'escapeKeyDown' | 'closeButtonClick'): void;
    }['bivarianceHack'] | undefined;
}
declare function Dialog(props: Props): import("react").JSX.Element;
export default Dialog;
