import type { MenuItem } from './Menu.tsx';
declare const DropDownMenu: ({ menuTitle, menuItems, }: {
    menuTitle: string;
    menuItems: MenuItem[] | (() => MenuItem[]);
}) => import("react").JSX.Element;
export default DropDownMenu;
