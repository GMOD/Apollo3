import type { DisplayTypeDefaultControl } from '../configuration/promotableDefaults.ts';
export declare function DefaultForAllAdornment({ control, label, }: {
    control: DisplayTypeDefaultControl;
    label?: string;
}): import("react").JSX.Element;
