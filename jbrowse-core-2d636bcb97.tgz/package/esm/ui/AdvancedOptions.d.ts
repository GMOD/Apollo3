import type { FormState } from '../util/assemblyConfigUtils.ts';
declare const AdvancedOptions: ({ form, setForm, }: {
    form: FormState;
    setForm: (update: (prev: FormState) => FormState) => void;
}) => import("react").JSX.Element;
export default AdvancedOptions;
