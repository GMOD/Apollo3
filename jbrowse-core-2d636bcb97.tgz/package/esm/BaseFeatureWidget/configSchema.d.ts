declare const configSchema: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{}, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export { configSchema };
