import type PluginManager from '../PluginManager.ts';
import type { SimpleFeatureSerialized } from '../util/index.ts';
import type { SequenceHoverPosition } from './SequenceFeatureDetails/model.ts';
import type { MaybeSerializedFeat } from './types.tsx';
import type { Instance } from '@jbrowse/mobx-state-tree';
export declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<"BaseFeatureWidget">;
    featureData: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<MaybeSerializedFeat, MaybeSerializedFeat, MaybeSerializedFeat>, [undefined]>;
    unformattedFeatureData: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<MaybeSerializedFeat, MaybeSerializedFeat, MaybeSerializedFeat>, [undefined]>;
    view: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    track: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    trackId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    trackType: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    maxDepth: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<number>>;
    sequenceFeatureDetails: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{}, {
        showCoordinatesSetting: import("./index.ts").ShowCoordinatesMode;
        intronBp: number;
        upDownBp: number;
        upperCaseCDS: boolean;
        charactersPerRow: number;
    } & {
        setUpDownBp(f: number): void;
        setIntronBp(f: number): void;
        setUpperCaseCDS(f: boolean): void;
        setShowCoordinates(f: import("./index.ts").ShowCoordinatesMode): void;
    } & {
        readonly showCoordinates: boolean;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    descriptions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Record<string, unknown> | undefined, Record<string, unknown> | undefined, Record<string, unknown> | undefined>, [undefined]>;
}, {
    error: unknown;
    sequenceHoverPosition: SequenceHoverPosition | undefined;
} & {
    setSequenceHoverPosition(pos: SequenceHoverPosition | undefined): void;
    setFeatureData(featureData: SimpleFeatureSerialized): void;
    clearFeatureData(): void;
    setFormattedData(feat: SimpleFeatureSerialized): void;
    setExtra(type?: string, trackId?: string, maxDepth?: number): void;
    setError(e: unknown): void;
} & {
    afterCreate(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, {
    id: string;
    type: "BaseFeatureWidget";
    view: import("@jbrowse/mobx-state-tree").ReferenceIdentifier | undefined;
    track: import("@jbrowse/mobx-state-tree").ReferenceIdentifier | undefined;
    trackId: string | undefined;
    trackType: string | undefined;
    maxDepth: number | undefined;
    sequenceFeatureDetails: import("@jbrowse/mobx-state-tree").ModelSnapshotType<{}>;
    descriptions: Record<string, unknown> | undefined;
    finalizedFeatureData: any;
}>;
export type BaseFeatureWidgetStateModel = ReturnType<typeof stateModelFactory>;
export type BaseFeatureWidgetModel = Instance<BaseFeatureWidgetStateModel>;
