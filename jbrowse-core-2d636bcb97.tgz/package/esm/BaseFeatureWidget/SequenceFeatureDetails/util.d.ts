import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { Feat } from '../util.tsx';
export declare function splitString({ str, charactersPerRow, showCoordinates, currRemainder, spacingInterval, }: {
    str: string;
    charactersPerRow: number;
    showCoordinates: boolean;
    currRemainder?: number;
    spacingInterval?: number;
}): {
    segments: string[];
    remainder: number;
};
export declare function coordLabelWidth({ firstCoord, totalLength, charactersPerRow, strand, }: {
    firstCoord: number;
    totalLength: number;
    charactersPerRow: number;
    strand: number;
}): number;
export declare function displayStrand(feature: SimpleFeatureSerialized, revcomp: boolean): -1 | 1;
export declare function computeCoordProps({ feature, useGenomicCoords, upstream, revcomp, }: {
    feature: SimpleFeatureSerialized;
    useGenomicCoords: boolean;
    upstream: string | undefined;
    revcomp: boolean;
}): {
    mult: number;
    coordStart: number;
};
export declare function transcriptRegions({ cds, exons, featureLength, }: {
    cds: Feat[];
    exons: Feat[];
    featureLength: number;
}): Feat[];
export declare function splitRegionByCds(region: Feat, cds: Feat[]): {
    start: number;
    end: number;
    isCds: boolean;
}[];
export declare function getIntronDisplayStr(intron: string, intronBp: number, collapseIntron: boolean): string;
export declare function getSequencePlaintext(el: HTMLElement): string;
