import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from './model.ts';
declare const SequenceName: ({ mode, model, revcomp, feature, }: {
    model: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    revcomp: boolean;
    feature: SimpleFeatureSerialized;
}) => import("react").JSX.Element;
export default SequenceName;
