import type { SequencePanelProps } from './types.ts';
declare const SequencePanel: ({ sequence, model, feature, mode, revcomp, assemblyGeneticCodeId, assemblyName, hoverTarget, ref, }: SequencePanelProps) => import("react").JSX.Element;
export default SequencePanel;
