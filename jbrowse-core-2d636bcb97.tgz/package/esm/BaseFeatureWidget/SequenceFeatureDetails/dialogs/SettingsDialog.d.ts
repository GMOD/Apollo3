import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const SequenceFeatureSettingsDialog: ({ handleClose, model, }: {
    handleClose: () => void;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default SequenceFeatureSettingsDialog;
