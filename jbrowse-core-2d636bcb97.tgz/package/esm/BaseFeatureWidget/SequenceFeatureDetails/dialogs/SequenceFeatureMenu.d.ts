import type { MenuItem } from '../../../ui/index.ts';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel } from '../model.ts';
import type { RefObject } from 'react';
interface Props {
    model: SequenceFeatureDetailsModel;
    ref: RefObject<HTMLDivElement | null>;
    mode: SequenceDisplayMode;
    revcomp: boolean;
    setRevcomp: (arg: boolean) => void;
    extraItems?: MenuItem[];
}
declare const SequenceFeatureMenu: ({ model, ref, mode, revcomp, setRevcomp, extraItems, }: Props) => import("react").JSX.Element;
export default SequenceFeatureMenu;
