import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { ErrorState, SeqState } from '../../util.tsx';
import type { SequenceDisplayMode, SequenceFeatureDetailsModel, SequenceHoverTarget } from '../model.ts';
declare const SequenceDialog: ({ handleClose, sequenceFeatureDetails, feature, mode, setMode, revcomp, setRevcomp, sequence, error, assemblyGeneticCodeId, assemblyName, hoverTarget, onForceLoad, }: {
    handleClose: () => void;
    feature: SimpleFeatureSerialized;
    sequenceFeatureDetails: SequenceFeatureDetailsModel;
    mode: SequenceDisplayMode;
    setMode: (mode: SequenceDisplayMode) => void;
    revcomp: boolean;
    setRevcomp: (arg: boolean) => void;
    sequence: SeqState | ErrorState | undefined;
    error: unknown;
    assemblyGeneticCodeId?: number;
    assemblyName?: string;
    hoverTarget?: SequenceHoverTarget;
    onForceLoad: () => void;
}) => import("react").JSX.Element;
export default SequenceDialog;
