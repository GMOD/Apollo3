import type { SimpleFeatureSerialized } from '../../../util/index.ts';
export default function TranscriptSelector({ transcripts, transcriptIndex, setTranscriptIndex, }: {
    transcripts: SimpleFeatureSerialized[];
    transcriptIndex: number;
    setTranscriptIndex: (index: number) => void;
}): import("react").JSX.Element;
