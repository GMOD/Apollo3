export default function HelpDialog({ handleClose, }: {
    handleClose: () => void;
}): import("react").JSX.Element;
