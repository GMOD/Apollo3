import type { SimpleFeatureSerialized } from '../../../util/index.ts';
import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const GenomicSequence: ({ sequence, upstream, feature, downstream, useGenomicCoords, revcomp, onHoverBase, model, }: {
    sequence: string;
    feature: SimpleFeatureSerialized;
    upstream?: string;
    downstream?: string;
    useGenomicCoords: boolean;
    revcomp: boolean;
    onHoverBase?: (base0: number) => void;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default GenomicSequence;
