import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const SequenceDisplay: ({ chunks, coordStart, labelWidth, remainder, color, strand, highlight, onHoverBase, model, }: {
    chunks: string[];
    coordStart: number;
    labelWidth: number;
    remainder?: number;
    strand?: number;
    color?: string;
    highlight?: (index: number) => string | undefined;
    onHoverBase?: (base0: number) => void;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element[];
export default SequenceDisplay;
