import type { Feat } from '../../util.tsx';
import type { SequenceFeatureDetailsModel } from '../model.ts';
declare const CDSSequence: ({ cds, sequence, model, }: {
    cds: Feat[];
    sequence: string;
    model: SequenceFeatureDetailsModel;
}) => import("react").JSX.Element;
export default CDSSequence;
