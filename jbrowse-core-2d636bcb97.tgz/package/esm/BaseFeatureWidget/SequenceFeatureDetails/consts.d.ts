export declare const utrColor = "rgb(200,240,240)";
export declare const proteinColor = "rgb(220,160,220)";
export declare const cdsColor = "rgb(220,220,180)";
export declare const updownstreamColor = "rgb(250,200,200)";
export declare const genomeColor = "rgb(200,240,200)";
export declare const translExceptColor = "rgb(255,200,80)";
