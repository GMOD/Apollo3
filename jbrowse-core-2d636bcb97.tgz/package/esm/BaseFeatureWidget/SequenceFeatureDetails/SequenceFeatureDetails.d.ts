import type { AbstractSessionModel, SimpleFeatureSerialized } from '../../util/index.ts';
import type { SequenceFeatureDetailsModel, SequenceHoverTarget } from './model.ts';
declare const SequenceFeatureDetails: ({ model, session, assemblyName, feature, hoverTarget, showOpenInDialog, }: {
    model: SequenceFeatureDetailsModel;
    session: AbstractSessionModel;
    assemblyName: string | undefined;
    feature: SimpleFeatureSerialized;
    hoverTarget?: SequenceHoverTarget;
    showOpenInDialog?: boolean;
}) => import("react").JSX.Element;
export default SequenceFeatureDetails;
