import type { SimpleFeatureSerialized } from '../util/simpleFeature.ts';
import type { BaseFeatureWidgetModel } from './stateModelFactory.ts';
import type React from 'react';
export interface Descriptors {
    [key: string]: React.ReactNode | Descriptors;
}
export type FeatureFormatter = (value: unknown, key: string, index?: number) => React.ReactNode;
export interface BaseProps extends BaseCardProps {
    feature: SimpleFeatureSerialized;
    formatter?: FeatureFormatter;
    descriptions?: Descriptors;
    model?: BaseFeatureWidgetModel;
}
export interface BaseCardProps {
    title?: string;
    defaultExpanded?: boolean;
    children?: React.ReactNode;
}
export interface SerializedFeat {
    [key: string]: unknown;
    subfeatures?: Record<string, unknown>[];
}
export type MaybeSerializedFeat = SimpleFeatureSerialized | undefined;
