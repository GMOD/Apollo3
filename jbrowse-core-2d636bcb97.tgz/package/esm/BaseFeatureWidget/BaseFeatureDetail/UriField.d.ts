export default function UriField({ value, prefix, name, }: {
    value: {
        uri: string;
        baseUri?: string;
    };
    name: string;
    prefix: string[];
}): import("react").JSX.Element;
