export default function BasicValue({ value }: {
    value: unknown;
}): import("react").JSX.Element;
