import type { BaseProps } from '../types.tsx';
export default function BaseAttributes(props: BaseProps): import("react").JSX.Element;
