import type { BaseProps } from '../types.tsx';
export default function BaseCoreDetails(props: BaseProps): import("react").JSX.Element;
