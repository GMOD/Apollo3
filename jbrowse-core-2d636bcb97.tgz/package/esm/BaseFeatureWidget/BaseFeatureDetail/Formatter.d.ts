export default function Formatter({ value }: {
    value: unknown;
}): import("react").JSX.Element;
