import type { FeatureFormatter } from '../types.tsx';
export default function ArrayValue({ name, value, description, formatter, prefix, }: {
    description?: React.ReactNode;
    name: string;
    value: unknown[];
    formatter?: FeatureFormatter;
    prefix?: string[];
}): import("react").JSX.Element;
