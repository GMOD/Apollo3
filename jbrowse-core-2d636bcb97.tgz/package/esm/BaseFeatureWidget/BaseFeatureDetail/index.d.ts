import type { BaseInputProps } from './types.ts';
declare const BaseFeatureDetail: ({ model, }: BaseInputProps) => import("react").JSX.Element | null;
export default BaseFeatureDetail;
export { default as BaseCard } from './BaseCard.tsx';
export { default as BaseAttributes } from './BaseAttributes.tsx';
export { default as BaseCoreDetails } from './BaseCoreDetails.tsx';
export { default as FeatureDetails } from './FeatureDetails.tsx';
