import type { SimpleFeatureSerialized } from '../../util/index.ts';
import type { Descriptors, FeatureFormatter } from '../types.tsx';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
interface FeatureDetailsProps {
    model: IAnyStateTreeNode;
    feature: SimpleFeatureSerialized;
    depth?: number;
    omit?: string[];
    descriptions?: Descriptors;
    formatter?: FeatureFormatter;
}
declare const FeatureDetails: (props: FeatureDetailsProps) => import("react").JSX.Element;
export default FeatureDetails;
