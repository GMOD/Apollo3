export interface SaveSvgAsImageOptions {
    format?: string;
    filename?: string;
}
export declare function svgHtmlToPngBlob(html: string, scale?: number): Promise<Blob>;
export declare function saveSvgAsImage(html: string, opts?: SaveSvgAsImageOptions): Promise<void>;
