import type { ThemeOptions } from '@mui/material';
export declare function wrapSvgExport({ theme, width, height, margin, fontFamily, Wrapper, children, }: {
    theme: ThemeOptions | undefined;
    width: number;
    height: number;
    margin?: number;
    fontFamily?: string;
    Wrapper?: React.FC<{
        children: React.ReactNode;
    }>;
    children: React.ReactNode;
}): string;
