export declare const exportMargin = 50;
