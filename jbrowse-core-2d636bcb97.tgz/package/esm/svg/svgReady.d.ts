export interface SvgExportable {
    svgReady: boolean;
    error: unknown;
    regionTooLarge: boolean;
}
export declare function awaitSvgReady(model: Pick<SvgExportable, 'svgReady'>): Promise<void>;
