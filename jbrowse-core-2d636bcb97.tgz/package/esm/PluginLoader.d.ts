import type { PluginConstructor } from './Plugin.ts';
export interface UMDLocPluginDefinition {
    umdLoc: {
        uri: string;
        baseUri?: string;
    };
    name: string;
    integrity?: string;
}
export interface UMDUrlPluginDefinition {
    umdUrl: string;
    name: string;
    integrity?: string;
}
export interface LegacyUMDPluginDefinition {
    url: string;
    name: string;
    integrity?: string;
}
type UMDPluginDefinition = UMDLocPluginDefinition | UMDUrlPluginDefinition;
export declare function isUMDPluginDefinition(def: PluginDefinition): def is UMDPluginDefinition | LegacyUMDPluginDefinition;
export interface ESMLocPluginDefinition {
    esmLoc: {
        uri: string;
        baseUri?: string;
    };
    name?: string;
}
export interface ESMUrlPluginDefinition {
    esmUrl: string;
    name?: string;
}
export type ESMPluginDefinition = ESMLocPluginDefinition | ESMUrlPluginDefinition;
export declare function isESMPluginDefinition(def: PluginDefinition): def is ESMPluginDefinition;
export interface CJSPluginDefinition {
    cjsUrl: string;
    name?: string;
}
export declare function isCJSPluginDefinition(def: PluginDefinition): def is CJSPluginDefinition;
export type PluginDefinition = UMDUrlPluginDefinition | UMDLocPluginDefinition | LegacyUMDPluginDefinition | ESMLocPluginDefinition | ESMUrlPluginDefinition | CJSPluginDefinition;
export declare const vendoredPluginNames: Set<string>;
export declare function dropVendoredPlugins(defs: PluginDefinition[]): PluginDefinition[];
export interface PluginRecord {
    plugin: PluginConstructor;
    definition: PluginDefinition;
}
export interface LoadedPlugin {
    default: PluginConstructor;
}
export declare function pluginDescriptionString(d: PluginDefinition): string;
export declare function pluginUrl(d: PluginDefinition): string;
export default class PluginLoader {
    definitions: PluginDefinition[];
    fetchESM?: (url: string) => Promise<LoadedPlugin>;
    fetchCJS?: (url: string) => Promise<LoadedPlugin>;
    constructor(defs?: PluginDefinition[], args?: {
        fetchESM?: (url: string) => Promise<LoadedPlugin>;
        fetchCJS?: (url: string) => Promise<LoadedPlugin>;
    });
    loadCJSPlugin(def: CJSPluginDefinition, baseUri?: string): Promise<LoadedPlugin>;
    loadESMPlugin(def: ESMPluginDefinition, baseUri?: string): Promise<LoadedPlugin>;
    loadUMDPlugin(def: UMDPluginDefinition | LegacyUMDPluginDefinition, baseUri?: string): Promise<{
        default: PluginConstructor;
    }>;
    loadPlugin(def: PluginDefinition, baseUri?: string): Promise<PluginConstructor>;
    installGlobalReExports(target: WindowOrWorkerGlobalScope): this;
    load(baseUri?: string): Promise<{
        plugin: PluginConstructor;
        definition: PluginDefinition;
    }[]>;
}
export {};
