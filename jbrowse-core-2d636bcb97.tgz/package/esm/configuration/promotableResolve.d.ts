import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationModel } from './types.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
export type PromotableDisplay = IAnyStateTreeNode & {
    type: string;
    configuration: AnyConfigurationModel;
    ignorePromotedDefaults: boolean;
    setIgnorePromotedDefaults: (flag: boolean) => void;
};
export declare function promotableSlotNames(config: AnyConfigurationModel): Set<string>;
export declare function promotableSlots(self: PromotableDisplay): string[];
export declare function isUsableValue(def: ConfigSlotDefinition, value: unknown): boolean;
export interface SlotResolution {
    base: unknown;
    customized: boolean;
    promoted: unknown;
    callback: boolean;
    value: unknown;
}
export declare function resolveSlot(self: PromotableDisplay, slot: string, args?: Record<string, unknown>): SlotResolution;
