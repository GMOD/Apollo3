import type { JexlInstance } from '../util/jexlStrings.ts';
export declare function isCallbackValue(value: unknown): value is string;
export declare function evaluateJexl(value: string, args: Record<string, unknown>, jexl: JexlInstance): unknown;
