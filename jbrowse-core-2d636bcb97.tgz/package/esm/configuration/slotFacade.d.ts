import type PluginManager from '../PluginManager.ts';
import type { ConfigSlotDefinition } from './configurationSlot.ts';
import type { AnyConfigurationModel } from './types.ts';
export declare function isConfigurationSlot(node: AnyConfigurationModel, slotName: string): boolean;
export declare function preProcessSlotValues(node: AnyConfigurationModel, values: Record<string, unknown>): Record<string, unknown>;
export interface SlotFacade {
    name: string;
    description: string;
    type: string;
    contextVariable: string[];
    defaultValue: unknown;
    choices?: string[];
    pluginManager: PluginManager;
    readonly value: unknown;
    readonly modified: boolean;
    set: (val: unknown) => void;
}
export declare function getSlotDefinition(node: AnyConfigurationModel, slotName: string): ConfigSlotDefinition;
export declare function makeSlotFacade(node: AnyConfigurationModel, slotName: string): SlotFacade;
