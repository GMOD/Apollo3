import type { TrackConfigChange } from '../util/trackConfigDelta.ts';
import type { PromotableDisplay } from './promotableResolve.ts';
export declare function isSlotCustomized(self: PromotableDisplay, slot: string): boolean;
export declare function resolvePromotableConfigSnapshot(self: PromotableDisplay): Record<string, unknown>;
export interface PromotableEntry {
    slot: string;
    value: unknown;
}
export interface DisplayTypeDefaultControl {
    active: boolean;
    toggle: () => void;
}
export declare function resetSlotsToInherit(displays: PromotableDisplay[], slots: string[]): void;
export declare function isPromotableDefault(self: PromotableDisplay, entries: PromotableEntry[]): boolean;
export declare function tracksDifferingFrom(self: PromotableDisplay, entries: PromotableEntry[]): PromotableDisplay[];
export declare function makeSlotsValueDisplayTypeDefaultControl(self: PromotableDisplay, entries: PromotableEntry[]): DisplayTypeDefaultControl;
export declare function makeDisplayTypeDefaultControl(self: PromotableDisplay, slot: string, onValue: unknown): DisplayTypeDefaultControl;
export declare function makeCurrentValueDisplayTypeDefaultControl(self: PromotableDisplay, slots: string[]): DisplayTypeDefaultControl;
export declare function getDisplayTypeDefaultChanges(self: PromotableDisplay): TrackConfigChange[];
export declare function clearPromotedDefaults(self: PromotableDisplay): void;
