import type PluginManager from '../PluginManager.ts';
import type { BaseFeatureDataAdapter } from './BaseAdapter/index.ts';
export interface GetFeatureAdapterArgs {
    pluginManager: PluginManager;
    sessionId: string;
    adapterConfig: Record<string, unknown>;
    sequenceAdapter?: Record<string, unknown>;
}
export declare function getFeatureAdapter({ pluginManager, sessionId, adapterConfig, sequenceAdapter, }: GetFeatureAdapterArgs): Promise<BaseFeatureDataAdapter | undefined>;
export declare function getFeatureAdapterOrThrow(args: GetFeatureAdapterArgs): Promise<BaseFeatureDataAdapter>;
