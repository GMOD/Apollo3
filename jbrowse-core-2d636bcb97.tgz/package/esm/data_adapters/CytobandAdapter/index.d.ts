import type PluginManager from '../../PluginManager.ts';
export default function CytobandAdapterF(pluginManager: PluginManager): void;
