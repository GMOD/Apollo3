declare const configSchema: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    readonly cytobandLocation: {
        readonly type: "fileLocation";
        readonly defaultValue: {
            readonly uri: "/path/to/cytoband.txt.gz";
        };
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default configSchema;
