import type { AnyConfigurationModel } from '../../configuration/index.ts';
export declare function getAdapterId(config: AnyConfigurationModel): string;
