import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationModel, ConfigurationSchemaForModel, ConfigurationSlotName, ConfigurationSlotValue } from '../../configuration/index.ts';
import type { getSubAdapterType } from '../dataAdapterCache.ts';
export declare class BaseAdapter<CONF extends AnyConfigurationModel = AnyConfigurationModel> {
    id: string;
    config: CONF;
    getSubAdapter?: getSubAdapterType;
    pluginManager?: PluginManager;
    sequenceAdapterConfig?: Record<string, unknown>;
    static capabilities: string[];
    constructor(config?: CONF, getSubAdapter?: getSubAdapterType, pluginManager?: PluginManager);
    setSequenceAdapterConfig(config: Record<string, unknown> | undefined): void;
    getConf<SLOT extends ConfigurationSlotName<ConfigurationSchemaForModel<CONF>> | string[] = ConfigurationSlotName<ConfigurationSchemaForModel<CONF>>>(arg: SLOT, args?: Record<string, unknown>): SLOT extends string ? ConfigurationSlotValue<ConfigurationSchemaForModel<CONF>, SLOT> : any;
}
