import { BaseAdapter } from './BaseAdapter.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
import type { Feature } from '../../util/simpleFeature.ts';
import type { AugmentedRegion as Region } from '../../util/types/index.ts';
import type { BaseOptions, RegionByteEstimate } from './types.ts';
import type { Observable } from 'rxjs';
export declare abstract class BaseFeatureDataAdapter<CONF extends AnyConfigurationModel = AnyConfigurationModel> extends BaseAdapter<CONF> {
    abstract getRefNames(opts?: BaseOptions): Promise<string[]>;
    abstract getFeatures(region: Region, opts?: BaseOptions): Observable<Feature>;
    getHeader(_opts?: BaseOptions): Promise<unknown>;
    getMetadata(_opts?: BaseOptions): Promise<unknown>;
    getFeaturesInMultipleRegions(regions: Region[], opts?: BaseOptions): Observable<Feature>;
    getFeaturesArray(region: Region, opts?: BaseOptions): Promise<Feature[]>;
    getFeaturesInMultipleRegionsArray(regions: Region[], opts?: BaseOptions): Promise<Feature[]>;
    hasDataForRefName(refName: string, opts?: BaseOptions): Promise<boolean>;
    getRegionQuantitativeStats(region: Region, opts?: BaseOptions): Promise<import("../../util/stats.ts").RectifiedQuantitativeStats>;
    getMultiRegionQuantitativeStats(regions?: Region[], opts?: BaseOptions): Promise<import("../../util/stats.ts").RectifiedQuantitativeStats>;
    getMultiRegionByteEstimate(regions: Region[], opts?: BaseOptions): Promise<RegionByteEstimate>;
    getRegionByteSize(_regions: Region[], _opts?: BaseOptions): Promise<number | undefined>;
    getSources(regions: Region[], opts?: BaseOptions): Promise<{
        name: string;
        color?: string;
        [key: string]: unknown;
    }[]>;
    getExportData(_regions: Region[], _formatType: string, _opts?: BaseOptions): Promise<string | undefined>;
}
