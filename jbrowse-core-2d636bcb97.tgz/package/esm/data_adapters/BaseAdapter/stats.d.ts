import type { Feature } from '../../util/simpleFeature.ts';
import type { RectifiedQuantitativeStats } from '../../util/stats.ts';
import type { AugmentedRegion as Region } from '../../util/types/index.ts';
import type { BaseOptions } from './types.ts';
import type { Observable } from 'rxjs';
export declare function aggregateQuantitativeStats(stats: RectifiedQuantitativeStats[]): RectifiedQuantitativeStats;
export declare function calculateFeatureDensityStats(region: Region, getFeatures: (region: Region, opts?: BaseOptions) => Observable<Feature>, opts?: BaseOptions): Promise<{
    featureDensity: number;
}>;
export { blankStats } from '../../util/stats.ts';
