import type { StatusCallback } from '../../util/progress.ts';
import type { StopToken } from '../../util/stopToken.ts';
import type { Region } from '../../util/types/index.ts';
export interface BaseOptions {
    stopToken?: StopToken;
    bpPerPx?: number;
    sessionId?: string;
    trackInstanceId?: string;
    signal?: AbortSignal;
    statusCallback?: StatusCallback;
    headers?: Record<string, string>;
    statsEstimationMode?: boolean;
    assemblyName?: string;
    targetAssemblyName?: string;
    lodMode?: 'auto' | 'fine' | 'coarse';
}
export interface BaseOptionsWithRegions extends BaseOptions {
    regions?: Region[];
}
export type SearchType = 'full' | 'prefix' | 'exact';
export interface BaseTextSearchArgs {
    queryString: string;
    searchType?: SearchType;
    stopToken?: StopToken;
}
export interface RegionByteEstimate {
    bytes?: number;
    fetchSizeLimit?: number;
    alwaysRender?: boolean;
}
