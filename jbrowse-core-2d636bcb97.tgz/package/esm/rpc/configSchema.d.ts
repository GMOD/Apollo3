declare const _default: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    readonly defaultDriver: {
        readonly type: "string";
        readonly description: "the RPC driver to use for tracks and tasks that are not configured to use a specific RPC backend";
        readonly defaultValue: "";
        readonly advanced: true;
    };
    readonly workerCount: {
        readonly type: "number";
        readonly description: "The number of workers to use. If 0 (the default) JBrowse will decide how many workers to use.";
        readonly defaultValue: 0;
        readonly advanced: true;
    };
}, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
export default _default;
