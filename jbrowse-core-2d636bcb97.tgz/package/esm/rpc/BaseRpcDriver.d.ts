import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type RpcMethodType from '../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../util/progress.ts';
export interface RpcDriverConstructorArgs {
    config: AnyConfigurationModel;
}
export default abstract class BaseRpcDriver {
    abstract name: string;
    config: AnyConfigurationModel;
    constructor(args: RpcDriverConstructorArgs);
    freeSession(_sessionId: string): void;
    destroy(): void;
    call(pluginManager: PluginManager, sessionId: string, functionName: string, args: Record<string, unknown> & {
        statusCallback?: StatusCallback;
    }, options?: Record<string, unknown>): Promise<unknown>;
    protected abstract transport(pluginManager: PluginManager, sessionId: string, rpcMethod: RpcMethodType, serializedArgs: Record<string, unknown>, statusCallback: StatusCallback | undefined, options: Record<string, unknown>): Promise<unknown>;
}
