import type PluginManager from '../PluginManager.ts';
import type { AnyConfigurationModel } from '../configuration/index.ts';
import type BaseRpcDriver from './BaseRpcDriver.ts';
import type { RpcArgs, RpcMethodName, RpcReturn } from './RpcRegistry.ts';
export type RpcDriverFactory = (config: AnyConfigurationModel, pluginManager: PluginManager) => BaseRpcDriver;
type RpcCallArgs<M extends string> = M extends RpcMethodName ? Omit<RpcArgs<M & RpcMethodName>, 'sessionId'> : Record<string, unknown>;
type RpcCallReturn<M extends string> = M extends RpcMethodName ? RpcReturn<M & RpcMethodName> : unknown;
export interface RpcManagerOptions {
    makeWorkerInstance?: () => Worker;
    defaultDriverName?: string;
}
export default class RpcManager {
    static configSchema: import("../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly defaultDriver: {
            readonly type: "string";
            readonly description: "the RPC driver to use for tracks and tasks that are not configured to use a specific RPC backend";
            readonly defaultValue: "";
            readonly advanced: true;
        };
        readonly workerCount: {
            readonly type: "number";
            readonly description: "The number of workers to use. If 0 (the default) JBrowse will decide how many workers to use.";
            readonly defaultValue: 0;
            readonly advanced: true;
        };
    }, import("../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, undefined>>;
    pluginManager: PluginManager;
    mainConfiguration: AnyConfigurationModel;
    defaultDriverName: string;
    driverObjects: Map<string, BaseRpcDriver>;
    driverFactories: Map<string, RpcDriverFactory>;
    constructor(pluginManager: PluginManager, mainConfiguration: AnyConfigurationModel, { makeWorkerInstance, defaultDriverName, }?: RpcManagerOptions);
    registerDriverFactory(name: string, factory: RpcDriverFactory): void;
    getDriver(backendName: string): BaseRpcDriver;
    private getDriverForCall;
    call<M extends string>(sessionId: string, functionName: M, args: RpcCallArgs<M>, opts?: {
        rpcDriverName?: string;
    } & Record<string, unknown>): Promise<RpcCallReturn<M>>;
    private withAuthRetry;
    private ensureAuthForOrigin;
    private freeSessionOnAllDrivers;
    destroy(): void;
}
export {};
