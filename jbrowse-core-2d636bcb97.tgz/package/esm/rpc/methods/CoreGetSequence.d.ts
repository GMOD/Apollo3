import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { Region } from '../../util/index.ts';
import type { StopToken } from '../../util/stopToken.ts';
export default class CoreGetSequence extends RpcMethodType {
    name: string;
    execute(args: {
        sessionId: string;
        region: Region;
        adapterConfig: Record<string, unknown>;
        stopToken?: StopToken;
    }, rpcDriver: string): Promise<string | undefined>;
}
