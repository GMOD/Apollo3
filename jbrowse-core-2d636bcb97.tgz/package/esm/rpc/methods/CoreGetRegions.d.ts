import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
export default class CoreGetRegions extends RpcMethodType {
    name: string;
    execute(args: {
        sessionId: string;
        adapterConfig: Record<string, unknown>;
    }, rpcDriver: string): Promise<never[] | import("../../util/index.ts").NoAssemblyRegion[]>;
}
