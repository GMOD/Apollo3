import RpcMethodType from '../../pluggableElementTypes/RpcMethodType.ts';
import type { StopToken } from '../../util/stopToken.ts';
export default class CoreGetInfo extends RpcMethodType {
    name: string;
    execute(args: {
        sessionId: string;
        stopToken?: StopToken;
        adapterConfig: Record<string, unknown>;
    }, rpcDriver: string): Promise<unknown>;
}
