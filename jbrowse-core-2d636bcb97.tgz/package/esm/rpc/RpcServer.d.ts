import type { ErrorObject } from './serializeError/index.ts';
export interface RpcResult {
    __rpcResult: true;
    value: unknown;
    transferables: Transferable[];
}
export declare function rpcResult(value: unknown, transferables: Transferable[]): RpcResult;
export declare function rpcResultWithArrayBuffers(value: object): RpcResult;
type Procedure = (data: unknown) => Promise<unknown>;
interface RpcMessageData {
    method: string;
    uid: string;
    libRpc?: true;
    data: unknown;
}
export default class RpcServer {
    protected methods: Record<string, Procedure>;
    constructor(methods: Record<string, Procedure>);
    handler(e: MessageEvent<RpcMessageData>): void;
    private post;
    protected reply(uid: string, response: unknown): void;
    protected throw(uid: string, error: ErrorObject | string): void;
    emit(eventName: string, data: unknown, transferables?: Transferable[]): void;
}
export {};
