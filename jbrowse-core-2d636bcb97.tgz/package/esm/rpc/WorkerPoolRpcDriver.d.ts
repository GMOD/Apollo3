import BaseRpcDriver from './BaseRpcDriver.ts';
import type PluginManager from '../PluginManager.ts';
import type RpcMethodType from '../pluggableElementTypes/RpcMethodType.ts';
import type { StatusCallback } from '../util/progress.ts';
export interface WorkerHandle {
    destroy(): void;
    onError?(callback: () => void): void;
    call(functionName: string, args?: unknown, options?: {
        statusCallback?: StatusCallback;
        rpcDriverClassName: string;
    }): Promise<unknown>;
}
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-extendWorker': {
            args: WorkerHandle;
            result: WorkerHandle;
        };
    }
}
export default abstract class WorkerPoolRpcDriver extends BaseRpcDriver {
    private lastWorkerAssignment;
    private workerAssignments;
    private workerPool?;
    abstract makeWorker(): Promise<WorkerHandle>;
    freeSession(sessionId: string): void;
    destroy(): void;
    private createWorkerPool;
    private getWorkerPool;
    getWorker(sessionId: string): Promise<WorkerHandle>;
    protected transport(pluginManager: PluginManager, sessionId: string, rpcMethod: RpcMethodType, serializedArgs: Record<string, unknown>, statusCallback: StatusCallback | undefined, options: Record<string, unknown>): Promise<unknown>;
}
