export interface ErrorObject {
    name?: string;
    message: string;
    stack?: string;
    cause?: unknown;
    [key: string]: unknown;
}
export declare function serializeError(value: unknown): ErrorObject;
export declare function deserializeError(value: unknown): Error;
