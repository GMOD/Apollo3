import type { ComponentType } from 'react';
export declare const DataGridEntries: Record<string, ComponentType<any>>;
