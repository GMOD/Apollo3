declare const libs: any;
export default libs;
