export declare const BaseFeatureDetail: any;
