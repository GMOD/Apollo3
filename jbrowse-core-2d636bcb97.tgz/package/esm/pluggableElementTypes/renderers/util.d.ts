import type { Region } from '../../util/index.ts';
export declare function normalizeRegion(region: Region): Region;
export declare function expandRegion(region: Region, bpExpansion: number): Region;
