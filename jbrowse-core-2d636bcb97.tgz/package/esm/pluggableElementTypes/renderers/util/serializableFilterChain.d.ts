import type { JexlExpression, JexlInstance } from '../../../util/jexlStrings.ts';
interface Filter {
    string: string;
    expr: JexlExpression;
}
export type SerializedFilterChain = string[];
export default class SerializableFilterChain {
    filterChain: Filter[];
    constructor({ filters, jexl, }: {
        filters: SerializedFilterChain;
        jexl: JexlInstance;
    });
    passes(feature: unknown, extraContext?: Record<string, unknown>): boolean;
    toJSON(): {
        filters: string[];
    };
    static fromJSON(json: {
        filters: SerializedFilterChain;
        jexl: JexlInstance;
    }): SerializableFilterChain;
}
export {};
