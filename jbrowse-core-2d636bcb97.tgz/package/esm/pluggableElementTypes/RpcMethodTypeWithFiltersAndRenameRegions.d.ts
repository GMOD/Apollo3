import RpcMethodTypeWithRenameRegions from './RpcMethodTypeWithRenameRegions.ts';
import SerializableFilterChain from './renderers/util/serializableFilterChain.ts';
import type { Region } from '../util/index.ts';
import type { StatusCallback } from '../util/progress.ts';
import type { StopToken } from '../util/stopToken.ts';
interface FilterRenameArgs {
    sessionId: string;
    regions?: Region[];
    adapterConfig: Record<string, unknown>;
    filters?: SerializableFilterChain;
}
export default abstract class RpcMethodTypeWithFiltersAndRenameRegions extends RpcMethodTypeWithRenameRegions {
    deserializeArguments<T>(args: T & {
        filters?: unknown;
    }, rpcDriverClassName: string): Promise<T>;
    serializeArguments(args: FilterRenameArgs & {
        stopToken?: StopToken;
        statusCallback?: StatusCallback;
    }, rpcDriverClassName: string): Promise<Record<string, unknown>>;
}
export {};
