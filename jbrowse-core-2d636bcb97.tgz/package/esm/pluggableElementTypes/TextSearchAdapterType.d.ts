import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { AnyAdapter } from '../data_adapters/BaseAdapter/index.ts';
export default class TextSearchAdapterType extends PluggableElementBase {
    getAdapterClass: () => Promise<AnyAdapter>;
    configSchema: AnyConfigurationSchemaType;
    description?: string;
    constructor(stuff: {
        name: string;
        configSchema: AnyConfigurationSchemaType;
        displayName?: string;
        description?: string;
    } & ({
        getAdapterClass: () => Promise<AnyAdapter>;
    } | {
        AdapterClass: AnyAdapter;
    }));
}
