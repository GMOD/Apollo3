import PluggableElementBase from './PluggableElementBase.ts';
import type { AnyConfigurationSchemaType } from '../configuration/index.ts';
import type { IAnyModelType, IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { ComponentType, LazyExoticComponent } from 'react';
import type React from 'react';
type WidgetComponentType = LazyExoticComponent<React.FC<any>> | React.FC<any>;
type HeadingComponentType = ComponentType<{
    model: IAnyStateTreeNode;
}>;
export default class WidgetType extends PluggableElementBase {
    heading?: string;
    configSchema: AnyConfigurationSchemaType;
    HeadingComponent?: HeadingComponentType;
    ReactComponent: WidgetComponentType;
    stateModel: IAnyModelType;
    helpText?: React.ReactNode;
    constructor(stuff: {
        name: string;
        heading?: string;
        HeadingComponent?: HeadingComponentType;
        configSchema: AnyConfigurationSchemaType;
        stateModel: IAnyModelType;
        ReactComponent: WidgetComponentType;
        helpText?: React.ReactNode;
    });
}
export {};
