import type { Feature } from '@jbrowse/core/util';
export declare function stringifyBED({ features }: {
    features: Feature[];
}): string;
