import type { HighlightType } from '../../util/highlights.ts';
export default function HighlightsMixin(): import("@jbrowse/mobx-state-tree").IModelType<{
    highlight: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IType<HighlightType, HighlightType, HighlightType>>, [undefined]>;
    showHighlightChips: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    addToHighlights(highlight: HighlightType): void;
    setHighlight(highlight?: HighlightType[]): void;
    removeHighlight(highlight: HighlightType): void;
    updateHighlight(old: HighlightType, updates: Partial<HighlightType>): void;
    setShowHighlightChips(arg: boolean): void;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
