import type { Instance } from '@jbrowse/mobx-state-tree';
declare const BaseConnectionConfig: import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
    readonly name: {
        readonly type: "string";
        readonly defaultValue: "nameOfConnection";
        readonly description: "a unique name for this connection";
    };
    readonly assemblyNames: {
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
        readonly description: "optional list of names of assemblies in this connection";
    };
}, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "connectionId">>;
export default BaseConnectionConfig;
export type BaseConnectionConfigSchema = typeof BaseConnectionConfig;
export type BaseConnectionConfigModel = Instance<BaseConnectionConfigSchema>;
