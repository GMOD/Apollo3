import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../../configuration/index.ts';
import type { MenuItem } from '../../ui/index.ts';
import type { DisplayModel } from './BaseDisplayModel.tsx';
import type { FileTypeExporter } from './saveTrackFileTypes/types.ts';
import type { IAnyStateTreeNode, IType, Instance } from '@jbrowse/mobx-state-tree';
export declare function getCompatibleDisplays(self: IAnyStateTreeNode): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
} & import("@jbrowse/mobx-state-tree").IStateTreeNode<AnyConfigurationSchemaType>)[];
export declare function createBaseTrackModel(pm: PluginManager, trackType: string, baseTrackConfig: AnyConfigurationSchemaType): import("@jbrowse/mobx-state-tree").IModelType<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<AnyConfigurationSchemaType>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    pinned: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    displays: import("@jbrowse/mobx-state-tree").IArrayType<IType<unknown, unknown, DisplayModel>>;
}, {
    readonly trackId: string;
    readonly rpcSessionId: string;
    readonly name: string;
    readonly textSearchAdapter: any;
    readonly adapterConfig: any;
    readonly activeDisplay: DisplayModel & import("@jbrowse/mobx-state-tree").IStateTreeNode<IType<unknown, unknown, DisplayModel>>;
    readonly canConfigure: boolean;
} & {
    readonly adapterType: import("../AdapterType.ts").default;
} & {
    setPinned(flag: boolean): void;
    setMinimized(flag: boolean): void;
    replaceDisplay(oldDisplayId: string, newDisplayId: string, initialSnapshot?: any): void;
    afterAttach(): void;
} & {
    saveTrackFileFormatOptions(): Record<string, FileTypeExporter>;
} & {
    readonly saveTrackDataMenuItem: MenuItem;
    trackMenuItems(): MenuItem[];
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseTrackStateModel = ReturnType<typeof createBaseTrackModel>;
export type BaseTrackModel = Instance<BaseTrackStateModel>;
