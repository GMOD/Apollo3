import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationSchemaType } from '../../configuration/index.ts';
export interface DisplaySnapshot {
    type: string;
    displayId?: string;
    [key: string]: unknown;
}
interface DisplayTypeLike {
    name: string;
    configSchema: AnyConfigurationSchemaType;
}
interface TrackTypeLike {
    displayTypes: DisplayTypeLike[];
}
export declare function trackDisplaySlots(trackType: TrackTypeLike): Map<string, Set<string>>;
export declare function collectDisplayOverrides(displaySettings: Record<string, unknown>, displaySlots: Map<string, Set<string>>): {
    overrides: Map<string, Record<string, unknown>>;
    unknownKeys: string[];
};
export declare function mergeOverridesIntoDisplays(displays: DisplaySnapshot[], overrides: Map<string, Record<string, unknown>>, trackId: string): DisplaySnapshot[];
export declare function expandTrackConfigShorthand(input: unknown, pluginManager: PluginManager): unknown;
export {};
