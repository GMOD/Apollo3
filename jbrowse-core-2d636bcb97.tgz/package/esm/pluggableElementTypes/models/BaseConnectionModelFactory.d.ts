import type PluginManager from '../../PluginManager.ts';
import type { AnyConfigurationModel } from '../../configuration/index.ts';
type TrackConf = AnyConfigurationModel | Record<string, unknown>;
declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyModelType>;
    configuration: import("../../configuration/configurationSchema.ts").IConfigurationReference<import("../../configuration/configurationSchema.ts").ConfigurationSchemaType<{
        readonly name: {
            readonly type: "string";
            readonly defaultValue: "nameOfConnection";
            readonly description: "a unique name for this connection";
        };
        readonly assemblyNames: {
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
            readonly description: "optional list of names of assemblies in this connection";
        };
    }, import("../../configuration/configurationSchema.ts").ConfigurationSchemaOptions<undefined, "connectionId">>>;
    silent: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    loading: boolean;
} & {
    readonly connectionId: string;
    readonly name: string;
} & {
    connect(): Promise<void>;
    setLoading(loading: boolean): void;
} & {
    afterAttach(): void;
    addTrackConf(trackConf: TrackConf): any;
    addTrackConfs(trackConfs: TrackConf[]): void;
    setTrackConfs(trackConfs: TrackConf[]): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type BaseConnectionModel = ReturnType<typeof stateModelFactory>;
export default stateModelFactory;
