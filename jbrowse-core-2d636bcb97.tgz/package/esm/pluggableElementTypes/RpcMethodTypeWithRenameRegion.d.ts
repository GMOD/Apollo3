import RpcMethodType from './RpcMethodType.ts';
import type { RenameRegionArgs } from './RpcMethodType.ts';
export default abstract class RpcMethodTypeWithRenameRegion extends RpcMethodType {
    serializeArguments<T extends RenameRegionArgs>(args: T, rpcDriverClassName: string): Promise<Record<string, unknown>>;
}
