import type PluginManager from '../../PluginManager.ts';
import type React from 'react';
export type InstanceTypeRestrictive<CONSTRUCTOR extends new (...args: any[]) => any> = CONSTRUCTOR extends new (...args: any[]) => infer CLASS ? CLASS : never;
export type ClassReturnedBy<FACT extends (pm: PluginManager) => any> = InstanceTypeRestrictive<ReturnType<FACT>>;
export type AnyReactComponentType = React.ComponentType<any>;
export type TypeTestedByPredicate<PREDICATE extends (thing: any) => boolean> = PREDICATE extends ((thing: any) => thing is infer TYPE) ? TYPE : never;
