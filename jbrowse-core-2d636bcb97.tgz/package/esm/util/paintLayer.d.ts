import { SvgCanvas } from './SvgCanvas.ts';
import type { SvgRasterCanvasOpts } from './createSvgRasterCanvas.ts';
import type React from 'react';
export type Ctx2D = CanvasRenderingContext2D | SvgCanvas;
export type PaintLayerOpts = SvgRasterCanvasOpts & {
    rasterizeLayers?: boolean;
};
export declare function PaintLayer({ width, height, opts, paint, }: {
    width: number;
    height: number;
    opts?: PaintLayerOpts;
    paint: (ctx: Ctx2D) => void;
}): React.ReactNode;
