import type { SessionWithAddTracks } from './types/index.ts';
export declare function addAndShowTrack(session: SessionWithAddTracks, conf: Parameters<SessionWithAddTracks['addTrackConf']>[0] & {
    trackId: string;
}, view?: {
    showTrack: (trackId: string) => void;
}): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
    setSubschema(slotName: string, data: Record<string, unknown>): any;
    setSlot(slotName: string, value: unknown): void;
} & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("../configuration/types.ts").AnyConfigurationSchemaType>) | undefined;
