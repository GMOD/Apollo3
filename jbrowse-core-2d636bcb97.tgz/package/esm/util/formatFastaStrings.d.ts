export interface SeqChunk {
    header: string;
    seq: string;
}
export declare function formatFastaLines(seqString: string): string;
export declare function formatSeqFasta(chunks: SeqChunk[]): string;
