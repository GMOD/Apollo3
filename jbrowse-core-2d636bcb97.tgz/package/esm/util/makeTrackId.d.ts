export declare function makeTrackId({ name, timestamp, index, }: {
    name: string;
    timestamp?: number;
    index?: number;
}): string;
