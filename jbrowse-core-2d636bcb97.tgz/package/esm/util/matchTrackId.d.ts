export declare function matchTrackId(trackId: string | undefined, patterns: (string | RegExp)[]): boolean;
