export declare function b64PadSuffix(b64: string): string;
export declare function fromUrlSafeB64(b64: string): Promise<string>;
export declare function toUrlSafeB64(str: string): Promise<string>;
export declare function shareSessionToDynamo(session: unknown, url: string, referer: string): Promise<{
    json: {
        sessionId: string;
    };
    encryptedSession: string;
    password: string;
}>;
export type SessionShareMode = 'short' | 'long' | 'json';
export interface EncodedSessionParam {
    sessionParam: string;
    password?: string;
    plaintext?: string;
}
export declare function encodeSessionParam(mode: SessionShareMode, session: unknown, options: {
    shareURL: string;
    referer: string;
}): Promise<EncodedSessionParam>;
export declare function readSessionFromDynamo(baseUrl: string, sessionQueryParam: string, password: string, signal?: AbortSignal): Promise<string>;
