export declare function addRelativeUris(config: Record<string, unknown> | null, base: URL): void;
export declare function stripBaseUris<T>(config: T): T;
