import type { AbstractSessionModel } from './index.ts';
export declare function useFeatureSequence({ session, start, end, refName, upDownBp, forceLoad, assemblyName, }: {
    assemblyName: string | undefined;
    session?: AbstractSessionModel;
    start: number;
    end: number;
    refName: string;
    upDownBp: number;
    forceLoad: boolean;
}): {
    sequence: {
        error: string;
        seq?: undefined;
        upstream?: undefined;
        downstream?: undefined;
    } | {
        error?: undefined;
        seq: string;
        upstream: string;
        downstream: string;
    } | undefined;
    loading: boolean;
    error: unknown;
};
