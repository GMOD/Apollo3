import { Observable } from 'rxjs';
declare class AbortError extends Error {
    code: string | undefined;
}
export declare function checkAbortSignal(signal?: AbortSignal): void;
export declare function abortBreakPoint(signal?: AbortSignal): Promise<void>;
export declare function makeAbortError(): AbortError | DOMException;
export declare function observeAbortSignal(signal?: AbortSignal): Observable<Event>;
export declare function isAbortException(exception: unknown): boolean;
export {};
