interface RGBA {
    r: number;
    g: number;
    b: number;
    a: number;
}
interface HSLA {
    h: number;
    s: number;
    l: number;
    a: number;
}
export interface Colord {
    alpha(): number;
    alpha(value: number): Colord;
    toHex(): string;
    toRgb(): RGBA;
    toRgbString(): string;
    toHsl(): HSLA;
    toHslString(): string;
    mix(color: Colord | string, ratio?: number): Colord;
    darken(amount?: number): Colord;
    lighten(amount?: number): Colord;
}
export declare function colord(input: string | {
    h: number;
    s: number;
    l: number;
}): Colord;
export declare function hexToGLrgb(hex: string): [number, number, number];
export {};
