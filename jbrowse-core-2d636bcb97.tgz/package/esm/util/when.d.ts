export { when } from 'mobx';
