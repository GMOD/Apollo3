export interface PointerPresence {
    readonly isOver: boolean;
    dispose: () => void;
}
export declare function trackPointerPresence(el: HTMLElement, onLeave?: () => void): PointerPresence;
