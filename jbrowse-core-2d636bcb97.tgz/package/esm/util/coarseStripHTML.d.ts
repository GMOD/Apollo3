export declare function coarseStripHTML(s: string): string;
