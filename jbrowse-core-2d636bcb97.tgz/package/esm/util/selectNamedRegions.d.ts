import type { Region } from './types/index.ts';
export declare function selectNamedRegions(regions: readonly Region[], names: readonly string[], getCanonicalRefName: (name: string) => string | undefined): Region[];
