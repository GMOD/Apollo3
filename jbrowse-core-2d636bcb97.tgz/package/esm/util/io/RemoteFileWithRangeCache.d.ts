import { RemoteFile } from 'generic-filehandle2';
export declare function clearCache(): void;
export declare class RemoteFileWithRangeCache extends RemoteFile {
    stat(): Promise<{
        size: number;
    }>;
    private fetchRange;
    private getCachedRange;
    fetch(url: string | RequestInfo, init?: RequestInit): Promise<Response>;
}
