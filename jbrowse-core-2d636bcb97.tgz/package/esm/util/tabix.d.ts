import type { StatusCallback } from './progress.ts';
export interface TabixLine {
    line: string;
    offset: number;
    start: number;
    end: number;
    type: string;
}
interface TabixLineSource {
    getLines(refName: string, start: number | undefined, end: number | undefined, opts: {
        lineCallback: (line: string, offset: number, start: number, end: number) => void;
        onProgress?: (bytesDownloaded: number, totalBytes?: number) => void;
    }): Promise<void>;
}
export declare function readTabixLines(gff: TabixLineSource, refName: string, start: number, end: number, statusCallback?: StatusCallback): Promise<TabixLine[]>;
export {};
