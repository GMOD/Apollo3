import { BlockSet } from './blockTypes.ts';
import type { Region } from './types/index.ts';
import type { Region as RegionModel } from './types/mst.ts';
import type { Instance } from '@jbrowse/mobx-state-tree';
export interface Base1DViewModel {
    offsetPx: number;
    width: number;
    displayedRegions: (Region | Instance<typeof RegionModel>)[];
    bpPerPx: number;
    minimumBlockWidth: number;
}
export default function calculateStaticBlocks(model: Base1DViewModel, padding?: boolean, elision?: boolean): BlockSet;
