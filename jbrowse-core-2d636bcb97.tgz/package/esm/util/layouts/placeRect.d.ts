export declare function placeRect(rows: number[][], start: number, end: number): number;
