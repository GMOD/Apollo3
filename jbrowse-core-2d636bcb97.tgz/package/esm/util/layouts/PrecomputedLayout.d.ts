import type { BaseLayout, RectTuple, Rectangle, SerializedLayout } from './BaseLayout.ts';
export interface Layout {
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    name: string;
}
export default class PrecomputedLayout<T> implements BaseLayout<T> {
    private rectangles;
    private totalHeight;
    maxHeightReached: boolean;
    private index?;
    private indexData;
    constructor({ rectangles, totalHeight, maxHeightReached }: SerializedLayout);
    private buildIndex;
    addRect(id: string): number;
    getRectangles(): Map<string, RectTuple>;
    getTotalHeight(): number;
    getByCoord(x: number, y: number): string | undefined;
    getByID(id: string): RectTuple | undefined;
    getDataByID(_id: string): T | undefined;
    addRectToBitmap(_rect: Rectangle<T>): void;
    discardRange(_left: number, _right: number): void;
    serializeRegion(_region: {
        start: number;
        end: number;
    }): SerializedLayout;
    toJSON(): SerializedLayout;
}
