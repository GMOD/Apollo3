import type { BaseLayout, RectTuple, Rectangle, SerializedLayout } from './BaseLayout.ts';
export default class GranularRectLayout<T> implements BaseLayout<T> {
    private pitchX;
    private pitchY;
    private hardRowLimit;
    private bitmap;
    private rectangles;
    maxHeightReached: boolean;
    private maxHeight;
    private pTotalHeight;
    constructor({ pitchX, pitchY, maxHeight, hardRowLimit, }?: {
        pitchX?: number;
        pitchY?: number;
        maxHeight?: number;
        hardRowLimit?: number;
    });
    addRect(id: string, left: number, right: number, height: number, data?: T, serializableData?: T): number | null;
    private getOrCreateRow;
    addRectToBitmap(rect: Rectangle<T>): void;
    discardRange(left: number, right: number): void;
    getByCoord(x: number, y: number): string | undefined;
    getByID(id: string): RectTuple | undefined;
    getDataByID(id: string): T | undefined;
    getTotalHeight(): number;
    getRectangles(): Map<string, RectTuple>;
    serializeRegion(region: {
        start: number;
        end: number;
    }): SerializedLayout;
    toJSON(): SerializedLayout;
}
