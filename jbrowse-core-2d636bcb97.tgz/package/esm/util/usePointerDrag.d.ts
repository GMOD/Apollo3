import type React from 'react';
export declare function usePointerDrag({ onDragStart, onDrag, onDragEnd, }: {
    onDragStart?: (event: React.PointerEvent) => void;
    onDrag: (event: React.PointerEvent) => void;
    onDragEnd?: (event: React.PointerEvent) => void;
}): {
    onPointerDown: (event: React.PointerEvent) => void;
    onPointerMove: (event: React.PointerEvent) => void;
    onPointerUp: (event: React.PointerEvent) => void;
    onPointerCancel: (event: React.PointerEvent) => void;
};
