import { Observable } from 'rxjs';
import type { StopToken } from './stopToken.ts';
import type { Observer } from 'rxjs';
export declare function ObservableCreate<T>(func: (arg: Observer<T>) => void | Promise<void>, _stopToken?: StopToken): Observable<T>;
