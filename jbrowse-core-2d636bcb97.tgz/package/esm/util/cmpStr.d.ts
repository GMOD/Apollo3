export declare function cmpStr(a: string, b: string): number;
