export { type RenderLifecycleModel, useRenderingBackend, } from '@jbrowse/render-core';
