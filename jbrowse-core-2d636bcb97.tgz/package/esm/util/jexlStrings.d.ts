export interface JexlExpression {
    eval(context?: Record<string, unknown>): unknown;
    _exprStr?: string;
}
export interface JexlInstance {
    compile(code: string): JexlExpression;
}
export declare const JEXL_PREFIX = "jexl:";
export declare function isJexl(str: unknown): str is string;
export declare function ensureJexlPrefix(code: string): string;
export declare function stringToJexlExpression(str: string, jexl: JexlInstance): JexlExpression;
