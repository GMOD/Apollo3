export declare function namedColorToHex(name: string): string | undefined;
export declare function isNamedColor(name: string): boolean;
