export declare function contrastingTextColor(color: string): string;
export declare function emphasize(color: string, coefficient?: number): string;
export declare function makeContrasting(foreground: string, background?: string, minContrastRatio?: number): string;
export { isNamedColor, namedColorToHex } from './cssColorsLevel4.ts';
export declare function randomColor(str: string): string;
