export interface ParsedLocString {
    assemblyName?: string;
    refName: string;
    start?: number;
    end?: number;
    reversed?: boolean;
}
export declare class UnknownRefNameError extends Error {
    name: string;
}
export declare function parseLocStringOneBased(locString: string, isValidRefName: (refName: string, assemblyName?: string) => boolean): ParsedLocString;
export declare function parseLocString(locString: string, isValidRefName: (refName: string, assemblyName?: string) => boolean): ParsedLocString;
export declare function assembleLocString(region: ParsedLocString): string;
export declare function assembleLocStringFast(region: ParsedLocString, cb?: (n: number) => string | number): string;
export declare function compareLocs(locA: ParsedLocString, locB: ParsedLocString): number;
export declare function compareLocStrings(a: string, b: string, isValidRefName: (refName: string, assemblyName?: string) => boolean): number;
