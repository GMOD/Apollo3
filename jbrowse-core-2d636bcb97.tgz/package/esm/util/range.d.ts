export declare function intersection2(left1: number, right1: number, left2: number, right2: number): [number, number] | [];
export declare function doesIntersect2(left1: number, right1: number, left2: number, right2: number): boolean;
export declare function isContainedWithin(left1: number, right1: number, left2: number, right2: number): boolean;
export declare function calculateRedispatchRange(features: {
    start: number;
    end: number;
    type: string;
}[], dontRedispatchSet: Set<string>, queryStart: number, queryEnd: number): {
    start: number;
    end: number;
} | undefined;
