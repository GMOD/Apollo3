export interface Feature {
    get(name: 'refName'): string;
    get(name: 'name' | 'type' | 'id' | 'source'): string | undefined;
    get(name: 'start' | 'end'): number;
    get(name: 'phase'): 0 | 1 | 2 | undefined;
    get(name: 'strand'): -1 | 0 | 1 | undefined;
    get(name: 'score'): number | undefined;
    get(name: 'subfeatures'): Feature[] | undefined;
    get(name: string): unknown;
    id(): string;
    parent?: () => Feature | undefined;
    children?: () => Feature[] | undefined;
    toJSON(): SimpleFeatureSerialized;
}
export declare function isFeature(thing: unknown): thing is Feature;
export declare function jexlFeatureProxy(feature: Feature): Feature;
export declare function buildJexlContext(args: Record<string, unknown>): Record<string, unknown>;
export interface SimpleFeatureArgs {
    data: Record<string, unknown>;
    parent?: Feature;
    id: string | number;
}
export interface SimpleFeatureSerializedNoId {
    [key: string]: unknown;
    parentId?: string;
    start: number;
    end: number;
    refName: string;
    type?: string;
    strand?: number;
    name?: string;
    id?: string | number;
    uniqueId?: string;
    __jbrowsefmt?: Record<string, unknown>;
    mate?: {
        refName: string;
        start: number;
        end: number;
        [key: string]: unknown;
    };
    subfeatures?: SimpleFeatureSerializedNoId[];
}
export interface SimpleFeatureSerialized extends SimpleFeatureSerializedNoId {
    uniqueId: string;
}
export default class SimpleFeature implements Feature {
    private data;
    private subfeatures?;
    private parentHandle?;
    private uniqueId;
    constructor(args: SimpleFeatureArgs | SimpleFeatureSerialized);
    get(name: 'refName'): string;
    get(name: 'name' | 'type' | 'id' | 'source'): string | undefined;
    get(name: 'start' | 'end'): number;
    get(name: 'phase'): 0 | 1 | 2 | undefined;
    get(name: 'strand'): -1 | 0 | 1 | undefined;
    get(name: 'score'): number | undefined;
    get(name: 'subfeatures'): Feature[] | undefined;
    get(name: string): unknown;
    tags(): string[];
    id(): string;
    parent(): Feature | undefined;
    children(): Feature[] | undefined;
    toJSON(): SimpleFeatureSerialized;
    static fromJSON(json: SimpleFeatureSerialized): SimpleFeature;
}
