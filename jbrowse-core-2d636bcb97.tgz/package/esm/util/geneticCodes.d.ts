export interface NcbiGeneticCode {
    id: number;
    name: string;
    ncbieaa: string;
    sncbieaa: string;
}
export declare const ncbiGeneticCodes: NcbiGeneticCode[];
export interface GeneticCode {
    id: number;
    name: string;
    codonTable: Record<string, string>;
    starts: string[];
}
export declare function parseTranslTable(value: unknown): number | undefined;
export interface TranslExcept {
    start: number;
    end: number;
    aa: string;
}
export declare function parseTranslExcept(value: unknown): TranslExcept[];
export declare function relativizeTranslExcept({ raw, featureStart, featureLength, strand, }: {
    raw: unknown;
    featureStart: number;
    featureLength: number;
    strand?: number;
}): TranslExcept[];
export declare function getGeneticCode(id?: number): GeneticCode;
