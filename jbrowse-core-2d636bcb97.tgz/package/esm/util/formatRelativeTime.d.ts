export declare function formatRelativeTime(date: Date | number, now?: number): string;
