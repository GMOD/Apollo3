export declare const BEZIER_CONNECTOR_MAX_REACH_PX: number;
export declare function bezierConnectorPath({ x1, y1, x2, y2, s1, s2, leadingEnd2, reversed1, reversed2, maxHandlePx, dip, }: {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
    s1: number;
    s2: number;
    leadingEnd2?: boolean;
    reversed1?: boolean;
    reversed2?: boolean;
    maxHandlePx?: number;
    dip?: boolean;
}): string;
