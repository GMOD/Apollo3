export declare function fetchJson<T = unknown>(url: string, init?: RequestInit): Promise<T>;
