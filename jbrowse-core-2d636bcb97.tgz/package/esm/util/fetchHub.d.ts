export interface HubConfig {
    assemblies?: Record<string, unknown>[];
    aggregateTextSearchAdapters?: Record<string, unknown>[];
    tracks?: Record<string, unknown>[];
    [key: string]: unknown;
}
export declare function hubUrl(hub: string): string;
export declare function fetchHub(hub: string): Promise<HubConfig>;
