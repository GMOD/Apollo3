export declare function getRelativeX(event: {
    clientX: number;
    target: EventTarget | null;
}, element: HTMLElement | null): number;
