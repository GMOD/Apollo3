import type { RpcResult } from './librpc.ts';
export declare function isRpcResult(value: unknown): value is RpcResult;
