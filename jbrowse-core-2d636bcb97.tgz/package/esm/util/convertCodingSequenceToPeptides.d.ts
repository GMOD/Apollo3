import type { TranslExcept } from './geneticCodes.ts';
export declare function translExceptProteinPositions({ cds, translExcept, }: {
    cds: {
        start: number;
        end: number;
        phase?: number;
    }[];
    translExcept?: TranslExcept[];
}): Set<number>;
export declare function convertCodingSequenceToPeptides({ cds, sequence, codonTable, starts, translExcept, }: {
    cds: {
        start: number;
        end: number;
        phase?: number;
    }[];
    sequence: string;
    codonTable: Record<string, string>;
    starts?: string[];
    translExcept?: TranslExcept[];
}): string;
