import type { Color } from './core.ts';
export declare const format: typeof formatHEXA;
export declare function formatHEXA(color: Color): string;
export declare function formatHEX(color: Color): string;
export declare function formatRGBA(color: Color): string;
export declare function toRGBA(color: Color): {
    r: number;
    g: number;
    b: number;
    a: number;
};
export declare function formatHSLA(color: Color): string;
export declare function toHSLA(color: Color): {
    h: number;
    s: number;
    l: number;
    a: number;
};
export declare function formatHWBA(color: Color): string;
export declare function toHWBA(color: Color): {
    h: number;
    w: number;
    b: number;
    a: number;
};
export declare function toGLrgb(color: Color): [number, number, number];
