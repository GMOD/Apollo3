import type { Color } from './core.ts';
export declare function alpha(color: Color, value: number): Color;
export declare function darken(color: Color, coefficient: number): Color;
export declare function lighten(color: Color, coefficient: number): Color;
export declare function blend(background: Color, overlay: Color, opacity: number, gamma?: number): number;
export declare function getLuminance(color: Color): number;
