import { Jexl } from '@jbrowse/jexl';
export default function JexlF(): Jexl;
