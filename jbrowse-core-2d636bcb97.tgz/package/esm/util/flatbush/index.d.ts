type TypedArrayConstructor = Int8ArrayConstructor | Uint8ArrayConstructor | Uint8ClampedArrayConstructor | Int16ArrayConstructor | Uint16ArrayConstructor | Int32ArrayConstructor | Uint32ArrayConstructor | Float32ArrayConstructor | Float64ArrayConstructor;
type FilterFn = (index: number, x0: number, y0: number, x1: number, y1: number) => boolean;
export default class Flatbush {
    numItems: number;
    nodeSize: number;
    byteOffset: number;
    ArrayType: TypedArrayConstructor;
    IndexArrayType: Uint16ArrayConstructor | Uint32ArrayConstructor;
    data: ArrayBuffer;
    minX: number;
    minY: number;
    maxX: number;
    maxY: number;
    private _levelBounds;
    private _boxes;
    private _indices;
    private _pos;
    private _queue;
    static from(data: ArrayBuffer, byteOffset?: number): Flatbush;
    constructor(numItems: number, nodeSize?: number, ArrayType?: TypedArrayConstructor, ArrayBufferType?: ArrayBufferConstructor, data?: ArrayBuffer, byteOffset?: number);
    add(minX: number, minY: number, maxX?: number, maxY?: number): number;
    finish(): void;
    search(minX: number, minY: number, maxX: number, maxY: number, filterFn?: FilterFn): number[];
    private _collectContained;
    neighbors(x: number, y: number, maxResults?: number, maxDistance?: number, filterFn?: (index: number) => boolean): number[];
}
export {};
