import type { Css, Cx } from './types.ts';
import type { EmotionCache } from '@emotion/cache';
export declare const createCssAndCx: (params: {
    cache: EmotionCache;
}) => {
    css: Css;
    cx: Cx;
};
export declare function createUseCssAndCx(params: {
    useCache: () => EmotionCache;
}): {
    useCssAndCx: () => {
        css: Css;
        cx: Cx;
    };
};
