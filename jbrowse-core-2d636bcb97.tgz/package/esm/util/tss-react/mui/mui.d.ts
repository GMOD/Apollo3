export declare const makeStyles: () => <RuleName extends string>(cssObjectByRuleNameOrGetCssObjectByRuleName: Record<RuleName, import("../types.ts").CSSObject> | ((theme: import("@mui/material").Theme) => Record<RuleName, import("../types.ts").CSSObject>)) => (_params?: unknown, muiStyleOverridesParams?: {
    props: {
        classes?: Record<string, string>;
    };
} | undefined) => {
    classes: Record<RuleName, string>;
    theme: import("@mui/material").Theme;
    css: import("../types.ts").Css;
    cx: import("../types.ts").Cx;
};
