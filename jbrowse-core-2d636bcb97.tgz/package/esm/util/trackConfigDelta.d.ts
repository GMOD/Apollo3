type Json = string | number | boolean | null | undefined | Json[] | {
    [key: string]: Json;
};
export declare function diffTrackConfig(base: Record<string, unknown>, edited: Record<string, unknown>): Record<string, unknown>;
export declare function mergeTrackConfig(base: Record<string, unknown>, delta: Record<string, unknown>): Record<string, unknown>;
export interface TrackConfigChange {
    path: string[];
    from: Json;
    to: Json;
}
export declare function flattenTrackConfigDelta(base: Record<string, unknown>, delta: Record<string, unknown>): TrackConfigChange[];
export {};
