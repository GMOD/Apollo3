export interface BasicFeature {
    end: number;
    start: number;
    refName: string;
}
export declare function mergeIntervals<T extends {
    start: number;
    end: number;
}>(intervals: T[], w?: number): T[];
export declare function gatherOverlaps<T extends BasicFeature>(regions: T[], w?: number): T[];
