export declare function blobToDataURL(blob: Blob): Promise<string>;
