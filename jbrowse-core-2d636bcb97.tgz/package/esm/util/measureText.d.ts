export declare function measureText(str: unknown, fontSize?: number): number;
