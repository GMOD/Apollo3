import type { FileLocation } from './types/index.ts';
export declare const adapterTypes: readonly ['IndexedFastaAdapter', 'BgzipFastaAdapter', 'FastaAdapter', 'TwoBitAdapter'];
export type AdapterType = (typeof adapterTypes)[number];
export declare const adapterLabels: Record<AdapterType, string>;
export interface FormState {
    adapterSelection: AdapterType;
    assemblyName: string;
    assemblyDisplayName: string;
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
    gziLocation: FileLocation;
    twoBitLocation: FileLocation;
    chromSizesLocation: FileLocation;
    refNameAliasesLocation: FileLocation;
    cytobandsLocation: FileLocation;
}
export declare function makeSetField(setForm: (update: (prev: FormState) => FormState) => void): <K extends keyof FormState>(key: K) => (value: FormState[K]) => void;
export declare function initialFormState(): FormState;
export declare function applyPrimaryFile(state: FormState, location: FileLocation): FormState;
export declare function applyTwoBitFile(state: FormState, location: FileLocation): FormState;
export declare function clearFormFields(state: FormState): FormState;
export declare function clearSequenceFiles(state: FormState): FormState;
export declare function getBaseAssemblyConfig(state: FormState): {
    name: string;
    displayName?: string | undefined;
    refNameAliases?: {
        adapter: {
            type: string;
            location: FileLocation;
        };
    } | undefined;
    cytobands?: {
        adapter: {
            type: string;
            cytobandLocation: FileLocation;
        };
    } | undefined;
};
export type AssemblyAdapter = {
    type: 'IndexedFastaAdapter';
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
} | {
    type: 'BgzipFastaAdapter';
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
    gziLocation: FileLocation;
} | {
    type: 'UnindexedFastaAdapter';
    fastaLocation: FileLocation;
} | {
    type: 'TwoBitAdapter';
    twoBitLocation: FileLocation;
    chromSizesLocation: FileLocation;
};
export type AssemblyConf = ReturnType<typeof getBaseAssemblyConfig> & {
    sequence: {
        type: 'ReferenceSequenceTrack';
        trackId: string;
        adapter: AssemblyAdapter;
    };
};
export declare function isBlank(location: FileLocation): boolean;
export declare function formHasSequence(form: FormState): boolean;
export declare function getAssemblyName(form: FormState): string;
export declare function isFormReady(form: FormState): boolean;
export declare function getFilename(location: FileLocation): string;
export declare function getAssemblyNameFromFilename(filename: string): string;
export declare function detectAdapterType(filename: string): AdapterType | undefined;
export type FileRole = 'fasta' | 'fastaGz' | 'fai' | 'gzi' | 'twoBit' | 'chromSizes' | 'cytobands' | 'refNameAliases';
export declare function classifyFilename(filename: string): FileRole | undefined;
export declare function classifyAssemblyFiles(locations: FileLocation[]): Partial<FormState>;
export declare function applyClassifiedFiles(state: FormState, locations: FileLocation[], keepName: boolean): FormState;
export declare function buildAssemblyConf(form: FormState, resolveFastaAdapter: (fastaLocation: FileLocation) => Promise<AssemblyAdapter> | AssemblyAdapter): Promise<AssemblyConf>;
export declare function urlTextToLocations(text: string): FileLocation[];
export type AdapterConfigResult = {
    kind: 'ready';
    adapter: AssemblyAdapter;
} | {
    kind: 'needsFastaIndex';
    fastaLocation: FileLocation;
};
export declare function getAdapterConfig({ adapterSelection, fastaLocation, faiLocation, gziLocation, twoBitLocation, chromSizesLocation, }: {
    adapterSelection: AdapterType;
    fastaLocation: FileLocation;
    faiLocation: FileLocation;
    gziLocation: FileLocation;
    twoBitLocation: FileLocation;
    chromSizesLocation: FileLocation;
}): AdapterConfigResult;
