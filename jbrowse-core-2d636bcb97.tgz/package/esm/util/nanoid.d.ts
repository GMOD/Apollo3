export declare const urlAlphabet = "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict";
export declare const random: (bytes: number) => Uint8Array<ArrayBuffer>;
export declare const customRandom: (alphabet: string, defaultSize: number, getRandom: (bytes: number) => Uint8Array) => (size?: number) => string;
export declare const customAlphabet: (alphabet: string, size?: number) => (size?: number) => string;
export declare const nanoid: (size?: number) => string;
