import type { RpcStatus } from './progress.ts';
import type { StopToken } from './stopToken.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
interface StatusReporter {
    setStatusMessage: (status?: RpcStatus) => void;
}
export interface ActiveFetch {
    stopToken: StopToken;
    isCurrent: () => boolean;
    statusCallback: (status: RpcStatus) => void;
}
export declare function createStopTokenRotation(self: IAnyStateTreeNode & StatusReporter): {
    begin(): ActiveFetch;
    dispose(): void;
};
export {};
