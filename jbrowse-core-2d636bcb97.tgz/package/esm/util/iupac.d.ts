export declare const IUPAC_MOTIF_REGEX: RegExp;
export declare function iupacToRegex(motif: string): string;
export declare function reverseComplementIupac(motif: string): string;
export declare function isPalindromic(motif: string): boolean;
