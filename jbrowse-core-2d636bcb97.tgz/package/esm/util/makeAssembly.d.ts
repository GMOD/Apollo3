export interface MakeAssemblyOptions {
    fastaUri: string;
    name?: string;
    faiUri?: string;
    gziUri?: string;
    aliases?: string[];
    refNameAliasesUri?: string;
}
export declare function isSequenceUri(uri: string): boolean;
export declare function assemblyNameFromUri(uri: string): string;
export declare function makeAssembly(opts: MakeAssemblyOptions): {
    name: string;
    aliases: string[];
    sequence: {
        type: string;
        trackId: string;
        adapter: {
            uri: string;
            faiLocation?: {
                uri: string;
            } | undefined;
            gziLocation?: {
                uri: string;
            } | undefined;
        };
    };
    refNameAliases?: {
        uri: string;
    } | undefined;
} | {
    name: string;
    aliases: string[];
    uri: string;
    refNameAliases?: {
        uri: string;
    } | undefined;
};
