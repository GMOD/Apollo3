export declare const MAX_ZOOM_RATE_PER_MS: number;
export declare const SCROLL_ZOOM_FACTOR_DIVISOR = 500;
export declare function wheelZoomAccum(normalizedDeltaY: number, isCtrlZoom: boolean): number;
export declare function getZoomNormalizer(deltaY: number): 25 | 75 | 150 | 500;
export declare function normalizeWheelDelta(delta: number, deltaMode: number, pageHeight?: number): number;
export declare function wheelFrameElapsedMs(now: number, lastRafTime: number | null): number;
export declare const ZOOM_ACTIVE_WINDOW_MS = 100;
export declare function isActivelyZooming(now: number, lastZoomTime: number | null): boolean;
export declare function applyZoomAccum(bpPerPx: number, zoomAccum: number, elapsedMs: number): number;
