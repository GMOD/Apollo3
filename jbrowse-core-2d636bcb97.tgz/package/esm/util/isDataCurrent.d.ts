export declare function isDataCurrent(loadedSignature: string | undefined, currentSignature: string | undefined): boolean;
