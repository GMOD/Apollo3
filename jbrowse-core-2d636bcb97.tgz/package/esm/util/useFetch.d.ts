export type FetchKey = string | readonly unknown[] | null | undefined | false;
interface FetchState<Data, Err> {
    data: Data | undefined;
    error: Err | undefined;
    isLoading: boolean;
}
interface UseFetchOptions<Data, Err> {
    onError?: (error: Err) => void;
    onSuccess?: (data: Data) => void;
}
interface UseFetchResponse<Data, Err> extends FetchState<Data, Err> {
    mutate: () => Promise<void>;
    isValidating: boolean;
}
export declare function mutate(key: FetchKey): Promise<void>;
export declare function useFetch<Data = unknown, Err = unknown>(key: FetchKey, fetcher: ((...args: any[]) => Promise<Data>) | null, options?: UseFetchOptions<Data, Err>): UseFetchResponse<Data, Err>;
export {};
