import type { ExportSvgDisplayOptions } from '../BaseLinearDisplay/types.ts';
import type { LinearGenomeViewModel } from '../LinearGenomeView/model.ts';
import type { SvgExportable } from '@jbrowse/core/svg/svgReady';
import type React from 'react';
/**
 * The minimum a display must expose to be exported through {@link
 * renderDisplaySvg}: the terminal-state trio from `SvgExportable` plus the
 * height its box occupies.
 */
export interface LgvSvgExportable extends SvgExportable {
    height: number;
}
/**
 * What the shell resolves for the body. `canvasWidth` is the load-bearing one:
 * see {@link renderDisplaySvg}.
 */
export interface LgvSvgBodyProps<M> {
    model: M;
    view: LinearGenomeViewModel;
    height: number;
    /**
     * The width the export paints at — `view.width`, deliberately NOT the
     * `view.trackWidthPx` a display's on-screen `renderState` carries.
     * `trackWidthPx` subtracts the 2px track outline, which the export doesn't
     * draw, and it is also the block scissor bound handed to `forEachClippedBlock`
     * — so painting an export at it clips the rightmost 2px column of content
     * inside a `view.width`-wide frame. `LinearMultiRowFeatureDisplay` shipped
     * exactly that bug. A body that reuses `model.renderState` must override
     * `canvasWidth` with this value.
     */
    canvasWidth: number;
    opts: ExportSvgDisplayOptions | undefined;
}
/**
 * The async shell every LGV display's `renderSvg` opens with: await readiness,
 * resolve the view geometry once, and mount the single terminal-state gate
 * around the display's own body.
 *
 * `Body` is a **component**, not a callback, and that is load-bearing:
 * `SvgChrome` renders `SVGErrorBox` / `SVGMessageBox` *instead of* its children
 * in a terminal state, so a body expressed as a component never runs there and
 * no `renderSvg` has to re-detect a terminal from empty or absent data. The
 * contract is documented in `agent-docs/reference/SVG_EXPORT.md`; this function
 * is where it is enforced rather than restated per display.
 *
 * ```tsx
 * export async function renderSvg(model: RenderSvgModel, opts?: ExportSvgDisplayOptions) {
 *   return renderDisplaySvg(model, opts, XxxSvgBody)
 * }
 *
 * function XxxSvgBody({ model, view, height, canvasWidth, opts }: LgvSvgBodyProps<RenderSvgModel>) {
 *   ...
 * }
 * ```
 */
export declare function renderDisplaySvg<M extends LgvSvgExportable>(model: M, opts: ExportSvgDisplayOptions | undefined, Body: React.ComponentType<LgvSvgBodyProps<M>>): Promise<React.ReactNode>;
