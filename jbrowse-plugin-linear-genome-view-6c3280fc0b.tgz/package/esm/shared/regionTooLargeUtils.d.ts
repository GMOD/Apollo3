/**
 * The span below which nothing gates: at this zoom a fetch is small enough that
 * a banner asking permission costs the user more than the download does. Lives
 * with the gate rather than on the view because the view never reads it — it is
 * a property of the gate, and `aboveForceLoadFloor` on `RegionTooLargeMixin` is
 * the only comparison against it (MAF's summary swap reads that getter, so the
 * threshold has one spelling).
 */
export declare const AUTO_FORCE_LOAD_BP = 20000;
export declare function getDisplayStr(totalBytes: number): string;
/**
 * Two byte numbers flow through this file. Both estimate how many bytes would
 * come over the wire if we fetched, and they differ only in WHICH SPAN of the
 * genome they cover:
 *
 * - `byteEstimate.bytes` — the adapter's estimate for the span that was on
 *   screen at the moment the estimate was taken. It never changes as you
 *   navigate, which is why it is stored alongside that span
 *   (`byteEstimate.measuredSpanBp`).
 * - `estimatedBytesForVisibleSpan` — the same estimate scaled to the span on
 *   screen right now, since bytes are roughly proportional to span. This one
 *   shrinks as you zoom in, which is what lets the banner release itself.
 *
 * The gate always compares `estimatedBytesForVisibleSpan` against the limit.
 */
export interface ByteEstimate {
    /**
     * The adapter's cheap index-only estimate, or undefined when it has none.
     * "Unmeasurable" rather than `0`, so the byte axis stays out of the verdict
     * instead of reading a zero as a measured value.
     */
    bytes: number | undefined;
    /** The span `bytes` covers — captured before the measurement round trip. */
    measuredSpanBp: number;
}
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
/**
 * Resolve the effective byte budget: the adapter's self-reported limit, else the
 * display's configured default. A non-positive adapter limit means "no opinion"
 * (e.g. htsget/no-index adapters report 0) and is skipped — without this guard a
 * 0 would gate every request as too-large, and a negative sentinel (-1) would
 * survive `|| undefined` (truthy) and do the same.
 *
 * Both inputs are read on the main thread (`gateByteLimit`), so the banner and
 * the worker budget resolve one number. There is deliberately no force-load tier:
 * force-load is a boolean "render this track regardless" (`byteGateExempt`), not
 * a raised ceiling — see agent-docs/reference/REGION_TOO_LARGE.md § Force-load.
 */
export declare function resolveByteLimit({ adapterFetchSizeLimit, configFetchSizeLimit, }: {
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number;
}): number;
/**
 * Produce `estimatedBytesForVisibleSpan` from a stored {@link ByteEstimate}, by
 * scaling from the span it covers to the span on screen now (`visibleBp`). This
 * is what makes the too-large verdict a pure function of the current view, so it
 * self-releases on zoom-in instead of a large zoomed-out estimate staying above
 * the limit forever and gating refetch. `tooLargeStatus` feeds the result to
 * `evaluateRegionTooLarge`.
 *
 * Undefined with no estimate, an unmeasurable one, or a zero span — keeping the
 * byte axis out of the verdict rather than comparing an unscaled (or infinite)
 * number against the budget.
 */
export declare function rescaleByteEstimateToVisibleSpan({ byteEstimate, visibleBp, }: {
    byteEstimate: ByteEstimate | undefined;
    visibleBp: number;
}): number | undefined;
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
}
export declare const NOT_TOO_LARGE: RegionTooLargeStatus;
/**
 * The comparison half of the verdict: which axis is over budget, and the banner
 * text for it. Bytes take precedence over density for both.
 *
 * Deliberately knows nothing about *whether* the gate applies — the
 * AUTO_FORCE_LOAD_BP floor, force-load and `alwaysRender` adapters all live in
 * `gateActive` on `RegionTooLargeMixin`, which is also what stops the pre-flight
 * RPC and the worker budgets. One place asks "may anything gate?", this one asks
 * "does it?".
 */
export declare function evaluateRegionTooLarge({ estimatedBytesForVisibleSpan, byteLimit, densityTooLarge, }: {
    estimatedBytesForVisibleSpan?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
}): RegionTooLargeStatus;
