import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * The RPC cache key both display families invalidate on: the display's
 * `rpcProps()` payload serialized to a string. Watched as the
 * `rpcPropsCacheKey` getter per-region (by `SettingsInvalidate`) and as a
 * `computed` in `installGlobalFetchAutorun` globally. `''` for a display with no
 * `rpcProps`.
 *
 * A string, because building the payload reads far more observables than it
 * returns and because a fresh object never compares equal. The corollary that
 * bites: a field whose distinct states serialize identically is a silently dead
 * cache axis — a class instance with no `toJSON` flattens to `{}`, and an
 * `undefined` value drops its key, so it can't be told from a sibling state that
 * also drops. Worked cases and the loop-trap consequence: ARCHITECTURE.md "the
 * cache key is the return value, not the reads".
 *
 * `rpcProps` is looked up dynamically rather than declared on either mixin's
 * public interface, so subclasses keep their narrow return types through MST's
 * `.views()` chains.
 */
export declare function serializeRpcProps(self: IAnyStateTreeNode & {
    rpcProps?: () => unknown;
}): string;
