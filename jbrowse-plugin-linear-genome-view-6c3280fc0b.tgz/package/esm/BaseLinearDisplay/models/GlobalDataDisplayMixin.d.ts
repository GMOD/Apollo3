import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
export type { FetchContext } from './FetchMixin.ts';
export { type GlobalFetchMixinType, default as GlobalFetchMixin, } from './GlobalFetchMixin.ts';
/**
 * Mixin for GPU displays that hold a single global (non-regional) dataset —
 * HiC contact matrix, LD triangle, variant matrix, etc.
 *
 * `GlobalFetchMixin` (the rendering-agnostic fetch foundation) + RenderLifecycleMixin
 * (attachRenderingBackend, renderNow, renderError, …) + the GPU `displayPhase`.
 *
 * Unlike MultiRegionDisplayMixin, it owns no per-region state and installs no
 * autoruns. Fetch triggering is left to the display's own afterAttach autorun so
 * each display can express its own trigger conditions (HiC: viewport change; LD:
 * viewport + showLDTriangle + etc). The shared skeleton of that autorun lives in
 * `installGlobalFetchAutorun` (below) — a display supplies only its own
 * `shouldFetch` gate + `fetch` action.
 *
 * #stateModel GlobalDataDisplayMixin
 * #displayFoundationDef One non-regional dataset with no per-region partitioning, plus the GPU render lifecycle. Installs no fetch autoruns; the display adds its own via `installGlobalFetchAutorun`.
 * #category display
 */
export default function GlobalDataDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<Omit<{}, never>, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
} & {
    readonly gateFoldedIntoFetch: boolean;
    readonly byteGateEnabled: boolean;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateVisibleBp: number | undefined;
} & {
    readonly derivedRegionTooLargeEnabled: boolean;
    readonly aboveForceLoadFloor: boolean;
    readonly byteGateExempt: boolean;
    readonly estimatedBytesForVisibleSpan: number | undefined;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
    resolvedByteLimit(): number | undefined;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
} & {
    setByteEstimate(estimate: import("../../index.ts").ByteEstimate): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: {
        isStale: () => boolean;
    }): Promise<boolean>;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
} & {
    readonly isLoading: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: import("./FetchMixin.ts").FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    reloadCounter: number;
} & {
    readonly dataCurrent: boolean;
    readonly svgReadyExtraTerminal: boolean;
} & {
    readonly svgReady: boolean;
} & {
    reload(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    /**
     * #getter
     * Same render-lifecycle precondition as MultiRegionDisplayMixin (overrides
     * `RenderLifecycleMixin`'s default-true hook): a global display's
     * `renderState` is still sized off view geometry (`totalWidthPx`,
     * `dynamicBlocks`), which throws before the view is measured. Gating the
     * autorun pair here keeps that out of every display's callbacks.
     */
    readonly canRender: boolean;
    /**
     * #getter
     * Whether this display paints a canvas in its current configuration.
     * Default true. Gates the pre-first-paint term of `displayPhase` below
     * (`rendersCanvas && !canvasDrawn`), so a display that can be toggled to
     * show a static non-canvas placeholder instead (LD with `showLDTriangle`
     * off renders an EmptyState, never a canvas) overrides this to false in
     * that state — otherwise the scrim would sit permanently over the
     * placeholder, since `canvasDrawn` never flips without a canvas.
     *
     * Why this is a hook and not inlined away: the pre-paint scrim decision
     * needs TWO facts — "nothing painted yet" (`!canvasDrawn`, on the model)
     * AND "this isn't a deliberate empty placeholder" — and only the display
     * knows the second. The alternative (render the placeholder OUTSIDE
     * `DisplayChrome` so there's no scrim to gate) was considered and rejected:
     * it would dispose/re-init the GPU backend on every toggle and move a
     * render path out of the shared chrome (see ADR-026). So the hook is
     * irreducible given LD's design — a future reader tempted to delete this
     * "single-override" getter must first move LD's EmptyState, or the scrim
     * regresses over the placeholder. Default lives here so the common case
     * (HiC, always a canvas) needs no override.
     */
    readonly rendersCanvas: boolean;
} & {
    /**
     * #getter
     * Same precedence as MultiRegionDisplayMixin (single-sourced in
     * `computeDisplayPhase`). A global display has no per-region staleness
     * axis, but it does have a pre-first-paint window: between component mount
     * and `isLoading` flipping true (on HiC that means the `CoreGetInfo`
     * round-trip its first fetch waits on). Mirror MultiRegion's `!isReady`
     * term with `!canvasDrawn` so the loading scrim shows immediately on open
     * instead of after that gap — gated by `rendersCanvas` so a display
     * showing a static non-canvas placeholder isn't stuck under it. Once
     * painted, `canvasDrawn` stays true through viewport/setting changes
     * (StaleViewportRescaleMixin keeps the last frame up during refetch), so
     * this adds no scrim on pan or zoom — those keep the existing `isLoading`
     * behavior. Reads `renderError` (RenderLifecycleMixin), which is why it
     * lives here, not in GlobalFetchMixin.
     */
    readonly displayPhase: DisplayPhase;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type GlobalDataDisplayMixinType = ReturnType<typeof GlobalDataDisplayMixin>;
interface GlobalFetchAutorunHost extends IAnyStateTreeNode {
    isMinimized: boolean;
    reloadCounter: number;
    rpcProps?: () => unknown;
}
/**
 * Install the fetch-trigger autorun for a `GlobalDataDisplayMixin` display.
 *
 * Unlike `MultiRegionDisplayMixin` (which installs its five fetch autoruns for
 * you), this mixin installs none — each global display owns its trigger. But
 * every global trigger shares the same skeleton: track the viewport,
 * minimize/expand, the `rpcProps()` cache key and `reloadCounter` so any of them
 * refires the fetch, then debounce. This helper owns that skeleton so a display
 * supplies only its own `shouldFetch` gate (reading — and thereby MobX-tracking —
 * its display-specific fetch inputs) and its `fetch` action.
 *
 * Runs through `autorunOnReadyView`, so the body never reads a throwing view
 * getter (`dynamicBlocks`, `width`) before the view is initialized, and
 * re-runs automatically once it is.
 *
 * `rpcProps()` loop hazard: unlike MultiRegion's `SettingsInvalidate` (which
 * clears data in a *separate, undelayed* autorun and so loops synchronously if
 * `rpcProps()` *returns* fetch-derived state — caught by `makeSettingsLoopGuard`),
 * this autorun reads the key and triggers `fetch()` in the *same* debounced body.
 * A fetch-derived value in the payload here loops on the async-fetch cadence
 * (refetch → commit → key changes → reschedule after `delay` → refetch), a slow
 * network thrash rather than a synchronous freeze, so a within-tick counter
 * cannot distinguish it from legitimate rapid interaction. The invariant is the
 * same: `rpcProps()` must return only user-controlled settings, never fetched
 * data (see ARCHITECTURE.md "rpcProps() loop trap").
 */
export declare function installGlobalFetchAutorun(self: GlobalFetchAutorunHost, opts: {
    shouldFetch: () => boolean;
    fetch: () => void;
    delay: number;
    name: string;
}): void;
