/**
 * Draws an ImageBitmap to a canvas element.
 * This is a shared utility for non-block-based displays that render
 * to a single canvas via RPC.
 *
 * @param canvas - The canvas element to draw to
 * @param imageData - The ImageBitmap to draw
 * @returns true if drawing was successful, false otherwise
 */
export declare function drawCanvasImageData(canvas: HTMLCanvasElement | null, imageData: ImageBitmap | undefined): boolean;
