import type { DisplayChromeOverlays } from './chromeOverlays.ts';
declare const plainChromeOverlays: DisplayChromeOverlays;
export default plainChromeOverlays;
