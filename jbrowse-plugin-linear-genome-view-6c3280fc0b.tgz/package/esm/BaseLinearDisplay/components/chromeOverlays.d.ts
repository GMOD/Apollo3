import type { TooLargeMessageModel } from '../../shared/TooLargeMessage.tsx';
import type { DisplayBackgroundProgressModel } from './DisplayBackgroundProgress.tsx';
import type { DisplayErrorBarModel } from './DisplayErrorBar.tsx';
import type { DisplayLoadingOverlayModel } from './DisplayLoadingOverlay.tsx';
import type { ComponentType } from 'react';
export interface DisplayChromeOverlays {
    /**
     * GPU/render-backend failure. A subtree-replacing terminal state: the canvas
     * unmounts and the backend disposes, so this owns the full display area.
     */
    RenderError: ComponentType<{
        error: unknown;
        onRetry: () => void;
        height: number;
    }>;
    /**
     * The byte gate tripped. Also subtree-replacing. Must offer `model.forceLoad`
     * or the region becomes unreachable for the rest of the session.
     */
    TooLarge: ComponentType<{
        model: TooLargeMessageModel;
    }>;
    /**
     * Fetch error, drawn *over* a live canvas rather than replacing it. Renders
     * null when `model.error` is unset -- the chrome mounts it unconditionally.
     */
    ErrorBar: ComponentType<{
        model: DisplayErrorBarModel;
    }>;
    /**
     * The loading scrim. `visible` is `displayPhase === 'loading'`; `immediate`
     * asks it to skip its anti-flash delay because nothing is painted yet.
     * Mounted unconditionally, so it must handle `visible === false` itself.
     */
    Loading: ComponentType<{
        model: DisplayLoadingOverlayModel;
        visible: boolean;
        immediate?: boolean;
    }>;
    /**
     * Status for work with no fetch behind it, while the phase is `ready`.
     * Mounted unconditionally; gates on `visible` itself.
     */
    BackgroundProgress: ComponentType<{
        model: DisplayBackgroundProgressModel;
        visible: boolean;
    }>;
}
