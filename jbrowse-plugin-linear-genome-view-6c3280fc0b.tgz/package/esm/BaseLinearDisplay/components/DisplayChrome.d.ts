import type { ChromeModel } from './DisplayChromeBase.tsx';
import type { DisplayChromeOverlays } from './chromeOverlays.ts';
import type { RenderLifecycleModel } from '@jbrowse/render-core/useRenderingBackend';
import type { ComponentPropsWithRef, ReactNode } from 'react';
export type { ChromeModel } from './DisplayChromeBase.tsx';
export declare const DisplayChromeOverlayProvider: import("react").Provider<DisplayChromeOverlays | undefined>;
/**
 * The chrome every in-tree GPU/Canvas2D display renders: `DisplayChromeBase`
 * with JBrowse's own MUI overlays bound in, unless a
 * `DisplayChromeOverlayProvider` above it says otherwise.
 *
 * All the behavior lives in `DisplayChromeBase` — see that file for the
 * `displayPhase` contract, the subtree-replacing terminal states, and the
 * canvas dispose/re-init lifecycle.
 *
 * Not an `observer`: it reads no observables, it only picks an overlay set and
 * forwards. The generic `<B>` threads through to `DisplayChromeBase`, which is
 * the observer.
 */
export default function DisplayChrome<B extends {
    dispose(): void;
}>(props: {
    model: ChromeModel & RenderLifecycleModel<B>;
    factory: (canvas: HTMLCanvasElement) => Promise<B>;
    children: (handle: {
        canvasRef: (node: HTMLCanvasElement | null) => void;
        canvas: HTMLCanvasElement | null;
    }) => ReactNode;
    testid?: string;
} & Omit<ComponentPropsWithRef<'div'>, 'children'>): import("react").JSX.Element;
