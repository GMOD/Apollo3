import type { LinearGenomeViewModel } from './model.ts';
/**
 * Autorun that handles the init state - navigating to initial location,
 * showing tracks, etc.
 */
export declare function setupInitAutorun(self: LinearGenomeViewModel): void;
/**
 * Sets up all afterAttach autoruns for the LinearGenomeView
 */
export declare function doAfterAttach(self: LinearGenomeViewModel): void;
