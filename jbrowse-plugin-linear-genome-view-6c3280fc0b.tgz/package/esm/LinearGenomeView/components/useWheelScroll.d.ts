import type { WheelZoomView } from '@jbrowse/core/util/wheelZoom';
import type React from 'react';
interface GenomeViewModel extends WheelZoomView {
    scrollZoom?: boolean;
}
export declare function useWheelScroll(ref: React.RefObject<HTMLDivElement | null>, model: GenomeViewModel): void;
export {};
