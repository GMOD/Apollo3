import type { AssemblyManager, ParsedLocString } from '@jbrowse/core/util';
import type { BaseBlock, ContentBlock } from '@jbrowse/core/util/blockTypes';
import type { Region } from '@jbrowse/core/util/types';
/**
 * Expand a region by a grow factor, adding padding on each side.
 *
 * @param start - region start coordinate
 * @param end - region end coordinate
 * @param grow - multiplier for expansion (e.g., 0.2 adds 20% padding on each
 * side)
 * @param minBound - minimum bound to clamp start to (default 0)
 * @param maxBound - maximum bound to clamp end to (default Infinity)
 * @returns object with expanded start and end coordinates
 */
export declare function expandRegion(start: number, end: number, grow: number, minBound?: number, maxBound?: number): {
    start: number;
    end: number;
};
/**
 * Generate tick positions for the overview scalebar. Anchors at the first neat
 * majorPitch multiple strictly inside the block so ticks land on round numbers
 * regardless of where the block starts/ends.
 */
export declare function makeOverviewTicks(start: number, end: number, bpPerPx: number, reversed?: boolean): {
    genomicCoord: number;
    offsetPx: number;
}[];
export interface Tick {
    type: 'major' | 'minor';
    base: number;
}
export declare function makeTicks(start: number, end: number, bpPerPx: number, emitMajor?: boolean, emitMinor?: boolean): Tick[];
/** A block's refName, or undefined for non-content (elided/padding) blocks. */
export declare function getBlockRefName(block: BaseBlock): string | undefined;
/**
 * For blocks in display order, returns whether each block's refName should be
 * labeled: true only for the first block of each run of same-refName regions,
 * so a refName is shown once instead of repeated at every region boundary (e.g.
 * collapsed introns produce many adjacent same-refName regions). Blocks whose
 * getRefName is undefined (non-content) map to false without breaking a run.
 */
export declare function showRefNameLabels<T>(blocks: T[], getRefName: (block: T) => string | undefined): boolean[];
/**
 * Index of the block carrying the "sticky" refName label pinned to the left
 * edge: the rightmost content block whose left edge has scrolled off the left of
 * the viewport, or the first content block when none have.
 */
export declare function stickyBlockIndex(blocks: BaseBlock[], offsetPx: number): number;
export interface ScalebarRefNameLabel {
    key: string;
    refName: string;
    displayedRegionIndex: number;
    transform: number;
    maxWidth: number;
    paddingLeft: number;
    text: string;
}
/**
 * Builds the refName labels drawn along the scalebar as plain data (no JSX): one
 * label per run of same-refName regions (deduped so collapsed introns don't
 * repeat the name) plus a "sticky" label pinned to the left edge naming the
 * refName under the viewport's left border. `prefix` (an assembly name, synteny
 * only) folds into the sticky label as "prefix:refName"; showPrefixFallback
 * flags that it must instead be drawn standalone because no sticky label carried
 * it (e.g. the leftmost region was too narrow to label).
 */
export declare function getScalebarRefNameLabels({ blocks, offsetPx, regionEndPx, prefix, }: {
    blocks: BaseBlock[];
    offsetPx: number;
    regionEndPx: Map<number, number>;
    prefix: string | undefined;
}): {
    labels: ScalebarRefNameLabel[];
    showPrefixFallback: boolean;
};
/**
 * Which reorder actions the refName-label menu should offer for the region at
 * `idx` of `numRegions`. The "far" moves are gated on there being a gap of more
 * than one between `idx` and the end — otherwise "Move to far left/right" would
 * target the same index as "Move left/right" and duplicate the entry.
 */
export declare function regionMoveActions(idx: number, numRegions: number): {
    canMoveLeft: boolean;
    canMoveRight: boolean;
    canMoveFarLeft: boolean;
    canMoveFarRight: boolean;
};
/**
 * The region reorderings offered by the refName-label menu, as pure list
 * transforms feeding setDisplayedRegions (which re-clamps bpPerPx/offsetPx for
 * the new region set).
 */
export declare function withRegionMoved(regions: Region[], from: number, to: number): Region[];
export declare function withRegionRemoved(regions: Region[], index: number): Region[];
export declare function withRegionReversed(regions: Region[], index: number): Region[];
/**
 * Whether a label occupying [leftPx, leftPx + labelWidth] fits within a block
 * of the given pixel width, used to skip tick labels that would be clipped at a
 * region edge (common with small collapsed-intron regions).
 */
export declare function labelFitsInBlock(leftPx: number, labelWidth: number, widthPx: number): boolean;
/** Font size of coordinate tick labels on the scalebar and overview scalebar. */
export declare const TICK_LABEL_FONT_SIZE = 11;
/**
 * On-screen width of a coordinate tick label: the text plus 2px of horizontal
 * padding on each side. Single-sourced so the HTML scalebar and the SVG export
 * agree on when a label is too wide to fit inside its block.
 */
export declare function tickLabelWidth(label: string): number;
/** Font size of the bold overview-scalebar refName label, drawn at the left
 * edge of its block. */
export declare const REF_NAME_LABEL_FONT_SIZE = 11;
/**
 * Horizontal space the overview refName label occupies at a block's left edge.
 * Overview tick labels use this to avoid drawing underneath the refName, which
 * otherwise collide when zoomed far out (ticks bunch up near the block start).
 */
export declare function overviewRefNameLabelWidth(refName: string): number;
/**
 * Coordinate labels drawn inside one overview-scalebar block: tick text plus its
 * x within the block. Labels that can't be drawn whole between the block's bold
 * refName label and its right edge are dropped by the same
 * tickLabelWidth/labelFitsInBlock test the main scalebar and SVG export use; if
 * fewer than MIN_OVERVIEW_TICK_LABELS survive, the block goes unnumbered.
 */
export declare function makeOverviewTickLabels({ block, bpPerPx, refNameLabelPx, }: {
    block: {
        start: number;
        end: number;
        reversed?: boolean;
        widthPx: number;
    };
    bpPerPx: number;
    refNameLabelPx: number;
}): {
    genomicCoord: number;
    offsetPx: number;
    label: string;
}[];
/**
 * A maximal run of adjacent staticBlocks that belong to one contiguous
 * displayed region. staticBlocks chop a region into ~800px chunks; merging them
 * back means a coordinate label sitting on an internal chunk boundary is no
 * longer clipped away by both neighbors (only genuine region edges clip).
 */
export interface BlockRun {
    offsetPx: number;
    widthPx: number;
    start: number;
    end: number;
    reversed: boolean;
}
export declare function groupContiguousBlocks(blocks: BaseBlock[]): BlockRun[];
/**
 * makeTicks plus each tick's pixel x within its block, accounting for reversed
 * regions. Single source of the tick→px formula shared by gridlines, the
 * scalebar coordinate labels, and SVG export so their positions can't drift.
 */
export declare function makeBlockTicks({ start, end, reversed, }: {
    start: number;
    end: number;
    reversed?: boolean;
}, bpPerPx: number, emitMajor?: boolean, emitMinor?: boolean): {
    type: 'major' | 'minor';
    base: number;
    x: number;
}[];
/**
 * Generate location objects for a set of parsed locstrings, which includes
 * translating the refNames to assembly-canonical refNames and adding the
 * 'parentRegion'
 *
 * Used by navToLocations and navToLocString
 *
 * @param regions - array of parsed location strings to generate locations for
 * @param assemblyManager - the assembly manager instance
 * @param assemblyName - optional assembly name to use for regions that don't
 * specify one
 * @param grow - optional multiplier to expand regions by (e.g., 0.2 adds 20%
 * padding on each side of the region). Useful for adding visual padding when
 * navigating to a feature
 */
export declare function generateLocations({ regions, assemblyManager, assemblyName, grow, }: {
    regions: ParsedLocString[];
    assemblyManager: AssemblyManager;
    assemblyName?: string;
    grow?: number;
}): Promise<{
    refName: string;
    start?: number;
    end?: number;
    reversed?: boolean;
    assemblyName: string;
    parentRegion: import("@jbrowse/core/assemblyManager/assembly").BasicRegion;
}[]>;
/**
 * Parses locString or space separated set of locStrings into location objects
 * Example inputs:
 * "chr1"
 * "chr1:1-100"
 * "chr1:1..100"
 * "chr1 chr2"
 * "chr1:1-100 chr2:1-100"
 * "chr1 100 200" equivalent to "chr1:1-100"
 *
 * Used by navToLocString
 */
export declare function parseLocStrings(input: string, assemblyName: string, isValidRefName: (str: string, assemblyName: string) => boolean): ParsedLocString[];
export declare function calculateVisibleLocStrings(contentBlocks: ContentBlock[]): string;
