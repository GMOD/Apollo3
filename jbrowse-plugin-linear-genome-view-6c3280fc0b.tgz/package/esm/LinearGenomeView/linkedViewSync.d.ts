import type { LinearGenomeViewModel } from './model.ts';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * The single source of truth for which LinearGenomeView actions can be
 * replayed across linked views. Keeping it here (rather than as loose string
 * arrays in each parent view) means the dispatch below stays exhaustive and a
 * typo can't silently produce a no-op sync.
 */
export type SyncableViewAction = 'horizontalScroll' | 'zoomTo' | 'showTrack' | 'toggleTrack' | 'hideTrack' | 'setTrackLabels' | 'setShowCenterLine';
interface LinkableViews {
    linkViews: boolean;
    views: LinearGenomeViewModel[];
}
/**
 * Install a middleware that, while `linkViews` is on, replays each listed
 * action onto every other sub-view so panning/zooming/track-toggling stays in
 * sync. Used by linear-comparative-view and breakpoint-split-view.
 */
export declare function installLinkedViewSync(self: IAnyStateTreeNode & LinkableViews, syncActions: readonly SyncableViewAction[]): void;
export {};
