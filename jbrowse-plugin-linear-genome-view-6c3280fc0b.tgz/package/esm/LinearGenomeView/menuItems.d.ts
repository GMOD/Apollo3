import type { LinearGenomeViewModel } from './model.ts';
import type { BpOffset } from './types.ts';
import type { MenuItem } from '@jbrowse/core/ui';
/**
 * Build the main view menu items
 */
export declare function buildMenuItems(self: LinearGenomeViewModel): MenuItem[];
/**
 * Build rubberband selection menu items. `launchItems` are the plugin-supplied
 * things a selection can start (`rubberBandLaunchMenuItems()`); they collect
 * under one "Launch" submenu so the menu stays three actions plus a group
 * however many plugins are loaded, and vanish entirely when none apply.
 */
export declare function buildRubberBandMenuItems(self: LinearGenomeViewModel, launchItems: MenuItem[]): MenuItem[];
/**
 * Build rubberband click menu items (single click on rubberband area)
 */
export declare function buildRubberbandClickMenuItems(self: LinearGenomeViewModel, clickOffset: BpOffset): MenuItem[];
