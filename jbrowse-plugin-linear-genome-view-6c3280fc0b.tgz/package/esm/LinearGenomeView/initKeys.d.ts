export declare function partitionLaunchKeys(spec: object): {
    init: Record<string, unknown>;
    viewProps: Record<string, unknown>;
    unknown: Record<string, unknown>;
};
