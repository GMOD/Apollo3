import type { PluginDefinition } from '@jbrowse/core/pluginDefinitions';
import type { IAnyStateTreeNode, IAnyType } from '@jbrowse/mobx-state-tree';
export interface DroppedSessionNode {
    type?: string;
    configuration?: string;
}
export declare function filterSessionInPlace(node: IAnyStateTreeNode, type: IAnyType, dropped?: DroppedSessionNode[]): DroppedSessionNode[];
export interface NonPortableLocation {
    locationType: string;
    name: string;
    trackId?: string;
    trackName?: string;
}
export interface WebPortabilityReport {
    nonPortable: NonPortableLocation[];
    portable: boolean;
}
export declare function analyzeWebPortability(snapshot: unknown): WebPortabilityReport;
export interface TrackSnapshot {
    trackId: string;
    [key: string]: unknown;
}
export interface WebExportInput {
    assemblies?: {
        name: string;
    }[];
    tracks?: TrackSnapshot[];
    plugins?: PluginDefinition[];
    connections?: unknown[];
    configuration?: {
        sourceConfigUrl?: string;
        webExportUrl?: string;
    };
    defaultSession?: Record<string, unknown>;
}
export interface HostedBaseConfig {
    assemblies?: {
        name: string;
    }[];
    tracks?: TrackSnapshot[];
    plugins?: PluginDefinition[];
    connections?: unknown[];
    configuration?: {
        shareURL?: string;
    };
    [key: string]: unknown;
}
export interface WebExportPlan {
    strategy: 'hostedConfigBase' | 'selfContained';
    configUrl?: string;
    webBaseUrl: string;
    session: Record<string, unknown>;
    droppedTracks: string[];
    blockingFiles: string[];
}
export declare function planWebExport(snapshot: WebExportInput, baseConfig?: HostedBaseConfig): WebExportPlan;
export declare const DEFAULT_WEB_BASE_URL = "https://jbrowse.org/code/jb2/latest/";
export declare function buildWebExportUrl(plan: WebExportPlan, sessionParam: string, options?: {
    password?: string;
    exportedFrom?: string;
}): string;
