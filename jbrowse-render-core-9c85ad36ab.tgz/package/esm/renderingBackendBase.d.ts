import type { GpuHal } from './hal/types.ts';
/**
 * What every rendering backend has, whatever its upload shape — the three
 * shape contracts (`PerRegionRenderingBackend`, `GlobalRenderingBackend`,
 * `KeyedRenderingBackend`) all extend this, and `useRenderingBackend` is
 * bounded by it.
 *
 * `setErrorHandler` is here rather than optional at the hook because it was
 * optional at the hook, and the three backends that then went without it —
 * alignments, dotplot and multi-LGV synteny, which allocate the largest vertex
 * buffers in the app — were the three whose over-limit allocations reached
 * nobody: the HAL reported "too much data to render on this GPU, zoom in", the
 * reporter's handler was null, and the view painted blank with a console line.
 * The displays had their error banners built and wired the whole time.
 *
 * Extending `GpuRenderingBackendBase` or `Canvas2DRenderingBackendBase` below
 * satisfies it, which is the intended way to get it.
 */
export interface RenderingBackend {
    /**
     * Route a HAL over-limit allocation to the display's `renderError`. Wired by
     * `useRenderingBackend` once the backend is live; a no-op on Canvas2D, which
     * allocates no GPU resources.
     */
    setErrorHandler(handler: (error: Error) => void): void;
    dispose(): void;
}
/**
 * Shared GPU-side state for every GPU rendering backend — both per-region
 * (`GpuPerRegionRenderingBackend`) and monolithic (`GpuGlobalRenderingBackend`).
 * Owns the `hal` reference and a pre-allocated uniform scratch `ArrayBuffer`
 * reused across frames to avoid per-frame GC churn. `dispose()` delegates to
 * the HAL. Subclasses add only their upload/render shape.
 */
export declare abstract class GpuRenderingBackendBase {
    protected hal: GpuHal;
    protected uniformData: ArrayBuffer;
    constructor(hal: GpuHal, uniformByteSize: number);
    setErrorHandler(handler: (error: Error) => void): void;
    dispose(): void;
}
/**
 * Shared Canvas2D-side state for every Canvas2D rendering backend — both
 * per-region (`Canvas2DPerRegionRenderingBackend`) and monolithic
 * (`Canvas2DGlobalRenderingBackend`). Owns the `canvas` and its 2D context
 * (constructor throws if unavailable). `dispose()` is a no-op since Canvas2D
 * holds no GPU resources. Subclasses add only their render shape and stub the
 * upload/prune hooks their interface requires (everything flows through the
 * model's data map at render time).
 */
export declare abstract class Canvas2DRenderingBackendBase {
    protected canvas: HTMLCanvasElement;
    protected ctx: CanvasRenderingContext2D;
    constructor(canvas: HTMLCanvasElement);
    setErrorHandler(_handler: (error: Error) => void): void;
    dispose(): void;
}
