import type { GpuHal, PipelineDescriptor } from './types.ts';
export declare class WebGPUHal implements GpuHal {
    private device;
    private canvas;
    private context;
    private regions;
    private descriptors;
    private pipelines;
    private passTextures;
    private passBindGroups;
    private layoutState;
    private alignedUniformSize;
    private uniformRingBuffer;
    private uniformStaging;
    private uniformSlot;
    private uniformOnlyBindGroup;
    private msaaTexture;
    private msaaView;
    private currentTextureView;
    private currentEncoder;
    private currentPass;
    private scissorRect;
    private viewportRect;
    private disposed;
    private oom;
    private constructor();
    static create(canvas: HTMLCanvasElement, descriptors: PipelineDescriptor[], uniformByteSize: number): Promise<WebGPUHal | null>;
    resize(width: number, height: number): void;
    private recreateMsaaTexture;
    setErrorHandler(handler: (error: Error) => void): void;
    uploadBuffer(regionKey: number, passId: string, data: ArrayBuffer | ArrayBufferView, count: number): void;
    /**
     * Bind group matching the pipeline layout of `passId`.
     *
     * Keyed on the pass being DRAWN, never on the buffer it draws from:
     * `drawPass(a, key, b)` runs pass `a`'s pipeline over pass `b`'s vertex
     * buffer, so the bind group has to match `a`'s layout. Caching it on the
     * (region, `b`) buffer entry instead bound `b`'s layout to `a`'s pipeline —
     * fine while every such pair happened to be uniform-only, a validation error
     * (and a dropped draw) the moment one side samples a texture.
     *
     * Nothing in a bind group varies per region either: it references the
     * HAL-wide uniform ring buffer plus the pass's own texture/sampler. So
     * uniform-only passes all share `uniformOnlyBindGroup`, and a textured pass
     * gets exactly one, cached until `uploadTexture` replaces its texture.
     * Returns undefined when a pass needs a texture that hasn't arrived yet;
     * drawPass skips those.
     */
    private getBindGroup;
    getBufferCount(regionKey: number, passId: string): number;
    private warnIfMidFrame;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    pruneRegions(active: Iterable<number>): void;
    beginUpload(): void;
    endUpload(): void;
    retainRegion(regionKey: number): void;
    uploadTexture(passId: string, data: Uint8Array, width: number, height: number): void;
    writeUniforms(data: ArrayBuffer): void;
    beginFrame(clearR: number, clearG: number, clearB: number, clearA?: number): void;
    drawPass(passId: string, regionKey: number, bufferPassId?: string): void;
    endFrame(): void;
    setScissor(x: number, y: number, w: number, h: number): void;
    clearScissor(): void;
    setViewport(x: number, y: number, w: number, h: number): void;
    clearViewport(): void;
    dispose(): void;
}
