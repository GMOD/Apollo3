/**
 * One field of a pass's **vertex input layout** — the map from bytes in the
 * packed instance buffer to an input the shader declares. Both HALs build from
 * it: WebGPU as a `GPUVertexBufferLayout` attribute, WebGL2 as a VAO pointer.
 * Emitted from the shader by codegen as `VERTEX_ATTRIBUTES`; never hand-written.
 */
export interface VertexAttributeLayout {
    name: string;
    components: number;
    type: 'float' | 'uint' | 'int';
    offsetBytes: number;
    integer: boolean;
}
export type BlendFactor = 'one' | 'src-alpha' | 'one-minus-src-alpha' | 'zero';
export type BlendState = {
    op?: 'add';
    srcFactor: BlendFactor;
    dstFactor: BlendFactor;
} | {
    op: 'max';
};
/**
 * One entry of a shader's GPU binding table, as the Slang codegen reflects it.
 *
 * `kind` is spelled the way WebGPU spells it so a consumer can build a
 * `createBindGroupLayout` entry from it directly. That is the point: the binding
 * indices used to be asserted by hand in three places that never consulted the
 * shader — this HAL's two hardcoded render layouts, and the LD compute driver's
 * own. A shader's `BINDINGS` export is the reflected truth, and `pnpm
 * gen:shaders` now refuses a render shader whose table is not one the HALs bind.
 */
export interface ShaderBinding {
    index: number;
    kind: 'uniform' | 'texture' | 'sampler' | 'storage' | 'read-only-storage';
    name: string;
}
export interface TextureBinding {
    textureBinding: number;
    samplerBinding: number;
    glTextureUnit: number;
    glUniformName: string;
    filter: 'linear' | 'nearest';
}
/**
 * A **pipeline state object (PSO)**: shaders, vertex input layout, blend state,
 * primitive topology and texture bindings, baked into one immutable
 * description. One of these compiles to exactly one `GPURenderPipeline`
 * (`webgpuHal`) or one linked program + VAO (`webgl2Hal`), up front at HAL
 * construction — never lazily mid-frame.
 *
 * `id` is the join key everything else calls a *pass*: `drawPass(id, …)` binds
 * this pipeline and issues one instanced draw, and the HAL's buffer registry is
 * keyed `(regionKey, id)`. That word does **not** mean WebGPU's render pass,
 * which is the `beginFrame`/`endFrame` bracket and happens once per frame.
 */
export interface PipelineDescriptor {
    id: string;
    wgslSource: string;
    glslVertex: string;
    glslFragment: string;
    instanceStride: number;
    verticesPerInstance: number;
    blend: boolean;
    blendState?: BlendState;
    vertexAttributes: readonly VertexAttributeLayout[];
    wgslFragmentEntry?: string;
    glslFragmentOverride?: string;
    topology?: 'triangle-list' | 'triangle-strip' | 'line-list';
    textures?: readonly [TextureBinding, ...TextureBinding[]];
    bindings?: readonly ShaderBinding[];
}
export interface GpuHal {
    resize(width: number, height: number): void;
    uploadBuffer(regionKey: number, passId: string, data: ArrayBuffer | ArrayBufferView, count: number): void;
    getBufferCount(regionKey: number, passId: string): number;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    pruneRegions(active: Iterable<number>): void;
    uploadTexture(passId: string, data: Uint8Array, width: number, height: number): void;
    writeUniforms(data: ArrayBuffer): void;
    beginFrame(clearR: number, clearG: number, clearB: number, clearA?: number): void;
    drawPass(passId: string, regionKey: number, bufferPassId?: string): void;
    endFrame(): void;
    setScissor(x: number, y: number, w: number, h: number): void;
    clearScissor(): void;
    setViewport(x: number, y: number, w: number, h: number): void;
    clearViewport(): void;
    setErrorHandler(handler: (error: Error) => void): void;
    dispose(): void;
}
