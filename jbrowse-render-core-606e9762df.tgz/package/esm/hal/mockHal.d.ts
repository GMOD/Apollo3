import type { GpuHal, PipelineDescriptor } from './types.ts';
export interface MockCall {
    method: string;
    args: unknown[];
}
interface MockBuffer {
    data: ArrayBufferLike;
    count: number;
}
export interface MockRect {
    x: number;
    y: number;
    w: number;
    h: number;
}
/**
 * One draw, with the state that was in force when it was issued — the clip, and
 * which `writeUniforms` it reads. `null` scissor/viewport means unclipped, the
 * full canvas, which is what both HALs owe after a `clearScissor` /
 * `clearViewport`.
 *
 * `uniformWrite` indexes {@link MockHal.getUniformWritesF32}, or is `-1` when
 * nothing has been written yet. It is here for the same reason the clip is:
 * uniforms are *state*, so "which values did this draw actually use" is a
 * question about the order of two methods, and a test asking it off `calls` has
 * to re-implement the pairing to find out.
 *
 * **The pairing is by adjacency, and the two HALs mean different things by
 * it.** `WebGPUHal` stages each write into a ring slot and binds slot
 * `uniformSlot - 1` — "whatever was written most recently" — while `WebGL2Hal`
 * does an immediate `bufferSubData` into one UBO. They agree only while a
 * renderer writes then draws, which is the convention every renderer in tree
 * follows and nothing enforces: batching the writes and then issuing the draws
 * is right on WebGL2 and Canvas2D and silently wrong on WebGPU. This field is
 * what lets a backend test pin its renderer's pairing.
 */
export interface MockDraw {
    passId: string;
    regionKey: number;
    bufferPassId: string | undefined;
    scissor: MockRect | null;
    viewport: MockRect | null;
    uniformWrite: number;
}
export declare class MockHal implements GpuHal {
    calls: MockCall[];
    private regions;
    private uniformWrites;
    private registered;
    /**
     * The clip each draw of the frame went out under — see {@link draws}.
     *
     * Scissor and viewport are the one part of the HAL contract a call log cannot
     * show. They are *state*: set once, they hold over every later draw until
     * changed, so "which columns did the mismatch pass actually paint into" is a
     * question about the order of two different methods, and a test asking it off
     * `calls` has to re-implement the state machine to find out.
     *
     * That is not hypothetical. `clearScissor` on WebGPU used to drop the stored
     * rect without re-issuing a full-canvas one, so every draw after it went on
     * being clipped to the previous block while WebGL2 drew them unclipped — right
     * on Canvas2D, right on WebGL2, wrong on WebGPU alone. Nothing in tree clears
     * mid-frame today, which is exactly why nothing caught it. Recording the
     * effective clip per draw is what makes that assertable at all.
     */
    private scissor;
    private viewport;
    private drawLog;
    constructor(passes: PipelineDescriptor[]);
    private record;
    errorHandler: ((error: Error) => void) | null;
    setErrorHandler(handler: (error: Error) => void): void;
    resize(width: number, height: number): void;
    uploadBuffer(regionKey: number, passId: string, data: ArrayBuffer | ArrayBufferView, count: number): void;
    getBufferCount(regionKey: number, passId: string): number;
    deleteBuffer(regionKey: number, passId: string): void;
    deleteRegion(regionKey: number): void;
    pruneRegions(active: Iterable<number>): void;
    uploadTexture(passId: string, data: Uint8Array, width: number, height: number): void;
    writeUniforms(data: ArrayBuffer): void;
    beginFrame(clearR: number, clearG: number, clearB: number, clearA?: number): void;
    drawPass(passId: string, regionKey: number, bufferPassId?: string): void;
    private assertRegistered;
    endFrame(): void;
    setScissor(x: number, y: number, w: number, h: number): void;
    clearScissor(): void;
    setViewport(x: number, y: number, w: number, h: number): void;
    clearViewport(): void;
    dispose(): void;
    private get lastUniforms();
    getLastUniformsF32(): Float32Array<ArrayBuffer> | null;
    getLastUniformsU32(): Uint32Array<ArrayBuffer> | null;
    getLastUniformsI32(): Int32Array<ArrayBuffer> | null;
    getUniformWritesF32(): Float32Array<ArrayBuffer>[];
    getUniformWritesU32(): Uint32Array<ArrayBuffer>[];
    getBuffer(regionKey: number, passId: string): MockBuffer | undefined;
    callsOf(method: string): MockCall[];
    /**
     * Every draw of the frame with the state it went out under, in order — the
     * answer to "which columns did this pass paint into" and "which uniforms did
     * it read", neither of which `callsOf('drawPass')` can give, because clip and
     * uniforms are state rather than arguments. `scissor: null` is unclipped;
     * `uniformWrite` indexes `getUniformWrites*`. See {@link MockDraw} for what
     * each is guarding.
     */
    draws(): MockDraw[];
    /**
     * The uniform bytes a recorded draw reads, as f32 — `draws()` joined to
     * `getUniformWritesF32()` for you, since doing it by hand at every call site
     * is how the index and the list drift apart. `null` when the draw preceded
     * any write, which is the case no renderer should rely on: WebGPU clamps it
     * to ring slot 0 and WebGL2 leaves the previous frame's UBO bound, so the two
     * backends disagree about what it even means.
     */
    uniformsOf(draw: MockDraw): Float32Array<ArrayBuffer> | null;
    reset(): void;
}
export {};
