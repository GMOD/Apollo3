/**
 * The track type each adapter's features are drawn by, from the `#trackType`
 * tag on its config schema. An adapter absent here has no tag, and the guessers
 * fall back to `FeatureTrack`.
 */
export declare const adapterTypesToTrackTypeMap: Record<string, string>;
