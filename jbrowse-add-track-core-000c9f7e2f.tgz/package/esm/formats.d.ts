/**
 * A sidecar file sits next to the data file at `${location}${suffix}`, unless it
 * is the index and the caller was handed one explicitly (`fromIndex`).
 */
export interface Sidecar {
    field: string;
    suffix: string;
    fromIndex?: boolean;
}
export type AdapterSpec = {
    kind: 'single';
    adapterType: string;
    locField: string;
} | {
    kind: 'indexed';
    adapterType: string;
    locField: string;
    suffix: string;
    indexType: 'BAI' | 'TBI';
} | {
    kind: 'sidecar';
    adapterType: string;
    locField: string;
    sidecars: Sidecar[];
} | {
    kind: 'anchors';
    adapterType: string;
    locField: string;
} | {
    kind: 'unsupported';
};
export interface FormatEntry {
    /**
     * Matched against the bare filename. Every regex in a list must match, which
     * is how a format identified by more than its extension is spelled. Absent
     * means the format is reachable only by naming its adapter type, because its
     * extension is indistinguishable from another format's.
     */
    regex?: RegExp | RegExp[];
    spec: AdapterSpec;
    /**
     * Track type for files matching this entry, where the adapter alone does not
     * decide it — a `.bedmethyl.gz` and a plain `.bed.gz` are both read by
     * `BedTabixAdapter` but drawn differently.
     */
    trackType?: string;
}
/**
 * Every file format the "Add track" flow knows, in first-match order.
 *
 * One table, two consumers: `@jbrowse/core`'s `Core-guessAdapterForLocation`
 * chain and `@jbrowse/cli`'s `add-track`. ADR-077.
 *
 * An entry here does not make a build able to open the format. Core guesses an
 * entry only when its adapter type is registered, so the plugin providing the
 * adapter is still what decides, and there is no second list to keep in step.
 *
 * Order matters only where two regexes can match the same name:
 * `.anchors.simple.gz` must precede `.anchors.gz`, and the tabix entries must
 * precede their plain counterparts.
 */
export declare const formats: FormatEntry[];
/**
 * The format `fileName` is, or — when `adapterHint` names an adapter type — that
 * adapter's format whatever the filename says. A hint always wins, which is what
 * lets the add-track form open a file the extension alone cannot identify.
 */
export declare function matchFormat(fileName: string, adapterHint?: string): FormatEntry | undefined;
/**
 * The track type to draw `adapterType` with, from its config schema's
 * `#trackType` tag. `fileName` is what distinguishes the formats that share an
 * adapter — a `.bedmethyl.gz` from a plain `.bed.gz` — so pass it when known.
 */
export declare function trackTypeForAdapter(adapterType: string, fileName?: string): string | undefined;
/**
 * The index spelling a location implies: htslib writes `.csi` in place of a
 * `.bai` or a `.tbi` for a reference over 512 Mb, and on request at any size.
 */
export declare function resolveIndexType(indexName: string | undefined, fallback: 'BAI' | 'TBI'): "BAI" | "CSI" | "TBI";
