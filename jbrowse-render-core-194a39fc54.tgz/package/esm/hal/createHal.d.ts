import type { GpuHal, PipelineDescriptor } from './types.ts';
export declare function createGpuHal(canvas: HTMLCanvasElement, passes: PipelineDescriptor[], uniformByteSize: number, failures?: unknown[]): Promise<GpuHal | null>;
