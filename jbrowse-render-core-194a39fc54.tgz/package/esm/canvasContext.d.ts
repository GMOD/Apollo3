/**
 * A `<canvas>` holds exactly **one** context kind for its whole lifetime. Once
 * `getContext('webgl2')` has succeeded on an element, `getContext('2d')` on that
 * same element returns `null` forever — not because Canvas2D is unavailable, but
 * because the element is spoken for. The browser gives no reason: every failure
 * mode of `getContext` is the same `null`.
 *
 * That collision is not hypothetical here. The HAL ladder (WebGPU → WebGL2 →
 * Canvas2D) picks a kind per backend init, and a **re-init on a reused element**
 * can pick a different one than last time — a WebGPU device loss where the
 * device can't be re-acquired drops to WebGL2, which then finds the canvas
 * already committed to `webgpu`. The remedy is a fresh element (`RenderCanvas`,
 * keyed on `useRenderingBackend`'s `canvasKey`), and the point of this module is
 * that the error *says so* instead of reporting "WebGL2 not supported" on a
 * machine that supports WebGL2 perfectly well.
 *
 * We track it ourselves because the platform offers no way to ask a canvas which
 * kind it holds. A `WeakMap` rather than a DOM attribute: nothing should be able
 * to observe or edit this from the outside, and a detached canvas must stay
 * collectable.
 */
export type CanvasContextKind = 'webgpu' | 'webgl2' | '2d';
/**
 * Record that `canvas` is now permanently committed to `kind`. Call on every
 * **successful** `getContext`, in every HAL and every Canvas2D backend — a kind
 * that isn't recorded is one the diagnosis below can't name, and it will fall
 * back to the vaguer message.
 */
export declare function noteCanvasContext(canvas: HTMLCanvasElement, kind: CanvasContextKind): void;
/** The kind this canvas is committed to, if we were the ones who took it. */
export declare function acquiredCanvasContext(canvas: HTMLCanvasElement): CanvasContextKind | undefined;
/**
 * `getContext('2d')` + null-check + bookkeeping, as one call. Every Canvas2D
 * backend hand-wrote that ritual with the same bare message, which is four
 * copies of a diagnosis to keep in step — and three of them belong to the two
 * consumers whose canvas *never* unmounts (dotplot, the synteny level), i.e.
 * exactly where a reused element is reachable.
 */
export declare function acquireCanvas2D(canvas: HTMLCanvasElement): CanvasRenderingContext2D;
/**
 * The error to throw when `getContext(requested)` returned null.
 *
 * Keeps each caller's historical message as the first clause (`Canvas 2D context
 * not available`, and tests match on it) and appends the *reason*, which is the
 * part that was missing: either "this element is already committed to X" — the
 * recoverable case, with the remedy named — or an honest statement of the two
 * possibilities when we don't know.
 */
export declare function canvasContextError(canvas: HTMLCanvasElement, requested: CanvasContextKind): Error;
