export declare const MIN_DRAWN_ROW_PX = 1;
export declare const MIN_DRAWN_CELL_PX = 1;
