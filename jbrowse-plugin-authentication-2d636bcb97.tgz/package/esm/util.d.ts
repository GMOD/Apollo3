import type { UriLocation } from '@jbrowse/core/util/types';
export declare function validateTokenWithHEAD(token: string, location: UriLocation, init: RequestInit): Promise<string>;
export declare function getResponseError({ response, reason, statusText, }: {
    response: Response;
    reason?: string;
    statusText?: string;
}): Promise<string>;
export declare function getError(response: Response): Promise<string>;
