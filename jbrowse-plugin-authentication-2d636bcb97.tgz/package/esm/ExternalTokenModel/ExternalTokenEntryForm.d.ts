export declare const ExternalTokenEntryForm: ({ internetAccountId, handleClose, }: {
    internetAccountId: string;
    handleClose: (token?: string) => void;
}) => import("react").JSX.Element;
