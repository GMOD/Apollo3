export declare function HTTPBasicLoginForm({ internetAccountId, handleClose, }: {
    internetAccountId: string;
    handleClose: (arg?: string) => void;
}): import("react").JSX.Element;
