export interface OAuthWindowParams {
    internetAccountId: string;
    expectedState: string | undefined;
    exchangeAuthorizationCode: (code: string, redirectUri: string) => Promise<string>;
    storeToken: (token: string) => void;
}
export declare function parseOAuthError(text: string): {
    isInvalidGrant: boolean;
    statusText: string;
};
export declare function finishOAuthWindow(event: MessageEvent, params: OAuthWindowParams): Promise<string | undefined>;
export declare function waitForOAuthMessage(finish: (event: MessageEvent) => Promise<string | undefined>): Promise<string>;
