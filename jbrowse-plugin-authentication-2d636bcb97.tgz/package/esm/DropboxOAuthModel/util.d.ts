export declare function getDescriptiveErrorMessage(response: Response, reason?: string): Promise<string>;
