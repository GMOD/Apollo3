import type { SvgIconProps } from '@mui/material';
export default function DropboxIcon(props: SvgIconProps): import("react").JSX.Element;
