import Plugin from '@jbrowse/core/Plugin';
import { modelFactory as DropboxOAuthInternetAccountModelFactory } from './DropboxOAuthModel/index.ts';
import { modelFactory as ExternalTokenInternetAccountModelFactory } from './ExternalTokenModel/index.ts';
import { modelFactory as GoogleDriveOAuthInternetAccountModelFactory } from './GoogleDriveOAuthModel/index.ts';
import { modelFactory as HTTPBasicInternetAccountModelFactory } from './HTTPBasicModel/index.ts';
import { modelFactory as OAuthInternetAccountModelFactory } from './OAuthModel/index.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
export default class AuthenticationPlugin extends Plugin {
    name: string;
    exports: {
        OAuthConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "Bearer";
            };
            readonly authEndpoint: {
                readonly description: "the authorization code endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly tokenEndpoint: {
                readonly description: "the token endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly needsPKCE: {
                readonly description: "boolean to indicate if the endpoint needs a PKCE code";
                readonly type: "boolean";
                readonly defaultValue: false;
            };
            readonly clientId: {
                readonly description: "id for the OAuth application";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly scopes: {
                readonly description: "optional scopes for the authorization call";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly state: {
                readonly description: "optional state for the authorization call";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly responseType: {
                readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
                readonly type: "string";
                readonly defaultValue: "code";
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>;
        OAuthInternetAccountModelFactory: typeof OAuthInternetAccountModelFactory;
        ExternalTokenConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly validateWithHEAD: {
                readonly description: "validate the token with a HEAD request before using it";
                readonly type: "boolean";
                readonly defaultValue: true;
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>;
        ExternalTokenInternetAccountModelFactory: typeof ExternalTokenInternetAccountModelFactory;
        HTTPBasicConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "Basic";
            };
            readonly validateWithHEAD: {
                readonly description: "validate the token with a HEAD request before using it";
                readonly type: "boolean";
                readonly defaultValue: true;
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>;
        HTTPBasicInternetAccountModelFactory: typeof HTTPBasicInternetAccountModelFactory;
        DropboxOAuthConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly authEndpoint: {
                readonly description: "the authorization code endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "https://www.dropbox.com/oauth2/authorize";
            };
            readonly tokenEndpoint: {
                readonly description: "the token endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "https://api.dropbox.com/oauth2/token";
            };
            readonly needsPKCE: {
                readonly description: "boolean to indicate if the endpoint needs a PKCE code";
                readonly type: "boolean";
                readonly defaultValue: true;
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly ["addtodropbox.com", "db.tt", "dropbox.com", "dropboxapi.com", "dropboxbusiness.com", "dropbox.tech", "getdropbox.com"];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "Bearer";
            };
            readonly authEndpoint: {
                readonly description: "the authorization code endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly tokenEndpoint: {
                readonly description: "the token endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly needsPKCE: {
                readonly description: "boolean to indicate if the endpoint needs a PKCE code";
                readonly type: "boolean";
                readonly defaultValue: false;
            };
            readonly clientId: {
                readonly description: "id for the OAuth application";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly scopes: {
                readonly description: "optional scopes for the authorization call";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly state: {
                readonly description: "optional state for the authorization call";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly responseType: {
                readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
                readonly type: "string";
                readonly defaultValue: "code";
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>, undefined>>;
        DropboxOAuthInternetAccountModelFactory: typeof DropboxOAuthInternetAccountModelFactory;
        GoogleDriveOAuthConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly authEndpoint: {
                readonly description: "the authorization code endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "https://accounts.google.com/o/oauth2/v2/auth";
            };
            readonly scopes: {
                readonly description: "optional scopes for the authorization call";
                readonly type: "string";
                readonly defaultValue: "https://www.googleapis.com/auth/drive.readonly";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly ["drive.google.com"];
            };
            readonly responseType: {
                readonly description: "the type of response from the authorization endpoint";
                readonly type: "string";
                readonly defaultValue: "token";
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "Bearer";
            };
            readonly authEndpoint: {
                readonly description: "the authorization code endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly tokenEndpoint: {
                readonly description: "the token endpoint of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly needsPKCE: {
                readonly description: "boolean to indicate if the endpoint needs a PKCE code";
                readonly type: "boolean";
                readonly defaultValue: false;
            };
            readonly clientId: {
                readonly description: "id for the OAuth application";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly scopes: {
                readonly description: "optional scopes for the authorization call";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly state: {
                readonly description: "optional state for the authorization call";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly responseType: {
                readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
                readonly type: "string";
                readonly defaultValue: "code";
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly name: {
                readonly description: "descriptive name of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly description: {
                readonly description: "a description of the internet account";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly authHeader: {
                readonly description: "request header for credentials";
                readonly type: "string";
                readonly defaultValue: "Authorization";
            };
            readonly tokenType: {
                readonly description: "a custom name for a token to include in the header";
                readonly type: "string";
                readonly defaultValue: "";
            };
            readonly domains: {
                readonly description: "array of valid domains the url can contain to use this account";
                readonly type: "stringArray";
                readonly defaultValue: readonly [];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>, undefined>>;
        GoogleDriveOAuthInternetAccountModelFactory: typeof GoogleDriveOAuthInternetAccountModelFactory;
    };
    install(pluginManager: PluginManager): void;
}
export { configSchema as OAuthConfigSchema, modelFactory as OAuthInternetAccountModelFactory, } from './OAuthModel/index.ts';
export { configSchema as ExternalTokenConfigSchema, modelFactory as ExternalTokenInternetAccountModelFactory, } from './ExternalTokenModel/index.ts';
export { configSchema as HTTPBasicConfigSchema, modelFactory as HTTPBasicInternetAccountModelFactory, } from './HTTPBasicModel/index.ts';
export { configSchema as DropboxOAuthConfigSchema, modelFactory as DropboxOAuthInternetAccountModelFactory, } from './DropboxOAuthModel/index.ts';
export { configSchema as GoogleDriveOAuthConfigSchema, modelFactory as GoogleDriveOAuthInternetAccountModelFactory, } from './GoogleDriveOAuthModel/index.ts';
