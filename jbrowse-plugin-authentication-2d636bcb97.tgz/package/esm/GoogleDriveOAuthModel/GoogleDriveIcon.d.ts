import type { SvgIconProps } from '@mui/material';
export default function GoogleDriveIcon(props: SvgIconProps): import("react").JSX.Element;
