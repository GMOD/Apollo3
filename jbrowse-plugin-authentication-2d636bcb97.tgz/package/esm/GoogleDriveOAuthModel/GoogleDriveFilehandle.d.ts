import { RemoteFileWithRangeCache } from '@jbrowse/core/util/io';
import type { RequestInitWithMetadata } from './model.tsx';
import type { FilehandleOptions, Stats } from 'generic-filehandle2';
interface GoogleDriveFilehandleOptions extends FilehandleOptions {
    fetch(input: RequestInfo, opts?: RequestInitWithMetadata): Promise<Response>;
}
export declare class GoogleDriveFile extends RemoteFileWithRangeCache {
    private statsPromise;
    constructor(source: string, opts: GoogleDriveFilehandleOptions);
    fetch(input: RequestInfo, opts?: RequestInitWithMetadata): Promise<Response>;
    stat(): Promise<Stats>;
}
export {};
