import type { BpOffset, ExportSvgOptions, HighlightType, InitState, NavLocation, VolatileGuide } from './types.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
import type { MenuItem } from '@jbrowse/core/ui';
import type { ParsedLocString } from '@jbrowse/core/util';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
import type { BlockSet, ContentBlock } from '@jbrowse/core/util/blockTypes';
import type { Region } from '@jbrowse/core/util/types';
import type { ViewStatus } from '@jbrowse/core/util/viewStatus';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel LinearGenomeView
 * #category view
 *
 * #example
 * A `LinearGenomeView` is what you hand-author under `defaultSession.views`. The
 * `init` shorthand fills in `displayedRegions`/`bpPerPx`/`offsetPx` for you:
 * ```js
 * defaultSession: {
 *   name: 'My session',
 *   views: [
 *     {
 *       type: 'LinearGenomeView',
 *       // plain persisted props sit alongside init, not inside it
 *       colorByCDS: true,
 *       init: {
 *         assembly: 'hg38',
 *         loc: 'chr1:1,000,000-1,100,000',
 *         tracks: ['genes', 'alignments'],
 *       },
 *     },
 *   ],
 * }
 * ```
 * `init` holds only keys that need on-attach resolution — also `tracklist`,
 * `nav`, `highlight` (see the `init` property below). Plain view props like
 * `colorByCDS`, `showAminoAcids`, `showCenterLine`, `trackLabels`,
 * `showHighlightChips` are set
 * directly on the view (MST restores them natively).
 * At runtime the same model is driven imperatively — every property and action
 * below is reachable on `viewState.session.views[0]`:
 * ```js
 * const view = viewState.session.views[0]
 * await view.navToLocString('chr1:2,000,000-2,100,000')
 * view.showTrack('alignments')
 * view.zoomTo(view.bpPerPx * 2) // zoom out 2x
 * ```
 */
export declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "highlight" | "showHighlightChips"> & {
    highlight: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IType<HighlightType, HighlightType, HighlightType>>, [undefined]>;
    showHighlightChips: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "colorByCDS" | "displayedRegions" | "hideHeader" | "hideHeaderOverview" | "hideNoTracksActive" | "id" | "init" | "labelsVisible" | "legacyBpPerPx" | "scalebarOnly" | "showAminoAcids" | "showCenterLine" | "showCytobands" | "showGridlines" | "showTrackOutlines" | "trackLabels" | "trackSelectorType" | "tracks" | "type" | "windowStartBp" | "windowWidthBp"> & {
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
    windowStartBp: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    windowWidthBp: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    legacyBpPerPx: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    displayedRegions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Region[], Region[], Region[]>, [undefined]>;
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    hideHeader: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    hideHeaderOverview: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    hideNoTracksActive: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    trackSelectorType: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    showCenterLine: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showCytobands: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    trackLabels: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    showGridlines: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    labelsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    colorByCDS: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showAminoAcids: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showTrackOutlines: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    scalebarOnly: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    init: import("@jbrowse/mobx-state-tree").IType<InitState | undefined, InitState | undefined, InitState | undefined>;
}, {
    width: number;
    bodyMounted: boolean;
} & {
    readonly effectiveBodyMounted: boolean;
    menuItems(): MenuItem[];
} & {
    setDisplayName(name: string): void;
    setWidth(newWidth: number): void;
    setBodyMounted(flag: boolean): void;
    setMinimized(flag: boolean): void;
} & {
    addToHighlights(highlight: HighlightType): void;
    setHighlight(highlight?: HighlightType[]): void;
    removeHighlight(highlight: HighlightType): void;
    updateHighlight(old: HighlightType, updates: Partial<HighlightType>): void;
    setShowHighlightChips(arg: boolean): void;
} & {
    afterAttach(): void;
} & {
    /**
     * #volatile
     */
    volatileWidth: number | undefined;
    /**
     * #volatile
     */
    minimumBlockWidth: number;
    /**
     * #volatile
     */
    draggingTrackId: undefined | string;
    /**
     * #volatile
     */
    lastTrackDragY: undefined | number;
    /**
     * #volatile
     */
    volatileError: unknown;
    /**
     * #volatile
     */
    trackRefs: Record<string, HTMLDivElement>;
    /**
     * #volatile
     */
    coarseDynamicBlocks: ContentBlock[];
    /**
     * #volatile
     */
    coarseTotalBp: number;
    /**
     * #volatile
     */
    coarseBpPerPx: number;
    /**
     * #volatile
     */
    leftOffset: undefined | BpOffset;
    /**
     * #volatile
     */
    rightOffset: undefined | BpOffset;
    /**
     * #volatile
     */
    isScalebarRefNameMenuOpen: boolean;
    /**
     * #volatile
     */
    scalebarRefNameClickPending: boolean;
    /**
     * #volatile
     * temporary vertical guides that can be set by displays (e.g., LD display hover)
     */
    volatileGuides: VolatileGuide[];
} & {
    /**
     * #getter
     * corresponds roughly to the zoom level, base-pairs per pixel.
     *
     * Zero before a width is measured, which is the same not-yet-measured
     * sentinel `Base1DView` uses and which `displayedRegionsTotalPx` and the
     * offset getters already guard for. Reads `volatileWidth` rather than the
     * `width` getter on purpose: that one throws when unmeasured, and these
     * are read from the first render.
     */
    readonly bpPerPx: number;
    /**
     * #getter
     * corresponds roughly to the horizontal scroll of the LGV
     */
    readonly offsetPx: number;
    /**
     * #getter
     * scroll-to-zoom is a global, personal preference resolved from the
     * session; toggling it in any view applies everywhere
     */
    readonly scrollZoom: boolean;
    /**
     * #getter
     */
    readonly pinnedTracks: any[];
    /**
     * #getter
     */
    readonly unpinnedTracks: any[];
    /**
     * #getter
     * the effective track labels setting, resolving the stored `trackLabels`
     * against the LinearGenomeViewPlugin config default
     */
    readonly effectiveTrackLabels: any;
    /**
     * #getter
     */
    readonly width: number;
    /**
     * #getter
     * width minus track outline borders (1px each side when shown)
     */
    readonly trackWidthPx: number;
    /**
     * #getter
     */
    readonly assemblyNames: string[];
    /**
     * #getter
     */
    readonly assemblyDisplayNames: string[];
    /**
     * #getter
     * checking if lgv is a 'top-level' view is used for toggling pin track
     * capability, sticky positioning
     */
    readonly isTopLevelView: boolean;
    /**
     * #getter
     * only uses sticky view headers when it is a 'top-level' view and
     * session allows it
     */
    readonly stickyViewHeaders: boolean;
} & {
    /**
     * #getter
     * Assembly-name prefix for the scalebar refName labels, or undefined for
     * none. A container view (e.g. LinearSyntenyView) opts its sub-views in by
     * exposing showAssemblyNameInSubviewScalebar; duck-typed rather than
     * matching a concrete view type so no upward plugin dependency is needed
     * and any container can opt in. A wrong nesting depth simply yields no
     * prefix — hence the hasParent guard, since getParent throws (rather than
     * returning undefined) when the view sits shallower than depth 2.
     */
    readonly scalebarDisplayPrefix: string | undefined;
    /**
     * #getter
     */
    readonly assembliesNotFound: string | undefined;
    /**
     * #getter
     */
    readonly assemblyErrors: string;
    /**
     * #getter
     */
    readonly assembliesInitialized: boolean;
    /**
     * #getter
     * the assembly named by a pending `init`, or undefined when no init is
     * set. `init`'s assembly isn't in `assemblyNames` yet (that derives from
     * displayedRegions, still empty pre-navigation), so init-phase readiness
     * and error checks resolve it directly through here.
     */
    readonly initAssembly: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        statusSource: string | undefined;
        refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getAliasesForRefName(refName: string): string[];
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        statusSource: string | undefined;
        refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getAliasesForRefName(refName: string): string[];
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #getter
     */
    readonly initialized: boolean;
    /**
     * #getter
     */
    readonly hasDisplayedRegions: boolean;
    /**
     * #getter
     * The assembly whose load the spinner is waiting on: the one `init` names
     * before navigation (it isn't in assemblyNames yet), else the first of the
     * displayed assemblies that hasn't finished loading.
     */
    readonly loadingAssembly: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        statusSource: string | undefined;
        refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getAliasesForRefName(refName: string): string[];
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        statusSource: string | undefined;
        refNameMismatches: Map<string, import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch>;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
        setRefNameMismatch(adapterCacheKey: string, mismatch: import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly namesByCanonicalRefName: Map<string, string[]> | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getRegionForRefName(refName: string): import("@jbrowse/core/assemblyManager/assembly").BasicRegion | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getAliasesForRefName(refName: string): string[];
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
        getRefNameMismatch(adapterCacheKey: string): import("@jbrowse/core/assemblyManager/assembly").RefNameMismatch | undefined;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #getter
     * What the spinner says. The assembly reports which of its files it is
     * downloading, so this is "Downloading chromosome aliases" rather than a bare
     * "Loading" for the part of startup that actually takes time. Falls back
     * once the assembly is loaded and the remaining wait is the init autorun's
     * own navigation, which is local.
     */
    readonly loadingMessage: string | undefined;
    /**
     * #getter
     * Determinate fraction for the spinner's bar, when the assembly load
     * reports one (a whole-file download with a Content-Length)
     */
    readonly loadingProgress: number | undefined;
    /**
     * #getter
     * The URL the assembly load is currently fetching, when the phase named
     * one. Only the stalled-load notice reads it — see
     * {@link ViewLoadingScreen}.
     */
    readonly loadingSource: string | undefined;
    /**
     * #getter
     */
    readonly hasSomethingToShow: boolean;
    /**
     * #getter
     * init is set but its async navigation (the afterAttach autorun) hasn't
     * populated displayedRegions yet. `initialized` can already be true here
     * (it only tracks assembly readiness), so without this the container
     * would mount over empty regions and pxToBp/hover would throw.
     *
     * **Not dotplot's or synteny's `initPending`**, which is the bare
     * `!!self.init` — "an init blob has not been applied" — and which those
     * views read from their `settled` gate rather than from `showLoading`.
     * This one is narrower on purpose: it closes only the window where there
     * is nothing on screen. Once navigation has produced regions the view is
     * usable and gets shown, even though `init` is still set while the tracks
     * and highlights land. Renamed away from the shared spelling because the
     * two predicates disagree exactly there, and the bare name reads as
     * theirs.
     */
    readonly awaitingInitNavigation: boolean;
    /**
     * #getter
     * Whether to show a loading indicator instead of the import form or view
     */
    readonly showLoading: boolean;
    /**
     * #getter
     * Whether to show the import form
     */
    readonly showImportForm: boolean;
    /**
     * #getter
     * Is there anything to draw yet? The gate anything reading block geometry
     * — a ruler, a scalebar, a display — has to pass first, because
     * `width`/`staticBlocks` throw by design before the view has been
     * measured and navigated.
     *
     * **Not `initialized`**, which is the trap this getter exists to close.
     * That one answers "have the assembly's regions loaded", which is only
     * the first of two async steps: navigating then populates
     * `displayedRegions`, and in the window between the two `initialized` is
     * already true while there is still nothing on screen. `showLoading`
     * folds in `awaitingInitNavigation`, the getter that exists for exactly
     * that gap.
     *
     * `error` is the third outcome and is why this is not a bare
     * `!showLoading`: a failed assembly load also ends the loading state, so
     * that alone would mount over the wreckage. Read `error` yourself if you
     * want to draw it.
     */
    readonly ready: boolean;
    /**
     * #getter
     * The same question as `ready` with the other three outcomes named, for a
     * host that draws its own chrome and has to render all four. See
     * `computeViewStatus`, whose precedence this defers to — and note its
     * `ready` is narrower than the getter above, which is true when nothing
     * has told the view where to look.
     */
    readonly status: ViewStatus;
    /**
     * #getter
     */
    readonly scalebarHeight: number;
    /**
     * #getter
     * What TrackContainer puts *above* a track's rendering container: the gap
     * over its Paper, and the Paper's own top border when outlines are on.
     */
    readonly trackLeadingChrome: number;
    /**
     * #getter
     * ...and what it puts below: the resize divider, plus the matching bottom
     * border.
     */
    readonly trackTrailingChrome: number;
    /**
     * #getter
     * A track's full cost beyond its display height.
     *
     * The track *label* is not counted, and cannot be: an offset label is an
     * in-flow box whose height is whatever the theme renders a Paper of icon
     * buttons at — 31.140625px on the stock theme, and not a number this file
     * can derive. So these getters are exact while labels are hidden or
     * overlapping, and short by one label box per labelled track otherwise.
     * Anything needing the offset to the pixel with labels showing measures
     * the DOM; `BreakpointSplitViewOverlay` does, and falls back to this
     * arithmetic only for a track with no mounted div.
     */
    readonly trackChromeHeight: number;
    /**
     * #getter
     */
    readonly headerHeight: number;
    /**
     * #getter
     * Where the scalebar pins when the view's chrome is sticky: everything
     * stacked above it, which is the view's own title bar plus this view's
     * header. Expressed from `headerHeight` rather than re-summing its
     * constants — the two are the same box, and a second spelling of the sum
     * is free to drift from the first while both typecheck.
     */
    readonly rubberbandTop: number;
    /**
     * #getter
     */
    readonly pinnedTracksTop: number;
    /**
     * #method
     * rendered height of a single track, collapsing to a fixed height when
     * minimized. Shared by trackHeights and getTrackYOffset so the two can't
     * disagree. Reads `activeDisplay` — the display TrackContainer actually
     * mounts — rather than re-picking `displays[0]`, so the view's height math
     * can't diverge from what is on screen.
     */
    trackHeight(track: (import("@jbrowse/mobx-state-tree").IMSTArray<import("@jbrowse/mobx-state-tree").IAnyType> & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>>)[number]): any;
    /**
     * #getter
     */
    readonly trackHeights: number;
    /**
     * #getter
     */
    readonly trackHeightsWithChrome: number;
    /**
     * #getter
     */
    readonly height: number;
    /**
     * #method
     * Y offset (in pixels, from the top of the view) where a track's
     * rendering container starts. Walks tracks in DOM render order (pinned
     * first, then unpinned), from the same constants TrackContainer lays its
     * Paper out with. Returns `undefined` if the track is not present.
     *
     * Exact while track labels are hidden or overlapping. With an offset
     * label the answer is short by one label box per labelled track above
     * this one — see `trackChromeHeight` for why that box is not derivable
     * here.
     */
    getTrackYOffset(trackId: string): number | undefined;
    /**
     * #method
     * the pinned or unpinned sibling list a track renders within; move
     * up/down/top/bottom reorder inside this section rather than the full
     * `tracks` array, since the two sections lay out independently
     */
    trackSection(id: string): any[];
    /**
     * #getter
     */
    readonly totalBp: number;
    /**
     * #getter
     */
    readonly fitBpPerPx: number;
    /**
     * #getter
     * The zoom-out limit. This view's own fit, except while a container holds
     * it on a shared scale coarser than that — a small genome next to a large
     * one, drawn short so the two compare by length.
     *
     * Raising the LIMIT is what makes such a scale survive: written past the
     * limit instead, it is undone by the first thing that clamps — a wheel
     * tick, a rubberband, a `setDisplayedRegions` — which is how the dotplot's
     * locked aspect ratio once turned "zoom out" into a zoom in
     * (`axisMaxBpPerPx`). Here every route to a zoom clamps against the same
     * ceiling, so full zoom-out LANDS on the shared scale.
     */
    readonly maxBpPerPx: number;
    /**
     * #getter
     * The zoom-out ceiling a containing comparative view holds this row to,
     * or 0 for a standalone view, a mode that is off, and a stack that cannot
     * answer yet.
     *
     * Pulled rather than pushed down into a volatile: the number is a
     * function of every row's fit, all of which move on a resize, and a
     * stored copy would be stale by the next layout.
     */
    readonly sharedFitBpPerPx: number;
    /**
     * #getter
     */
    readonly minBpPerPx: number;
    /**
     * #getter
     */
    readonly error: unknown;
    /**
     * #getter
     */
    readonly maxOffset: number;
    /**
     * #getter
     */
    readonly minOffset: number;
    /**
     * #getter
     */
    readonly displayedRegionsTotalPx: number;
    /**
     * #getter
     */
    readonly trackMap: Map<string, any>;
    /**
     * #method
     */
    getTrack(id: string): any;
    /**
     * #method
     * displayId of the active (shown) display for a track in this view, used
     * by the config editor to expand the relevant display and collapse the
     * track's other displays
     */
    getActiveDisplayId(trackId: string): string | undefined;
} & {
    /**
     * #action
     */
    setShowTrackOutlines(arg: boolean): void;
    /**
     * #action
     */
    setScrollZoom(flag: boolean): void;
    /**
     * #action
     */
    setColorByCDS(flag: boolean): void;
    /**
     * #action
     */
    setShowAminoAcids(flag: boolean): void;
    /**
     * #action
     */
    setShowCytobands(flag: boolean): void;
    /**
     * #action
     */
    setWidth(newWidth: number): void;
    /**
     * #action
     */
    setError(error: unknown): void;
    /**
     * #action
     */
    setIsScalebarRefNameMenuOpen(isOpen: boolean): void;
    /**
     * #action
     */
    setScalebarRefNameClickPending(pending: boolean): void;
    /**
     * #action
     */
    setHideHeader(b: boolean): void;
    /**
     * #action
     */
    setHideHeaderOverview(b: boolean): void;
    /**
     * #action
     */
    setScalebarOnly(b: boolean): void;
    /**
     * #action
     */
    setHideNoTracksActive(b: boolean): void;
    /**
     * #action
     */
    setShowGridlines(b: boolean): void;
    /**
     * #action
     */
    setLabelsVisible(arg: boolean): void;
    /**
     * #action
     * set temporary vertical guides (e.g., for LD display hover)
     */
    setVolatileGuides(guides: VolatileGuide[]): void;
    /**
     * #action
     */
    scrollTo(offsetPx: number): number;
    /**
     * #action
     * `scrollTo`'s bp-space twin: place the window's left edge at a
     * linearized bp coordinate, clamped to the same scroll limits.
     *
     * It exists so a caller that already knows where it wants to be in bp —
     * zoomTo, anchoring the base under the cursor — does not have to convert
     * to pixels and let this convert back. That round trip is lossy once per
     * frame, and a scroll-zoom burst is a few dozen frames, which is enough
     * to walk the base out from under the cursor.
     */
    scrollToBp(startBp: number): number;
    /**
     * #action
     */
    zoomTo(bpPerPx: number, offset?: any): number;
    /**
     * #action
     * sets offsets of rubberband, used in the get sequence dialog can call
     * view.getSelectedRegions(view.leftOffset,view.rightOffset) to compute
     * the selected regions from the offsets
     */
    setOffsets(left?: BpOffset, right?: BpOffset): void;
    /**
     * #action
     */
    setSearchResults(searchResults: BaseResult[], searchQuery: string, assemblyName: string): void;
    /**
     * #action
     */
    showTrack(trackId: string, initialSnapshot?: any, displayInitialSnapshot?: any, inlineConf?: Record<string, unknown>): any;
    /**
     * #action
     */
    hideTrack(trackId: string): boolean;
} & {
    /**
     * #action
     */
    moveTrackDown(id: string): void;
    /**
     * #action
     */
    moveTrackUp(id: string): void;
    /**
     * #action
     */
    moveTrackToTop(id: string): void;
    /**
     * #action
     */
    moveTrackToBottom(id: string): void;
    /**
     * #action
     */
    moveTrack(movingId: string, targetId: string): void;
    /**
     * #action
     */
    toggleTrack(trackId: string): boolean;
    /**
     * #action
     */
    setTrackLabels(setting: 'overlapping' | 'offset' | 'hidden'): void;
    /**
     * #action
     */
    setShowCenterLine(b: boolean): void;
    /**
     * #action
     */
    activateTrackSelector(): import("@jbrowse/core/util").Widget;
    /**
     * #action
     */
    toggleTrackSelector(): import("@jbrowse/core/util").Widget;
    /**
     * #method
     * Helper method for the fetchSequence.
     * Retrieves the corresponding regions that were selected by the
     * rubberband
     *
     * @param leftOffset - `object as {start, end, index, offset}`, offset = start
     * of user drag
     * @param rightOffset - `object as {start, end, index, offset}`,
     * offset = end of user drag
     * @returns array of Region[]
     */
    getSelectedRegions(leftOffset?: BpOffset, rightOffset?: BpOffset): {
        assemblyName: string;
        refName: string;
        start: number;
        end: number;
    }[];
    /**
     * #action
     */
    horizontalScroll(distance: number): number;
    /**
     * #action
     */
    setDraggingTrackId(idx?: string): void;
    /**
     * #action
     */
    setLastTrackDragY(y: number): void;
    /**
     * #action
     * called while dragging a track over the track at `targetId`; reorders
     * once the cursor has moved far enough (see shouldSwapTracks) to avoid
     * jitter when a short track is dragged over a tall one
     */
    onTrackDragOver(targetId: string, currentY: number): void;
    /**
     * #action
     */
    setInit(arg?: InitState): void;
    /**
     * #method
     * creates an svg export and save using FileSaver
     */
    exportSvg(opts?: ExportSvgOptions): Promise<void>;
} & {
    slide: (viewWidths: number) => void;
    zoom: (targetBpPerPx: number) => void;
    cancelZoomAnimation: () => void;
} & {
    /**
     * #getter
     */
    readonly showsWholeChromosome: boolean;
    /**
     * #getter
     * an ideogram only reads correctly against an entire chromosome: on a
     * sub-region it is a meaningless slice of bands, and the centromere shows
     * up as a lone half-triangle
     */
    readonly canShowCytobands: boolean;
    /**
     * #getter
     * the `showCytobands` setting gated by whether cytobands can be shown at
     * all (whole chromosome + data present) — i.e. actually on screen
     */
    readonly effectiveShowCytobands: boolean;
    /**
     * #getter
     */
    readonly anyCytobandsExist: boolean;
    /**
     * #getter
     * the cytoband is displayed to the right of the chromosome name, and
     * that offset is calculated manually with this method
     */
    readonly cytobandOffset: number;
    /**
     * #getter
     */
    readonly isTrackSelectorOpen: boolean;
} & {
    /**
     * #method
     * return the view menu items
     */
    menuItems(): MenuItem[];
    /**
     * #method
     * what a plugin can start from the selected region — a synteny view, a
     * consensus call. Extend this rather than `rubberBandMenuItems` so the
     * entries collect under the menu's "Launch" submenu; that grouping is
     * decided once here rather than by whichever contributor runs first, and
     * keeps the rubberband menu itself short as plugins pile on.
     */
    rubberBandLaunchMenuItems(): MenuItem[];
    /**
     * #getter
     * geometry of the overview scalebar — derived from displayedRegions,
     * width, and cytobandOffset so it stays cached by MobX
     */
    readonly overviewLayout: ViewLayout;
} & {
    /**
     * #getter
     * static blocks are an important concept jbrowse uses to avoid
     * re-rendering when you scroll to the side. when you horizontally
     * scroll to the right, old blocks to the left may be removed, and new
     * blocks may be instantiated on the right. tracks may use the static
     * blocks to render their data for the region represented by the block
     */
    readonly staticBlocks: BlockSet;
    /**
     * #getter
     * dynamic blocks represent the exact coordinates of the currently
     * visible genome regions on the screen. they are similar to static
     * blocks, but static blocks can go offscreen while dynamic blocks
     * represent exactly what is on screen
     */
    readonly dynamicBlocks: BlockSet;
    /**
     * #getter
     * all overview scalebar blocks (content + elided), laid out on the
     * overviewLayout. memoized so the scalebar doesn't recompute it per
     * render
     */
    readonly overviewBlocks: import("@jbrowse/core/util/blockTypes").BaseBlock[];
    /**
     * #getter
     * leading/trailing pixel span of the visible regions projected onto the
     * overviewLayout — the geometry of the overview's "you are here"
     * rectangle, and of the top edge of the polygon drawn under it. Elided
     * regions count: at whole-genome zoom the tail of an assembly is all
     * coalesced tiny contigs, and stopping at the last *content* block left
     * the rectangle short of (or, scrolled onto that tail, absent from) the
     * polygon it sits on.
     */
    readonly overviewRegionPxSpan: import("@jbrowse/core/util/Base1DUtils").PxSpan | undefined;
    /**
     * #getter
     * Max right-edge pixel position for each displayedRegionIndex, derived
     * from staticBlocks geometry. staticBlocks caches a stable reference
     * when only offsetPx changes, so this getter is also stable during
     * normal scroll — avoiding a Map rebuild every frame.
     * Used by ScalebarRefNameLabels to clip chromosome name labels.
     */
    readonly scalebarRegionEndPx: Map<number, number>;
    /**
     * #getter
     * The x shift that maps the **staticBlocks frame** onto the viewport:
     * `translateX(view.staticBlocksTranslateX)` on one container places
     * every `gridlineTicks`, `scalebarLabels` and `paddingSpans` entry at
     * once, and a pan then moves that single transform rather than each
     * child.
     *
     * The frame exists because those three are laid out across every
     * displayed region rather than across the viewport — it overhangs on
     * both sides — so their `x` values are stable under a scroll and only
     * this number moves. `scalebarRefNameLabels` is the exception and says
     * so: its `transform` is already a screen x, because a sticky label's
     * position is a function of the scroll rather than of block geometry.
     *
     * **The subtraction must happen here, in float64, and that is the
     * load-bearing part.** `offsetPx` is a whole-genome pixel coordinate —
     * hg38 chr1 at base resolution is already past 1e10 — and a length that
     * size does not survive the trip through CSS: the transform matrix is
     * float32 by the time it reaches the compositor, where consecutive
     * representable values at 1e10 are ~1024px apart, and layout saturates
     * sooner still (Blink's `LayoutUnit` is int32 at 1/64px, so ±33.5M px).
     * So the shape that looks obvious — lay an overlay out in absolute
     * genome pixels, write `translateX(-view.offsetPx)` — does not lose a
     * subpixel, it puts the row somewhere else entirely, and only on large
     * assemblies at high zoom, which is not where anyone tests. Both
     * operands here are large and their difference is bounded by the
     * overhang (a block or two), so what reaches CSS is small and exact.
     * Same rule as the GPU side, one layer up —
     * `agent-docs/reference/BP_PRECISION.md`.
     *
     * Published because it is the one piece of coordinate arithmetic a host
     * drawing its own chrome would otherwise have to know, and because
     * having it written out at each call site is how the two in-tree copies
     * came to disagree about rounding. Round it where the content is text
     * (a fractional offset blurs a label); leave it alone for paths and
     * boxes.
     */
    readonly staticBlocksTranslateX: number;
    /**
     * #getter
     * Gridline tick positions (x relative to the staticBlocks frame),
     * derived from staticBlocks + bpPerPx. Computed once and shared by every
     * Gridlines instance (scalebar, main view, each pinned track) rather
     * than recomputing the makeTicks loop per component.
     */
    readonly gridlineTicks: {
        x: number;
        major: boolean;
    }[];
    /**
     * #getter
     * Scalebar coordinate labels (x in the staticBlocks frame + display
     * text). Sibling of gridlineTicks sharing the same makeBlockTicks
     * formula, so labels line up exactly with their gridlines. staticBlocks
     * chop a region into ~800px chunks; groupContiguousBlocks merges them
     * back per region so a label on an internal chunk boundary isn't clipped
     * away by both neighbors — only genuine region edges clip a label.
     *
     * A run that can hold too few labels to make a ruler goes unnumbered
     * (`tickLabelsWorthDrawing`), the same rule the overview scalebar and
     * the dotplot axes apply: with a whole genome displayed each chromosome
     * catches one lone coordinate, which conveys no scale by itself and
     * reads as the same number repeated across the row.
     */
    readonly scalebarLabels: {
        x: number;
        label: string;
        key: string;
    }[];
    /**
     * #getter
     * The bold refName labels drawn along the scalebar, as plain data:
     * `{key, refName, displayedRegionIndex, transform, maxWidth,
     * paddingLeft, text}` each. One per run of same-refName regions, plus a
     * "sticky" one pinned to the viewport's left edge naming the refName
     * under it, so panning into a chromosome does not scroll its own name
     * off the screen.
     *
     * Three rules live in here that a host drawing region names will
     * otherwise rediscover the hard way, and two of them are invisible until
     * the data is awkward:
     *
     * - the sticky label rides the rightmost block that has scrolled off the
     *   left, not the region's first block — that one is gone from
     *   staticBlocks entirely once you zoom into a region's interior, taking
     *   the chromosome name off screen at exactly the zoom where nothing
     *   else names it.
     * - adjacent regions of the same refName (collapsed introns) get one
     *   label between them, not one each.
     * - a name is drawn whole or not at all, measured against the space its
     *   region leaves. Clipped to its own width, `chr16` reads as `chr1` —
     *   a different chromosome rather than a shortened name, which is why
     *   this is a fit test rather than an ellipsis.
     *
     * **Viewport frame, unlike its siblings.** `transform` is a screen x,
     * already net of `offsetPx`, where gridlineTicks / scalebarLabels /
     * paddingSpans are all in the staticBlocks frame. The sticky label's
     * position is a function of `offsetPx` rather than of block geometry, so
     * it has no fixed position in that frame — and for the same reason this
     * getter recomputes on every scroll frame where those three do not.
     *
     * `showPrefixFallback` accompanies the labels for the assembly-name chip
     * a container view (synteny) can opt into; a plain LGV never sets a
     * prefix and always gets `false`. The SVG export deliberately calls
     * `getScalebarRefNameLabels` itself with no prefix rather than reading
     * this, since it draws its own assembly name above the ruler.
     */
    readonly scalebarRefNameLabels: {
        labels: import("./util.ts").ScalebarRefNameLabel[];
        showPrefixFallback: boolean;
    };
    /**
     * #getter
     * Every span along the row that is not track data, as plain geometry in
     * the staticBlocks frame — the same frame as gridlineTicks and
     * scalebarLabels, so one `translateX(staticBlocksTranslateX)` places all
     * three. Three kinds, and a host drawing its own chrome needs all of
     * them:
     *
     * - `seam`: the 3px bar at a region's right edge. Displayed regions are
     *   laid out **contiguously** — calculateStaticBlocks emits boundary
     *   padding only before the first region and after the last — so this
     *   bar is the only thing separating two of them. Without it a
     *   two-region view reads as a one-region view scrolled somewhere
     *   strange. `isRightEndOfDisplayedRegion` is what marks it;
     *   `scalebarRegionEndPx` looks like a shortcut for the same filter and
     *   is not one, being the right edge of the blocks currently *loaded*.
     * - `elided`: a region too narrow to draw at this zoom. Whole-genome on
     *   a real assembly is mostly these — hg38 has 455 sequences and all
     *   but the 24 chromosomes land sub-pixel — so a host that skips them
     *   renders that tail as nothing at all.
     * - `boundary`: past the start of the first region or the end of the
     *   last. Greying it is what makes the last region's seam read as the
     *   edge of a filled area rather than a rule floating in the track.
     *
     * Elided blocks get no seam even though they carry the flag: at the
     * zoom where regions elide, one bar per region is a solid grey wall.
     *
     * PaddingBlocks is the in-tree consumer. The SVG export is deliberately
     * NOT one: `SVGRegionSeparators` walks dynamicBlocks itself and draws
     * only the seam, because `elided` and `boundary` are chrome for an
     * interactive row rather than information a figure carries — striped
     * grey saying "regions here are too narrow to draw" is noise in a
     * static image, and at whole-genome zoom it would be most of the row.
     * The seam is the one that must survive: regions lay out contiguously,
     * so it is all that separates two of them.
     */
    readonly paddingSpans: {
        key: string;
        x: number;
        width: number;
        kind: 'seam' | 'elided' | 'boundary';
    }[];
    /**
     * #getter
     * Integer-rounded sum of all visible block widths. Slightly less than
     * view.width when the genome ends before the right edge; use view.width
     * for SVG clip rects (display boundary) and this for paint canvas sizing
     * (actual content width).
     */
    readonly totalWidthPx: number;
    /**
     * #getter
     * Like totalWidthPx but excluding inter-region boundary blocks. Used
     * when column layout divides the canvas width by feature count.
     */
    readonly totalWidthPxWithoutBorders: number;
    /**
     * #getter
     */
    readonly visibleBp: number;
    /**
     * #getter
     * Whether any part of a displayed region actually falls inside the
     * viewport. False both when the view holds no regions at all and when
     * it holds some but is scrolled entirely off them; either way there is
     * no visible span for the scalebar, ruler and refName labels to
     * describe, which is what the SVG export's header checks before drawing
     * one. Distinct from `hasDisplayedRegions`, which only asks whether the
     * view has been given regions, not whether any are on screen.
     */
    readonly hasVisibleContent: boolean;
    /**
     * #getter
     * Returns the currently visible content blocks with screen pixel
     * positions and displayedRegionIndex guaranteed.
     * Used by WebGL displays for per-region data fetching and rendering.
     */
    readonly visibleRegions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
        reversed: boolean | undefined;
        displayedRegionIndex: number;
        screenStartPx: number;
        screenEndPx: number;
    }[];
    /**
     * #getter
     * visibleRegions expanded by a half-screen buffer on each side,
     * clamped to displayedRegion bounds, with integer-rounded coordinates.
     * Use this when fetching data that should extend slightly beyond the
     * viewport for smooth scrolling.
     */
    readonly bufferedVisibleRegions: {
        region: {
            refName: string;
            start: number;
            end: number;
            assemblyName: string;
            reversed: boolean | undefined;
        };
        displayedRegionIndex: number;
    }[];
    /**
     * #getter
     * a single "combo-locstring" representing all the regions visible on
     * the screen
     */
    readonly visibleLocStrings: string;
    /**
     * #getter
     * **What a debounced consumer clips to**: the coarse blocks once the
     * view has settled at least once, the live ones before that.
     *
     * The coarse blocks exist so a per-bp scan does not recompute on every
     * animation frame during a pan or zoom — wiggle's autoscale domain, the
     * alignments coverage scale and MAF's coverage band are the three — and
     * while they are stale
     * the answer is merely a frame or two old, which is what the debounce
     * means. **Empty is different in kind.** A scan over no blocks yields no
     * entries, and no entries is not a stale domain, it is the fallback one:
     * `[0,1]`, which draws a line plot blank and a density plot saturated.
     * That window is the 500ms between a view initializing and the coarse
     * autorun's first run, and data can now land inside it — the per-region
     * fetch used to be trailing-edge at 600ms, so it never did.
     *
     * One recompute at that transition, against N per frame, which is the
     * trade the guard was making anyway.
     */
    readonly settledDynamicBlocks: ContentBlock[];
    /**
     * #getter
     * same as visibleLocStrings, but only updated every 500ms
     */
    readonly coarseVisibleLocStrings: string;
    /**
     * #getter
     */
    readonly coarseTotalBpDisplayStr: string;
    /**
     * #getter
     */
    readonly effectiveTotalBp: number;
    /**
     * #getter
     */
    readonly effectiveTotalBpDisplayStr: string;
} & {
    /**
     * #action
     */
    setCoarseDynamicBlocks(blocks: BlockSet, bpPerPx: number): void;
} & {
    /**
     * #action
     * Bring the coarse blocks to the viewport as it stands now, for a
     * placement that JUMPED rather than travelled.
     *
     * The coarse blocks are a 500ms throttle, and every consumer trades
     * freshness for not recomputing per animation frame — the location box,
     * canvas's on-screen feature set, and the two per-bp scans behind
     * `settledDynamicBlocks`. That trade is only sound while the answer is a
     * few frames old. **A jump makes it unrelated instead**, because there is
     * nothing to coalesce: the viewport left behind is not an approximation of
     * the new one, it is a different place. Unsettled, the location box reads
     * as a navigation that didn't happen, and wiggle's autoscale domain is
     * computed over the window the user just left — measured at `[0,200]`
     * against a correct `[0,300]` when a 40bp coarse window survived a jump to
     * 4040bp on screen. Only the per-region fetch moving to the leading edge
     * made that reachable: at 600ms the data never landed inside the hole.
     *
     * **The continuous paths deliberately do not come through here.** The
     * spring zoom writes through `zoomTo` per frame and a drag through
     * `scrollTo`, so this adds no per-frame work; the settle is idempotent
     * (`setCoarseDynamicBlocks` compares block keys), so the debounced
     * autorun's own follow-up run costs nothing.
     *
     * Every placer calls it, and `placersSettleCoarseBlocks.test.ts` is what
     * makes that true of the next one — it scans this file for the writes and
     * fails on a placer that reaches neither the settle nor its named list of
     * continuous paths. Two passes by hand missed four.
     */
    settleCoarseBlocks(): void;
} & {
    /**
     * #action
     * offset is the base-pair-offset in the displayed region, index is the
     * index of the displayed region in the linear genome view
     *
     * @param start - object as `{start, end, offset, index}`
     * @param end - object as `{start, end, offset, index}`
     */
    moveTo(start?: BpOffset, end?: BpOffset): void;
    /**
     * #action
     * Place the viewport by the pair of PIXEL quantities it used to be stored
     * as. Prefer `setWindow`: pixels mean nothing without the width they were
     * measured at, so a round trip through here is only exact while the width
     * holds still. Kept for callers that genuinely have pixels — a wheel
     * gesture, a rubberband — and for reading old snapshots.
     */
    setNewView(bpPerPx: number, offsetPx: number): void;
    /**
     * #action
     * Place the viewport by the pair it is actually STORED as: the window's
     * width and left edge, both in bp. `setNewView`'s bp-space twin, and the
     * right one for anything that captures a viewport and puts it back later
     * (an Undo, a saved location) — those two moments can be a window resize
     * apart, and this pair survives one where a pixel pair does not.
     *
     * Still clamped, by the same zoom and scroll limits as every other mover:
     * the regions may have changed under it, and a window the new set can't
     * hold is not restorable however it was spelled.
     */
    setWindow(windowWidthBp: number, windowStartBp: number): void;
    /**
     * #action
     * `setWindow` without the settle, for a writer that runs per animation
     * frame. Flushing the coarse blocks sixty times a second is the one thing
     * such a writer must not do: they are a 500ms throttle that a synteny
     * follow pass and two autoscale domains hang off, and settling each frame
     * turns each of those into per-frame work — `positionViewOnSpans` states
     * the same rule for the same reason.
     */
    setWindowFrame(windowWidthBp: number, windowStartBp: number): void;
    /**
     * #action
     * The worst jump of them to leave unsettled: the coarse blocks are keyed
     * by `displayedRegionIndex`, so a set that outlives the region list has a
     * consumer reading one contig's data against another's blocks.
     */
    setDisplayedRegions(regions: Region[]): void;
    /**
     * #action
     * Re-assert `maxBpPerPx` over the current zoom, for a container whose
     * shared ceiling just fell — otherwise the view is stranded above it with
     * zoom-out disabled and the slider's min past its value. Goes through
     * `zoomTo` so the clamp keeps one definition, and settles because a
     * ceiling drop moves the window in one step.
     *
     * Requires an `initialized` view; the caller checks, since an MST action
     * reads untracked and a guard here would never re-run once the row
     * arrived.
     */
    clampZoomToCeiling(): void;
    /**
     * #action
     */
    showAllRegions(): void;
    /**
     * #action
     * Fit the displayed regions to the width exactly, edge to edge.
     *
     * Not the same as `showAllRegions`, which goes to `maxBpPerPx` — the
     * zoom-out LIMIT, where `SHOW_ALL_REGIONS_FILL` deliberately keeps a 10%
     * margin so the whole genome doesn't sit flush against both edges. That
     * margin is right for "show me everything" and wrong for a caller that
     * named the regions it wants: it draws them at 1/0.9 of fit-to-width,
     * centered, which is a silent 11% scale difference from the
     * single-region path (`moveTo`, span/width) reached through the same
     * location box.
     *
     * The scale comes from `fitAllRegionsWindow`, which is where the rule is
     * written — a snapshot builder that cannot call an action needs the same
     * answer, and the two agreeing matters more than either being local. Where
     * it clamps up to `minBpPerPx` the content is narrower than the view, and
     * the centering is what frames it.
     */
    fitAllRegions(): void;
    /**
     * #action
     */
    horizontallyFlip(): void;
} & {
    /**
     * #action
     */
    showAllRegionsInAssembly(assemblyName?: string): void;
    /**
     * #action
     * this "clears the view" and makes the view return to the import form
     */
    clearView(): void;
    /**
     * #action
     * Navigate to a location based on its refName and optionally start, end,
     * and assemblyName. Will not try to change displayed regions, use
     * `navToLocations` instead. Only navigates to a location if it is
     * entirely within a displayedRegion. Navigates to the first matching
     * location encountered.
     *
     * Throws an error if navigation was unsuccessful
     *
     * @param query - a proposed location to navigate to
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navTo(query: NavLocation, grow?: number): void;
    /**
     * #action
     * Navigate to a location based on its refName and optionally start, end,
     * and assemblyName. Will not try to change displayed regions, use
     * navToLocations instead. Only navigates to a location if it is entirely
     * within a displayedRegion. Navigates to the first matching location
     * encountered.
     *
     * Throws an error if navigation was unsuccessful
     *
     * @param locations - proposed location to navigate to
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToMultiple(locations: NavLocation[], grow?: number): void;
} & {
    /**
     * #action
     * Replace the region list and place the viewport in one step. The pair is
     * the unit a coarse-block consumer can act on: called separately they
     * publish the viewport in between, and post-await in `navToLocations`
     * they are two transactions, so a per-bp scan runs over a window that was
     * never on screen.
     *
     * With no location named it fits the regions rather than going through
     * `showAllRegions`: the caller named the regions it wants, so it gets the
     * width, where showAllRegions goes to the zoom-out LIMIT and its 10%
     * margin is dead frame for a named subset.
     */
    showRegions(regions: Region[], location?: NavLocation): void;
} & {
    /**
     * #action
     * Navigate to the given locstring, will change displayed regions if
     * needed, and wait for assemblies to be initialized
     *
     * @param input - e.g. "chr1:1-100", "chr1:1-100 chr2:1-100", "chr 1 100"
     * @param optAssemblyName - (optional) the assembly name to use when
     * navigating to the locstring
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     * @returns whether the view moved. A multi-hit search raises the picker
     * instead of navigating, and both resolve — see `handleSelectedRegion`.
     */
    navToLocString(input: string, optAssemblyName?: string, grow?: number): Promise<boolean>;
    /**
     * #action
     * Similar to `navToLocString`, but accepts a list of parsed location
     * objects instead of a locstring. Will try to perform
     * `setDisplayedRegions` if changing regions
     *
     * @param regions - array of parsed location objects
     * @param assemblyName - optional assembly name
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToLocations(regions: ParsedLocString[], assemblyName?: string, grow?: number): Promise<void>;
} & {
    /**
     * #action
     * Similar to `navToLocString`, but accepts a parsed location object
     * instead of a locstring. Will try to perform `setDisplayedRegions` if
     * changing regions
     *
     * @param parsedLocString - a parsed location object with refName, start,
     * end, etc.
     * @param assemblyName - optional assembly name
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToLocation(parsedLocString: ParsedLocString, assemblyName?: string, grow?: number): Promise<void>;
} & {
    /**
     * #method
     */
    rubberBandMenuItems(): MenuItem[];
    /**
     * #method
     */
    bpToPx({ refName, coord, displayedRegionIndex, }: {
        refName: string;
        coord: number;
        displayedRegionIndex?: number;
    }): {
        index: number;
        offsetPx: number;
    } | undefined;
    /**
     * #method
     * Map a highlight or bookmark region to its pixel position+width inside
     * the tracks container. Falls back to the raw refName if the region's
     * assemblyName is missing or unknown so highlights authored without an
     * assembly still render in single-assembly views.
     */
    getHighlightCoords(region: {
        assemblyName?: string;
        refName: string;
        start: number;
        end: number;
    }): {
        width: number;
        left: number;
    } | undefined;
    /**
     * #method
     * like getHighlightCoords but laid out against the overview scalebar and
     * shifted by the cytoband offset
     */
    getOverviewHighlightCoords(region: {
        assemblyName?: string;
        refName: string;
        start: number;
        end: number;
    }): {
        width: number;
        left: number;
    } | undefined;
    /**
     * #method
     * scrolls the view to center on the given bp. if that is not in any of
     * the displayed regions, does nothing
     *
     * @param coord - basepair at which you want to center the view
     * @param refName - refName of the displayedRegion you are centering at
     * @param displayedRegionIndex - index of the displayedRegion
     */
    centerAt(coord: number, refName: string, displayedRegionIndex?: number): void;
    /**
     * #method
     */
    pxToBp(px: number): import("@jbrowse/core/util/Base1DUtils").PxToBpResult;
    /**
     * #getter
     */
    readonly centerLineInfo: import("@jbrowse/core/util/Base1DUtils").PxToBpResult | undefined;
} & {
    /**
     * #method
     */
    rubberbandClickMenuItems(clickOffset: BpOffset): MenuItem[];
    /**
     * #method
     * returns menu items for a highlight context menu. plugins can extend
     * this via Core-extendPluggableElement to add their own items
     */
    highlightMenuItems(_highlight: HighlightType): MenuItem[];
} & {
    flyTo: (centerBp: number, windowWidthBp: number) => void;
    /**
     * #action
     * `centerAt`'s animated twin: the same destination, reached along the
     * arc instead of jumped to, at the zoom the view is already on.
     */
    flyToCenter(coord: number, refName: string): void;
} & {
    afterCreate(): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, {
    displayName: string | undefined;
    minimized: boolean;
    highlight: HighlightType[];
    showHighlightChips: boolean;
    id: string;
    type: string;
    windowStartBp: number;
    windowWidthBp: number;
    legacyBpPerPx: number;
    displayedRegions: Region[];
    tracks: any[];
    hideHeader: boolean;
    hideHeaderOverview: boolean;
    hideNoTracksActive: boolean;
    trackSelectorType: string;
    showGridlines: boolean;
    labelsVisible: boolean;
    scalebarOnly: boolean;
    init?: InitState | undefined;
    showCytobands?: false | undefined;
    trackLabels?: string | undefined;
    colorByCDS?: true | undefined;
    showAminoAcids?: false | undefined;
    showTrackOutlines?: false | undefined;
}>;
export type LinearGenomeViewStateModel = ReturnType<typeof stateModelFactory>;
export type LinearGenomeViewModel = Instance<LinearGenomeViewStateModel>;
declare module '@jbrowse/core/PluginManager' {
    interface ViewTypeRegistry {
        LinearGenomeView: LinearGenomeViewStateModel;
    }
}
