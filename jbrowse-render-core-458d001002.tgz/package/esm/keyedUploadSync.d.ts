interface KeyedUploadTarget<T> {
    uploadGeometry(key: number, data: T): void;
    deleteGeometry(key: number): void;
}
export declare function createKeyedUploadSync<T, B extends KeyedUploadTarget<T>>(): (backend: B, entries: ReadonlyMap<number, T>) => void;
export {};
