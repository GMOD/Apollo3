export declare function createGlobalUploadSync<B>(): <T>(backend: B, key: string, value: T, upload: (backend: B, value: T) => void) => void;
