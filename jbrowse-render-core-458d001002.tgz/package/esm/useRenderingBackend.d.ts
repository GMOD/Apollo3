export declare function createGpuContextLostError(): Error & {
    gpuContextLost: true;
};
export declare function isGpuContextLostError(error: unknown): error is object & Record<"gpuContextLost", unknown>;
export interface RenderLifecycleModel<RenderingBackendType> {
    startRenderingBackend: (backend: RenderingBackendType) => void;
    stopRenderingBackend: () => void;
    renderNow: () => void;
    renderError: unknown;
    setRenderError: (error: unknown) => void;
}
export declare function useRenderingBackend<RenderingBackendType extends {
    dispose(): void;
    setErrorHandler?: (handler: (error: Error) => void) => void;
}>(factory: (canvas: HTMLCanvasElement) => Promise<RenderingBackendType>, model: RenderLifecycleModel<RenderingBackendType>): {
    canvas: HTMLCanvasElement | null;
    canvasRef: (node: HTMLCanvasElement | null) => void;
    error: unknown;
    retry: () => void;
    canvasKey: number;
};
