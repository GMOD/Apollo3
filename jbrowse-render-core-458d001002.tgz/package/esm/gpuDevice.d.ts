export declare function onDeviceLost(listener: () => void): () => void;
export declare function setGpuOverride(value: string | null): void;
export declare function getGpuOverride(): string | null;
export declare function isGpuRenderingDisabled(): boolean;
export declare function resetGpuDeviceForTests(): void;
export declare function getGpuDevice(): Promise<GPUDevice | null>;
