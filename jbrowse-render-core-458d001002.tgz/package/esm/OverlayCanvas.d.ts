export default function OverlayCanvas({ width, height, draw, }: {
    width: number;
    height: number;
    draw: (ctx: CanvasRenderingContext2D) => void;
}): import("react").JSX.Element;
