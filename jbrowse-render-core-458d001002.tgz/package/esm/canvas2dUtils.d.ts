import type { BpRegionBounds } from './renderBlock.ts';
export interface BlockClip {
    scissorX: number;
    scissorW: number;
    fullBlockWidth: number;
    bpLength: number;
}
export declare const MAX_DPR = 2;
export declare function getDpr(): number;
export declare const MAX_CANVAS_DIM_PX = 8192;
export declare function syncCanvasSize(canvas: HTMLCanvasElement, width: number, height: number): boolean;
export declare function prepareCanvas(canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D, canvasWidth: number, canvasHeight: number): void;
export declare function getPreparedCanvas2D(canvas: HTMLCanvasElement | null, width: number, height: number): CanvasRenderingContext2D | null;
export declare function devicePxSpan(cssStart: number, cssEnd: number, dpr: number): {
    start: number;
    width: number;
};
export declare function clampBlockScissor(screenStartPx: number, screenEndPx: number, canvasWidth: number): {
    scissorX: number;
    scissorEnd: number;
    scissorW: number;
} | null;
export declare function clipBlockForCanvas(block: BpRegionBounds, canvasWidth: number): BlockClip | null;
export interface ClipContext2D {
    save(): void;
    restore(): void;
    beginPath(): void;
    rect(x: number, y: number, w: number, h: number): void;
    clip(): void;
}
export declare function forEachClippedBlock<T, B extends BpRegionBounds>(ctx: ClipContext2D, blocks: readonly B[], canvasWidth: number, clipHeight: number, select: (block: B) => T | undefined, paint: (data: T, block: B, clip: BlockClip) => void): void;
export declare function spanLeft(x1: number, x2: number, width: number): number;
export declare function lookupColorRamp(ramp: Uint8Array, t: number): {
    r: number;
    g: number;
    b: number;
    a: number;
};
export declare function makeRampFillStyleLut(ramp: Uint8Array): (t: number) => string;
export declare function bpToScreenPx(absBp: number, regionStart: number, regionEnd: number, screenStartPx: number, screenEndPx: number, reversed?: boolean): number;
export declare function makeBpMapper(bounds: BpRegionBounds): (bp: number) => number;
export declare function makeCellLeftMapper(bounds: BpRegionBounds): (bp: number) => number;
