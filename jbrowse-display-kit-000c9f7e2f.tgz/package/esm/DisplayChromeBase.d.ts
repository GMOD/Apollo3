import type { StatusChromeModel } from './DisplayStatusChromeBase.tsx';
import type { MouseState, MouseTracker } from '@jbrowse/core/ui/useMouseTracking';
import type { DisplayChromeOverlays } from '@jbrowse/display-ui';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
import type { RenderingBackend } from '@jbrowse/render-core/renderingBackendBase';
import type { RenderLifecycleModel } from '@jbrowse/render-core/useRenderingBackend';
import type { ComponentPropsWithRef, ReactNode } from 'react';
export type ChromeModel = {
    displayPhase: DisplayPhase;
    height: number;
    painted: boolean;
} & StatusChromeModel;
export interface CanvasHandle {
    canvasRef: (node: HTMLCanvasElement | null) => void;
    canvas: HTMLCanvasElement | null;
    /**
     * The container-relative pointer position, published rather than held — read
     * it with `useMouseState(mouseTracker)` **in the body**, never beside the
     * chrome. The chrome binds the handlers itself precisely so that rule can't be
     * got wrong: there is no longer a position to hold up here.
     */
    mouseTracker: MouseTracker;
}
export type DisplayChromeBaseProps<B> = {
    model: ChromeModel & RenderLifecycleModel<B>;
    factory: (canvas: HTMLCanvasElement) => Promise<B>;
    children: (handle: CanvasHandle) => ReactNode;
    testid: string;
    overlays: DisplayChromeOverlays;
    /**
     * Called with each measured pointer position (and `undefined` on leave), for
     * a display that hit-tests as the cursor moves. It runs off the same single
     * measurement the tracker publishes, so a display's hit and its guides can't
     * come from two different rects in two different frames.
     */
    onPointerPosition?: (state?: MouseState) => void;
} & Omit<ComponentPropsWithRef<'div'>, 'children'>;
declare function DisplayChromeBaseInner<B extends RenderingBackend>({ model, factory, children, overlays, onPointerPosition, onMouseMove, onMouseLeave, ...chromeProps }: DisplayChromeBaseProps<B>): import("react").JSX.Element;
declare const DisplayChromeBase: typeof DisplayChromeBaseInner;
export default DisplayChromeBase;
