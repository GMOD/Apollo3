import type { BaseLinearDisplayConfigModel } from './configSchema.ts';
export interface TrackHeightHost {
    configuration: BaseLinearDisplayConfigModel;
}
/**
 * #stateModel TrackHeightMixin
 * #category display
 * #crossCuttingMixin Internal vertical scroll. `scrollableHeight` (default `Infinity` = doesn't scroll). Brings the clamped `setScrollTop` and the autorun that re-clamps when content shrinks
 *
 * The display height is stored directly on the `height` config slot (drag-resize
 * writes it via `setSlot`), so it survives a track being unticked and reticked —
 * the config node outlives the ephemeral display instance. Displays with an
 * auto-fit mode declare `height` as a `maybeNumber` slot (default `undefined`)
 * and override the `height` getter to fall back to their computed content
 * height when unset.
 *
 * It also owns the **internal vertical scroll** every canvas display that
 * scrolls its own content shares: the `scrollTop` volatile, a `setScrollTop`
 * clamped against the overridable `scrollableHeight` hook, and the autorun that
 * re-clamps when the content shrinks. Four displays (alignments, canvas, MAF,
 * multi-sample variants) each carried their own copy of the last two, with four
 * copies of the same "a virtual-scrolled canvas has no overflow container to
 * self-correct" paragraph; a display now opts into all of it by overriding one
 * getter.
 */
export default function TrackHeightMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     */
    scrollTop: number;
    /**
     * #volatile
     * True for the duration of a height drag, set by the track container's
     * resize handle. A display whose row geometry is a function of the track
     * height restretches every row per animation frame, and can use this to
     * sit an expensive per-frame layer out of the drag (MAF's dense per-base
     * letter overlay is a Canvas2D pass that scales with rows x columns).
     *
     * Lives here rather than per display because the handle that knows the
     * drag has started is the shared one next to `resizeHeight`. Displays
     * with their own handles (MAF's band handles) set it directly.
     */
    resizing: boolean;
} & {
    readonly height: number;
    /**
     * #getter
     * Overridable hook: how far this display's content can scroll past its
     * viewport, in px. `Infinity` (the default) means "this display doesn't
     * scroll internally" — `setScrollTop` then never clamps and the re-clamp
     * autorun below is inert, so a non-scrolling display pays nothing and,
     * crucially, never evaluates a getter that would read view geometry.
     *
     * A display that scrolls a canvas overrides this with `max(0, contentHeight
     * - viewportHeight)`, and gets the clamped setter plus the shrink autorun
     * for free. It is the single "does it scroll, and by how much" answer: the
     * wheel handler (`useVirtualScrollWheel`) and `VerticalScrollbar` read the
     * same getter.
     */
    readonly scrollableHeight: number;
} & {
    /**
     * #action
     * Clamped into `[0, scrollableHeight]`, so no caller has to remember the
     * bound. Unbounded for a display that leaves `scrollableHeight` at its
     * `Infinity` default.
     */
    setScrollTop(scrollTop: number): void;
    /**
     * #action
     */
    setResizing(arg: boolean): void;
    /**
     * #action
     */
    setHeight(displayHeight: number): number;
    /**
     * #action
     */
    resizeHeight(distance: number): number;
} & {
    /**
     * #action
     * Grow the track by exactly the content it is currently hiding, so a
     * display scrolled over a taller stack ends up showing all of it. The
     * track's resize handle runs this on a double click.
     *
     * `scrollableHeight` is the whole measurement — it is already every
     * scrolling display's answer to "how much is off the bottom", so no
     * display has to supply a second one. A display that doesn't scroll
     * internally leaves it at `Infinity` and gets a no-op, as does one
     * already showing everything (0).
     *
     * Routed through `resizeHeight` rather than `setHeight` so grow mode's
     * override still gets to leave grow first; going straight to the slot
     * would let the reactive height re-derive `grownHeight` and the double
     * click would appear to do nothing.
     */
    expandToContentHeight(): number;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
