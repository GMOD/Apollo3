import { makeFetchContext } from '@jbrowse/core/util/fetchContext';
import type { FetchContext } from '@jbrowse/core/util/fetchContext';
import type { RpcStatus } from '@jbrowse/core/util/progress';
import type { StopToken } from '@jbrowse/core/util/stopToken';
export { makeFetchContext };
export type { FetchContext };
/**
 * #stateModel FetchMixin
 * #category display
 *
 * Cancel-safe fetch lifecycle for any display that loads data over RPC. Owns
 * the entire fetch state machine (stop-token rotation, staleness tracking,
 * error capture, status reporting); consumers see only `runFetch`,
 * `cancelFetch`, `isLoading`, `error`, `statusMessage`, and `fetchGeneration`.
 */
export default function FetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     * stop token of the in-flight fetch, or undefined when idle
     */
    activeStopToken: StopToken | undefined;
    /**
     * #volatile
     * bumps at every fetch end; autoruns read it to re-evaluate, and it
     * doubles as the staleness epoch inside runFetch
     */
    fetchGeneration: number;
    /**
     * #volatile
     * Bumped by `reload()` and read unconditionally by the fetch autoruns,
     * so a user retry re-runs the body even where nothing else moved — after
     * an error every other fetch input is unchanged. It is also the half
     * that survives a `reload()` override that forgets to invalidate, which
     * is the dead Retry button `makeRetryContractCheck` reports. Declared
     * here because this is the one mixin both LGV fetch foundations compose,
     * the same argument that put `fetchInert` below; the comparative family
     * carries its own on `SyntenyFetchStateMixin` (ADR-054).
     */
    reloadCounter: number;
    /**
     * #volatile
     * This display's status field, and the only thing that writes it: one
     * throttle window, one slot per concurrent operation, so N parallel
     * per-region fetches thin to one stream between them rather than N and a
     * second operation cannot end the first one's label (ADR-081). Lent whole
     * to `createStopTokenRotation` by a display that also runs a bare-autorun
     * fetch — see `StatusReporter`.
     */
    statusWindow: import("@jbrowse/core/util").StatusWindow;
    /**
     * #volatile
     * last non-abort fetch error, or undefined
     */
    error: unknown;
    /**
     * #volatile
     * work-in-progress status string
     */
    statusMessage: string | undefined;
    /**
     * #volatile
     * determinate progress fraction [0,1] for the current status, or
     * undefined when the in-flight phase is indeterminate
     */
    statusProgress: number | undefined;
    /**
     * #volatile
     * true after the user explicitly cancels a load (the loading overlay's
     * cancel button → `cancelFetchByUser`). A durable, blocking state — unlike
     * `cancelFetch`, it does not retrigger the fetch autoruns — so the load
     * stays stopped until the user retries (`reload`) or the viewport changes.
     * Any new fetch clears it (`runFetch` resets it at the start).
     */
    fetchCanceled: boolean;
} & {
    /**
     * #volatile
     * **The latest-wins machine this mixin is a wrapper around**, and not a
     * second one: `createStopTokenRotation` owns token rotation, the
     * `isCurrent` guard, the status slot and the supersede-versus-end rule
     * (ADR-080, ADR-081), for every fetch in the codebase that has one.
     * `runFetch` adds the observable bookkeeping a display needs on top —
     * `isLoading`, `error`, `fetchGeneration`, `fetchCanceled` — and nothing
     * else.
     *
     * It was two implementations of that machine until 2026-08-20, which is
     * how they came to disagree about whether a completed fetch releases its
     * token. A display's *primary* fetch is this wrapper; a second concurrent
     * fetch on the same node holds a rotation of its own, which is why the
     * primitive is the thing that exists and this is the thing built on it
     * (ADR-054 §1).
     *
     * It is lent this display's `statusWindow`, so the fetch takes a slot on
     * the one field rather than opening a second window over it — the whole
     * point of `StatusReporter`.
     */
    fetchRotation: {
        begin(): import("@jbrowse/core/util").ActiveFetch;
        cancel: () => void;
        dispose(): void;
    };
} & {
    /**
     * #getter
     * true while a fetch is active
     */
    readonly isLoading: boolean;
} & {
    /**
     * #getter
     * `isLoading` widened to cover a user-canceled load. **This, not
     * `isLoading`, is what a `displayPhase` loading term wants.**
     * `cancelFetchByUser` clears the stop token synchronously, so `isLoading`
     * goes false the instant the user clicks Cancel — and the loading overlay
     * that unmounts on it is carrying the Retry button, which is the only way
     * back: the state is deliberately durable, so no autorun restarts the
     * fetch on its own. A bare `isLoading` therefore reads as `ready` over a
     * display that is stopped, empty and offering nothing.
     *
     * Arc read `isLoading` directly and had exactly that hole. It is a getter
     * here so no family has to remember the second term.
     */
    readonly isLoadingOrCanceled: boolean;
    /**
     * #getter
     * Overridable hook (default false): the states where this display
     * deliberately never fetches, so it holds no data and none is coming.
     * Sequence sets it past base resolution ("Zoom in to see sequence"); LD
     * sets it with the triangle toggled off.
     *
     * **One hook, three readers**, and that is the whole point — a display
     * that grows such a state has one thing to say rather than three, and the
     * reader it would have forgotten is always the one outside itself:
     *
     * - the loading scrim (`computeLoadingTerm`), which otherwise parks over
     *   the placeholder, permanently once a cancel has been clicked;
     * - the SVG export (`computeSvgReady`'s `extraTerminal`), whose
     *   `awaitSvgReady` is an unbounded `when`, so one such display hangs the
     *   whole view's export;
     * - the dev-only retry check (`makeRetryContractCheck`), which would
     *   otherwise report a dead Retry on a display correctly declining to
     *   load anything.
     *
     * It was three hooks — `loadingSuppressed`, `svgReadyExtraTerminal` on
     * each of the two foundations, and `fetchInert` on the comparative
     * family, which had already collapsed them. Both LGV displays that
     * override it returned one expression for all three, and one of the three
     * was hard-coded `false` on the global family for a while, which is how
     * LD came to be able to express only half its own state. Same name and
     * same meaning as `SyntenyFetchStateMixin.fetchInert` now, so the retry
     * check reads one field across all three fetch families. ADR-082.
     *
     * A hook rather than a `displayPhase` override, because overriding the
     * getter means restating the whole loading condition — which is how
     * sequence came to hold a verbatim copy of the other terms, one `git blame`
     * away from silently missing the next one added.
     *
     * It lives **here** because this is the one mixin all three display
     * foundations compose. Same argument, one level down, that put
     * `rendersCanvas` on `RenderLifecycleMixin` beside `canvasDrawn`.
     */
    readonly fetchInert: boolean;
    /**
     * #getter
     * Overridable hook (default false), read only by the dev-only retry check
     * (`makeRetryContractCheck`): "this run declined because a prerequisite
     * fetch in another autorun has not landed, and its arrival wakes this one
     * again". It **defers** the retry verdict to that later run rather than
     * waiving it, so a display cannot spend its retry on a decline it called
     * preliminary.
     *
     * Two displays say it, one per fetch foundation, which is why it lives
     * beside `fetchInert` rather than on either: HiC's contacts fetch
     * declines until `CoreGetInfo` lands, and `MultiSampleVariantBaseModel`'s
     * `fetchNeeded` declines until `sourcesBase` does. Both have a `reload()`
     * that wakes the prerequisite's autorun as well as their own.
     *
     * **It has to be strictly narrower than the gate it explains.** One that
     * restates the gate's negation makes every decline a deferred one, so no
     * run is ever judged and the display has silently opted out — an exemption
     * by another name. HiC is in that shape deliberately, because its gate and
     * its prerequisite are one condition; what covers its retry instead is
     * `LinearHicDisplay/infoFetchFailure.test.ts`.
     *
     * Not for a display deliberately not fetching at all — that is
     * `fetchInert` above, which the loading scrim and the export read too.
     */
    readonly awaitingPrerequisite: boolean;
    /**
     * #getter
     * The RPC cache key both fetch foundations invalidate on: this display's
     * `rpcProps()` payload serialized to a string. `serializeRpcProps` owns
     * the why, including the silently-dead-axis corollary.
     *
     * Here, beside the two hooks above, for the same reason they are: it
     * describes the display, and every foundation composes this mixin. The
     * per-region family watches it from `SettingsInvalidate` and the global
     * one from its fetch autorun's trigger list — one getter and one name, so
     * the two cannot come to invalidate on different axes. The global side
     * built its own local `computed` over the same function until 2026-08,
     * which was the same value under a second spelling.
     */
    readonly rpcPropsCacheKey: string;
} & {
    /**
     * #action
     */
    setError(error?: unknown): void;
    /**
     * #action
     * Unthrottled: a display writing a phase label by hand must see every
     * write land. The high-frequency RPC stream is thinned one level up, by
     * the streams `self.statusWindow` hands out — and aggregated across them,
     * which a write by hand is not.
     */
    setStatusMessage(status?: RpcStatus): void;
} & {
    /**
     * #action
     * Abort the in-flight fetch (if any) and retire its slot. The shared
     * preamble of both cancel paths; the difference between them is only what
     * they do to `fetchCanceled` / `fetchGeneration` afterward.
     */
    stopActiveFetch(): void;
    /**
     * #action
     * Open one operation's slot on the display's status field: an RPC
     * `statusCallback` throttled through the display-wide window and guarded
     * so a callback that fires after the node is torn down (RPCs resolve
     * their status stream asynchronously) is a safe no-op, plus the `clear`
     * that retires the slot when the operation ends.
     *
     * **Every operation on the display opens one**, and the two come back
     * together because an operation that never retires goes on voting for a
     * phase that is over. The viewport fetch (`runFetch`), the clustering run
     * and a lent `createStopTokenRotation` are three of them on one field;
     * before ADR-081 each blanked the field outright and the last one to
     * finish decided what the other two were still saying.
     *
     * `isCurrent` is required and has no "node is alive" default, because
     * alive is not the interesting question: a *superseded* fetch is on a live
     * node, and its late status repainting the overlay of the fetch that
     * replaced it is the failure this guards. `runFetch` passes `!isStale()`,
     * which is what every display gets for free through `ctx.statusCallback`;
     * a caller outside a fetch (the clustering autorun) passes its own run's
     * flag. Defaulting to `isAlive` made the loose answer the easy one and
     * five displays took it.
     *
     * Declared this early only so `runFetch` can put one on every
     * `FetchContext`.
     */
    openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
} & {
    /**
     * #action
     * cancel any in-flight fetch and bump fetchGeneration (always bumps, so
     * callers can retrigger fetch autoruns even when nothing was in flight).
     * This is the *internal* reset `clearAllRpcData` runs — it clears any
     * user-cancel flag so the retrigger actually re-fetches.
     */
    cancelFetch(): void;
    /**
     * #action
     * User-initiated cancel from the loading overlay. Stops the in-flight
     * fetch and lands in a durable `fetchCanceled` state. Unlike
     * `cancelFetch`, it does NOT bump fetchGeneration — so the fetch autoruns
     * don't immediately restart the load. The user retries via `reload`
     * (the overlay's retry button), or it clears on the next viewport change.
     */
    cancelFetchByUser(): void;
    /**
     * #action
     * Release an in-flight fetch's stop token on teardown. Without this, a
     * display destroyed mid-fetch (track/view closed while loading) never
     * signals the worker to abort the now-useless work, and its in-flight HTTP
     * reads keep downloading. MST auto-chains lifecycle hooks, so a composing
     * display can still define its own beforeDestroy.
     */
    beforeDestroy(): void;
    /**
     * #action
     * The `finally` half of `runFetch`'s bookkeeping, an action of its own
     * because `runFetchOnce`'s `finally` resumes on a microtask the flow does
     * not own — a direct volatile write there is outside the action context,
     * which is the one thing hoisting the sequence into a shared function
     * costs. The stale branch is a superseded fetch: whoever superseded it —
     * a newer `begin`, or `cancel` — already released this token.
     */
    endFetch(current: boolean, stopToken: StopToken): void;
} & {
    /**
     * #action
     * Run a cancel-safe fetch (cancels any prior). The work callback gets a
     * FetchContext with a stopToken to forward to the RPC and an isStale()
     * check to short-circuit commits once the user has moved on.
     *
     * **The MST-flow wrapper over the shared `runFetchOnce` sequence**, and
     * only the wrapper: the begin/clear/run/commit/error/end order, and the
     * rules that keep a superseded run from writing back, are the same
     * function every other fetch in the tree runs. What this adds is the
     * observable bookkeeping a display needs — `isLoading` through
     * `activeStopToken`, `fetchGeneration`, the user-cancel clear — and the
     * flow itself, which is an action, so `work`'s synchronous prefix runs
     * untracked wherever a fetch autorun calls this.
     */
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type FetchMixinType = ReturnType<typeof FetchMixin>;
