import type { IndexedRegion } from './planRegionFetch.ts';
import type { Region } from '@jbrowse/core/util/types/data';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * What the per-region fetch autoruns read and call. Duck-typed rather than the
 * mixin's own `Instance` type: `MultiRegionDisplayMixin` composes this
 * installer, so a nominal type would be circular, and naming the members here
 * is also the list of what the autoruns are allowed to touch.
 */
export interface PerRegionFetchHost extends IStateTreeNode {
    error: unknown;
    fetchCanceled: boolean;
    fetchGeneration: number;
    reloadCounter: number;
    isLoading: boolean;
    fetchInert: boolean;
    awaitingPrerequisite: boolean;
    gateSkipsMeasuredViewport: boolean;
    /** read by the hover-clear reaction, which the too-large banner also fires */
    regionTooLarge: boolean;
    loadedRegions: {
        get: (displayedRegionIndex: number) => Region | undefined;
    };
    rpcPropsCacheKey: string;
    isCacheValid: (displayedRegionIndex: number) => boolean;
    fetchNeeded: (needed: IndexedRegion[]) => void;
    setError: (error?: unknown) => void;
    clearAllRpcData: () => void;
    clearByteEstimate: () => void;
    clearHoveredFeature: () => void;
}
/**
 * Install the per-region fetch lifecycle: `DisplayedRegionsChange`,
 * `FetchVisibleRegions`, `SettingsInvalidate`,
 * `ClearBlockingStateOnViewportChange`, and the stored-hover clear.
 *
 * The third fetch-family installer, beside `installGlobalFetchAutorun` and
 * `installComparativeFetchAutorun`. It is a function rather than an inline
 * `afterAttach` body for the reason those two are: **what this file decides is
 * the MobX dependency set**, and that is the half no pure function can express.
 * `planRegionFetch` owns the decision; this owns which reads are tracked and
 * which sit behind a thunk so an early bail-out does not subscribe to the
 * viewport. `installPerRegionFetchAutoruns.test.ts` is what fails when one of
 * those moves, and its last block states the whole set per state.
 *
 * `untracked` is allowed on two grounds only: a read the body's own effect
 * writes (`ClearBlockingStateOnViewportChange` clears the flags it reads, so
 * tracking them would re-fire it off `setError` and wipe the flag before any
 * viewport change), and a dev-only check that must not alter the production
 * dependency set. Anything else was a perf guard, and the two this file carried
 * (`isLoading`, `loadedRegions`) were measured on 2026-08-23 and removed: a
 * fetch shorter than the 600 ms debounce coalesces the flip into the run
 * `fetchGeneration` already owes, and a longer one costs one idle run of the
 * plan mid-fetch. Two runs per fetch cycle either way, three past the debounce.
 */
export declare function installPerRegionFetchAutoruns(self: PerRegionFetchHost): void;
