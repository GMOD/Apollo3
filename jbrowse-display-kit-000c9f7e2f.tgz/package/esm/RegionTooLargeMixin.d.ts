import type { BaseLinearDisplayConfigModel } from './configSchema.ts';
import type { ByteEstimate, GateFetchState, GateViewport } from './regionTooLargeUtils.ts';
/** The whole of what `RegionTooLargeMixin` needs a composing display to be. */
export interface RegionTooLargeHost {
    configuration: BaseLinearDisplayConfigModel;
}
/**
 * Shared mixin owning "region too large" state and force-load UI.
 *
 * Composed by MultiRegionDisplayMixin (canvas/GPU displays like
 * LinearAlignmentsDisplay, LinearWiggleDisplay, LinearBasicDisplay) and
 * directly by the SVG arc displays (LinearArcDisplay, LinearPairedArcDisplay),
 * which do their own byte-estimate gating in arcFetchPhases.
 *
 * Owns the state that TooLargeMessage reads: regionTooLarge,
 * regionTooLargeReason, forceLoad.
 *
 * ## Measurement follows the viewport
 *
 * `regionTooLarge` is a pure function of one cached measurement
 * (`tooLargeStatus`), and that measurement is kept describing the viewport it is
 * judging. Two mechanisms, one per state, and between them the estimate is never
 * a model:
 *
 * - **Not gated:** the fetch measures. Every gated display's feature RPC takes
 *   `resolvedByteLimit()` and reads the index before it downloads, so every
 *   fetch re-anchors the estimate to what it is about to pull.
 * - **Gated:** the fetch measures anyway, once. `FetchVisibleRegions` and
 *   `installGlobalFetchAutorun` used to return early on `regionTooLarge`, which
 *   froze the estimate at the viewport it was captured over; they skip on
 *   `gateSkipsMeasuredViewport` instead — one getter, read by both. So a
 *   blocked display runs
 *   one fetch per settled viewport, and that fetch stops at whichever gate
 *   rejected it — which is what releases the banner. No second,
 *   measurement-only RPC path exists, and canvas therefore keeps the single-call
 *   fetch it was built around.
 *
 *   What that costs, precisely, because "it re-fetches while blocked" reads
 *   alarming: on the **byte** axis, one index read and no features. On canvas's
 *   **density** axis, the pre-fetch probe
 *   (`samplePreFetchDensity`) — a 1kb sample window, doubling until it has seen
 *   70 features — and then the short-circuit. A region dense enough to be
 *   density-blocked is exactly the region that satisfies that on the first
 *   window, so it is small and bounded, but it is not nothing.
 *
 * There used to be a third thing, a derived `estimatedBytesForVisibleSpan` that
 * scaled the stored bytes by `visibleBp / measuredSpanBp`, and it was the
 * release mechanism. It is gone, because bytes do not follow span: an index
 * quotes whole blocks, so the estimate is a step function whose steps are a
 * property of the file. Measured 2026-08-06, the whole-genome
 * `hs37d5.HG002…sv.vcf.gz` charges an identical 15,408 bytes from 7.8 Mb of span
 * all the way down, where the linear model extrapolated from chr1 predicts 22 —
 * a 700x under-report, in the direction that releases a banner it should hold.
 * Every gated track above the old floor paid for that with a release, an aborted
 * fetch, and a re-banner on each zoom step.
 *
 * A display opts in with two lines: override `gateEnabled` to true, and pass
 * `byteLimit: self.resolvedByteLimit()` in its fetch RPC's args. The commit is
 * the fetch runners' — the three fan-out helpers per-region, `runGlobalFetch`
 * global — so the measurement and the verdict both live here, they can't drift
 * apart, and the "capture the viewport before the await" rule is structural
 * rather than a call-site convention. Add `densityTooLarge` for a second gating
 * axis (canvas's feature-density gate); the budget hooks default off the
 * display config.
 *
 * `MultiRegionDisplayMixin` drops the cached estimate on chromosome nav for
 * everything it composes; the two displays outside that family (LD, arc) wire
 * `onDisplayedRegionsChange(self, () => self.clearByteEstimate())` themselves.
 * The estimate intentionally survives viewport-change clears, so only region
 * navigation drops it. Used by canvas/LD/arc/maf/MultiSampleVariant/alignments.
 *
 * A display that opts into neither axis never gates on size (`regionTooLarge` is
 * a literal false, so the LGV-only `tooLargeStatus` getters aren't evaluated —
 * safe for ungated / non-LGV consumers like synteny). The old imperative
 * `setRegionTooLarge` flag path was removed once every gated display went
 * derived.
 *
 * ## The names, and the one rule behind them
 *
 * **A `byte`/`density` prefix means the term is genuinely about that axis, and
 * nothing else carries one.** The gate reads as three questions asked in order,
 * and the middle one is shared:
 *
 * - *does this display measure at all?* — `gateEnabled`.
 * - *may the gate act right now?* — `gateActive` (opted in, not exempt, view
 *   measured). Nothing axis-specific here.
 * - *may this axis act?* — `gateActive` plus that axis's own terms.
 *   `densityGateActive` adds `densityGateEnabled` and the `AUTO_FORCE_LOAD_BP`
 *   floor; the byte axis adds nothing, which is why it has no getter of its own
 *   and reads `gateActive` directly.
 *
 * Until 2026-08 the middle question was called `byteGateActive` and the
 * exemption `byteGateExempt`, while `densityGateActive` was literally
 * `byteGateActive && …` and `byteGateExempt`'s own first sentence said "on
 * either axis". Two names claiming an axis they had no term from is how a reader
 * comes to believe force-load only lifts the byte gate — which is a thing this
 * mixin's *predecessor* actually did, and one of the four bugs the boolean
 * replaced (see REGION_TOO_LARGE.md § Force-load).
 *
 * #stateModel RegionTooLargeMixin
 * #category display
 */
export default function RegionTooLargeMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     * The force-load button's answer: render this track regardless of region
     * size or feature density. One boolean for the whole track, not a raised
     * ceiling per region — the banner already tells the user how much data is
     * involved, so one informed click approves the track and they never have to
     * re-approve it per locus.
     *
     * Volatile, not persisted, so it can't leak a disabled gate into a saved or
     * shared session (a recipient would download the same data with no warning
     * and no way to see why). A page load re-arms the gate. The durable,
     * declarative equivalent is the `forceLoad` config slot, for session specs,
     * embeds and `jbrowse-img --force`.
     */
    forceLoadTrack: boolean;
    /**
     * #volatile
     * The last byte measurement for this display: the estimated bytes, the span
     * they were measured at, and whether zooming has been shown not to shrink
     * them. One volatile rather than three, because they are a single
     * measurement — written together by `setByteEstimate`, dropped together by
     * `clearByteEstimate`, and meaningless apart. Survives `clearAllRpcData` so
     * an ordinary viewport change doesn't flicker the banner; the two things
     * that do drop it are chromosome navigation and a tier swap, which are one
     * rule on two axes — the measurement is about a fetch, and each changes
     * which fetch that is. Ignored unless `gateEnabled`.
     */
    byteEstimate: ByteEstimate | undefined;
    /**
     * #volatile
     * The viewport (`gateViewport().key`) the gate last got a measurement for,
     * on **either** axis. Not part of `byteEstimate`, because a fetch can
     * measure density and no bytes at all — a dense region short-circuits on
     * the feature count with the byte estimate deliberately left alone — and
     * that fetch still asked the adapter about this viewport.
     *
     * Its whole job is `gateMeasurementStale`, which is what lets the fetch
     * autoruns run exactly one fetch per settled viewport while the banner
     * holds. Keying it on bytes instead loops forever on a density rejection.
     */
    gateMeasuredViewportKey: string | undefined;
} & {
    /**
     * #getter
     * Whether this display measures at all. **The whole opt-in**: a display
     * that answers true passes `resolvedByteLimit()` into its fetch RPC, that
     * RPC measures the index before it downloads anything and answers a
     * `RegionTooLargeResult` when the region is over budget, and the fan-out
     * helper commits what came back. False for the ungated displays (wiggle,
     * manhattan, sequence, synteny), which therefore never evaluate the
     * LGV-only getters below.
     *
     * It was the OR of two opt-ins, `measuresBytesPreFlight` and
     * `measuresBytesInFetch`, because there were two measurement paths — a
     * `CoreGetRegionByteEstimate` round trip before the fetch, and the
     * measurement folded into the fetch itself. The second strictly dominates
     * (one round trip; the adapter already in hand; one result carrying every
     * measurement taken on the way to it), so the first is gone and with it
     * the additive OR, the lint rule that stopped a display overriding this
     * name, and the pair of names that only made sense against each other.
     *
     * **Nothing in the tree turns it off once on**, and there is no longer a
     * reason to. "Can this adapter be measured" is the adapter's answer, not
     * a display's: one with no index estimate reports `undefined`, and an
     * unmeasurable estimate keeps the byte axis out of the verdict on its
     * own. It is emphatically not for a fetch believed to be small — a
     * display that reads a cheaper file at some zooms points
     * `byteGateAdapterConfig` at that file and stays gated, which is what MAF
     * does. Off means nothing is watching, and "this tier is cheap" is a
     * premise, not a bound.
     *
     * A mixin contributing this — `CanvasFeatureGateMixin` is the one that
     * does — has to be composed AFTER the mixin that declares it, since
     * `types.compose` resolves a member collision to the later argument.
     * `no-restricted-syntax` fails the other order and says why.
     */
    readonly gateEnabled: boolean;
    /**
     * #getter
     * Whether the **density** (features-per-pixel) axis applies to this
     * display at all. **False here, and `CanvasFeatureGateMixin` is what
     * turns it on** — the axis is on exactly where something measures it, and
     * that mixin is the only thing in the tree that does. It contributes this
     * beside `gateEnabled` for the same reason and by the same route.
     *
     * It defaulted to *true* until 2026-08, on the reading that "both axes
     * are on and the display supplies the numbers". The reading was harmless
     * and wrong: the five byte-only displays (alignments, arc, maf, LD,
     * multi-sample-variant) then sat permanently in `densityGateActive ===
     * true`, the mixin asserting an axis is live for displays that cannot
     * measure one. Nothing broke, because their `densityTooLarge` is the
     * `false` below — but a state that says the opposite of what is true is
     * one a reader has to be told to disbelieve, and the fix is the default,
     * not the telling.
     *
     * It lives on this mixin rather than on `CanvasFeatureGateMixin` — where
     * it used to — because it is the second half of a contract whose first
     * half (`densityTooLarge`) is already here, and because a hook the base
     * doesn't know about cannot be folded into `densityGateActive`. It wasn't,
     * and the cost was that "is the density axis on?" had two spellings, both
     * of which had to be asked at the one consumer:
     * `!densityGateEnabled || !densityGateActive`.
     *
     * `LinearMultiRowFeatureDisplay` composes that mixin and turns this back
     * off: it paints into fixed lanes, so a high total feature count is not a
     * per-glyph render cost and only the download budget should gate it. That
     * override is in its own `.views` block, after the `.compose`, so it wins
     * over the contributed `true` regardless of mixin order.
     */
    readonly densityGateEnabled: boolean;
    /**
     * #getter
     * Which adapter the gate measures: the config sitting at
     * `byteGateAdapterPath`, which is `['adapter']` here — the display's own,
     * correct wherever a display has one fetch path.
     *
     * **Derived from the path rather than declared beside it**, so a display
     * that swaps tiers by zoom overrides one hook instead of two and the
     * measurement cannot name a file the budget doesn't. MAF is the case it
     * was built for: past the force-load floor it reads a `summaryAdapter`
     * instead of the alignment, and measuring the alignment there would quote a
     * download nobody is doing. The alternative it replaced — turning
     * `gateEnabled` off for the cheap tier — exempted that tier from the
     * gate entirely, which is only safe if the tier really is bounded. A
     * `BigBedAdapter` read is a full-feature download (see its `getFeatures`),
     * so at genome scale it is not, and the exemption was hiding it.
     *
     * Still overridable, and the case that needs it is a display whose
     * `adapterConfig` is *synthesized* rather than read — GC content wraps the
     * track's sequence adapter and folds `windowSize` / `gcMode` in, so no
     * path on the track config names what it fetches. Neither GC-content
     * display gates today; one that opted in would override this getter and
     * leave the path alone.
     */
    readonly byteGateAdapterConfig: Record<string, unknown>;
    /**
     * #getter
     * The composing display's configured `fetchSizeLimit`, read straight from
     * its config. Only evaluated when the gate is enabled (guarded by
     * `gateEnabled`), and every gated display extends
     * `baseLinearDisplayConfigSchema`, which owns the slot — so the read is
     * always valid where it fires. A display with a bespoke source can still
     * override it.
     */
    readonly configuredFetchSizeLimit: number;
    /**
     * #getter
     * Second (non-byte) too-large axis folded into the derived verdict — canvas
     * overrides it with its feature-density gate. Byte-only derived displays
     * leave it false.
     */
    readonly densityTooLarge: boolean;
    /**
     * #getter
     * Where on the track config the adapter `byteGateAdapterConfig` names
     * lives. The track's own `adapter` by default; a display that swaps tiers
     * overrides **this one hook**, and both the measurement and the budget
     * follow it, so they cannot describe two different files.
     *
     * A path rather than the node or the budget itself because
     * `byteGateAdapterConfig` is a resolved snapshot, and a snapshot cannot
     * answer this: it omits every slot sitting at its schema default, so a
     * sub-adapter's declared limit is absent from it in any config that does
     * not restate the number. Pointing `adapterFetchSizeLimit` at the same
     * path is what makes a sub-adapter's own `fetchSizeLimit` reachable at
     * all. Inert in the tree today — the four adapters declaring the slot are
     * Bam/Cram/VcfTabix/SplitVcfTabix and MAF's summary tier is a BigBed — and
     * a static check cannot close it, because which adapter type sits behind
     * an override is a config-time fact.
     */
    readonly byteGateAdapterPath: string[];
    /**
     * #getter
     * The measured adapter's own `fetchSizeLimit` slot (undefined when its
     * type declares none); `resolveByteLimit` prefers it over the display
     * config. Read on the main thread, and only here — the estimate that
     * crosses the worker boundary carries bytes and nothing else, so the
     * banner and the worker budget have no second spelling of "the adapter's
     * limit" to disagree about.
     *
     * A slot **path off the live config**, not a read off `self.adapterConfig`:
     * that getter is a snapshot, which by design omits slots sitting at their
     * default, so a BAM's declared 5 Mb read back as `undefined` in every config
     * that doesn't restate it. Resolved values come from a config node — see
     * CONFIG_PATTERN.md §"Reading a slot: node, not snapshot".
     */
    readonly adapterFetchSizeLimit: number | undefined;
    /**
     * #getter
     * Declarative force-load: when true the display always renders regardless
     * of region size / feature density (the config-driven equivalent of the
     * force-load button). Read straight from the `forceLoad` config slot on
     * `baseLinearDisplayConfigSchema` (same guard/ownership as
     * `configuredFetchSizeLimit`), so every opt-in display honors it without
     * per-display wiring.
     */
    readonly configForceLoad: boolean;
    /**
     * #getter
     * What a measurement taken right now would be about: the span on screen,
     * and a comparable identity for the exact stretch of genome it covers.
     * Undefined before the view is measured, which every reader takes as
     * "there is nothing to measure yet".
     *
     * **The gate's only read of the view** — `adapterFetchSizeLimit` reaches
     * the containing track, and nothing else leaves the display — which is
     * also why the pre-init guard lives here once: `visibleBp` reads
     * `view.width`, which throws before measurement, and a bare getter must
     * never throw. There used to be a second getter for the span alone
     * (`gateVisibleBp`), with its own copy of that walk and that guard, read
     * by the two places that wanted a number rather than a label. One quantity
     * under two names is one more thing to keep in step for nothing: both
     * callers now take `gateViewport?.spanBp`, and `gateActive`'s precondition
     * reads as what it means — we know what a measurement would be about.
     *
     * Captured as one value, and captured *before* the round trip, because
     * both halves answer a question about the measurement that cannot be
     * recovered afterwards. The span is what `zoomIneffective` compares across
     * two measurements; the key is what tells the fetch autoruns whether the
     * stored estimate still describes what the user is looking at
     * (`gateMeasurementStale`). Reading either at commit time would label the
     * number with a viewport it never covered.
     *
     * Rounded, because `visibleRegions` carries fractional bp and a key that
     * changed on sub-base jitter would call every estimate stale.
     */
    readonly gateViewport: GateViewport | undefined;
} & {
    /**
     * #getter
     * Which tier the stored estimate is *about*, as a comparable value. The
     * cached estimate answers "how many bytes would the fetch pull", and a
     * display that swaps `byteGateAdapterConfig` by zoom changes which fetch
     * that is — so past the swap the stored number describes a download nobody
     * is going to do, exactly the way a stale estimate describes the previous
     * chromosome's. Both are dropped, and for the same reason.
     *
     * Stringified rather than compared by reference: `byteGateAdapterConfig`
     * is a snapshot getter, and whether a given display's is referentially
     * stable is not something this mixin should have to rely on. An identity
     * comparison that turned out unstable would clear the estimate on every
     * recompute — a banner that flickers on pan, which is the property the
     * cached estimate exists to provide.
     */
    readonly byteGateAdapterKey: string;
    /**
     * #getter
     * Whether the span on screen is above `AUTO_FORCE_LOAD_BP` — that constant
     * compared here and nowhere else. False before the view is measured.
     *
     * Three readers, each doing something different with the same span, which
     * is why this is one getter rather than a term inside any of them: the
     * **density** axis stops gating below it (`densityGateActive`), MAF's
     * `showSummary` swaps to the cheap summary adapter at it, and the **byte**
     * axis multiplies its budget by `SUB_FLOOR_BYTE_BUDGET_FACTOR` below it
     * (`gateByteLimit`).
     *
     * Deliberately independent of the opt-in and of force-load, so a display
     * whose *own* opt-in depends on the floor can read it without a cycle:
     * `byteGateAdapterConfig` is downstream of MAF's swap. The two gate
     * getters add `gateActive` and their axis's own terms on top — so note
     * this is false on an unmeasured view, and a reader that isn't already
     * behind `gateActive` has to say what it wants that to mean.
     */
    readonly aboveForceLoadFloor: boolean;
    /**
     * #getter
     * True when nothing may gate, on either axis and in both the worker and the
     * banner: the declarative `forceLoad` slot, or the force-load button. One
     * boolean is the whole force-load mechanism — there is no per-region ceiling
     * to carry, expire, or reconcile between the two axes. A self-summarizing
     * adapter (BigWig, HiC, sequence) needs no term here: it reports no byte
     * estimate at all, which already keeps the byte axis out of the verdict.
     */
    readonly gateExempt: boolean;
    /**
     * #getter
     * How many bytes we estimate the fetch this display would issue right now
     * would pull. The stored measurement, unmodified — the viewport it
     * describes is kept current by re-measuring rather than by scaling it (see
     * the mixin docstring). Undefined when nothing has been measured — which
     * includes the adapter offering no index estimate, since neither path
     * stores one for that — and that keeps the byte axis out of the verdict
     * entirely.
     */
    readonly estimatedFetchBytes: number | undefined;
    /**
     * #getter
     * Whether the gate's last measurement is about a viewport the user has
     * since left. True when there has been no measurement at all.
     *
     * **This is what lets the gate release.** The fetch autoruns skip while
     * `regionTooLarge` holds — they have to, or a too-large region would
     * refetch forever off its own `fetchGeneration` bump — and skipping is
     * also what leaves the verdict frozen at the viewport it was taken at. So
     * they skip on `gateSkipsMeasuredViewport` instead: one fetch
     * per settled viewport while blocked, and none once that viewport has been
     * measured.
     *
     * Running the ordinary fetch is the whole re-measure, because every gated
     * display's fetch begins by measuring and stops there when the answer is
     * over budget — `measureRegionBytes` ahead of the download, inside the
     * display's own feature RPC. On the byte axis that is one index read and
     * no features; on canvas's density axis it is the 1kb pre-fetch probe. A
     * second, measurement-only RPC path would buy nothing and cost every
     * display the two-call coordination.
     */
    readonly gateMeasurementStale: boolean;
} & {
    /**
     * #getter
     * The byte budget the gate enforces: the adapter's limit, else the display
     * config, raised by `SUB_FLOOR_BYTE_BUDGET_FACTOR` below the
     * `AUTO_FORCE_LOAD_BP` span. Also what `resolvedByteLimit()` hands the
     * worker, so the two can't gate against different numbers. Force-load
     * doesn't raise this — it exempts the track outright via `gateExempt`.
     *
     * The span tier makes this swing at 20kb, which is safe only because this
     * budget reaches the worker as a call-site argument rather than through
     * `rpcProps()`. In the payload it would be an RPC cache key, and crossing
     * the floor would be a full `clearAllRpcData()` refetch — the bug
     * `maxFeatureDensity` already shipped once. "Neither worker budget may be
     * an RPC cache key", in REGION_TOO_LARGE.md § How the verdict is built.
     *
     * `aboveForceLoadFloor` is also false on an unmeasured view, so this must
     * be read under `gateActive` — which is why nothing reads it directly.
     * `resolvedByteLimit()` is the one consumer, and it is what the verdict,
     * the worker and MAF's `framesReadOverBudget` all take.
     */
    readonly gateByteLimit: number;
    /**
     * #getter
     * Whether the gate may act at this moment, on **any** axis: the display
     * opted in, nothing exempts it, and the view is measured. Every per-axis
     * question is this plus that axis's own terms — today that is nothing at
     * all on the byte side and `densityGateEnabled && aboveForceLoadFloor` on
     * the density one.
     *
     * It was `byteGateActive`, and none of its three terms was ever about
     * bytes; `densityGateActive` was defined as `byteGateActive && …`, which
     * is what that name being wrong looks like from the outside.
     *
     * No span floor on the byte axis. There was one — `AUTO_FORCE_LOAD_BP` —
     * and it rested on "a small span is a small fetch", which the gate now
     * checks rather than assumes: it re-measures at whatever is on screen, so
     * below 20kb the verdict is the same measured comparison it is above. The
     * premise it replaced is false often enough to matter — a 470-way MAF is
     * 6-8MB inside a 40kb window, an amplicon pileup tens of MB — and where it
     * held, the measured estimate is orders of magnitude under
     * `fetchSizeLimit` and no banner appears. Two displays used to opt out of
     * it one at a time (`gateBelowForceLoadFloor`, on MAF and alignments); the
     * opt-in is gone because there is nothing left to opt out of.
     *
     * What the span does below 20kb is raise the *budget*
     * (`SUB_FLOOR_BYTE_BUDGET_FACTOR`, on `gateByteLimit`) rather than switch
     * this off. The difference is that the gate stays reachable at every zoom:
     * index estimates are monotone in span, so an off-switch made the gate
     * bypassable by zooming into it, which is what the floor's own banner told
     * people to do.
     *
     * Everything reads it rather than restating it: the verdict, the worker's
     * `resolvedByteLimit()` (an undefined budget is an RPC that measures
     * nothing at all), and the density axis below.
     */
    readonly gateActive: boolean;
} & {
    /**
     * #getter
     * Whether the **density** axis may gate at this moment — `gateActive`
     * plus this axis's own two terms: the display opted the axis in, and the
     * span is above the `AUTO_FORCE_LOAD_BP` floor, which is now the floor's
     * only remaining job.
     *
     * `densityGateEnabled` used to live on `CanvasFeatureGateMixin`, out of
     * this getter's reach, so "is the density axis on?" had two spellings and
     * the one consumer that mattered had to ask both
     * (`!densityGateEnabled || !densityGateActive`). Folded in, this getter
     * is the single answer and the budget below it is a plain ternary.
     *
     * The two axes part company because their numbers do. The byte estimate is
     * measured at the span being judged; the density figure is a model — the
     * last fetch's features-per-bp times the current bpPerPx — with nothing
     * measured under it at that span, and it is not monotone in the way the
     * byte axis's argument for dropping the floor relies on (features clump, so
     * a smaller window can hold a *higher* local density than the window that
     * produced the stat). A scan of every indexed file in this repo
     * (2026-08-06) found the density gate would trip below 20kb on exactly two,
     * both cohort copy-number BEDs whose feature count doesn't fall with span
     * at all — and both are `LinearMultiRowFeatureDisplay` tracks, which turn
     * this axis off. So the floor here costs nothing measurable and removing it
     * would buy nothing measurable.
     *
     * `CanvasFeatureGateMixin` reads this for its `maxFeatureDensity` budget.
     */
    readonly densityGateActive: boolean;
    /**
     * #method
     * The gated byte budget: `gateByteLimit` under `gateActive`, and the only
     * spelling of that pair. Undefined (unlimited) when the gate may not act.
     *
     * **Three things take it, which is why it exists rather than each of them
     * writing the ternary**: the fetch RPCs enforce it worker-side,
     * short-circuiting an over-budget region before it downloads any features;
     * `tooLargeStatus` compares the estimate against it for the banner; and
     * MAF's `framesReadOverBudget` bounds a third file with it. A worker
     * rejecting a region the banner then calls fine is a blank display that
     * never refetches, and it is reachable only by two of these resolving
     * differently.
     *
     * Lives here, not on the canvas gate that consumes it, because both its
     * terms are this mixin's — canvas owns only how the density number is
     * measured.
     */
    resolvedByteLimit(): number | undefined;
    /**
     * #method
     * The gate as it is right now, for a fetch about to be issued. Calling it
     * is the capture, which is why it is a method.
     */
    gateFetchState(): GateFetchState;
} & {
    /**
     * #getter
     * The verdict the whole mixin exists to produce, with the banner text: true
     * when the measured download for what is on screen exceeds the resolved
     * byte budget, or when the display's own density axis trips (bytes take
     * precedence for the text). One expression per axis, each already carrying
     * every "may this axis gate" term — the opt-ins, force-load, the density
     * floor — so none of them is restated here.
     *
     * **The byte term is `resolvedByteLimit()`, the very budget the worker
     * enforces**, rather than a second `gateActive ? gateByteLimit :
     * undefined` beside it. The two were written out separately and had to be
     * kept equal by hand, which is the drift this subsystem is least able to
     * afford: a worker rejecting a region the banner then calls fine is a
     * blank display that never refetches. It also carries the `gateActive`
     * guard that keeps `gateByteLimit`'s containing-track read out of an
     * ungated display — "nothing below the opt-in is evaluated", which the
     * ungated composers (wiggle, Manhattan, sequence) and the simplified test
     * models rely on. The estimate needs no such guard: it is a volatile read
     * that reaches nothing, and an undefined budget refuses nothing.
     *
     * The fetch autoruns re-measure rather than fetch while `regionTooLarge` is
     * true, and `DisplayChrome` renders the banner from `regionTooLargeReason`.
     */
    readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
} & {
    /**
     * #getter
     */
    readonly regionTooLarge: boolean;
    /**
     * #getter
     * Which axis tripped, as banner text: the estimated download size, or
     * "Too many features". Empty string when the region isn't too large.
     */
    readonly regionTooLargeReason: string;
    /**
     * #getter
     * Whether "zoom in to see features" is still honest advice — the banner
     * offers that way out only when this is true, and force-load alone when it
     * isn't.
     *
     * **Asked of the axis that actually tripped**, because only one of the two
     * can ever answer no. Screen density is features ÷ pixels, so it falls
     * with `bpPerPx` by construction and zooming always releases it. Bytes
     * don't work that way: an index quotes whole blocks, so whether zooming
     * shrinks a given file's fetch is a property of that file's blocks and not
     * of any span threshold, and `ByteEstimate.zoomIneffective` records that
     * the user zoomed in materially and the bytes did not move.
     *
     * Reading `zoomIneffective` alone gets the density case backwards on
     * exactly the files that axis exists for. A dense VCF is small on disk and
     * flat across zooms, so two zoom steps while density-blocked set the flag
     * — the worker reports `bytes` alongside a density rejection, so the
     * estimate keeps updating while the banner holds — and the banner would
     * then withhold the one way out that works.
     *
     * True until proven otherwise, so a track that has been measured once
     * still reads as escapable. That is the right default: the failure this
     * guards is telling someone to keep zooming forever, not withholding the
     * suggestion for one zoom step.
     */
    readonly zoomCanReleaseGate: boolean;
} & {
    /**
     * #getter
     * The skip both fetch foundations apply before consulting the display's
     * own gate: the banner is up **and** the measurement behind it already
     * describes the viewport on screen, so this run has nothing to do. Its
     * negation is the rule `gateMeasurementStale` states — one fetch per
     * settled viewport while blocked, which IS the re-measure and the only
     * thing that can release the gate.
     *
     * One getter because it was one expression written twice, in
     * `installGlobalFetchAutorun` and in `MultiRegionDisplayMixin`'s
     * FetchVisibleRegions, each under its own paragraph saying the same thing.
     * A guard kept in two copies is where an escape clause gets added to one
     * of them; the two families should be exactly as far apart as their
     * autoruns need and no further.
     *
     * A display that opts into no byte gate reads `regionTooLarge` as a
     * literal false, so this is false for it too.
     */
    readonly gateSkipsMeasuredViewport: boolean;
} & {
    /**
     * #action
     * Commits a byte measurement together with the viewport it describes.
     * `viewport` must be `gateViewport` read when the measurement was
     * *requested*, not at commit time — a view that moved during the round trip
     * would otherwise label the number with a viewport it never covered, and
     * both readers of that label (`gateMeasurementStale`, `zoomIneffective`) would
     * answer about the wrong one. Harmless for non-gated displays (they ignore
     * it).
     *
     * Goes through `nextByteEstimate` rather than storing the argument,
     * because one thing about a measurement is only knowable from the one
     * before it: whether zooming in moved the number at all. See
     * `ByteEstimate.zoomIneffective`.
     *
     * `bytes` is a number, never `undefined`: a fetch that measured nothing
     * calls this not at all, so the stored estimate stays whatever the last
     * real measurement said. `commitByteMeasurement` is the one caller and
     * skips that write; the type is what keeps another from publishing an
     * empty one.
     */
    setByteEstimate(measurement: {
        bytes: number;
        viewport: GateViewport;
    }): void;
    /**
     * #action
     * Record that the gate has asked the adapter about this viewport, whatever
     * it learned. Every gated fetch reaches it through `commitByteMeasurement`,
     * and it is deliberately **separate**
     * from `setByteEstimate`, because a fetch can come back having measured
     * density and no bytes (a dense region short-circuits on the feature count,
     * and an unmeasurable byte result must not overwrite a good estimate). Both
     * still asked, and `gateMeasurementStale` is the question "did we ask about
     * what is on screen now", not "do we have bytes for it".
     */
    setGateMeasuredViewport(viewport: GateViewport): void;
    /**
     * #action
     * Drops the cached estimate. Two callers, and they are the same rule on
     * two axes — the estimate describes one fetch, and each of them changes
     * which fetch that is: chromosome navigation (`MultiRegionDisplayMixin`'s
     * `DisplayedRegionsChange` autorun; LD and arc wire their own), and a tier
     * swap (`ClearByteEstimateOnTierSwap`, this mixin's own `afterAttach`).
     * Not an ordinary viewport change: the estimate intentionally survives
     * `clearAllRpcData` so panning doesn't flicker the banner.
     *
     * `forceLoadTrack` deliberately survives both: it is a track-wide
     * approval, so expiring it here is exactly the per-locus re-approval the
     * button exists to avoid.
     */
    clearByteEstimate(): void;
    /**
     * #action
     * Exempt this track from the gate (or put it back under it). Separate from
     * `forceLoad` so turning the gate off and refetching stay separable — a
     * caller that just wants the flag (a revoke, a test) doesn't trigger a
     * fetch, and `forceLoad` doesn't have to inline a volatile write.
     */
    setForceLoadTrack(flag: boolean): void;
    /**
     * #action
     */
    reload(): void;
} & {
    /**
     * #action
     * The measurement-commit protocol, held once for every display: the
     * fan-out helpers reach it through `commitFetchBytes` and the global
     * runner through the same. Four rules, each of which used to be spelled
     * at two call sites or nowhere:
     *
     * - a measurement is judged by the tier it was *issued* against — a fetch
     *   still in flight when `ClearByteEstimateOnTierSwap` fires would
     *   otherwise re-instate the old tier's bytes right behind the clear, and
     *   the banner would quote them against the new tier's file until the
     *   next fetch corrected it
     * - a fetch the gate sat out stamps nothing (`gated: false`), so
     *   `gateMeasurementStale` keeps asking about the live viewport
     * - unmeasurable is not a measurement — an undefined `bytes` must not
     *   wipe the last real estimate
     * - the estimate commits whatever the budget was, so lowering a budget
     *   later re-banners from stored numbers with no RPC
     */
    commitByteMeasurement({ viewport, gated, tierKey, bytes, }: {
        viewport: GateViewport;
        gated: boolean;
        tierKey: string | undefined;
        bytes?: number;
    }): void;
} & {
    /**
     * #action
     * The byte axis of a finished fetch, committed from what its results
     * measured. **The fan-out helpers call this, not the display**: a display
     * opts into the gate by passing `byteLimit: self.resolvedByteLimit()` in
     * its RPC call and nothing else, and every RPC that takes that budget
     * answers `bytes` — in the payload when it was under, in the
     * `RegionTooLargeResult` when it was not.
     *
     * **Max, not sum**: the budget is what one region may cost, so a batch
     * commits its largest. An empty batch commits nothing, because a fetch
     * with no results asked the adapter nothing and stamping the viewport
     * would tell `gateMeasurementStale` otherwise.
     *
     * The rules about which measurement wins, what an unmeasurable result
     * leaves alone and which tier a number is about are all
     * `commitByteMeasurement`'s — this adds only the max and the capture.
     */
    commitFetchBytes(perRegionBytes: (number | undefined)[], issued: GateFetchState): void;
} & {
    /**
     * #action
     * Force-load: exempt this track from the gate and refetch. One click covers
     * every region and both axes, informed by the size the banner just quoted.
     * The display chrome calls this from TooLargeMessage's button; concrete
     * display models override `reload()` to do the actual refetch.
     */
    forceLoad(): void;
} & {
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
