import type { TooLargeMessageModel } from '@jbrowse/display-ui';
export type { TooLargeMessageModel };
declare const TooLargeMessage: ({ model, }: {
    model: TooLargeMessageModel;
}) => import("react").JSX.Element;
export default TooLargeMessage;
