import type { Mark } from './marks.ts';
import type { ExportSvgDisplayOptions } from './types.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type { ConfigSlotDefinition } from '@jbrowse/core/configuration/configurationSlot';
import type { BaseFeatureDataAdapter } from '@jbrowse/core/data_adapters/BaseAdapter';
import type { Region } from '@jbrowse/core/util';
import type { Ctx2D } from '@jbrowse/core/util/paintLayer';
import type { StatusCallback } from '@jbrowse/core/util/progress';
import type { StopToken } from '@jbrowse/core/util/stopToken';
import type { BlockClipResult } from '@jbrowse/render-core/blockClipUtils';
import type { InstancePass } from '@jbrowse/render-core/instancePass';
import type { PerRegionRenderingBackend } from '@jbrowse/render-core/perRegionRenderingBackend';
import type { RenderBlock } from '@jbrowse/render-core/renderBlock';
import type { ShaderModule } from '@jbrowse/render-core/slangPass';
/**
 * What a setting invalidates when it changes: the worker fetch, the
 * main-thread encode, or only the next frame. The factory derives the RPC
 * cache key from the `fetch` set and the render state from all of them, so a
 * display never spells `rpcProps` / `gpuProps` / `renderState` by hand and
 * cannot put a fetch result in a cache key.
 */
export type ParamAffects = 'fetch' | 'encode' | 'frame';
export type ParamDefinition = ConfigSlotDefinition & {
    affects: ParamAffects;
};
export type ParamSchema = Record<string, ParamDefinition>;
export type ParamValues<P extends ParamSchema> = {
    [K in keyof P]: P[K]['defaultValue'];
};
type KeysAffecting<P extends ParamSchema, A extends ParamAffects> = {
    [K in keyof P]: P[K]['affects'] extends A ? K : never;
}[keyof P];
export type FetchParams<P extends ParamSchema> = Pick<ParamValues<P>, KeysAffecting<P, 'fetch'>>;
/** What the worker `data` function is handed for one region. */
export interface DataContext<P extends ParamSchema> {
    adapter: BaseFeatureDataAdapter;
    region: Region;
    params: FetchParams<P>;
    stopToken: StopToken | undefined;
    statusCallback: StatusCallback;
}
/** What every paint reads: the canvas box and every setting, resolved. */
export interface DisplayRenderState<P extends ParamSchema> {
    canvasWidth: number;
    canvasHeight: number;
    params: ParamValues<P>;
}
export type Paint<Payload, P extends ParamSchema> = (ctx: Ctx2D, regions: ReadonlyMap<number, Payload>, blocks: RenderBlock[], state: DisplayRenderState<P>) => void;
/**
 * The GPU accelerator: a generated shader module, the passes packed from one
 * region's payload, and the uniforms one clipped block draws with. The
 * factory owns the renderer around it, so a display writes no backend class.
 */
export interface GpuSpec<Payload, P extends ParamSchema, Uniforms> {
    shader: ShaderModule & {
        UNIFORMS_SIZE_BYTES: number;
        writeUniforms: (buf: ArrayBuffer, uniforms: Uniforms) => void;
    };
    passes: InstancePass<Payload>[];
    uniforms: (block: RenderBlock, clip: BlockClipResult, region: Payload, state: DisplayRenderState<P>) => Uniforms;
}
/**
 * How the display draws: a `mark` (a shape plus its channels, from which the
 * GPU pass, the Canvas2D painter and the SVG export all derive), or a `paint`
 * of your own with an optional `gpu` block beside it.
 */
export type Drawing<Payload, P extends ParamSchema, Uniforms> = {
    mark: Mark<Payload, P>;
    paint?: never;
    gpu?: never;
} | {
    paint: Paint<Payload, P>;
    gpu?: GpuSpec<Payload, P, Uniforms>;
    mark?: never;
};
export type DisplaySpec<Payload extends object, P extends ParamSchema, Uniforms> = {
    name: string;
    displayName?: string;
    trackType: string;
    params: P;
    /** Runs in the worker, once per region. Positions come back as absolute bp. */
    data: (ctx: DataContext<P>) => Promise<Payload>;
} & Drawing<Payload, P, Uniforms>;
/**
 * A track type in one call. The spec is the four things a display genuinely
 * decides — its settings, its worker fetch, how it paints, and optionally how
 * the GPU draws it — and the factory composes the display layer around them:
 * the config schema, the per-region fetch foundation, the upload lifecycle,
 * the chrome, the RPC method, and SVG export. Register with `install(pm)`
 * from the plugin's own `install`; it runs on the main thread and in the
 * worker alike, which is what puts `data` where the adapter is.
 */
export declare function defineDisplay<Payload extends object, P extends ParamSchema, Uniforms>(spec: DisplaySpec<Payload, P, Uniforms>): {
    name: string;
    configSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        [k: string]: {
            description?: string;
            model?: import("@jbrowse/mobx-state-tree").IAnyType;
            contextVariable?: string[];
            advanced?: boolean;
            promotedBase?: unknown;
            validate?: (value: unknown) => boolean;
            type: import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName;
            defaultValue?: unknown;
        } | {
            description?: string;
            model?: import("@jbrowse/mobx-state-tree").IAnyType;
            contextVariable?: string[];
            advanced?: boolean;
            promotedBase?: unknown;
            validate?: (value: unknown) => boolean;
            type: Exclude<import("@jbrowse/core/configuration/configurationSlot").ConfigSlotType, import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName>;
            defaultValue: unknown;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly maxFeatureScreenDensity: {
            readonly type: "number";
            readonly description: "maximum features per pixel before showing a \"too many features\" message";
            readonly defaultValue: 1;
            readonly advanced: true;
        };
        readonly fetchSizeLimit: {
            readonly type: "number";
            readonly defaultValue: 1000000;
            readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
            readonly advanced: true;
        };
        readonly forceLoad: {
            readonly type: "boolean";
            readonly defaultValue: false;
            readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
            readonly advanced: true;
        };
        readonly height: {
            readonly type: "number";
            readonly defaultValue: 100;
            readonly description: "default height for the track";
        };
        readonly mouseover: {
            readonly type: "string";
            readonly description: "text to display when the cursor hovers over a feature";
            readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
            readonly contextVariable: ["feature"];
        };
        readonly jexlFilters: {
            readonly type: "stringArray";
            readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>, undefined>>;
    stateModel: import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{
        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    }, never>, never> & Omit<Omit<Omit<{}, never>, never>, never>, "configuration" | "type"> & {
        type: import("@jbrowse/mobx-state-tree").ILiteralType<string>;
        configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            [k: string]: {
                description?: string;
                model?: import("@jbrowse/mobx-state-tree").IAnyType;
                contextVariable?: string[];
                advanced?: boolean;
                promotedBase?: unknown;
                validate?: (value: unknown) => boolean;
                type: import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName;
                defaultValue?: unknown;
            } | {
                description?: string;
                model?: import("@jbrowse/mobx-state-tree").IAnyType;
                contextVariable?: string[];
                advanced?: boolean;
                promotedBase?: unknown;
                validate?: (value: unknown) => boolean;
                type: Exclude<import("@jbrowse/core/configuration/configurationSlot").ConfigSlotType, import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName>;
                defaultValue: unknown;
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly maxFeatureScreenDensity: {
                readonly type: "number";
                readonly description: "maximum features per pixel before showing a \"too many features\" message";
                readonly defaultValue: 1;
                readonly advanced: true;
            };
            readonly fetchSizeLimit: {
                readonly type: "number";
                readonly defaultValue: 1000000;
                readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
                readonly advanced: true;
            };
            readonly forceLoad: {
                readonly type: "boolean";
                readonly defaultValue: false;
                readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
                readonly advanced: true;
            };
            readonly height: {
                readonly type: "number";
                readonly defaultValue: 100;
                readonly description: "default height for the track";
            };
            readonly mouseover: {
                readonly type: "string";
                readonly description: "text to display when the cursor hovers over a feature";
                readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
                readonly contextVariable: ["feature"];
            };
            readonly jexlFilters: {
                readonly type: "stringArray";
                readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
                readonly defaultValue: readonly [];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>, undefined>>>;
    }, {
        error: unknown;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
    } & {
        readonly RenderingComponent: React.FC<{
            model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            }> & {
                error: unknown;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            }, {
                error: unknown;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            onHorizontalScroll?: (distance: number) => void;
            blockState?: Record<string, unknown>;
        }>;
        readonly DisplayBlurb: React.FC<{
            model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            }> & {
                error: unknown;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            }, {
                error: unknown;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }> | null;
        readonly adapterConfig: Record<string, unknown>;
        readonly isMinimized: boolean;
        readonly hoveredFeature: unknown;
        readonly featureNoun: string;
        readonly featureWidgetType: {
            type: string;
            id: string;
        };
    } & {
        renderingProps(): {
            displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            }> & {
                error: unknown;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
            } & {
                readonly RenderingComponent: React.FC<{
                    model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }> & {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }, {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    onHorizontalScroll?: (distance: number) => void;
                    blockState?: Record<string, unknown>;
                }>;
                readonly DisplayBlurb: React.FC<{
                    model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }> & {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }, {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                }> | null;
                readonly adapterConfig: Record<string, unknown>;
                readonly isMinimized: boolean;
                readonly hoveredFeature: unknown;
                readonly featureNoun: string;
                readonly featureWidgetType: {
                    type: string;
                    id: string;
                };
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
            }, {
                error: unknown;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
            } & {
                readonly RenderingComponent: React.FC<{
                    model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }> & {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }, {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    onHorizontalScroll?: (distance: number) => void;
                    blockState?: Record<string, unknown>;
                }>;
                readonly DisplayBlurb: React.FC<{
                    model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }> & {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                        id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                        type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                    }, {
                        error: unknown;
                        statusMessage: string | undefined;
                        statusProgress: number | undefined;
                    } & {
                        readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                }> | null;
                readonly adapterConfig: Record<string, unknown>;
                readonly isMinimized: boolean;
                readonly hoveredFeature: unknown;
                readonly featureNoun: string;
                readonly featureWidgetType: {
                    type: string;
                    id: string;
                };
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        };
        trackMenuItems(): import("@jbrowse/core/ui").MenuItem[];
    } & {
        setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
        setError(error?: unknown): void;
        clearHoveredFeature(): void;
        reload(): void;
    } & {
        scrollTop: number;
        resizing: boolean;
    } & {
        readonly height: number;
        readonly scrollableHeight: number;
    } & {
        setScrollTop(scrollTop: number): void;
        setResizing(arg: boolean): void;
        setHeight(displayHeight: number): number;
        resizeHeight(distance: number): number;
    } & {
        expandToContentHeight(): number;
        afterAttach(): void;
    } & {
        forceLoadTrack: boolean;
        byteEstimate: import("./regionTooLargeUtils.ts").ByteEstimate | undefined;
        gateMeasuredViewportKey: string | undefined;
    } & {
        readonly gateEnabled: boolean;
        readonly densityGateEnabled: boolean;
        readonly byteGateAdapterConfig: Record<string, unknown>;
        readonly configuredFetchSizeLimit: number;
        readonly densityTooLarge: boolean;
        readonly byteGateAdapterPath: string[];
        readonly adapterFetchSizeLimit: number | undefined;
        readonly configForceLoad: boolean;
        readonly gateViewport: import("./regionTooLargeUtils.ts").GateViewport | undefined;
    } & {
        readonly byteGateAdapterKey: string;
        readonly aboveForceLoadFloor: boolean;
        readonly gateExempt: boolean;
        readonly estimatedFetchBytes: number | undefined;
        readonly gateMeasurementStale: boolean;
    } & {
        readonly gateByteLimit: number;
        readonly gateActive: boolean;
    } & {
        readonly densityGateActive: boolean;
        resolvedByteLimit(): number | undefined;
        gateFetchState(): import("./regionTooLargeUtils.ts").GateFetchState;
    } & {
        readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
    } & {
        readonly regionTooLarge: boolean;
        readonly regionTooLargeReason: string;
        readonly zoomCanReleaseGate: boolean;
    } & {
        readonly gateSkipsMeasuredViewport: boolean;
    } & {
        setByteEstimate(measurement: {
            bytes: number;
            viewport: import("./regionTooLargeUtils.ts").GateViewport;
        }): void;
        setGateMeasuredViewport(viewport: import("./regionTooLargeUtils.ts").GateViewport): void;
        clearByteEstimate(): void;
        setForceLoadTrack(flag: boolean): void;
        reload(): void;
    } & {
        commitByteMeasurement({ viewport, gated, tierKey, bytes, }: {
            viewport: import("./regionTooLargeUtils.ts").GateViewport;
            gated: boolean;
            tierKey: string | undefined;
            bytes?: number;
        }): void;
    } & {
        commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("./regionTooLargeUtils.ts").GateFetchState): void;
    } & {
        forceLoad(): void;
    } & {
        afterAttach(): void;
    } & {
        canvasDrawn: boolean;
        currentRenderingBackend: unknown;
        renderTick: number;
        autorunsInstalled: boolean;
        renderError: unknown;
    } & {
        readonly canRender: boolean;
        readonly rendersCanvas: boolean;
        readonly paintInert: boolean;
    } & {
        readonly painted: boolean;
    } & {
        markCanvasDrawn(): void;
        resetCanvasDrawn(): void;
        stopRenderingBackend(): void;
        renderNow(): void;
        setRenderError(error: unknown): void;
    } & {
        attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
    } & {
        activeStopToken: StopToken | undefined;
        fetchGeneration: number;
        reloadCounter: number;
        statusWindow: import("@jbrowse/core/util").StatusWindow;
        error: unknown;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
        fetchCanceled: boolean;
    } & {
        fetchRotation: {
            begin(): import("@jbrowse/core/util").ActiveFetch;
            cancel: () => void;
            dispose(): void;
        };
    } & {
        readonly isLoading: boolean;
    } & {
        readonly isLoadingOrCanceled: boolean;
        readonly fetchInert: boolean;
        readonly awaitingPrerequisite: boolean;
        readonly rpcPropsCacheKey: string;
    } & {
        setError(error?: unknown): void;
        setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    } & {
        stopActiveFetch(): void;
        openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
    } & {
        cancelFetch(): void;
        cancelFetchByUser(): void;
        beforeDestroy(): void;
        endFetch(current: boolean, stopToken: StopToken): void;
    } & {
        runFetch: (work: (ctx: import("@jbrowse/core/util/fetchContext").FetchContext) => Promise<void>) => Promise<void>;
    } & {
        loadedRegions: import("mobx").ObservableMap<number, import("./regionCommit.ts").LoadedRegion>;
    } & {
        readonly host: import("./regionHost.ts").RegionHost;
        readonly canvasWidthPx: number;
        readonly canRender: boolean;
        readonly viewportWithinLoadedData: boolean;
        readonly viewportEmpty: boolean;
        readonly layoutReady: boolean;
        readonly regionFetchKey: string;
        regionHasData(_displayedRegionIndex: number): boolean;
        readonly dataSuperseded: boolean;
        readonly renderBlocks: RenderBlock[];
    } & {
        readonly dataCurrent: boolean;
        readonly loadedAssembly: import("@jbrowse/core/assemblyManager/assembly").Assembly | undefined;
    } & {
        readonly svgReady: boolean;
        readonly paintInert: boolean;
        readonly displayPhase: import("@jbrowse/render-core/displayPhase").DisplayPhase;
    } & {
        setLoadedRegion(displayedRegionIndex: number, region: Region, fetchKey?: string): void;
        dropLoadedRegion(displayedRegionIndex: number): void;
        clearDisplaySpecificData(): void;
    } & {
        clearAllRpcData(): void;
        reload(): void;
    } & {
        fetchNeeded(_needed: import("./planRegionFetch.ts").IndexedRegion[]): void;
    } & {
        isCacheValid(displayedRegionIndex: number): boolean;
    } & {
        fetchRegions(needed: import("./planRegionFetch.ts").IndexedRegion[], work: (ctx: import("./regionCommit.ts").RegionFetchContext) => Promise<void>): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        rpcDataMap: import("mobx").ObservableMap<number, Payload>;
    } & {
        readonly params: ParamValues<P>;
        rpcProps(): {
            params: ParamValues<P>;
        };
        readonly renderState: DisplayRenderState<P>;
    } & {
        setRpcData(displayedRegionIndex: number, payload: Payload): void;
        clearDisplaySpecificData(): void;
    } & {
        fetchNeeded(needed: {
            region: Region;
            displayedRegionIndex: number;
        }[]): Promise<void>;
        startRenderingBackend(backend: PerRegionRenderingBackend<Payload, DisplayRenderState<P>, RenderBlock, Payload>): void;
        renderSvg(opts?: ExportSvgDisplayOptions): Promise<import("react").ReactNode>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
    ReactComponent: ({ model, }: {
        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Omit<Omit<Omit<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, never>, never> & Omit<Omit<Omit<{}, never>, never>, never>, "configuration" | "type"> & {
            type: import("@jbrowse/mobx-state-tree").ILiteralType<string>;
            configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
                [k: string]: {
                    description?: string;
                    model?: import("@jbrowse/mobx-state-tree").IAnyType;
                    contextVariable?: string[];
                    advanced?: boolean;
                    promotedBase?: unknown;
                    validate?: (value: unknown) => boolean;
                    type: import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName;
                    defaultValue?: unknown;
                } | {
                    description?: string;
                    model?: import("@jbrowse/mobx-state-tree").IAnyType;
                    contextVariable?: string[];
                    advanced?: boolean;
                    promotedBase?: unknown;
                    validate?: (value: unknown) => boolean;
                    type: Exclude<import("@jbrowse/core/configuration/configurationSlot").ConfigSlotType, import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName>;
                    defaultValue: unknown;
                };
            }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
                readonly maxFeatureScreenDensity: {
                    readonly type: "number";
                    readonly description: "maximum features per pixel before showing a \"too many features\" message";
                    readonly defaultValue: 1;
                    readonly advanced: true;
                };
                readonly fetchSizeLimit: {
                    readonly type: "number";
                    readonly defaultValue: 1000000;
                    readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
                    readonly advanced: true;
                };
                readonly forceLoad: {
                    readonly type: "boolean";
                    readonly defaultValue: false;
                    readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
                    readonly advanced: true;
                };
                readonly height: {
                    readonly type: "number";
                    readonly defaultValue: 100;
                    readonly description: "default height for the track";
                };
                readonly mouseover: {
                    readonly type: "string";
                    readonly description: "text to display when the cursor hovers over a feature";
                    readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
                    readonly contextVariable: ["feature"];
                };
                readonly jexlFilters: {
                    readonly type: "stringArray";
                    readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
                    readonly defaultValue: readonly [];
                };
            }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>, undefined>>>;
        }> & {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: Record<string, unknown>;
            readonly isMinimized: boolean;
            readonly hoveredFeature: unknown;
            readonly featureNoun: string;
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        } & {
            renderingProps(): {
                displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            };
            trackMenuItems(): import("@jbrowse/core/ui").MenuItem[];
        } & {
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
            setError(error?: unknown): void;
            clearHoveredFeature(): void;
            reload(): void;
        } & {
            scrollTop: number;
            resizing: boolean;
        } & {
            readonly height: number;
            readonly scrollableHeight: number;
        } & {
            setScrollTop(scrollTop: number): void;
            setResizing(arg: boolean): void;
            setHeight(displayHeight: number): number;
            resizeHeight(distance: number): number;
        } & {
            expandToContentHeight(): number;
            afterAttach(): void;
        } & {
            forceLoadTrack: boolean;
            byteEstimate: import("./regionTooLargeUtils.ts").ByteEstimate | undefined;
            gateMeasuredViewportKey: string | undefined;
        } & {
            readonly gateEnabled: boolean;
            readonly densityGateEnabled: boolean;
            readonly byteGateAdapterConfig: Record<string, unknown>;
            readonly configuredFetchSizeLimit: number;
            readonly densityTooLarge: boolean;
            readonly byteGateAdapterPath: string[];
            readonly adapterFetchSizeLimit: number | undefined;
            readonly configForceLoad: boolean;
            readonly gateViewport: import("./regionTooLargeUtils.ts").GateViewport | undefined;
        } & {
            readonly byteGateAdapterKey: string;
            readonly aboveForceLoadFloor: boolean;
            readonly gateExempt: boolean;
            readonly estimatedFetchBytes: number | undefined;
            readonly gateMeasurementStale: boolean;
        } & {
            readonly gateByteLimit: number;
            readonly gateActive: boolean;
        } & {
            readonly densityGateActive: boolean;
            resolvedByteLimit(): number | undefined;
            gateFetchState(): import("./regionTooLargeUtils.ts").GateFetchState;
        } & {
            readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
        } & {
            readonly regionTooLarge: boolean;
            readonly regionTooLargeReason: string;
            readonly zoomCanReleaseGate: boolean;
        } & {
            readonly gateSkipsMeasuredViewport: boolean;
        } & {
            setByteEstimate(measurement: {
                bytes: number;
                viewport: import("./regionTooLargeUtils.ts").GateViewport;
            }): void;
            setGateMeasuredViewport(viewport: import("./regionTooLargeUtils.ts").GateViewport): void;
            clearByteEstimate(): void;
            setForceLoadTrack(flag: boolean): void;
            reload(): void;
        } & {
            commitByteMeasurement({ viewport, gated, tierKey, bytes, }: {
                viewport: import("./regionTooLargeUtils.ts").GateViewport;
                gated: boolean;
                tierKey: string | undefined;
                bytes?: number;
            }): void;
        } & {
            commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("./regionTooLargeUtils.ts").GateFetchState): void;
        } & {
            forceLoad(): void;
        } & {
            afterAttach(): void;
        } & {
            canvasDrawn: boolean;
            currentRenderingBackend: unknown;
            renderTick: number;
            autorunsInstalled: boolean;
            renderError: unknown;
        } & {
            readonly canRender: boolean;
            readonly rendersCanvas: boolean;
            readonly paintInert: boolean;
        } & {
            readonly painted: boolean;
        } & {
            markCanvasDrawn(): void;
            resetCanvasDrawn(): void;
            stopRenderingBackend(): void;
            renderNow(): void;
            setRenderError(error: unknown): void;
        } & {
            attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
        } & {
            activeStopToken: StopToken | undefined;
            fetchGeneration: number;
            reloadCounter: number;
            statusWindow: import("@jbrowse/core/util").StatusWindow;
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
            fetchCanceled: boolean;
        } & {
            fetchRotation: {
                begin(): import("@jbrowse/core/util").ActiveFetch;
                cancel: () => void;
                dispose(): void;
            };
        } & {
            readonly isLoading: boolean;
        } & {
            readonly isLoadingOrCanceled: boolean;
            readonly fetchInert: boolean;
            readonly awaitingPrerequisite: boolean;
            readonly rpcPropsCacheKey: string;
        } & {
            setError(error?: unknown): void;
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
        } & {
            stopActiveFetch(): void;
            openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
        } & {
            cancelFetch(): void;
            cancelFetchByUser(): void;
            beforeDestroy(): void;
            endFetch(current: boolean, stopToken: StopToken): void;
        } & {
            runFetch: (work: (ctx: import("@jbrowse/core/util/fetchContext").FetchContext) => Promise<void>) => Promise<void>;
        } & {
            loadedRegions: import("mobx").ObservableMap<number, import("./regionCommit.ts").LoadedRegion>;
        } & {
            readonly host: import("./regionHost.ts").RegionHost;
            readonly canvasWidthPx: number;
            readonly canRender: boolean;
            readonly viewportWithinLoadedData: boolean;
            readonly viewportEmpty: boolean;
            readonly layoutReady: boolean;
            readonly regionFetchKey: string;
            regionHasData(_displayedRegionIndex: number): boolean;
            readonly dataSuperseded: boolean;
            readonly renderBlocks: RenderBlock[];
        } & {
            readonly dataCurrent: boolean;
            readonly loadedAssembly: import("@jbrowse/core/assemblyManager/assembly").Assembly | undefined;
        } & {
            readonly svgReady: boolean;
            readonly paintInert: boolean;
            readonly displayPhase: import("@jbrowse/render-core/displayPhase").DisplayPhase;
        } & {
            setLoadedRegion(displayedRegionIndex: number, region: Region, fetchKey?: string): void;
            dropLoadedRegion(displayedRegionIndex: number): void;
            clearDisplaySpecificData(): void;
        } & {
            clearAllRpcData(): void;
            reload(): void;
        } & {
            fetchNeeded(_needed: import("./planRegionFetch.ts").IndexedRegion[]): void;
        } & {
            isCacheValid(displayedRegionIndex: number): boolean;
        } & {
            fetchRegions(needed: import("./planRegionFetch.ts").IndexedRegion[], work: (ctx: import("./regionCommit.ts").RegionFetchContext) => Promise<void>): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            rpcDataMap: import("mobx").ObservableMap<number, Payload>;
        } & {
            readonly params: ParamValues<P>;
            rpcProps(): {
                params: ParamValues<P>;
            };
            readonly renderState: DisplayRenderState<P>;
        } & {
            setRpcData(displayedRegionIndex: number, payload: Payload): void;
            clearDisplaySpecificData(): void;
        } & {
            fetchNeeded(needed: {
                region: Region;
                displayedRegionIndex: number;
            }[]): Promise<void>;
            startRenderingBackend(backend: PerRegionRenderingBackend<Payload, DisplayRenderState<P>, RenderBlock, Payload>): void;
            renderSvg(opts?: ExportSvgDisplayOptions): Promise<import("react").ReactNode>;
        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{
            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
        }, never>, never> & Omit<Omit<Omit<{}, never>, never>, never>, "configuration" | "type"> & {
            type: import("@jbrowse/mobx-state-tree").ILiteralType<string>;
            configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
                [k: string]: {
                    description?: string;
                    model?: import("@jbrowse/mobx-state-tree").IAnyType;
                    contextVariable?: string[];
                    advanced?: boolean;
                    promotedBase?: unknown;
                    validate?: (value: unknown) => boolean;
                    type: import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName;
                    defaultValue?: unknown;
                } | {
                    description?: string;
                    model?: import("@jbrowse/mobx-state-tree").IAnyType;
                    contextVariable?: string[];
                    advanced?: boolean;
                    promotedBase?: unknown;
                    validate?: (value: unknown) => boolean;
                    type: Exclude<import("@jbrowse/core/configuration/configurationSlot").ConfigSlotType, import("@jbrowse/core/configuration/configurationSlot").MaybeSlotTypeName>;
                    defaultValue: unknown;
                };
            }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
                readonly maxFeatureScreenDensity: {
                    readonly type: "number";
                    readonly description: "maximum features per pixel before showing a \"too many features\" message";
                    readonly defaultValue: 1;
                    readonly advanced: true;
                };
                readonly fetchSizeLimit: {
                    readonly type: "number";
                    readonly defaultValue: 1000000;
                    readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
                    readonly advanced: true;
                };
                readonly forceLoad: {
                    readonly type: "boolean";
                    readonly defaultValue: false;
                    readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
                    readonly advanced: true;
                };
                readonly height: {
                    readonly type: "number";
                    readonly defaultValue: 100;
                    readonly description: "default height for the track";
                };
                readonly mouseover: {
                    readonly type: "string";
                    readonly description: "text to display when the cursor hovers over a feature";
                    readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
                    readonly contextVariable: ["feature"];
                };
                readonly jexlFilters: {
                    readonly type: "stringArray";
                    readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
                    readonly defaultValue: readonly [];
                };
            }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>, undefined>>>;
        }, {
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
        } & {
            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
        } & {
            readonly RenderingComponent: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                onHorizontalScroll?: (distance: number) => void;
                blockState?: Record<string, unknown>;
            }>;
            readonly DisplayBlurb: React.FC<{
                model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            }> | null;
            readonly adapterConfig: Record<string, unknown>;
            readonly isMinimized: boolean;
            readonly hoveredFeature: unknown;
            readonly featureNoun: string;
            readonly featureWidgetType: {
                type: string;
                id: string;
            };
        } & {
            renderingProps(): {
                displayModel: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }> & {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                }, {
                    error: unknown;
                    statusMessage: string | undefined;
                    statusProgress: number | undefined;
                } & {
                    readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                } & {
                    readonly RenderingComponent: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                        onHorizontalScroll?: (distance: number) => void;
                        blockState?: Record<string, unknown>;
                    }>;
                    readonly DisplayBlurb: React.FC<{
                        model: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }> & {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                            id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
                            type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
                        }, {
                            error: unknown;
                            statusMessage: string | undefined;
                            statusProgress: number | undefined;
                        } & {
                            readonly parentTrack: import("@jbrowse/core/util").AbstractTrackModel;
                        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
                    }> | null;
                    readonly adapterConfig: Record<string, unknown>;
                    readonly isMinimized: boolean;
                    readonly hoveredFeature: unknown;
                    readonly featureNoun: string;
                    readonly featureWidgetType: {
                        type: string;
                        id: string;
                    };
                }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
            };
            trackMenuItems(): import("@jbrowse/core/ui").MenuItem[];
        } & {
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
            setError(error?: unknown): void;
            clearHoveredFeature(): void;
            reload(): void;
        } & {
            scrollTop: number;
            resizing: boolean;
        } & {
            readonly height: number;
            readonly scrollableHeight: number;
        } & {
            setScrollTop(scrollTop: number): void;
            setResizing(arg: boolean): void;
            setHeight(displayHeight: number): number;
            resizeHeight(distance: number): number;
        } & {
            expandToContentHeight(): number;
            afterAttach(): void;
        } & {
            forceLoadTrack: boolean;
            byteEstimate: import("./regionTooLargeUtils.ts").ByteEstimate | undefined;
            gateMeasuredViewportKey: string | undefined;
        } & {
            readonly gateEnabled: boolean;
            readonly densityGateEnabled: boolean;
            readonly byteGateAdapterConfig: Record<string, unknown>;
            readonly configuredFetchSizeLimit: number;
            readonly densityTooLarge: boolean;
            readonly byteGateAdapterPath: string[];
            readonly adapterFetchSizeLimit: number | undefined;
            readonly configForceLoad: boolean;
            readonly gateViewport: import("./regionTooLargeUtils.ts").GateViewport | undefined;
        } & {
            readonly byteGateAdapterKey: string;
            readonly aboveForceLoadFloor: boolean;
            readonly gateExempt: boolean;
            readonly estimatedFetchBytes: number | undefined;
            readonly gateMeasurementStale: boolean;
        } & {
            readonly gateByteLimit: number;
            readonly gateActive: boolean;
        } & {
            readonly densityGateActive: boolean;
            resolvedByteLimit(): number | undefined;
            gateFetchState(): import("./regionTooLargeUtils.ts").GateFetchState;
        } & {
            readonly tooLargeStatus: import("./regionTooLargeUtils.ts").RegionTooLargeStatus;
        } & {
            readonly regionTooLarge: boolean;
            readonly regionTooLargeReason: string;
            readonly zoomCanReleaseGate: boolean;
        } & {
            readonly gateSkipsMeasuredViewport: boolean;
        } & {
            setByteEstimate(measurement: {
                bytes: number;
                viewport: import("./regionTooLargeUtils.ts").GateViewport;
            }): void;
            setGateMeasuredViewport(viewport: import("./regionTooLargeUtils.ts").GateViewport): void;
            clearByteEstimate(): void;
            setForceLoadTrack(flag: boolean): void;
            reload(): void;
        } & {
            commitByteMeasurement({ viewport, gated, tierKey, bytes, }: {
                viewport: import("./regionTooLargeUtils.ts").GateViewport;
                gated: boolean;
                tierKey: string | undefined;
                bytes?: number;
            }): void;
        } & {
            commitFetchBytes(perRegionBytes: (number | undefined)[], issued: import("./regionTooLargeUtils.ts").GateFetchState): void;
        } & {
            forceLoad(): void;
        } & {
            afterAttach(): void;
        } & {
            canvasDrawn: boolean;
            currentRenderingBackend: unknown;
            renderTick: number;
            autorunsInstalled: boolean;
            renderError: unknown;
        } & {
            readonly canRender: boolean;
            readonly rendersCanvas: boolean;
            readonly paintInert: boolean;
        } & {
            readonly painted: boolean;
        } & {
            markCanvasDrawn(): void;
            resetCanvasDrawn(): void;
            stopRenderingBackend(): void;
            renderNow(): void;
            setRenderError(error: unknown): void;
        } & {
            attachRenderingBackend<B>(backend: B, setup: () => import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
        } & {
            activeStopToken: StopToken | undefined;
            fetchGeneration: number;
            reloadCounter: number;
            statusWindow: import("@jbrowse/core/util").StatusWindow;
            error: unknown;
            statusMessage: string | undefined;
            statusProgress: number | undefined;
            fetchCanceled: boolean;
        } & {
            fetchRotation: {
                begin(): import("@jbrowse/core/util").ActiveFetch;
                cancel: () => void;
                dispose(): void;
            };
        } & {
            readonly isLoading: boolean;
        } & {
            readonly isLoadingOrCanceled: boolean;
            readonly fetchInert: boolean;
            readonly awaitingPrerequisite: boolean;
            readonly rpcPropsCacheKey: string;
        } & {
            setError(error?: unknown): void;
            setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
        } & {
            stopActiveFetch(): void;
            openStatusStream(isCurrent: () => boolean): import("@jbrowse/core/util").StatusStream;
        } & {
            cancelFetch(): void;
            cancelFetchByUser(): void;
            beforeDestroy(): void;
            endFetch(current: boolean, stopToken: StopToken): void;
        } & {
            runFetch: (work: (ctx: import("@jbrowse/core/util/fetchContext").FetchContext) => Promise<void>) => Promise<void>;
        } & {
            loadedRegions: import("mobx").ObservableMap<number, import("./regionCommit.ts").LoadedRegion>;
        } & {
            readonly host: import("./regionHost.ts").RegionHost;
            readonly canvasWidthPx: number;
            readonly canRender: boolean;
            readonly viewportWithinLoadedData: boolean;
            readonly viewportEmpty: boolean;
            readonly layoutReady: boolean;
            readonly regionFetchKey: string;
            regionHasData(_displayedRegionIndex: number): boolean;
            readonly dataSuperseded: boolean;
            readonly renderBlocks: RenderBlock[];
        } & {
            readonly dataCurrent: boolean;
            readonly loadedAssembly: import("@jbrowse/core/assemblyManager/assembly").Assembly | undefined;
        } & {
            readonly svgReady: boolean;
            readonly paintInert: boolean;
            readonly displayPhase: import("@jbrowse/render-core/displayPhase").DisplayPhase;
        } & {
            setLoadedRegion(displayedRegionIndex: number, region: Region, fetchKey?: string): void;
            dropLoadedRegion(displayedRegionIndex: number): void;
            clearDisplaySpecificData(): void;
        } & {
            clearAllRpcData(): void;
            reload(): void;
        } & {
            fetchNeeded(_needed: import("./planRegionFetch.ts").IndexedRegion[]): void;
        } & {
            isCacheValid(displayedRegionIndex: number): boolean;
        } & {
            fetchRegions(needed: import("./planRegionFetch.ts").IndexedRegion[], work: (ctx: import("./regionCommit.ts").RegionFetchContext) => Promise<void>): Promise<void>;
        } & {
            afterAttach(): void;
        } & {
            rpcDataMap: import("mobx").ObservableMap<number, Payload>;
        } & {
            readonly params: ParamValues<P>;
            rpcProps(): {
                params: ParamValues<P>;
            };
            readonly renderState: DisplayRenderState<P>;
        } & {
            setRpcData(displayedRegionIndex: number, payload: Payload): void;
            clearDisplaySpecificData(): void;
        } & {
            fetchNeeded(needed: {
                region: Region;
                displayedRegionIndex: number;
            }[]): Promise<void>;
            startRenderingBackend(backend: PerRegionRenderingBackend<Payload, DisplayRenderState<P>, RenderBlock, Payload>): void;
            renderSvg(opts?: ExportSvgDisplayOptions): Promise<import("react").ReactNode>;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
    }) => import("react").JSX.Element;
    install(pluginManager: PluginManager): void;
};
export {};
