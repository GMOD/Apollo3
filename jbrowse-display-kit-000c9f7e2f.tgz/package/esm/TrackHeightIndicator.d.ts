import type { HeightMode } from './heightMode.ts';
export default function TrackHeightIndicator({ heightMode, hasOverflow, scrollZoom, noun, truncatedCount, onSetHeightMode, }: {
    heightMode: HeightMode;
    hasOverflow: boolean;
    scrollZoom: boolean;
    noun: string;
    truncatedCount?: number;
    onSetHeightMode: (mode: HeightMode) => void;
}): import("react").JSX.Element;
