import type { TrackControlProps } from '@jbrowse/display-ui';
export default function MuiTrackControl({ icon, tooltip, label, options, onClick, onDelete, warning, }: TrackControlProps): import("react").JSX.Element;
