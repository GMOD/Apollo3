import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
import type { RenderingBackend } from '@jbrowse/render-core/renderingBackendBase';
export interface StubBackend extends RenderingBackend {
}
export declare function stubFactory(): Promise<StubBackend>;
export declare const TestChromeModel: import("@jbrowse/mobx-state-tree").IModelType<{
    configuration: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<{
        displayId: string;
    }, {
        displayId: string;
    }, {
        displayId: string;
    }>, [undefined]>;
    height: import("@jbrowse/mobx-state-tree").IType<number | undefined, number, number>;
    regionTooLarge: import("@jbrowse/mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    regionTooLargeReason: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
    zoomCanReleaseGate: import("@jbrowse/mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    canvasDrawn: import("@jbrowse/mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    rendersCanvas: import("@jbrowse/mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    statusMessage: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    statusProgress: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<number>>;
}, {
    error: unknown;
    renderError: unknown;
    loadingCondition: boolean;
} & {
    readonly painted: boolean;
    readonly displayPhase: DisplayPhase;
} & {
    reload(): void;
    forceLoad(): void;
    renderNow(): void;
    startRenderingBackend(_backend: StubBackend): void;
    stopRenderingBackend(): void;
    setRenderError(error: unknown): void;
    setError(error: unknown): void;
    setRegionTooLarge(value: boolean, reason?: any): void;
    setCanvasDrawn(value: boolean): void;
    setRendersCanvas(value: boolean): void;
    setLoadingCondition(value: boolean): void;
    setStatus(message?: string, progress?: number): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
