import type { DisplayLoadingOverlayModel } from '@jbrowse/display-ui';
export type { DisplayLoadingOverlayModel };
declare const DisplayLoadingOverlay: ({ model, visible, immediate, }: {
    model: DisplayLoadingOverlayModel;
    visible: boolean;
    immediate?: boolean;
}) => import("react").JSX.Element;
export default DisplayLoadingOverlay;
