import type { HeightMode } from './heightMode.ts';
import type { HeightModeConfigModel } from './heightModeConfigSchemaFields.ts';
import type { AnyConfigurationModel, ResolvableDisplay } from '@jbrowse/core/configuration';
import type { MenuItem } from '@jbrowse/core/ui';
export type HeightModeMenuModel<CONF extends AnyConfigurationModel = HeightModeConfigModel> = ResolvableDisplay<CONF> & {
    heightMode: HeightMode;
    setHeightMode: (mode: HeightMode) => void;
};
export declare function heightModeMenuItems<CONF extends AnyConfigurationModel>(model: HeightModeMenuModel<CONF>, noun: string): MenuItem[];
