export declare const HEIGHT_MODE_VALUES: readonly ['fixed', 'grow', 'fit'];
export type HeightMode = (typeof HEIGHT_MODE_VALUES)[number];
export declare const GROW_MAX_HEIGHT = 800;
export declare function heightModeLabel(mode: HeightMode, noun: string): string;
export declare function getHeightModeOptions(noun: string): {
    value: HeightMode;
    label: string;
}[];
