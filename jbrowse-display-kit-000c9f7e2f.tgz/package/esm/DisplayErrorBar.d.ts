import type { DisplayErrorBarModel } from '@jbrowse/display-ui';
export type { DisplayErrorBarModel };
declare const DisplayErrorBar: ({ model, visible, }: {
    model: DisplayErrorBarModel;
    visible: boolean;
}) => import("react").JSX.Element | null;
export default DisplayErrorBar;
