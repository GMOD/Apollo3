import type { FetchContext } from './FetchMixin.ts';
import type { GateFetchState } from './regionTooLargeUtils.ts';
import type { RegionTooLargeResult } from '@jbrowse/core/rpc/byteBudget';
import type { FetchPhases } from '@jbrowse/core/util/fetchPhases';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * This family's spelling of the shared three-phase contract, over
 * `FetchMixin.runFetch` and its `FetchContext`. The rules live on
 * {@link FetchPhases}; the comparative family names the same type over its own
 * context.
 *
 * `run` may answer the worker's refusal marker in place of a payload, which is
 * how the byte gate reaches this family: the RPC takes `resolvedByteLimit()`,
 * measures before it downloads, and {@link runGlobalFetch} turns the marker
 * into a byte measurement and no commit.
 */
export interface GlobalFetchPhases<TArgs, TResult> extends Omit<FetchPhases<TArgs, TResult, FetchContext>, 'run'> {
    run: (args: TArgs, ctx: FetchContext) => Promise<TResult | RegionTooLargeResult | undefined>;
}
export interface GlobalFetchHost extends IStateTreeNode {
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
    isMinimized: boolean;
    fetchSignature: string | undefined;
    dataCurrent: boolean;
    commitFetchResult: (commit: () => void, signature: string) => void;
    gateFetchState: () => GateFetchState;
    commitFetchBytes: (perRegionBytes: (number | undefined)[], issued: GateFetchState) => void;
}
export interface GlobalFetchAutorunHost extends GlobalFetchHost {
    reloadCounter: number;
    fetchCanceled: boolean;
    cancelFetch: () => void;
    fetchInert: boolean;
    awaitingPrerequisite: boolean;
    rpcPropsCacheKey: string;
    gateSkipsMeasuredViewport: boolean;
}
/**
 * One fetch through the phases, with the family's shared gates around them:
 * decline while minimized, while the signature is not yet computable (a
 * prerequisite pending), or while `dataCurrent` says the held data already
 * answers; then the display's `run` under `FetchMixin.runFetch` (which owns
 * cancellation, the error and the loading flag), the byte measurement its
 * result carried, and a commit that stamps the signature the fetch was *issued*
 * for — captured here, before any await, so a mid-flight view change cannot
 * relabel the data. Each display used to spell some subset of this and each
 * subset was missing a different piece (LD never declined on current data,
 * HiC's signature missed the settings axis, a reload had to remember its own
 * invalidation).
 *
 * **A refused result commits its bytes and nothing else.** `dataCurrent`
 * therefore stays false, and what stops the autorun spinning on that is
 * `gateSkipsMeasuredViewport` one level up: the commit stamped the viewport the
 * measurement was taken at, so the next run has nothing left to learn until the
 * user moves.
 *
 * Returns the fetch's promise, or `undefined` when the gates or the display's
 * `prepare` declined — so the autorun below can say which happened, and a
 * caller that wants one round trip on demand can await it.
 */
export declare function runGlobalFetch<TArgs, TResult>(self: GlobalFetchHost, { prepare, run, commit }: GlobalFetchPhases<TArgs, TResult>): Promise<void> | undefined;
/**
 * Install the fetch-trigger autorun for a `GlobalFetchMixin` display.
 *
 * Unlike `MultiRegionDisplayMixin` (which installs its five fetch autoruns for
 * you), that mixin installs none — each global display owns its trigger. But
 * every global trigger shares the same skeleton: track the viewport,
 * minimize/expand, the `rpcProps()` cache key and `reloadCounter` so any of them
 * refires the fetch, then debounce. This helper owns that skeleton so a display
 * supplies only its own `prepare` / `run` / `commit`.
 *
 * Runs through `autorunOnReadyView`, so the body never reads a throwing view
 * getter (`dynamicBlocks`, `width`) before the view is initialized, and
 * re-runs automatically once it is. `prepare` inherits that: it is reached only
 * on a ready view, so a composer restating `view.initialized` is restating the
 * skeleton.
 *
 * **What `prepare` adds to the dependency set.** Everything it reads, since it
 * runs synchronously in the autorun body — which for the two displays that used
 * to bail out inside an MST action (MobX runs those untracked) means the
 * viewport pair and the block list join the set. Both were already in it
 * transitively: `dynamicBlocks` above is a computed over `offsetPx`, `bpPerPx`
 * and `width`, so any move that a direct read would catch has already
 * invalidated it. Arc reads `staticBlocks` in its `prepare` on top of that, and
 * static blocks are quantized from the same pair, so it fires on a subset of the
 * runs `dynamicBlocks` already causes. What a `prepare` must NOT do is move a
 * trigger read of its own under a bail-out — that is the failure the trigger
 * list above exists for.
 *
 * `rpcProps()` loop hazard: unlike MultiRegion's `SettingsInvalidate` (which
 * clears data in a *separate, undelayed* autorun and so loops synchronously if
 * `rpcProps()` *returns* fetch-derived state — caught by `makeSettingsLoopGuard`),
 * this autorun reads the key and starts the fetch in the *same* debounced body.
 * A fetch-derived value in the payload here loops on the async-fetch cadence
 * (refetch → commit → key changes → reschedule after `delay` → refetch), a slow
 * network thrash rather than a synchronous freeze, so a within-tick counter
 * cannot distinguish it from legitimate rapid interaction. The invariant is the
 * same: `rpcProps()` must return only user-controlled settings, never fetched
 * data (see ARCHITECTURE.md §"rpcProps() loop trap").
 */
export declare function installGlobalFetchAutorun<TArgs, TResult>(self: GlobalFetchAutorunHost, opts: GlobalFetchPhases<TArgs, TResult> & {
    delay: number;
    name: string;
}): void;
