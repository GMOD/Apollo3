import type { ReactNode } from 'react';
declare function BottomRightIndicators({ scrollbarWidth, children, }: {
    /**
     * How much of the display's right edge its own scrollbar occupies *right
     * now* — 0 when nothing is overflowing. Keeps the indicators from rendering
     * underneath it. Displays that scroll with a native overflow container pass
     * that container's scrollbar width; displays drawing `VerticalScrollbar` pass
     * its track width.
     *
     * It shifts this row alone rather than the whole corner, and that is right in
     * both directions: the row is the rightmost member, so the status chip stacked
     * above it clears the scrollbar transitively, and a display showing only the
     * chip is where the chip was before.
     */
    scrollbarWidth?: number;
    children: ReactNode;
}): import("react").JSX.Element;
export default BottomRightIndicators;
