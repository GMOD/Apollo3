import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
/**
 * Dev-only check of the display contracts that no type expresses and whose
 * violation is silent. No-op in production.
 *
 * Called once per display from **whichever fetch foundation installed its
 * autoruns** — `MultiRegionDisplayMixin`'s `afterAttach` for the per-region
 * family, `installGlobalFetchAutorun` for the global one. It was per-region
 * only until 2026-08, which left the family with *fewer* safety nets
 * unchecked: HiC and LD both define `rpcProps()`, `installGlobalFetchAutorun`
 * serializes it into the autorun's trigger list, and an `rpcProps` declared in
 * `.actions()` there fails exactly the same way — reads register no
 * dependency, so a settings change stops invalidating — with no
 * `makeSettingsLoopGuard` on that side to catch anything either.
 *
 * `installedBy` names the caller so the double-install message can describe the
 * right thing; the WeakSet is shared, which is correct — a display composes one
 * fetch foundation, so reaching here twice is the bug regardless of which.
 *
 * ARCHITECTURAL_LIMITS.md §"Ordering is the contract" asks for exactly this —
 * "each order becomes explicit data … `makeSettingsLoopGuard` is this move
 * already applied to the `rpcProps` loop trap. Generalize it." That doc's "Now
 * checked" list is the authoritative account of which contracts report
 * themselves and which are still silent; don't restate the split here, because
 * this comment said "four places" against a heading that said five and a list
 * that held six.
 *
 * Every message names the fix, not just the symptom — the failure modes here
 * cost hours precisely because the symptom (a wedged display, a stale cache)
 * points nowhere near the cause.
 */
export declare function assertDisplayContract(self: IAnyStateTreeNode, installedBy?: string): void;
