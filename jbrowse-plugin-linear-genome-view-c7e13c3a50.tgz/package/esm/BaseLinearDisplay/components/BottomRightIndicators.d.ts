import type { ReactNode } from 'react';
declare function BottomRightIndicators({ scrollbarWidth, children, }: {
    /**
     * How much of the display's right edge its own scrollbar occupies *right
     * now* — 0 when nothing is overflowing. Keeps the indicators from rendering
     * underneath it. Displays that scroll with a native overflow container pass
     * that container's scrollbar width; displays drawing `VerticalScrollbar` pass
     * its track width.
     */
    scrollbarWidth?: number;
    children: ReactNode;
}): import("react").JSX.Element;
export default BottomRightIndicators;
