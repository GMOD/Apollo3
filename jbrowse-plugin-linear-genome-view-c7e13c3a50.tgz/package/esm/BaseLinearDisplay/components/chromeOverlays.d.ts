import type { TooLargeMessageModel } from '../../shared/TooLargeMessage.tsx';
import type { DisplayBackgroundProgressModel } from './DisplayBackgroundProgress.tsx';
import type { DisplayErrorBarModel } from './DisplayErrorBar.tsx';
import type { DisplayLoadingOverlayModel } from './DisplayLoadingOverlay.tsx';
import type { ComponentType } from 'react';
export interface DisplayChromeOverlays {
    /**
     * GPU/render-backend failure. A subtree-replacing terminal state: the canvas
     * unmounts and the backend disposes, so this owns the full display area.
     */
    RenderError: ComponentType<{
        error: unknown;
        onRetry: () => void;
        height: number;
    }>;
    /**
     * The byte gate tripped. Also subtree-replacing. Must offer `model.forceLoad`
     * or the region becomes unreachable for the rest of the session.
     */
    TooLarge: ComponentType<{
        model: TooLargeMessageModel;
    }>;
    /**
     * Fetch error, drawn *over* a live canvas rather than replacing it. Mounted
     * unconditionally like the two below, so `visible` (`displayPhase ===
     * 'error'`) is the gate -- don't re-derive it from `model.error`, which is
     * the same subtraction `displayPhase` exists to retire.
     */
    ErrorBar: ComponentType<{
        model: DisplayErrorBarModel;
        visible: boolean;
    }>;
    /**
     * The loading scrim. `visible` is `displayPhase === 'loading'`; `immediate`
     * asks it to skip its anti-flash delay because nothing is painted yet.
     *
     * Mounted unconditionally, so it must handle `visible === false` itself — and
     * that is load-bearing rather than a style choice: the anti-flash delay is
     * component state, so a chrome that mounted this only while loading would
     * restart the timer on every activation and never reach it. Keep any
     * replacement mountable-while-hidden for the same reason.
     */
    Loading: ComponentType<{
        model: DisplayLoadingOverlayModel;
        visible: boolean;
        immediate?: boolean;
    }>;
    /**
     * Status for work with no fetch behind it, while the phase is `ready`.
     * Mounted unconditionally; gates on `visible` itself.
     */
    BackgroundProgress: ComponentType<{
        model: DisplayBackgroundProgressModel;
        visible: boolean;
    }>;
}
