import Plugin from '@jbrowse/core/Plugin';
import type PluginManager from '@jbrowse/core/PluginManager';
export default class LinearGenomeViewPlugin extends Plugin {
    name: string;
    exports: {
        baseLinearDisplayConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
            readonly maxFeatureScreenDensity: {
                readonly type: "number";
                readonly description: "maximum features per pixel before showing a \"too many features\" message";
                readonly defaultValue: 1;
                readonly advanced: true;
            };
            readonly fetchSizeLimit: {
                readonly type: "number";
                readonly defaultValue: 1000000;
                readonly description: "maximum data to attempt to download for a given track, used if adapter doesn't specify one";
                readonly advanced: true;
            };
            readonly forceLoad: {
                readonly type: "boolean";
                readonly defaultValue: false;
                readonly description: "always render regardless of the region-size / feature-density gate (declarative equivalent of the \"Force load\" button)";
                readonly advanced: true;
            };
            readonly height: {
                readonly type: "number";
                readonly defaultValue: 100;
                readonly description: "default height for the track";
            };
            readonly mouseover: {
                readonly type: "string";
                readonly description: "text to display when the cursor hovers over a feature";
                readonly defaultValue: "jexl:get(feature,'_mouseOver')||get(feature,'name')||get(feature,'function')||get(feature,'id')";
                readonly contextVariable: ["feature"];
            };
            readonly jexlFilters: {
                readonly type: "stringArray";
                readonly description: "default set of jexl filters to apply to a track. note: these do not use the jexl prefix because they have a deferred evaluation system";
                readonly defaultValue: readonly ["get(feature,'gbkey')!='Src'"];
            };
        }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "displayId">>;
        SearchBox: {
            (props: {
                model: import("./index.ts").LinearGenomeViewModel;
                showHelp?: boolean;
                minWidth?: number;
                maxWidth?: number;
                style?: React.CSSProperties;
            }): import("react").JSX.Element;
            displayName: string;
        };
        ZoomControls: {
            (props: {
                model: import("./index.ts").LinearGenomeViewModel;
            }): import("react").JSX.Element;
            displayName: string;
        };
        LinearGenomeView: {
            (props: {
                model: import("./index.ts").LinearGenomeViewModel;
            }): import("react").JSX.Element;
            displayName: string;
        };
    };
    /**
     * #config LinearGenomeViewConfigSchema
     * #category root
     */
    configurationSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        /**
         * #slot configuration.LinearGenomeViewPlugin.trackLabels
         * where a track's name is drawn: `offset` gives it its own line above the
         * data, `overlapping` floats it over the top of the data to save vertical
         * space, `hidden` omits it. The view's "Track labels" menu sets the same
         * thing per session
         */
        readonly trackLabels: {
            readonly type: "string";
            readonly defaultValue: "offset";
            readonly model: import("@jbrowse/mobx-state-tree").ISimpleType<"hidden" | "offset" | "overlapping">;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    install(pluginManager: PluginManager): void;
    configure(pluginManager: PluginManager): void;
}
export type { ExportSvgDisplayOptions, LayoutRecord, LegendItem, LegendSection, RenderTransform, RenderTransformInputs, TrackControlComponent, TrackControlIcon, TrackControlOption, TrackControlProps, } from './BaseLinearDisplay/index.ts';
export { BlockMsg, BottomRightIndicators, DisplayChrome, DisplayChromeBase, DisplayChromeOverlayProvider, DisplayUIProvider, DisplayErrorBar, DisplayLoadingOverlay, DisplayStatusChrome, DisplayStatusChromeBase, FetchMixin, FloatingLegend, GROW_MAX_HEIGHT, GlobalDataDisplayMixin, GlobalFetchMixin, HEIGHT_MODE_VALUES, HeightModeMixin, MIN_DISPLAY_HEIGHT, MultiRegionDisplayMixin, StaleViewportRescaleMixin, TooLargeMessage, TrackControl, TrackControlProvider, TrackHeightIndicator, TrackHeightMixin, autorunOnReadyView, baseLinearDisplayConfigSchema, callEachRegion, computeRenderTransform, computeTriangleYScalar, fetchAllRegions, fetchEachRegion, foundationDisplayStatusPhase, squashToHeightCheckboxItem, getHeightModeOptions, heightModeLabel, heightModeMenuItems, installClearHoverOnViewportChange, installGlobalFetchAutorun, installGrowExitBake, onDisplayedRegionsChange, plainTrackControl, viewportMatchesLastDrawn, } from './BaseLinearDisplay/index.ts';
export type { DisplayBackgroundProgressModel, DisplayChromeOverlays, DisplayErrorBarModel, DisplayLoadingOverlayModel, DisplayStatusPhaseFoundation, FetchContext, HeightMode, HeightModeMenuModel, StatusChromeModel, TooLargeMessageModel, } from './BaseLinearDisplay/index.ts';
export { plainChromeOverlays } from './BaseLinearDisplay/index.ts';
export { computeDisplayPhase, computeDisplayStatusPhase, computeLoadingTerm, } from '@jbrowse/render-core/displayPhase';
export type { DisplayLoadingInputs, DisplayPhase, DisplayPhaseInputs, DisplayStatusPhase, DisplayStatusPhaseInputs, } from '@jbrowse/render-core/displayPhase';
export type { ByteEstimate, GateViewport, RegionTooLargeStatus, } from './shared/regionTooLargeUtils.ts';
export { HighlightBand, HighlightChip, type LinearGenomeViewModel, type LinearGenomeViewStateModel, OverviewHighlightBand, SVGHighlightBand, installLinkedViewSync, stateModelFactory as linearGenomeViewStateModelFactory, } from './LinearGenomeView/index.ts';
export { default as SearchBox } from './LinearGenomeView/components/SearchBox.tsx';
export { normalizeTrackInit } from '@jbrowse/core/util/tracks';
export { partitionLaunchKeys } from './LinearGenomeView/initKeys.ts';
export { MultiLevelRubberband } from './MultiLevelRubberband/index.ts';
export { fetchResults, SearchResultsNotFoundError } from './searchUtils.ts';
export type { LaunchLinearGenomeViewArgs } from './LaunchLinearGenomeView/index.ts';
export type { BpOffset, ExportSvgOptions, HighlightType, InitState, LinearGenomeViewLaunchProps, NavLocation, TrackInit, TrackLabelMode, VolatileGuide, } from './LinearGenomeView/types.ts';
export type { ScalebarRefNameLabel } from './LinearGenomeView/util.ts';
export { renderToSvg } from './LinearGenomeView/svgcomponents/SVGLinearGenomeView.tsx';
export { default as SVGTracks } from './LinearGenomeView/svgcomponents/SVGTracks.tsx';
export { default as SVGView } from './LinearGenomeView/svgcomponents/SVGView.tsx';
export { default as SVGRowHeader } from './LinearGenomeView/svgcomponents/SVGRowHeader.tsx';
export { default as SVGHighlights } from './LinearGenomeView/svgcomponents/SVGHighlights.tsx';
export { default as SVGHighlightsOverlay } from './LinearGenomeView/svgcomponents/SVGHighlightsOverlay.tsx';
export { default as ExportSvgDialog } from './LinearGenomeView/components/ExportSvgDialog.tsx';
export { GetSequenceDialog } from './LinearGenomeView/lazyDialogs.ts';
export { default as ConnectedHoverHighlight } from './LinearGenomeView/components/ConnectedHoverHighlight.tsx';
export { default as HoverPositionHighlight } from './LinearGenomeView/components/HoverPositionHighlight.tsx';
export { TrackOverlayContext } from './LinearGenomeView/TrackOverlayContext.ts';
export { TrackOverlayPortal } from './LinearGenomeView/TrackOverlayPortal.tsx';
export { FloatingSvgOverlay } from './LinearGenomeView/FloatingSvgOverlay.tsx';
export type { HoverHighlightPosition } from './LinearGenomeView/components/HoverPositionHighlight.tsx';
export { SvgChrome, SvgClipRect } from '@jbrowse/core/svg/SvgExport';
export { svgSafeId } from '@jbrowse/core/svg/svgId';
export { awaitSvgReady, awaitSvgRenders } from '@jbrowse/core/svg/svgReady';
export type { SvgExportable } from '@jbrowse/core/svg/svgReady';
export { renderDisplaySvg } from './shared/renderDisplaySvg.tsx';
export type { LgvSvgBodyProps, LgvSvgExportable, } from './shared/renderDisplaySvg.tsx';
export { defaultTextHeight, labelBaselineFromTop, labelOffset, totalHeight, trackBoxHeight, trackBoxOffsets, trackLabelLeftOffset, } from './LinearGenomeView/svgcomponents/util.ts';
export { renderViewTracks } from './LinearGenomeView/svgcomponents/renderViewTracks.ts';
export type { SvgExportTrack, ViewTracksSvg, } from './LinearGenomeView/svgcomponents/renderViewTracks.ts';
export type { SvgDisplayResult } from './LinearGenomeView/svgcomponents/util.ts';
