import type { LinearGenomeViewModel } from '../index.ts';
export default function SVGRowHeader({ view, fontSize, rulerHeight, }: {
    view: LinearGenomeViewModel;
    fontSize: number;
    rulerHeight: number;
}): import("react").JSX.Element;
