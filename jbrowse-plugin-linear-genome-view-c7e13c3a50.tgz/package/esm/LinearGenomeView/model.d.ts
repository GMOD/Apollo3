import type { BpOffset, ExportSvgOptions, HighlightType, InitState, NavLocation, VolatileGuide } from './types.ts';
import type PluginManager from '@jbrowse/core/PluginManager';
import type BaseResult from '@jbrowse/core/TextSearch/BaseResults';
import type { MenuItem } from '@jbrowse/core/ui';
import type { ParsedLocString } from '@jbrowse/core/util';
import type { ViewLayout } from '@jbrowse/core/util/Base1DUtils';
import type { BlockSet, ContentBlock } from '@jbrowse/core/util/blockTypes';
import type { Region } from '@jbrowse/core/util/types';
import type { Instance } from '@jbrowse/mobx-state-tree';
import type React from 'react';
/**
 * #stateModel LinearGenomeView
 * #category view
 *
 * #example
 * A `LinearGenomeView` is what you hand-author under `defaultSession.views`. The
 * `init` shorthand fills in `displayedRegions`/`bpPerPx`/`offsetPx` for you:
 * ```js
 * defaultSession: {
 *   name: 'My session',
 *   views: [
 *     {
 *       type: 'LinearGenomeView',
 *       // plain persisted props sit alongside init, not inside it
 *       colorByCDS: true,
 *       init: {
 *         assembly: 'hg38',
 *         loc: 'chr1:1,000,000-1,100,000',
 *         tracks: ['genes', 'alignments'],
 *       },
 *     },
 *   ],
 * }
 * ```
 * `init` holds only keys that need on-attach resolution — also `tracklist`,
 * `nav`, `highlight` (see the `init` property below). Plain view props like
 * `colorByCDS`, `showAminoAcids`, `showCenterLine`, `trackLabels`,
 * `showHighlightChips` are set
 * directly on the view (MST restores them natively).
 * At runtime the same model is driven imperatively — every property and action
 * below is reachable on `viewState.session.views[0]`:
 * ```js
 * const view = viewState.session.views[0]
 * await view.navToLocString('chr1:2,000,000-2,100,000')
 * view.showTrack('alignments')
 * view.zoomTo(view.bpPerPx * 2) // zoom out 2x
 * ```
 */
export declare function stateModelFactory(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    displayName: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "highlight" | "showHighlightChips"> & {
    highlight: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IType<HighlightType, HighlightType, HighlightType>>, [undefined]>;
    showHighlightChips: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "bpPerPx" | "colorByCDS" | "displayedRegions" | "hideHeader" | "hideHeaderOverview" | "hideNoTracksActive" | "id" | "init" | "labelsVisible" | "offsetPx" | "scalebarOnly" | "showAminoAcids" | "showCenterLine" | "showCytobands" | "showGridlines" | "showTrackOutlines" | "trackLabels" | "trackSelectorType" | "tracks" | "type"> & {
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").IType<string | undefined, string, string>;
    offsetPx: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    bpPerPx: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    displayedRegions: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IType<Region[], Region[], Region[]>, [undefined]>;
    tracks: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    hideHeader: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    hideHeaderOverview: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    hideNoTracksActive: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    trackSelectorType: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    showCenterLine: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showCytobands: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    trackLabels: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    showGridlines: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    labelsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    colorByCDS: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showAminoAcids: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    showTrackOutlines: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    scalebarOnly: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    init: import("@jbrowse/mobx-state-tree").IType<InitState | undefined, InitState | undefined, InitState | undefined>;
}, {
    width: number;
} & {
    menuItems(): MenuItem[];
} & {
    setDisplayName(name: string): void;
    setWidth(newWidth: number): void;
    setMinimized(flag: boolean): void;
} & {
    addToHighlights(highlight: HighlightType): void;
    setHighlight(highlight?: HighlightType[]): void;
    removeHighlight(highlight: HighlightType): void;
    updateHighlight(old: HighlightType, updates: Partial<HighlightType>): void;
    setShowHighlightChips(arg: boolean): void;
} & {
    afterAttach(): void;
} & {
    /**
     * #volatile
     */
    volatileWidth: number | undefined;
    /**
     * #volatile
     */
    minimumBlockWidth: number;
    /**
     * #volatile
     */
    draggingTrackId: undefined | string;
    /**
     * #volatile
     */
    lastTrackDragY: undefined | number;
    /**
     * #volatile
     */
    volatileError: unknown;
    /**
     * #volatile
     */
    trackRefs: Record<string, HTMLDivElement>;
    /**
     * #volatile
     */
    coarseDynamicBlocks: ContentBlock[];
    /**
     * #volatile
     */
    coarseTotalBp: number;
    /**
     * #volatile
     */
    coarseBpPerPx: number;
    /**
     * #volatile
     */
    leftOffset: undefined | BpOffset;
    /**
     * #volatile
     */
    rightOffset: undefined | BpOffset;
    /**
     * #volatile
     */
    isScalebarRefNameMenuOpen: boolean;
    /**
     * #volatile
     */
    scalebarRefNameClickPending: boolean;
    /**
     * #volatile
     * temporary vertical guides that can be set by displays (e.g., LD display hover)
     */
    volatileGuides: VolatileGuide[];
} & {
    /**
     * #getter
     * scroll-to-zoom is a global, personal preference resolved from the
     * session; toggling it in any view applies everywhere
     */
    readonly scrollZoom: boolean;
    /**
     * #getter
     */
    readonly pinnedTracks: any[];
    /**
     * #getter
     */
    readonly unpinnedTracks: any[];
    /**
     * #getter
     * the effective track labels setting, resolving the stored `trackLabels`
     * against the LinearGenomeViewPlugin config default
     */
    readonly effectiveTrackLabels: any;
    /**
     * #getter
     */
    readonly width: number;
    /**
     * #getter
     * width minus track outline borders (1px each side when shown)
     */
    readonly trackWidthPx: number;
    /**
     * #getter
     */
    readonly assemblyNames: string[];
    /**
     * #getter
     */
    readonly assemblyDisplayNames: string[];
    /**
     * #getter
     * checking if lgv is a 'top-level' view is used for toggling pin track
     * capability, sticky positioning
     */
    readonly isTopLevelView: boolean;
    /**
     * #getter
     * only uses sticky view headers when it is a 'top-level' view and
     * session allows it
     */
    readonly stickyViewHeaders: boolean;
    /**
     * #getter
     */
    readonly rubberbandTop: number;
    /**
     * #getter
     */
    readonly pinnedTracksTop: number;
} & {
    /**
     * #getter
     * Assembly-name prefix for the scalebar refName labels, or undefined for
     * none. A container view (e.g. LinearSyntenyView) opts its sub-views in by
     * exposing showAssemblyNameInSubviewScalebar; duck-typed rather than
     * matching a concrete view type so no upward plugin dependency is needed
     * and any container can opt in. A wrong nesting depth simply yields no
     * prefix — hence the hasParent guard, since getParent throws (rather than
     * returning undefined) when the view sits shallower than depth 2.
     */
    readonly scalebarDisplayPrefix: string | undefined;
    /**
     * #method
     */
    MiniControlsComponent(): React.FC<any>;
    /**
     * #method
     */
    HeaderComponent(): React.FC<any>;
    /**
     * #getter
     */
    readonly assembliesNotFound: string | undefined;
    /**
     * #getter
     */
    readonly assemblyErrors: string;
    /**
     * #getter
     */
    readonly assembliesInitialized: boolean;
    /**
     * #getter
     * the assembly named by a pending `init`, or undefined when no init is
     * set. `init`'s assembly isn't in `assemblyNames` yet (that derives from
     * displayedRegions, still empty pre-navigation), so init-phase readiness
     * and error checks resolve it directly through here.
     */
    readonly initAssembly: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #getter
     */
    readonly initialized: boolean;
    /**
     * #getter
     */
    readonly hasDisplayedRegions: boolean;
    /**
     * #getter
     * The assembly whose load the spinner is waiting on: the one `init` names
     * before navigation (it isn't in assemblyNames yet), else the first of the
     * displayed assemblies that hasn't finished loading.
     */
    readonly loadingAssembly: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }> & {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
    }, {
        error: unknown;
        loadingP: Promise<void> | undefined;
        adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
        volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
        cytobands: import("@jbrowse/core/util").Feature[] | undefined;
        loadedGeneticCodes: Record<string, number> | undefined;
        lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
        statusMessage: string | undefined;
        statusProgress: number | undefined;
    } & {
        getConf(arg: string): any;
    } & {
        readonly name: string;
        readonly aliases: string[];
        readonly displayName: string;
        readonly refNameColors: string[];
    } & {
        readonly allAliases: string[];
        hasName(name: string): boolean;
    } & {
        setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
    } & {
        setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes, }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
            regions: import("@jbrowse/core/util").Region[];
            cytobands: import("@jbrowse/core/util").Feature[];
            geneticCodes: Record<string, number>;
        }): void;
        setError(e: unknown): void;
        setLoadingP(p?: Promise<void>): void;
        loadPre(): Promise<void>;
    } & {
        load(): Promise<void>;
    } & {
        afterAttach(): void;
    } & {
        readonly initialized: boolean;
        readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
        readonly allRefNames: string[] | undefined;
        readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    } & {
        readonly refNames: string[] | undefined;
    } & {
        readonly refNameToIndex: Map<string, number> | undefined;
    } & {
        getCanonicalRefName(refName: string): string | undefined;
        getRefNameColor(refName: string): string | undefined;
        getGeneticCodeId(refName: string): number;
        getSeqAdapterRefName(canonicalRefName: string): string;
    } & {
        getCanonicalRefName2(refName: string): string;
        isValidRefName(refName: string): boolean;
    } & {
        getRefNameMapForAdapter(adapterConf: {
            [x: string]: unknown;
        }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
    /**
     * #getter
     * What the spinner says. The assembly reports which of its files it is
     * downloading, so this is "Downloading chromosome aliases" rather than a bare
     * "Loading" for the part of startup that actually takes time. Falls back
     * once the assembly is loaded and the remaining wait is the init autorun's
     * own navigation, which is local.
     */
    readonly loadingMessage: string | undefined;
    /**
     * #getter
     * Determinate fraction for the spinner's bar, when the assembly load
     * reports one (a whole-file download with a Content-Length)
     */
    readonly loadingProgress: number | undefined;
    /**
     * #getter
     */
    readonly hasSomethingToShow: boolean;
    /**
     * #getter
     * init is set but its async navigation (the afterAttach autorun) hasn't
     * populated displayedRegions yet. `initialized` can already be true here
     * (it only tracks assembly readiness), so without this the container
     * would mount over empty regions and pxToBp/hover would throw.
     */
    readonly initPending: boolean;
    /**
     * #getter
     * Whether to show a loading indicator instead of the import form or view
     */
    readonly showLoading: boolean;
    /**
     * #getter
     * Whether to show the import form
     */
    readonly showImportForm: boolean;
    /**
     * #getter
     * Is there anything to draw yet? The gate anything reading block geometry
     * — a ruler, a scalebar, a display — has to pass first, because
     * `width`/`staticBlocks` throw by design before the view has been
     * measured and navigated.
     *
     * **Not `initialized`**, which is the trap this getter exists to close.
     * That one answers "have the assembly's regions loaded", which is only
     * the first of two async steps: navigating then populates
     * `displayedRegions`, and in the window between the two `initialized` is
     * already true while there is still nothing on screen. `showLoading`
     * folds in `initPending`, the getter that exists for exactly that gap.
     *
     * `error` is the third outcome and is why this is not a bare
     * `!showLoading`: a failed assembly load also ends the loading state, so
     * that alone would mount over the wreckage. Read `error` yourself if you
     * want to draw it.
     */
    readonly ready: boolean;
    /**
     * #getter
     */
    readonly scalebarHeight: number;
    /**
     * #getter
     */
    readonly headerHeight: number;
    /**
     * #method
     * rendered height of a single track, collapsing to a fixed height when
     * minimized. Shared by trackHeights and getTrackYOffset so the two can't
     * disagree. Reads `activeDisplay` — the display TrackContainer actually
     * mounts — rather than re-picking `displays[0]`, so the view's height math
     * can't diverge from what is on screen.
     */
    trackHeight(track: (import("@jbrowse/mobx-state-tree").IMSTArray<import("@jbrowse/mobx-state-tree").IAnyType> & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>>)[number]): any;
    /**
     * #getter
     */
    readonly trackHeights: number;
    /**
     * #getter
     */
    readonly trackHeightsWithResizeHandles: number;
    /**
     * #getter
     */
    readonly height: number;
    /**
     * #method
     * Y offset (in pixels, from the top of the view) where a track's
     * rendering container starts. Walks tracks in DOM render order (pinned
     * first, then unpinned), matching TrackContainer's layout and using the
     * same constants it renders with. Returns `undefined` if the track is
     * not present in the view.
     */
    getTrackYOffset(trackId: string): number | undefined;
    /**
     * #method
     * the pinned or unpinned sibling list a track renders within; move
     * up/down/top/bottom reorder inside this section rather than the full
     * `tracks` array, since the two sections lay out independently
     */
    trackSection(id: string): any[];
    /**
     * #getter
     */
    readonly totalBp: number;
    /**
     * #getter
     */
    readonly maxBpPerPx: number;
    /**
     * #getter
     */
    readonly minBpPerPx: number;
    /**
     * #getter
     */
    readonly error: unknown;
    /**
     * #getter
     */
    readonly maxOffset: number;
    /**
     * #getter
     */
    readonly minOffset: number;
    /**
     * #getter
     */
    readonly displayedRegionsTotalPx: number;
    /**
     * #getter
     */
    readonly trackMap: Map<string, any>;
    /**
     * #method
     */
    getTrack(id: string): any;
    /**
     * #method
     * displayId of the active (shown) display for a track in this view, used
     * by the config editor to expand the relevant display and collapse the
     * track's other displays
     */
    getActiveDisplayId(trackId: string): string | undefined;
} & {
    /**
     * #action
     */
    setShowTrackOutlines(arg: boolean): void;
    /**
     * #action
     */
    setScrollZoom(flag: boolean): void;
    /**
     * #action
     */
    setColorByCDS(flag: boolean): void;
    /**
     * #action
     */
    setShowAminoAcids(flag: boolean): void;
    /**
     * #action
     */
    setShowCytobands(flag: boolean): void;
    /**
     * #action
     */
    setWidth(newWidth: number): void;
    /**
     * #action
     */
    setError(error: unknown): void;
    /**
     * #action
     */
    setIsScalebarRefNameMenuOpen(isOpen: boolean): void;
    /**
     * #action
     */
    setScalebarRefNameClickPending(pending: boolean): void;
    /**
     * #action
     */
    setHideHeader(b: boolean): void;
    /**
     * #action
     */
    setHideHeaderOverview(b: boolean): void;
    /**
     * #action
     */
    setScalebarOnly(b: boolean): void;
    /**
     * #action
     */
    setHideNoTracksActive(b: boolean): void;
    /**
     * #action
     */
    setShowGridlines(b: boolean): void;
    /**
     * #action
     */
    setLabelsVisible(arg: boolean): void;
    /**
     * #action
     * set temporary vertical guides (e.g., for LD display hover)
     */
    setVolatileGuides(guides: VolatileGuide[]): void;
    /**
     * #action
     */
    scrollTo(offsetPx: number): number;
    /**
     * #action
     */
    zoomTo(bpPerPx: number, offset?: any): number;
    /**
     * #action
     * sets offsets of rubberband, used in the get sequence dialog can call
     * view.getSelectedRegions(view.leftOffset,view.rightOffset) to compute
     * the selected regions from the offsets
     */
    setOffsets(left?: BpOffset, right?: BpOffset): void;
    /**
     * #action
     */
    setSearchResults(searchResults: BaseResult[], searchQuery: string, assemblyName: string): void;
    /**
     * #action
     */
    setNewView(bpPerPx: number, offsetPx: number): void;
    /**
     * #action
     */
    horizontallyFlip(): void;
    /**
     * #action
     */
    showTrack(trackId: string, initialSnapshot?: any, displayInitialSnapshot?: any): any;
    /**
     * #action
     */
    hideTrack(trackId: string): boolean;
} & {
    /**
     * #action
     */
    moveTrackDown(id: string): void;
    /**
     * #action
     */
    moveTrackUp(id: string): void;
    /**
     * #action
     */
    moveTrackToTop(id: string): void;
    /**
     * #action
     */
    moveTrackToBottom(id: string): void;
    /**
     * #action
     */
    moveTrack(movingId: string, targetId: string): void;
    /**
     * #action
     */
    toggleTrack(trackId: string): boolean;
    /**
     * #action
     */
    setTrackLabels(setting: 'overlapping' | 'offset' | 'hidden'): void;
    /**
     * #action
     */
    setShowCenterLine(b: boolean): void;
    /**
     * #action
     */
    setDisplayedRegions(regions: Region[]): void;
    /**
     * #action
     */
    activateTrackSelector(): import("@jbrowse/core/util").Widget;
    /**
     * #action
     */
    toggleTrackSelector(): import("@jbrowse/core/util").Widget;
    /**
     * #method
     * Helper method for the fetchSequence.
     * Retrieves the corresponding regions that were selected by the
     * rubberband
     *
     * @param leftOffset - `object as {start, end, index, offset}`, offset = start
     * of user drag
     * @param rightOffset - `object as {start, end, index, offset}`,
     * offset = end of user drag
     * @returns array of Region[]
     */
    getSelectedRegions(leftOffset?: BpOffset, rightOffset?: BpOffset): {
        assemblyName: string;
        refName: string;
        start: number;
        end: number;
    }[];
    /**
     * #action
     */
    horizontalScroll(distance: number): number;
    /**
     * #action
     */
    showAllRegions(): void;
    /**
     * #action
     * showAllRegions at a scale the caller supplies rather than this view's
     * own fit-to-width one, so several views can share one bp/px and their
     * genomes compare by drawn length. Deliberately assigns past maxBpPerPx
     * instead of going through zoomTo: a scale that fits the LARGEST genome
     * in a set necessarily exceeds every smaller genome's fit-to-width limit,
     * and clamping each row back to its own limit is exactly the equal-width
     * stretch this exists to avoid. Only a caller that owns the layout of a
     * whole set of views has a reason to reach for it — anything zooming a
     * single view wants zoomTo, whose clamp keeps the genome on screen.
     */
    showAllRegionsAtScale(bpPerPx: number): void;
    /**
     * #action
     */
    showAllRegionsInAssembly(assemblyName?: string): void;
    /**
     * #action
     */
    setDraggingTrackId(idx?: string): void;
    /**
     * #action
     */
    setLastTrackDragY(y: number): void;
    /**
     * #action
     * called while dragging a track over the track at `targetId`; reorders
     * once the cursor has moved far enough (see shouldSwapTracks) to avoid
     * jitter when a short track is dragged over a tall one
     */
    onTrackDragOver(targetId: string, currentY: number): void;
    /**
     * #action
     * this "clears the view" and makes the view return to the import form
     */
    clearView(): void;
    /**
     * #action
     */
    setInit(arg?: InitState): void;
    /**
     * #method
     * creates an svg export and save using FileSaver
     */
    exportSvg(opts?: ExportSvgOptions): Promise<void>;
} & {
    slide: (viewWidths: number) => void;
    zoom: (targetBpPerPx: number) => void;
    cancelZoomAnimation: () => void;
} & {
    /**
     * #getter
     */
    readonly showsWholeChromosome: boolean;
    /**
     * #getter
     * an ideogram only reads correctly against an entire chromosome: on a
     * sub-region it is a meaningless slice of bands, and the centromere shows
     * up as a lone half-triangle
     */
    readonly canShowCytobands: boolean;
    /**
     * #getter
     * the `showCytobands` setting gated by whether cytobands can be shown at
     * all (whole chromosome + data present) — i.e. actually on screen
     */
    readonly effectiveShowCytobands: boolean;
    /**
     * #getter
     */
    readonly anyCytobandsExist: boolean;
    /**
     * #getter
     * the cytoband is displayed to the right of the chromosome name, and
     * that offset is calculated manually with this method
     */
    readonly cytobandOffset: number;
    /**
     * #getter
     */
    readonly isTrackSelectorOpen: boolean;
} & {
    /**
     * #method
     * return the view menu items
     */
    menuItems(): MenuItem[];
    /**
     * #method
     * what a plugin can start from the selected region — a synteny view, a
     * consensus call. Extend this rather than `rubberBandMenuItems` so the
     * entries collect under the menu's "Launch" submenu; that grouping is
     * decided once here rather than by whichever contributor runs first, and
     * keeps the rubberband menu itself short as plugins pile on.
     */
    rubberBandLaunchMenuItems(): MenuItem[];
    /**
     * #getter
     * geometry of the overview scalebar — derived from displayedRegions,
     * width, and cytobandOffset so it stays cached by MobX
     */
    readonly overviewLayout: ViewLayout;
} & {
    /**
     * #getter
     * static blocks are an important concept jbrowse uses to avoid
     * re-rendering when you scroll to the side. when you horizontally
     * scroll to the right, old blocks to the left may be removed, and new
     * blocks may be instantiated on the right. tracks may use the static
     * blocks to render their data for the region represented by the block
     */
    readonly staticBlocks: BlockSet;
    /**
     * #getter
     * dynamic blocks represent the exact coordinates of the currently
     * visible genome regions on the screen. they are similar to static
     * blocks, but static blocks can go offscreen while dynamic blocks
     * represent exactly what is on screen
     */
    readonly dynamicBlocks: BlockSet;
    /**
     * #getter
     * all overview scalebar blocks (content + elided), laid out on the
     * overviewLayout. memoized so the scalebar doesn't recompute it per
     * render
     */
    readonly overviewBlocks: import("@jbrowse/core/util/blockTypes").BaseBlock[];
    /**
     * #getter
     * leading/trailing pixel span of the visible regions projected onto the
     * overviewLayout — the geometry of the overview's "you are here"
     * rectangle, and of the top edge of the polygon drawn under it. Elided
     * regions count: at whole-genome zoom the tail of an assembly is all
     * coalesced tiny contigs, and stopping at the last *content* block left
     * the rectangle short of (or, scrolled onto that tail, absent from) the
     * polygon it sits on.
     */
    readonly overviewRegionPxSpan: import("@jbrowse/core/util/Base1DUtils").PxSpan | undefined;
    /**
     * #getter
     * Max right-edge pixel position for each displayedRegionIndex, derived
     * from staticBlocks geometry. staticBlocks caches a stable reference
     * when only offsetPx changes, so this getter is also stable during
     * normal scroll — avoiding a Map rebuild every frame.
     * Used by ScalebarRefNameLabels to clip chromosome name labels.
     */
    readonly scalebarRegionEndPx: Map<number, number>;
    /**
     * #getter
     * Gridline tick positions (x relative to the staticBlocks frame),
     * derived from staticBlocks + bpPerPx. Computed once and shared by every
     * Gridlines instance (scalebar, main view, each pinned track) rather
     * than recomputing the makeTicks loop per component.
     */
    readonly gridlineTicks: {
        x: number;
        major: boolean;
    }[];
    /**
     * #getter
     * Scalebar coordinate labels (x in the staticBlocks frame + display
     * text). Sibling of gridlineTicks sharing the same makeBlockTicks
     * formula, so labels line up exactly with their gridlines. staticBlocks
     * chop a region into ~800px chunks; groupContiguousBlocks merges them
     * back per region so a label on an internal chunk boundary isn't clipped
     * away by both neighbors — only genuine region edges clip a label.
     *
     * A run that can hold fewer than MIN_TICK_LABELS_PER_BLOCK labels goes
     * unnumbered, the same rule the overview scalebar applies: with a whole
     * genome displayed each chromosome catches one lone coordinate, which
     * conveys no scale by itself and reads as the same number repeated
     * across the row.
     */
    readonly scalebarLabels: {
        x: number;
        label: string;
        key: string;
    }[];
    /**
     * #getter
     * The bold refName labels drawn along the scalebar, as plain data:
     * `{key, refName, displayedRegionIndex, transform, maxWidth,
     * paddingLeft, text}` each. One per run of same-refName regions, plus a
     * "sticky" one pinned to the viewport's left edge naming the refName
     * under it, so panning into a chromosome does not scroll its own name
     * off the screen.
     *
     * Three rules live in here that a host drawing region names will
     * otherwise rediscover the hard way, and two of them are invisible until
     * the data is awkward:
     *
     * - the sticky label rides the rightmost block that has scrolled off the
     *   left, not the region's first block — that one is gone from
     *   staticBlocks entirely once you zoom into a region's interior, taking
     *   the chromosome name off screen at exactly the zoom where nothing
     *   else names it.
     * - adjacent regions of the same refName (collapsed introns) get one
     *   label between them, not one each.
     * - a name is drawn whole or not at all, measured against the space its
     *   region leaves. Clipped to its own width, `chr16` reads as `chr1` —
     *   a different chromosome rather than a shortened name, which is why
     *   this is a fit test rather than an ellipsis.
     *
     * **Viewport frame, unlike its siblings.** `transform` is a screen x,
     * already net of `offsetPx`, where gridlineTicks / scalebarLabels /
     * paddingSpans are all in the staticBlocks frame. The sticky label's
     * position is a function of `offsetPx` rather than of block geometry, so
     * it has no fixed position in that frame — and for the same reason this
     * getter recomputes on every scroll frame where those three do not.
     *
     * `showPrefixFallback` accompanies the labels for the assembly-name chip
     * a container view (synteny) can opt into; a plain LGV never sets a
     * prefix and always gets `false`. The SVG export deliberately calls
     * `getScalebarRefNameLabels` itself with no prefix rather than reading
     * this, since it draws its own assembly name above the ruler.
     */
    readonly scalebarRefNameLabels: {
        labels: import("./util.ts").ScalebarRefNameLabel[];
        showPrefixFallback: boolean;
    };
    /**
     * #getter
     * Every span along the row that is not track data, as plain geometry in
     * the staticBlocks frame — the same frame as gridlineTicks and
     * scalebarLabels, so one `translateX(staticBlocks.offsetPx - offsetPx)`
     * places all three. Three kinds, and a host drawing its own chrome
     * needs all of them:
     *
     * - `seam`: the 3px bar at a region's right edge. Displayed regions are
     *   laid out **contiguously** — calculateStaticBlocks emits boundary
     *   padding only before the first region and after the last — so this
     *   bar is the only thing separating two of them. Without it a
     *   two-region view reads as a one-region view scrolled somewhere
     *   strange. `isRightEndOfDisplayedRegion` is what marks it;
     *   `scalebarRegionEndPx` looks like a shortcut for the same filter and
     *   is not one, being the right edge of the blocks currently *loaded*.
     * - `elided`: a region too narrow to draw at this zoom. Whole-genome on
     *   a real assembly is mostly these — hg38 has 455 sequences and all
     *   but the 24 chromosomes land sub-pixel — so a host that skips them
     *   renders that tail as nothing at all.
     * - `boundary`: past the start of the first region or the end of the
     *   last. Greying it is what makes the last region's seam read as the
     *   edge of a filled area rather than a rule floating in the track.
     *
     * Elided blocks get no seam even though they carry the flag: at the
     * zoom where regions elide, one bar per region is a solid grey wall.
     *
     * PaddingBlocks is the in-tree consumer. The SVG export is deliberately
     * NOT one: `SVGRegionSeparators` walks dynamicBlocks itself and draws
     * only the seam, because `elided` and `boundary` are chrome for an
     * interactive row rather than information a figure carries — striped
     * grey saying "regions here are too narrow to draw" is noise in a
     * static image, and at whole-genome zoom it would be most of the row.
     * The seam is the one that must survive: regions lay out contiguously,
     * so it is all that separates two of them.
     */
    readonly paddingSpans: {
        key: string;
        x: number;
        width: number;
        kind: 'seam' | 'elided' | 'boundary';
    }[];
    /**
     * #getter
     * Integer-rounded sum of all visible block widths. Slightly less than
     * view.width when the genome ends before the right edge; use view.width
     * for SVG clip rects (display boundary) and this for paint canvas sizing
     * (actual content width).
     */
    readonly totalWidthPx: number;
    /**
     * #getter
     * Like totalWidthPx but excluding inter-region boundary blocks. Used
     * when column layout divides the canvas width by feature count.
     */
    readonly totalWidthPxWithoutBorders: number;
    /**
     * #getter
     */
    readonly visibleBp: number;
    /**
     * #getter
     * Whether any part of a displayed region actually falls inside the
     * viewport. False both when the view holds no regions at all and when
     * it holds some but is scrolled entirely off them; either way there is
     * no visible span for the scalebar, ruler and refName labels to
     * describe, which is what the SVG export's header checks before drawing
     * one. Distinct from `hasDisplayedRegions`, which only asks whether the
     * view has been given regions, not whether any are on screen.
     */
    readonly hasVisibleContent: boolean;
    /**
     * #getter
     * Returns the currently visible content blocks with screen pixel
     * positions and displayedRegionIndex guaranteed.
     * Used by WebGL displays for per-region data fetching and rendering.
     */
    readonly visibleRegions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
        reversed: boolean | undefined;
        displayedRegionIndex: number;
        screenStartPx: number;
        screenEndPx: number;
    }[];
    /**
     * #getter
     * visibleRegions expanded by a half-screen buffer on each side,
     * clamped to displayedRegion bounds, with integer-rounded coordinates.
     * Use this when fetching data that should extend slightly beyond the
     * viewport for smooth scrolling.
     */
    readonly bufferedVisibleRegions: {
        region: {
            refName: string;
            start: number;
            end: number;
            assemblyName: string;
            reversed: boolean | undefined;
        };
        displayedRegionIndex: number;
    }[];
    /**
     * #getter
     * a single "combo-locstring" representing all the regions visible on
     * the screen
     */
    readonly visibleLocStrings: string;
    /**
     * #getter
     * same as visibleLocStrings, but only updated every 500ms
     */
    readonly coarseVisibleLocStrings: string;
    /**
     * #getter
     */
    readonly coarseTotalBpDisplayStr: string;
    /**
     * #getter
     */
    readonly effectiveTotalBp: number;
    /**
     * #getter
     */
    readonly effectiveTotalBpDisplayStr: string;
} & {
    /**
     * #action
     */
    setCoarseDynamicBlocks(blocks: BlockSet, bpPerPx: number): void;
} & {
    /**
     * #action
     * offset is the base-pair-offset in the displayed region, index is the
     * index of the displayed region in the linear genome view
     *
     * @param start - object as `{start, end, offset, index}`
     * @param end - object as `{start, end, offset, index}`
     */
    moveTo(start?: BpOffset, end?: BpOffset): void;
    /**
     * #action
     * Navigate to the given locstring, will change displayed regions if
     * needed, and wait for assemblies to be initialized
     *
     * @param input - e.g. "chr1:1-100", "chr1:1-100 chr2:1-100", "chr 1 100"
     * @param optAssemblyName - (optional) the assembly name to use when
     * navigating to the locstring
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToLocString(input: string, optAssemblyName?: string, grow?: number): Promise<void>;
    /**
     * #action
     * Similar to `navToLocString`, but accepts a list of parsed location
     * objects instead of a locstring. Will try to perform
     * `setDisplayedRegions` if changing regions
     *
     * @param regions - array of parsed location objects
     * @param assemblyName - optional assembly name
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToLocations(regions: ParsedLocString[], assemblyName?: string, grow?: number): Promise<void>;
    /**
     * #action
     * Navigate to a location based on its refName and optionally start, end,
     * and assemblyName. Will not try to change displayed regions, use
     * `navToLocations` instead. Only navigates to a location if it is
     * entirely within a displayedRegion. Navigates to the first matching
     * location encountered.
     *
     * Throws an error if navigation was unsuccessful
     *
     * @param query - a proposed location to navigate to
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navTo(query: NavLocation, grow?: number): void;
    /**
     * #action
     * Navigate to a location based on its refName and optionally start, end,
     * and assemblyName. Will not try to change displayed regions, use
     * navToLocations instead. Only navigates to a location if it is entirely
     * within a displayedRegion. Navigates to the first matching location
     * encountered.
     *
     * Throws an error if navigation was unsuccessful
     *
     * @param locations - proposed location to navigate to
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToMultiple(locations: NavLocation[], grow?: number): void;
} & {
    /**
     * #action
     * Similar to `navToLocString`, but accepts a parsed location object
     * instead of a locstring. Will try to perform `setDisplayedRegions` if
     * changing regions
     *
     * @param parsedLocString - a parsed location object with refName, start,
     * end, etc.
     * @param assemblyName - optional assembly name
     * @param grow - optional multiplier to expand the region by (e.g., 0.2
     * adds 20% padding on each side)
     */
    navToLocation(parsedLocString: ParsedLocString, assemblyName?: string, grow?: number): Promise<void>;
} & {
    /**
     * #method
     */
    rubberBandMenuItems(): MenuItem[];
    /**
     * #method
     */
    bpToPx({ refName, coord, displayedRegionIndex, }: {
        refName: string;
        coord: number;
        displayedRegionIndex?: number;
    }): {
        index: number;
        offsetPx: number;
    } | undefined;
    /**
     * #method
     * Map a highlight or bookmark region to its pixel position+width inside
     * the tracks container. Falls back to the raw refName if the region's
     * assemblyName is missing or unknown so highlights authored without an
     * assembly still render in single-assembly views.
     */
    getHighlightCoords(region: {
        assemblyName?: string;
        refName: string;
        start: number;
        end: number;
    }): {
        width: number;
        left: number;
    } | undefined;
    /**
     * #method
     * like getHighlightCoords but laid out against the overview scalebar and
     * shifted by the cytoband offset
     */
    getOverviewHighlightCoords(region: {
        assemblyName?: string;
        refName: string;
        start: number;
        end: number;
    }): {
        width: number;
        left: number;
    } | undefined;
    /**
     * #method
     * scrolls the view to center on the given bp. if that is not in any of
     * the displayed regions, does nothing
     *
     * @param coord - basepair at which you want to center the view
     * @param refName - refName of the displayedRegion you are centering at
     * @param displayedRegionIndex - index of the displayedRegion
     */
    centerAt(coord: number, refName: string, displayedRegionIndex?: number): void;
    /**
     * #method
     */
    pxToBp(px: number): import("@jbrowse/core/util/Base1DUtils").PxToBpResult;
    /**
     * #getter
     */
    readonly centerLineInfo: import("@jbrowse/core/util/Base1DUtils").PxToBpResult | undefined;
} & {
    /**
     * #method
     */
    rubberbandClickMenuItems(clickOffset: BpOffset): MenuItem[];
    /**
     * #method
     * returns menu items for a highlight context menu. plugins can extend
     * this via Core-extendPluggableElement to add their own items
     */
    highlightMenuItems(_highlight: HighlightType): MenuItem[];
} & {
    afterCreate(): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, {
    displayName: string | undefined;
    minimized: boolean;
    highlight: HighlightType[];
    showHighlightChips: boolean;
    id: string;
    type: string;
    offsetPx: number;
    bpPerPx: number;
    displayedRegions: Region[];
    tracks: any[];
    hideHeader: boolean;
    hideHeaderOverview: boolean;
    hideNoTracksActive: boolean;
    trackSelectorType: string;
    showGridlines: boolean;
    labelsVisible: boolean;
    scalebarOnly: boolean;
    init?: InitState | undefined;
    showCytobands?: false | undefined;
    trackLabels?: string | undefined;
    colorByCDS?: true | undefined;
    showAminoAcids?: false | undefined;
    showTrackOutlines?: false | undefined;
}>;
export type LinearGenomeViewStateModel = ReturnType<typeof stateModelFactory>;
export type LinearGenomeViewModel = Instance<LinearGenomeViewStateModel>;
declare module '@jbrowse/core/PluginManager' {
    interface ViewTypeRegistry {
        LinearGenomeView: LinearGenomeViewStateModel;
    }
}
