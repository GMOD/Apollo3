export declare class OomReporter {
    private hal;
    private handler;
    constructor(hal: string);
    setHandler(handler: (error: Error) => void): void;
    report(message: string): void;
}
