import type { GpuHal, PassDescriptor } from './types.ts';
export declare function createGpuHal(canvas: HTMLCanvasElement, passes: PassDescriptor[], uniformByteSize: number): Promise<GpuHal | null>;
