export declare function useTabVisibilityRerender(renderFn: () => void): void;
