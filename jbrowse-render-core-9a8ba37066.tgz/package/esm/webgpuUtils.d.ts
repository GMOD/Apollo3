export declare const STANDARD_BLEND_STATE: GPUBlendState;
export declare function createUniformOnlyBindGroupLayout(device: GPUDevice): GPUBindGroupLayout;
export declare function createUniformOnlyBindGroup(device: GPUDevice, layout: GPUBindGroupLayout, uniformBuffer: GPUBuffer, uniformVisibleSize: number): GPUBindGroup;
export declare function createVertexBuffer(device: GPUDevice, data: ArrayBuffer | ArrayBufferView): GPUBuffer;
export declare function glToGpuVertexFormat(attr: {
    components: number;
    type: 'float' | 'uint' | 'int';
}): GPUVertexFormat;
