import React from 'react';
export declare function ScrollLockedOverlay({ scrollTop, viewportHeight, contentHeight, children, }: {
    scrollTop: number;
    viewportHeight: number;
    contentHeight: number;
    children: React.ReactNode;
}): React.JSX.Element;
