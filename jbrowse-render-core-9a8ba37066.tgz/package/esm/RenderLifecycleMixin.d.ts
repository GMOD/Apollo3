export interface RenderingBackendCallbacks<B> {
    upload: (backend: B) => void;
    render: (backend: B) => boolean;
}
export declare function RenderLifecycleMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: RenderingBackendCallbacks<B>): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
