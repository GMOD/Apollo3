import type { BlobLocation } from '@jbrowse/core/util';
import type { LooseTrackInput } from '@jbrowse/core/util/tracks';
import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
export type TrackConf = Record<string, unknown>;
/**
 * What a controller accepts per track: a full config, a bare data-file URL, or
 * `{ uri, index?, ...extra }`. The loose forms expand through core's
 * `guessTrackConf`, the same inference the "Add track" flow runs.
 */
export type TrackInput = string | TrackConf;
interface ControllerView {
    tracks: {
        configuration: {
            trackId: string;
        };
    }[];
    showTrack: (trackId: string) => unknown;
    hideTrack: (trackId: string) => unknown;
}
export interface ControllerSession extends IStateTreeNode {
    view: ControllerView;
    getTrackById: (trackId: string) => unknown;
    addTrackConf: (conf: TrackConf) => unknown;
}
export declare function isLooseTrack(track: TrackInput): track is string | LooseTrackInput;
/**
 * Stamp the view's assembly onto a full-config track that omits
 * `assemblyNames`. A single-view embed has exactly one assembly, so it is
 * unambiguous — and doing it here frees every host (R htmlwidgets, anywidget,
 * vanilla JS) from computing the name itself, which it often cannot: the
 * assembly may have arrived as a hub name only the view resolved. Loose tracks
 * take the same name through `guessTrackConf`'s `assemblyName` argument.
 */
export declare function withAssemblyName(track: TrackConf, assemblyName?: string): TrackConf;
/**
 * Expand every loose entry into a full track config; stamp the assembly name
 * onto the ones already written out. `node` is any node of the live tree — the
 * pluginManager whose format plugins drive the guess comes off its env.
 */
export declare function resolveTracks(tracks: TrackInput[], node: IStateTreeNode, assemblyName?: string, localFiles?: Record<string, BlobLocation>): TrackConf[];
/**
 * Register each track config only if the session cannot already resolve it, then
 * show it. The guard matters: `addTrackConf` only dedupes against
 * `sessionTracks`, so re-adding a config already seeded into the config catalog
 * would push a duplicate into `sessionTracks` that then shadows the catalog
 * entry. `getTrackById` resolves catalog + connection + session tracks, so this
 * is idempotent.
 */
export declare function openTracks(session: ControllerSession, tracks: TrackConf[]): void;
/** Open every wanted track and close any others the view currently shows. */
export declare function reconcileTracks(session: ControllerSession, tracks: TrackConf[]): void;
/** Merge a hub's own search adapters with the ones the caller supplied. */
export declare function mergeSearchAdapters<T>(a: readonly T[] | undefined, b: readonly T[] | undefined): T[] | undefined;
export {};
