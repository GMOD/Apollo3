export declare const getDescriptiveErrorMessage: (response: Response, reason?: string) => Promise<string>;
