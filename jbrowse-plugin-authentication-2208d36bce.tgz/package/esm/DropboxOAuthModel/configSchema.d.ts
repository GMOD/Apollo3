import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #config DropboxOAuthInternetAccount
 *
 * #example
 * The Dropbox endpoints are pre-filled, so an entry needs only your own OAuth
 * app's `clientId`. Leave `domains` off and the account is still selectable by
 * hand in the Add Track form.
 * ```js
 * {
 *   type: 'DropboxOAuthInternetAccount',
 *   internetAccountId: 'dropboxOAuth',
 *   name: 'Dropbox',
 *   clientId: 'your-dropbox-app-key',
 * }
 * ```
 */
declare const DropboxOAuthConfigSchema: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    /**
     * #slot
     */
    readonly authEndpoint: {
        readonly description: "the authorization code endpoint of the internet account";
        readonly type: "string";
        readonly defaultValue: "https://www.dropbox.com/oauth2/authorize";
    };
    /**
     * #slot
     */
    readonly tokenEndpoint: {
        readonly description: "the token endpoint of the internet account";
        readonly type: "string";
        readonly defaultValue: "https://api.dropbox.com/oauth2/token";
    };
    /**
     * #slot
     */
    readonly needsPKCE: {
        readonly description: "boolean to indicate if the endpoint needs a PKCE code";
        readonly type: "boolean";
        readonly defaultValue: true;
    };
    /**
     * #slot
     */
    readonly domains: {
        readonly description: "array of valid domains the url can contain to use this account";
        readonly type: "stringArray";
        readonly defaultValue: readonly ["addtodropbox.com", "db.tt", "dropbox.com", "dropboxapi.com", "dropboxbusiness.com", "dropbox.tech", "getdropbox.com"];
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly tokenType: {
        readonly description: "a custom name for a token to include in the header";
        readonly type: "string";
        readonly defaultValue: "Bearer";
    };
    readonly authEndpoint: {
        readonly description: "the authorization code endpoint of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly tokenEndpoint: {
        readonly description: "the token endpoint of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly needsPKCE: {
        readonly description: "boolean to indicate if the endpoint needs a PKCE code";
        readonly type: "boolean";
        readonly defaultValue: false;
    };
    readonly clientId: {
        readonly description: "id for the OAuth application";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly scopes: {
        readonly description: "optional scopes for the authorization call";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly state: {
        readonly description: "optional state for the authorization call";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly responseType: {
        readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
        readonly type: "string";
        readonly defaultValue: "code";
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly name: {
        readonly description: "descriptive name of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly description: {
        readonly description: "a description of the internet account";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly authHeader: {
        readonly description: "request header for credentials";
        readonly type: "string";
        readonly defaultValue: "Authorization";
    };
    readonly tokenType: {
        readonly description: "a custom name for a token to include in the header";
        readonly type: "string";
        readonly defaultValue: "";
    };
    readonly domains: {
        readonly description: "array of valid domains the url can contain to use this account";
        readonly type: "stringArray";
        readonly defaultValue: readonly [];
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>, undefined>>;
export type DropboxOAuthInternetAccountConfigModel = typeof DropboxOAuthConfigSchema;
export type DropboxOAuthInternetAccountConfig = Instance<DropboxOAuthInternetAccountConfigModel>;
export default DropboxOAuthConfigSchema;
