export declare function getResponseError({ response, reason, statusText, }: {
    response: Response;
    reason?: string;
    statusText?: string;
}): Promise<string>;
export declare function getError(response: Response): Promise<string>;
/**
 * Builds the `describeError` a provider hands `validateTokenWithProbe` and
 * throws from its fetcher: read the body, pull the human-readable part out of
 * the provider's own error JSON, and fall back to the raw text when it is not
 * that shape at all — an HTML error page from a proxy in front of the API, say.
 *
 * `extract` runs inside the same guard as the parse, so it may reach into the
 * payload without checking each hop.
 */
export declare function descriptiveErrorMessage<T>(extract: (parsed: T) => string | undefined): (response: Response, reason?: string) => Promise<string>;
