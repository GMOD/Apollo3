export declare function OAuthLoginPrompt({ internetAccountId, handleClose, }: {
    internetAccountId: string;
    handleClose: (proceed: boolean) => void;
}): import("react").JSX.Element;
