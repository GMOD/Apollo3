export interface OAuthWindowParams {
    internetAccountId: string;
    expectedState: string | undefined;
    exchangeAuthorizationCode: (code: string, redirectUri: string) => Promise<string>;
    storeToken: (token: string) => void;
}
export declare function parseOAuthError(text: string): {
    isInvalidGrant: boolean;
    statusText: string;
};
/**
 * Completes the flow from the URL the provider redirected back to. Returns the
 * token, or undefined if the redirect carries neither a token, a code, nor an
 * error. Throws on any OAuth error.
 */
export declare function finishOAuthRedirect(redirectUri: string, params: OAuthWindowParams): Promise<string | undefined>;
/**
 * The redirect URI a message event carries, if it is this account's popup
 * reporting back, and undefined otherwise. Synchronous, so a caller can tell a
 * relevant message from an unrelated one before finishing it — finishing can
 * take a round trip of its own.
 */
export declare function getOAuthRedirectUri(event: MessageEvent, internetAccountId: string): string | undefined;
/**
 * Parses an OAuth redirect message event. Returns the token if the event
 * completes the flow, undefined if the event isn't this account's redirect.
 * Throws on any OAuth error.
 */
export declare function finishOAuthWindow(event: MessageEvent, params: OAuthWindowParams): Promise<string | undefined>;
/**
 * Returns a promise that resolves to the token when the OAuth popup posts its
 * redirect back. The listener is self-contained and cleaned up when the promise
 * settles.
 *
 * Given a `watch`, closing the popup without completing the flow rejects rather
 * than leaving the promise pending — and pending is not a benign state here,
 * because `getToken` caches this promise and hands it to every later request:
 * one dismissed login window left the account dead for the rest of the session,
 * showing nothing. Same failure the blocked-popup check in `getTokenViaAuthFlow`
 * covers, reached the other way.
 */
export declare function waitForOAuthMessage(finish: (event: MessageEvent) => Promise<string | undefined>, watch?: {
    popup: Pick<Window, 'closed'>;
    /** whether an event is this popup's redirect, tested synchronously */
    isOwnMessage: (event: MessageEvent) => boolean;
}): Promise<string>;
