import type { OAuthInternetAccountConfig, OAuthInternetAccountConfigModel } from './configSchema.ts';
import type { UriLocation } from '@jbrowse/core/util';
import type { Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel OAuthInternetAccount
 */
declare const stateModelFactory: (configSchema: OAuthInternetAccountConfigModel) => import("@jbrowse/mobx-state-tree").IModelType<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    type: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>>;
}, "configuration" | "type"> & {
    /**
     * #property
     */
    type: import("@jbrowse/mobx-state-tree").ISimpleType<"OAuthInternetAccount">;
    /**
     * #property
     */
    configuration: import("@jbrowse/core/configuration/configurationSchema").IConfigurationReference<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "Bearer";
        };
        readonly authEndpoint: {
            readonly description: "the authorization code endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly tokenEndpoint: {
            readonly description: "the token endpoint of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly needsPKCE: {
            readonly description: "boolean to indicate if the endpoint needs a PKCE code";
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        readonly clientId: {
            readonly description: "id for the OAuth application";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly scopes: {
            readonly description: "optional scopes for the authorization call";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly state: {
            readonly description: "optional state for the authorization call";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly responseType: {
            readonly description: "the type of response from the authorization endpoint. can be 'token' or 'code'";
            readonly type: "string";
            readonly defaultValue: "code";
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        readonly name: {
            readonly description: "descriptive name of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly description: {
            readonly description: "a description of the internet account";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly authHeader: {
            readonly description: "request header for credentials";
            readonly type: "string";
            readonly defaultValue: "Authorization";
        };
        readonly tokenType: {
            readonly description: "a custom name for a token to include in the header";
            readonly type: "string";
            readonly defaultValue: "";
        };
        readonly domains: {
            readonly description: "array of valid domains the url can contain to use this account";
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, "internetAccountId">>, undefined>>>;
}, {
    readonly name: string;
    readonly description: string;
    readonly internetAccountId: string;
    readonly authHeader: string;
    readonly tokenType: string;
    readonly domains: string[];
    readonly toggleContents: React.ReactNode;
    readonly SelectorComponent: import("@jbrowse/core/util").AnyReactComponentType | undefined;
    readonly selectorLabel: string | undefined;
} & {
    handlesLocation(location: UriLocation): boolean;
    readonly tokenKey: string;
} & {
    getTokenFromUser(_resolve: (token: string) => void, _reject: (error: Error) => void): void;
    storeToken(token: string): void;
    retrieveToken(): string | null;
    validateToken(token: string, _loc: UriLocation): Promise<string>;
} & {
    removeToken(): void;
    getToken(location?: UriLocation): Promise<string>;
} & {
    addAuthHeaderToInit(init?: RequestInit, token?: string): {
        body?: BodyInit | null;
        cache?: RequestCache;
        credentials?: RequestCredentials;
        integrity?: string;
        keepalive?: boolean;
        method?: string;
        mode?: RequestMode;
        priority?: RequestPriority;
        redirect?: RequestRedirect;
        referrer?: string;
        referrerPolicy?: ReferrerPolicy;
        signal?: AbortSignal | null;
        window?: null;
        headers: Headers;
    };
    getValidatedToken(loc?: UriLocation): Promise<string>;
    getPreAuthorizationInformation(location: UriLocation): Promise<{
        internetAccountType: string;
        authInfo: {
            token: string;
            configuration: import("@jbrowse/mobx-state-tree").ModelSnapshotType<Record<string, any>>;
        };
    }>;
} & {
    getFetcher(loc?: UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
} & {
    openLocation(location: UriLocation): import("@jbrowse/core/util/io").RemoteFileWithRangeCache;
} & {
    /**
     * #getter
     * The config typed off the concrete schema. `ConfigurationReference`
     * erases `self.configuration` to `any` (the reference's MST instance brand
     * doesn't carry the schema's slot definitions), so reads go through this
     * getter to recover per-slot types and slot-name validation.
     */
    readonly conf: OAuthInternetAccountConfig;
} & {
    /**
     * #getter
     */
    readonly codeVerifierPKCE: string;
} & {
    /**
     * #getter
     */
    readonly authEndpoint: string;
    /**
     * #getter
     */
    readonly tokenEndpoint: string;
    /**
     * #getter
     */
    readonly needsPKCE: boolean;
    /**
     * #getter
     */
    readonly clientId: string;
    /**
     * #getter
     */
    readonly scopes: string;
    /**
     * #getter
     * OAuth state parameter:
     * https://www.rfc-editor.org/rfc/rfc6749#section-4.1.1
     *
     * Can override or extend if dynamic state is needed.
     */
    readonly state: string;
    /**
     * #getter
     */
    readonly responseType: 'token' | 'code';
    /**
     * #getter
     */
    readonly refreshTokenKey: string;
    /**
     * #getter
     * Extra parameters to add to the authorization request. Empty here;
     * a provider that needs one of its own overrides this.
     */
    readonly authFlowParams: Record<string, string>;
} & {
    /**
     * #action
     */
    storeRefreshToken(refreshToken: string): void;
    /**
     * #action
     */
    removeRefreshToken(): void;
    /**
     * #method
     */
    retrieveRefreshToken(): string | undefined;
    /**
     * #action
     * Swap in an access token obtained from a refresh, in place of the one it
     * replaces.
     */
    replaceToken(token: string): void;
} & {
    /**
     * #action
     */
    exchangeAuthorizationForAccessToken(code: string, redirectUri: string): Promise<string>;
    /**
     * #action
     */
    exchangeRefreshForAccessToken(refreshToken: string): Promise<string>;
} & {
    /**
     * #action
     * Opens the provider's auth page and returns a promise for the resulting
     * token. For Electron, drives the flow directly via IPC; for web, opens a
     * popup and waits for the redirect message.
     */
    getTokenViaAuthFlow(): Promise<string>;
} & {
    /**
     * #action
     */
    getTokenFromUser(resolve: (token: string) => void, reject: (error: Error) => void): Promise<void>;
    /**
     * #action
     */
    validateToken(token: string, location: UriLocation): Promise<string>;
} & {
    /**
     * #action
     * Run a request with the current token and, only if it comes back 401,
     * refresh the token through `validateToken` and run it exactly once more.
     * This is how the fetchers reach a resource.
     */
    fetchWithToken(loc: UriLocation | undefined, run: (token: string) => Promise<Response>): Promise<Response>;
} & {
    /**
     * #action
     */
    getFetcher(loc?: UriLocation): (input: RequestInfo, init?: RequestInit) => Promise<Response>;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export default stateModelFactory;
export type OAuthStateModel = ReturnType<typeof stateModelFactory>;
export type OAuthModel = Instance<OAuthStateModel>;
