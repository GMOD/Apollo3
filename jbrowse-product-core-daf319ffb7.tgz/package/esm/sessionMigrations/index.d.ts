/**
 * Migrates old session and config snapshots to be compatible with the current
 * display type registrations. Handles display types that were removed or
 * renamed in the v4 rendering rearchitecture.
 *
 * Remapped display types (see `displayTypeMap` for the band settings each one
 * carries over):
 *   LinearPileupDisplay → LinearAlignmentsDisplay
 *   LinearSNPCoverageDisplay → LinearAlignmentsDisplay
 *   LinearReadArcsDisplay → LinearAlignmentsDisplay
 *   LinearReadCloudDisplay → LinearAlignmentsDisplay
 *   LinearFeatureDisplay → LinearBasicDisplay
 *
 * Also lifts the per-instance alignments settings a v4.3.0 session persisted
 * (`colorBySetting`, `filterBySetting`, `jexlFilters`, `trackMaxHeight`,
 * `hideMismatchesSetting`) into the config where they now live as slots — off
 * the nested `LinearAlignmentsDisplay` container's `PileupDisplay` /
 * `SNPCoverageDisplay` sub-nodes and off a flat old display alike, see
 * `extractAlignmentsInstanceSettings` — and routes the legacy per-instance
 * `heightPreConfig` display-height prop onto the `height` config slot — see
 * `extractInstanceHeight`.
 */
/**
 * Every display-instance key this module still understands, keyed by the display
 * type it applies to — `*` for the ones any display gets. A session snapshot
 * carrying one of these loads correctly, so `jbrowse validate` reports it as
 * stale rather than dead; that command reads this map (through the generated
 * config manifest) rather than keeping a copy that could drift.
 *
 * Keyed rather than flat because the same name means different things on
 * different displays: `jexlFilters` is lifted here for the alignments display,
 * while on a LinearBasicDisplay — whose own prop is `jexlFiltersSetting` — it is
 * simply dead, and a flat list would call that one supported.
 */
export declare const MIGRATED_DISPLAY_INSTANCE_KEYS: Record<string, string[]>;
/**
 * Walks a session snapshot and remaps old display types to their new names.
 * Handles displays nested inside views, tracks, and sessionTracks.
 */
export declare function migrateSessionSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
/**
 * Walks a config snapshot and remaps old display types in track definitions.
 * Config tracks have displays in their configuration (not in views).
 */
export declare function migrateConfigSnapshot(snapshot: Record<string, unknown>): Record<string, unknown>;
