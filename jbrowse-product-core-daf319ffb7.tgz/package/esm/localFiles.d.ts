import type { BlobLocation } from '@jbrowse/core/util';
/**
 * Bytes for one browser-local file, keyed by the name a track config refers to
 * it by. `Blob`/`File` pass through; anything else (a `Uint8Array` from a
 * notebook kernel's binary channel, an `ArrayBuffer` from a fetch) is wrapped.
 */
export type LocalFileInput = Record<string, Blob | BufferSource>;
/**
 * Register in-memory bytes as browser-local files JBrowse can read, returning
 * the `name -> BlobLocation` map {@link resolveLocalFileUris} substitutes with.
 *
 * This is the escape from "the data has to be on a web server first". A
 * `BlobLocation` opens as a `BlobFile`, which serves byte ranges out of
 * `Blob.slice()` — so a bgzipped+tabixed file, a BAM with its `.bai`, or a
 * bigWig is *seeked into* exactly as if it were remote, and only the bytes the
 * current view needs are ever touched. That is the whole point of doing this
 * rather than inlining features into a config: a 200k-feature table is ~20MB of
 * JSON to serialize, ship, and hold in memory, while the same data as a tabix
 * file is a few MB the view reads a few KB of at a time.
 *
 * For hosts that hold their data in a process rather than at a URL — a notebook
 * kernel, an R session, a desktop app — this is the way in, and it needs no web
 * server, no CORS, and no temporary public bucket.
 */
export declare function registerLocalFiles(files: LocalFileInput): {
    [k: string]: BlobLocation;
};
/**
 * Rewrite every `{ uri: <a registered name> }` in a track config to that file's
 * `BlobLocation`, in place of nothing else — unregistered URIs are left alone,
 * so a config can mix local and remote files freely.
 *
 * Runs *after* type inference rather than instead of it: `guessTrackConf` reads
 * the extension off the uri string to pick the adapter, and derives the index's
 * location as a conventional sibling (`.tbi`/`.bai`/`.crai`) of that same
 * string. So a host registers `peaks.bed.gz` and `peaks.bed.gz.tbi` under their
 * plain names, the guesser produces a BedTabixAdapter pointing at both, and this
 * swaps both for blobs — index and all, with no host-side knowledge of which
 * adapter wanted which sibling.
 */
export declare function resolveLocalFileUris<T>(config: T, locations: Record<string, BlobLocation>): T;
