/**
 * #config PreferencesConfigSchema
 * #category root
 * admin/embedder defaults for user-facing preferences, found on the root config
 * as `configuration.preferences`. Individual users override these at runtime
 * (persisted to localStorage) via the session `getPreference` reader; a runtime
 * override map layered over config defaults, at app scope.
 */
export declare function PreferencesConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    /**
     * #slot configuration.preferences.animationMode
     * controls feature-layout animations: 'enabled' always animates (the
     * default), 'system' respects the OS prefers-reduced-motion setting,
     * 'disabled' never animates
     */
    readonly animationMode: {
        readonly model: import("@jbrowse/mobx-state-tree").ISimpleType<"disabled" | "enabled" | "system">;
        readonly type: "stringEnum";
        readonly defaultValue: "enabled";
    };
    /**
     * #slot configuration.preferences.scrollZoom
     * when true, scrolling the mouse wheel over a track zooms in and out
     * without holding Ctrl. Applies globally to all wheel-zoom views.
     */
    readonly scrollZoom: {
        readonly type: "boolean";
        readonly defaultValue: false;
    };
    /**
     * #slot configuration.preferences.numberGrouping
     * when true (the default), numbers are displayed with thousand separators
     * — `chr1:1,234,567`. Turn it off to render them bare, which is what you
     * want if you copy coordinates out of JBrowse into tools that won't accept
     * the commas. Applies to every displayed number, and takes effect on
     * reload.
     */
    readonly numberGrouping: {
        readonly type: "boolean";
        readonly defaultValue: true;
    };
    /**
     * #slot configuration.preferences.useWorkspaces
     * when true, views open in the dockview-based tabbed/tiled workspace layout
     * rather than stacked vertically. Only the default: a session that names
     * `useWorkspaces` itself (a shared snapshot, or a session spec carrying a
     * `layout`) still wins, and a user's own toggle overrides it.
     */
    readonly useWorkspaces: {
        readonly type: "boolean";
        readonly defaultValue: false;
    };
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
