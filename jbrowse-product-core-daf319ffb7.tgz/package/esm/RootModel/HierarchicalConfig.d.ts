/**
 * #config HierarchicalConfigSchema
 * #category root
 * generally exists on the config.json or root config as configuration.hierarchical
 */
export declare function HierarchicalConfigSchemaFactory(): import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
    readonly sort: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        /**
         * #slot configuration.hierarchical.sort.trackNames
         * start the track selector with tracks sorted alphabetically inside each
         * category rather than in config order. Only the initial state — the
         * selector's own "Sort track names" toggle overrides it from then on
         */
        readonly trackNames: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        /**
         * #slot configuration.hierarchical.sort.categories
         * start the track selector with categories sorted alphabetically rather
         * than in config order. Only the initial state — the selector's own
         * "Sort categories" toggle overrides it from then on
         */
        readonly categories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
    /**
     * #slot configuration.hierarchical.trackAdornments
     * show the short suffix a plugin can add after a track's name to say what
     * turning it on will do — for a synteny track, which assembly it compares
     * against. Worth turning off for a config whose track names already carry
     * that (`hg38_vs_mm10`), where the suffix only repeats the name. Only the
     * initial state — the selector's own "Show track annotations" toggle
     * overrides it from then on
     */
    readonly trackAdornments: {
        readonly type: "boolean";
        readonly defaultValue: true;
    };
    /**
     * #slot configuration.hierarchical.defaultFolderCategories
     */
    readonly defaultFolderCategories: {
        readonly type: "stringArray";
        readonly description: "list of category names to display as folders by default";
        readonly defaultValue: readonly [];
    };
    readonly defaultCollapsed: import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaType<{
        /**
         * #slot configuration.hierarchical.defaultCollapsed.categoryNames
         * named top-level categories that start collapsed, e.g.
         * `['ENCODE', 'RNA-seq']`. Once a user expands or collapses anything, the
         * selector remembers their state instead
         */
        readonly categoryNames: {
            readonly type: "stringArray";
            readonly defaultValue: readonly [];
        };
        /**
         * #slot configuration.hierarchical.defaultCollapsed.topLevelCategories
         * start every top-level category collapsed, so a config with many
         * categories opens as a short list rather than a wall of tracks
         */
        readonly topLevelCategories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
        /**
         * #slot configuration.hierarchical.defaultCollapsed.subCategories
         * start every nested category collapsed while leaving the top level
         * open, for deeply categorized track sets
         */
        readonly subCategories: {
            readonly type: "boolean";
            readonly defaultValue: false;
        };
    }, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
}, import("@jbrowse/core/configuration/configurationSchema").ConfigurationSchemaOptions<undefined, undefined>>;
