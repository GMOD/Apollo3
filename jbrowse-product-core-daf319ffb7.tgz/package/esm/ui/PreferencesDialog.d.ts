import type PluginManager from '@jbrowse/core/PluginManager';
import type { ThemeMap } from '@jbrowse/core/ui';
import type { AnimationMode, TrackConfigChange } from '@jbrowse/core/util';
import type React from 'react';
export interface PreferencesDialogSession {
    allThemes: () => ThemeMap;
    themeName?: string;
    setThemeName: (arg: string) => void;
    stickyViewHeaders: boolean;
    setStickyViewHeaders: (sticky: boolean) => void;
    effectiveUseWorkspaces: boolean;
    defaultUseWorkspaces: boolean;
    setUseWorkspacesPreference: (useWorkspaces: boolean) => void;
    resetUseWorkspaces: () => void;
    animationMode: AnimationMode;
    numberGrouping: boolean;
    setPreferenceOverride: (key: string, value: unknown) => void;
    clearPreferenceOverrides: () => void;
    getPreferenceChanges: () => TrackConfigChange[];
    resetPreferenceChange: (path: string[]) => void;
}
/**
 * Descriptor returned from the `Core-preferencesDialogPanels` extension point.
 * Each panel renders as its own labeled section in the dialog.
 */
export interface PreferencesPanelDescriptor {
    name: string;
    Component: React.ComponentType<{
        session: PreferencesDialogSession;
    }>;
}
declare module '@jbrowse/core/PluginManager' {
    interface ExtensionPointRegistry {
        'Core-preferencesDialogPanels': {
            args: PreferencesPanelDescriptor[];
            result: PreferencesPanelDescriptor[];
            props: {
                session: PreferencesDialogSession;
            };
        };
    }
}
declare const PreferencesDialog: ({ handleClose, session, pluginManager, }: {
    handleClose: () => void;
    session: PreferencesDialogSession;
    pluginManager: PluginManager;
}) => React.JSX.Element;
export default PreferencesDialog;
