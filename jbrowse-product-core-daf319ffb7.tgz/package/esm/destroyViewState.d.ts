import type { IStateTreeNode } from '@jbrowse/mobx-state-tree';
interface EmbeddedRoot extends IStateTreeNode {
    session?: unknown;
    rpcManager: {
        destroy: () => void;
    };
}
/**
 * Tear down an engine built by an embedded product's `createViewState`:
 * terminate its RPC worker threads and destroy the MST tree so its
 * `addDisposer`'d autoruns stop.
 *
 * Unmounting the React tree is not enough — the engine is not owned by React.
 * A host that builds and discards engines (a Jupyter cell re-run, an SPA route
 * change, a controller's `destroy()`) otherwise orphans a whole worker pool and
 * a live autorun set per discarded engine. A component that owns one engine for
 * the lifetime of the page never needs this.
 *
 * Idempotent: destroying an already-destroyed engine is a no-op.
 */
export declare function destroyViewState(viewState: EmbeddedRoot): void;
export {};
