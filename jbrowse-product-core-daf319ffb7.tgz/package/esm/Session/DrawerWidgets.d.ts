import type PluginManager from '@jbrowse/core/PluginManager';
import type { AnyConfigurationModel } from '@jbrowse/core/configuration';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel DrawerWidgetSessionMixin
 */
export declare function DrawerWidgetSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<{
    /**
     * #property
     */
    drawerPosition: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    drawerWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    /**
     * #property
     */
    widgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    /**
     * #property
     */
    activeWidgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>>, [undefined]>;
    /**
     * #property
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, {
    /**
     * #getter
     */
    readonly visibleWidget: any;
} & {
    /**
     * #volatile
     * true while the visible widget is shown in a modal dialog instead of the
     * drawer. Volatile because a restored session that opened straight into a
     * modal, with no drawer behind it, is disorienting
     */
    poppedOut: boolean;
} & {
    /**
     * #action
     */
    setDrawerPosition(arg: string): void;
    /**
     * #action
     */
    updateDrawerWidth(drawerWidth: number): number;
    /**
     * #action
     */
    resizeDrawer(distance: number): number;
    /**
     * #action
     */
    addWidget(typeName: string, id: string, initialState?: any, conf?: unknown): any;
    /**
     * #action
     */
    showWidget(widget: any): void;
    /**
     * #action
     */
    hideWidget(widget: any): void;
    /**
     * #action
     */
    minimizeWidgetDrawer(): void;
    /**
     * #action
     */
    showWidgetDrawer(): void;
    /**
     * #action
     * show the visible widget in a modal dialog, freeing the drawer column
     */
    popoutWidget(): void;
    /**
     * #action
     */
    returnWidgetToDrawer(): void;
    /**
     * #action
     */
    hideAllWidgets(): void;
    /**
     * #action
     * opens a configuration editor to configure the given thing,
     * and sets the current task to be configuring it
     * @param configuration - can be an MST model or a frozen/plain object with trackId
     */
    editConfiguration(configuration: AnyConfigurationModel | {
        trackId: string;
    }, opts?: {
        expandedDisplayId?: string;
    }): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree").ModelSnapshotType<{
    /**
     * #property
     */
    drawerPosition: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    /**
     * #property
     */
    drawerWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    /**
     * #property
     */
    widgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    /**
     * #property
     */
    activeWidgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>>, [undefined]>;
    /**
     * #property
     */
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}>>;
/** Session mixin MST type for a session that manages drawer widgets */
export type SessionWithDrawerWidgetsType = ReturnType<typeof DrawerWidgetSessionMixin>;
/** Instance of a session that manages drawer widgets */
export type SessionWithDrawerWidgets = Instance<SessionWithDrawerWidgetsType>;
/** Type guard for SessionWithDrawerWidgets */
export declare function isSessionWithDrawerWidgets(session: IAnyStateTreeNode): session is SessionWithDrawerWidgets;
