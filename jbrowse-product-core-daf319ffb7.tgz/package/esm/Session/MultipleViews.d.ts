import type PluginManager from '@jbrowse/core/PluginManager';
import type { IBaseViewModel } from '@jbrowse/core/pluggableElementTypes';
import type { IAnyStateTreeNode, Instance } from '@jbrowse/mobx-state-tree';
/**
 * #stateModel MultipleViewsSessionMixin
 */
export declare function MultipleViewsSessionMixin(pluginManager: PluginManager): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    margin: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    focusedViewId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    highlightsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, never>, "activeWidgets" | "drawerPosition" | "drawerWidth" | "minimized" | "widgets"> & {
    drawerPosition: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    drawerWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    widgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    activeWidgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>>, [undefined]>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "stickyViewHeaders" | "useWorkspaces" | "views"> & {
    /**
     * #property
     */
    views: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    /**
     * #property
     */
    stickyViewHeaders: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    /**
     * #property
     * enables the dockview-based tabbed/tiled workspace layout for this
     * session. Undefined means unspecified — read `effectiveUseWorkspaces`.
     */
    useWorkspaces: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>>, [undefined]>;
}, {
    selection: unknown;
    hovered: unknown;
    queueOfDialogs: [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>][];
    preferencesOverrides: import("mobx").ObservableMap<string, unknown>;
    scrollZoomHintCount: number;
} & {
    readonly root: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
        jbrowse: import("@jbrowse/mobx-state-tree").IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            unrecognizedReports: {
                report(session: unknown, name: string, handlerCount: number, fire: () => unknown): void;
                reportFor(session: unknown, name: string): {
                    handled: boolean;
                    claim?: Promise<void>;
                } | undefined;
            };
        } & {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            loadingAssembly(asmNames: string[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            readonly assemblyNamesList: string[];
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            settleAssemblyResolution(assemblyName: string): Promise<void>;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            requireAssembly(assemblyName: string): Promise<import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }> & {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<import("@jbrowse/mobx-state-tree").IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
        jbrowse: import("@jbrowse/mobx-state-tree").IAnyType;
        session: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IAnyType>;
        sessionPath: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
        assemblyManager: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IModelType<{
            assemblies: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
        }, {
            unrecognizedReports: {
                report(session: unknown, name: string, handlerCount: number, fire: () => unknown): void;
                reportFor(session: unknown, name: string): {
                    handled: boolean;
                    claim?: Promise<void>;
                } | undefined;
            };
        } & {
            readonly assemblyNameMap: Record<string, import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
        } & {
            getCanonicalAssemblyName(asmName: string): string | undefined;
            getDisplayName(asmName: string): string;
            get(asmName: string): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            has(asmName: string): boolean;
            loadingAssembly(asmNames: string[]): (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined;
            readonly assemblyNamesList: string[];
            readonly assemblyList: (import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
                setSubschema(slotName: string, data: Record<string, unknown>): any;
                setSlot(slotName: string, value: unknown): void;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>)[];
            readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        } & {
            settleAssemblyResolution(assemblyName: string): Promise<void>;
        } & {
            waitForAssembly(assemblyName: string): Promise<(import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>) | undefined>;
            requireAssembly(assemblyName: string): Promise<import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }> & {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/mobx-state-tree").IModelType<{
                configuration: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>;
            }, {
                error: unknown;
                loadingP: Promise<void> | undefined;
                adapterLoads: import("@jbrowse/quick-lru").default<string, Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>>;
                volatileRegions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                refNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                canonicalToSeqAdapterRefNames: Record<string, string> | undefined;
                cytobands: import("@jbrowse/core/util").Feature[] | undefined;
                loadedGeneticCodes: Record<string, number> | undefined;
                lowerCaseRefNameAliases: import("@jbrowse/core/assemblyManager/assembly").RefNameAliases | undefined;
                statusMessage: string | undefined;
                statusProgress: number | undefined;
            } & {
                getConf(arg: string): any;
            } & {
                readonly name: string;
                readonly aliases: string[];
                readonly displayName: string;
                readonly refNameColors: string[];
            } & {
                readonly allAliases: string[];
                hasName(name: string): boolean;
            } & {
                setStatus(status?: import("@jbrowse/core/util").RpcStatus): void;
            } & {
                setLoaded({ regions, refNameAliases, lowerCaseRefNameAliases, canonicalToSeqAdapterRefNames, cytobands, geneticCodes }: import("@jbrowse/core/assemblyManager/assembly").RefNameMaps & {
                    regions: import("@jbrowse/core/util").Region[];
                    cytobands: import("@jbrowse/core/util").Feature[];
                    geneticCodes: Record<string, number>;
                }): void;
                setError(e: unknown): void;
                setLoadingP(p?: Promise<void>): void;
                loadPre(): Promise<void>;
            } & {
                load(): Promise<void>;
            } & {
                afterAttach(): void;
            } & {
                readonly initialized: boolean;
                readonly regions: import("@jbrowse/core/assemblyManager/assembly").BasicRegion[] | undefined;
                readonly allRefNames: string[] | undefined;
                readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
            } & {
                readonly refNames: string[] | undefined;
            } & {
                readonly refNameToIndex: Map<string, number> | undefined;
            } & {
                getCanonicalRefName(refName: string): string | undefined;
                getRefNameColor(refName: string): string | undefined;
                getGeneticCodeId(refName: string): number;
                getSeqAdapterRefName(canonicalRefName: string): string;
            } & {
                getCanonicalRefName2(refName: string): string;
                isValidRefName(refName: string): boolean;
            } & {
                getRefNameMapForAdapter(adapterConf: {
                    [x: string]: unknown;
                }, options: import("@jbrowse/core/data_adapters/BaseAdapter").BaseOptions): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>>;
            getRefNameMapForAdapter(adapterConf: {
                [x: string]: unknown;
            }, assemblyName: string | undefined, opts: import("@jbrowse/core/assemblyManager").AssemblyBaseOpts): Promise<import("@jbrowse/core/assemblyManager/assembly").RefNameAliases>;
            isValidRefName(refName: string, assemblyName: string): boolean;
        } & {
            afterAttach(): void;
            removeAssembly(asm: import("@jbrowse/core/assemblyManager/assembly").Assembly): void;
            addAssembly(configuration: any): void;
        }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>, [undefined]>;
    }, {
        rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
        adminMode: boolean;
        error: unknown;
        textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
        pluginManager: PluginManager;
    } & {
        setError(error: unknown): void;
        setSession(sessionSnapshot?: import("@jbrowse/mobx-state-tree").SnapshotIn<import("@jbrowse/mobx-state-tree").IAnyType>): void;
        setDefaultSession(): void;
        setSessionPath(path: string): void;
        renameCurrentSession(newName: string): void;
    }, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>>;
} & {
    readonly jbrowse: any;
    readonly rpcManager: import("@jbrowse/core/rpc/RpcManager").default;
    readonly configuration: import("@jbrowse/mobx-state-tree").ModelInstanceTypeProps<Record<string, any>> & {
        setSubschema(slotName: string, data: Record<string, unknown>): any;
        setSlot(slotName: string, value: unknown): void;
    } & import("@jbrowse/mobx-state-tree").IStateTreeNode<import("@jbrowse/core/configuration").AnyConfigurationSchemaType>;
    readonly adminMode: boolean;
    readonly textSearchManager: import("@jbrowse/core/TextSearch/TextSearchManager").default;
} & {
    readonly assemblies: import("@jbrowse/core/assemblyManager").BaseAssemblyConfigModel[];
    readonly DialogComponent: import("@jbrowse/core/util").DialogComponentType | undefined;
    readonly DialogProps: Record<string, unknown> | undefined;
} & {
    getPreferenceDefault(key: string): unknown;
    getPreference(key: string): unknown;
    getDisplayTypeDefault(displayType: string, slot: string): unknown;
    getPreferenceChanges(): import("@jbrowse/core/util").TrackConfigChange[];
} & {
    readonly animationMode: import("@jbrowse/core/util").AnimationMode;
    readonly scrollZoom: boolean;
    readonly canShowScrollZoomHint: boolean;
    readonly numberGrouping: boolean;
} & {
    afterAttach(): void;
    setSelection(thing: unknown): void;
    clearSelection(): void;
    setHovered(thing: unknown): void;
    setHighlightsVisible(arg: boolean): void;
    revealHighlights(): void;
    setPreferenceOverride(key: string, value: unknown): void;
    clearPreferenceOverrides(): void;
    clearPreferenceOverride(key: string): void;
    resetPreferenceChange(path: string[]): void;
    setScrollZoom(flag: boolean): void;
    setScrollZoomHintCount(n: number): void;
    setDisplayTypeDefault(displayType: string, slot: string, value: unknown): void;
    setName(str: string): void;
    setFocusedViewId(viewId: string): void;
    removeActiveDialog(): void;
    queueDialog(doneCallback: (doneCallback: () => void) => [import("@jbrowse/core/util").DialogComponentType, Record<string, unknown>]): void;
} & {
    snackbarMessages: import("mobx").IObservableArray<import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
    errorDialog: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined;
} & {
    readonly snackbarMessageSet: Map<string, import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage>;
} & {
    notify(message: string, level?: import("@jbrowse/core/util").NotificationLevel, action?: import("@jbrowse/core/util").SnackAction | import("@jbrowse/core/util").SnackAction[]): void;
    notifyError(errorMessage: string, error?: unknown, extra?: unknown, action?: import("@jbrowse/core/util").SnackAction): void;
    setErrorDialog(state: import("@jbrowse/core/ui/SnackbarModel").ErrorDialogState | undefined): void;
    pushSnackbarMessage(message: string, level?: import("@jbrowse/core/util").NotificationLevel, actions?: import("@jbrowse/core/util").SnackAction[]): void;
    popSnackbarMessage(): import("@jbrowse/core/ui/SnackbarModel").SnackbarMessage | undefined;
    removeSnackbarMessage(message: string): void;
} & {
    readonly visibleWidget: any;
} & {
    poppedOut: boolean;
} & {
    setDrawerPosition(arg: string): void;
    updateDrawerWidth(drawerWidth: number): number;
    resizeDrawer(distance: number): number;
    addWidget(typeName: string, id: string, initialState?: any, conf?: unknown): any;
    showWidget(widget: any): void;
    hideWidget(widget: any): void;
    minimizeWidgetDrawer(): void;
    showWidgetDrawer(): void;
    popoutWidget(): void;
    returnWidgetToDrawer(): void;
    hideAllWidgets(): void;
    editConfiguration(configuration: import("@jbrowse/core/configuration").AnyConfigurationModel | {
        trackId: string;
    }, opts?: {
        expandedDisplayId?: string;
    }): void;
    afterAttach(): void;
} & {
    /**
     * #getter
     * resolved workspaces flag (never undefined): this session's value, else
     * the user preference over the `configuration.preferences.useWorkspaces`
     * admin default. Every consumer reads this, not the raw property — only
     * sessions built from a snapshot or a spec `layout` set that, so the
     * admin default is what reaches the arrivals that bypass defaultSession.
     */
    readonly effectiveUseWorkspaces: boolean;
    /**
     * #getter
     * what `effectiveUseWorkspaces` becomes after `resetUseWorkspaces` — the
     * admin default, with both this session's own value and the user's
     * override out of the way. The Preferences reset diff needs this rather
     * than the override map, which can't see a session-scoped value (a spec
     * `layout`, a "move view to a tab") and so reported nothing to reset.
     */
    readonly defaultUseWorkspaces: boolean;
} & {
    /**
     * #action
     */
    moveViewDown(id: string, scopeIds?: string[]): void;
    /**
     * #action
     */
    moveViewUp(id: string, scopeIds?: string[]): void;
    /**
     * #action
     */
    moveViewToTop(id: string, scopeIds?: string[]): void;
    /**
     * #action
     */
    moveViewToBottom(id: string, scopeIds?: string[]): void;
    /**
     * #action
     * Put the named views into the given relative order, leaving views not
     * named in their own slots.
     *
     * `session.views` is the one ordering, so this is how a channel that
     * states an order in some other vocabulary gets it applied: a session
     * spec's `layout` names views per panel, top to bottom, and that used to
     * be honoured by the panel assignment array's order. Now the assignment
     * carries membership only, so the layout says it here instead, once.
     */
    orderViews(ids: string[]): void;
    /**
     * #action
     */
    addView(typeName: string, initialState?: any): any;
    /**
     * #action
     * swap `view` for a new view of `typeName`, in the slot it occupied.
     *
     * The launchers that build a view out of one you are already looking at
     * — collapse introns, launch synteny view — otherwise append, leaving
     * the source view above the thing it produced and a stack of two views
     * showing the same locus. This is the "replace" half of that offer, and
     * a slot swap rather than remove-then-add so the new view lands where
     * the reader was looking instead of at the bottom of the session.
     *
     * The slot is `session.views`, which is the order views render in under
     * both layout modes (a panel assignment says which panel a view is in,
     * not where in it), so the swap lands in place either way.
     *
     * WHICH panel is a separate question and this does not answer it: the
     * new view arrives unassigned and dockview's reconcile homes it to the
     * active panel, the same panel only when the replaced view was in the
     * active one. In practice it is, since clicking into a view activates
     * its panel, and the launch that offers a replace is a click on that
     * view's own menu.
     */
    replaceView(view: IBaseViewModel, typeName: string, initialState?: any): any;
    /**
     * #action
     */
    removeView(view: IBaseViewModel): void;
    /**
     * #action
     */
    setStickyViewHeaders(sticky: boolean): void;
    /**
     * #action
     * set the workspaces layout for this session only, leaving the user's
     * personal default untouched. For session-scoped intent — a spec
     * carrying a `layout`, or an ad-hoc "move view to a tab/split" — where
     * rewriting the visitor's global preference would be a surprise. The
     * user-facing default toggle is `setUseWorkspacesPreference`.
     */
    setUseWorkspaces(useWorkspaces: boolean): void;
    /**
     * #action
     * the user-facing workspaces toggle: applies to this session and
     * becomes their default for sessions that don't specify one. Persisted
     * only here, on an explicit toggle — an autorun mirroring the resolved
     * value would bake the admin default into every visitor's localStorage
     * on first load, so a later admin change could never reach them.
     */
    setUseWorkspacesPreference(useWorkspaces: boolean): void;
    /**
     * #action
     * drop both this session's explicit value and the user's override so
     * workspaces falls back to the admin default
     */
    resetUseWorkspaces(): void;
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree").ModelSnapshotType<Omit<Omit<Omit<{
    id: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("@jbrowse/mobx-state-tree").ISimpleType<string>;
    margin: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    focusedViewId: import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<string>>;
    highlightsVisible: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, never>, "activeWidgets" | "drawerPosition" | "drawerWidth" | "minimized" | "widgets"> & {
    drawerPosition: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<string>, [undefined]>;
    drawerWidth: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<number>, [undefined]>;
    widgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IAnyType>, [undefined]>;
    activeWidgets: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMapType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").IReferenceType<import("@jbrowse/mobx-state-tree").IAnyType>>>, [undefined]>;
    minimized: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
}, "stickyViewHeaders" | "useWorkspaces" | "views"> & {
    /**
     * #property
     */
    views: import("@jbrowse/mobx-state-tree").IArrayType<import("@jbrowse/mobx-state-tree").IAnyType>;
    /**
     * #property
     */
    stickyViewHeaders: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    /**
     * #property
     * enables the dockview-based tabbed/tiled workspace layout for this
     * session. Undefined means unspecified — read `effectiveUseWorkspaces`.
     */
    useWorkspaces: import("@jbrowse/mobx-state-tree").IOptionalIType<import("@jbrowse/mobx-state-tree").IMaybe<import("@jbrowse/mobx-state-tree").ISimpleType<boolean>>, [undefined]>;
}>>;
/** Session mixin MST type for a session that manages multiple views */
export type SessionWithMultipleViewsType = ReturnType<typeof MultipleViewsSessionMixin>;
/** Instance of a session with multiple views */
export type SessionWithMultipleViews = Instance<SessionWithMultipleViewsType>;
/** Type guard for SessionWithMultipleViews */
export declare function isSessionWithMultipleViews(session: IAnyStateTreeNode): session is SessionWithMultipleViews;
