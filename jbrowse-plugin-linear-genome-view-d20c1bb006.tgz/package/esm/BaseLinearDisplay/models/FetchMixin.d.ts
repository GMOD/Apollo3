import type { RpcStatus } from '@jbrowse/core/util';
import type { StopToken } from '@jbrowse/core/util/stopToken';
export interface FetchContext {
    stopToken: StopToken;
    isStale: () => boolean;
}
/**
 * #stateModel FetchMixin
 * #category display
 *
 * Cancel-safe fetch lifecycle for any display that loads data over RPC. Owns
 * the entire fetch state machine (stop-token rotation, staleness tracking,
 * error capture, status reporting); consumers see only `runFetch`,
 * `cancelFetch`, `isLoading`, `error`, `statusMessage`, and `fetchGeneration`.
 */
export default function FetchMixin(): import("@jbrowse/mobx-state-tree").IModelType<{}, {
    /**
     * #volatile
     * stop token of the in-flight fetch, or undefined when idle
     */
    activeStopToken: StopToken | undefined;
    /**
     * #volatile
     * bumps at every fetch end; autoruns read it to re-evaluate, and it
     * doubles as the staleness epoch inside runFetch
     */
    fetchGeneration: number;
    /**
     * #volatile
     * last non-abort fetch error, or undefined
     */
    error: unknown;
    /**
     * #volatile
     * work-in-progress status string
     */
    statusMessage: string | undefined;
    /**
     * #volatile
     * determinate progress fraction [0,1] for the current status, or
     * undefined when the in-flight phase is indeterminate
     */
    statusProgress: number | undefined;
    /**
     * #volatile
     * true after the user explicitly cancels a load (the loading overlay's
     * cancel button → `cancelFetchByUser`). A durable, blocking state — unlike
     * `cancelFetch`, it does not retrigger the fetch autoruns — so the load
     * stays stopped until the user retries (`reload`) or the viewport changes.
     * Any new fetch clears it (`runFetch` resets it at the start).
     */
    fetchCanceled: boolean;
    /**
     * #volatile
     * latest status of each concurrent in-flight operation, keyed by an
     * arbitrary id (the canvas display uses displayedRegionIndex). Plain
     * bookkeeping — not read reactively; setRegionStatus derives the
     * observable statusMessage/statusProgress from it on every update so N
     * parallel region fetches aggregate into one bar instead of clobbering.
     */
    regionStatuses: Map<number, RpcStatus>;
} & {
    /**
     * #getter
     * true while a fetch is active
     */
    readonly isLoading: boolean;
} & {
    /**
     * #getter
     * `isLoading` widened to cover a user-canceled load. **This, not
     * `isLoading`, is what a `displayPhase` loading term wants.**
     * `cancelFetchByUser` clears the stop token synchronously, so `isLoading`
     * goes false the instant the user clicks Cancel — and the loading overlay
     * that unmounts on it is carrying the Retry button, which is the only way
     * back: the state is deliberately durable, so no autorun restarts the
     * fetch on its own. A bare `isLoading` therefore reads as `ready` over a
     * display that is stopped, empty and offering nothing.
     *
     * Arc read `isLoading` directly and had exactly that hole. It is a getter
     * here so no family has to remember the second term.
     */
    readonly isLoadingOrCanceled: boolean;
    /**
     * #getter
     * Overridable hook (default false): a subclass returns true when its body
     * is deliberately showing a static message instead of data, so the loading
     * scrim must not cover it. Sequence sets it past base resolution ("Zoom in
     * to see sequence"); LD sets it with the triangle toggled off.
     *
     * A hook rather than a `displayPhase` override, because overriding the
     * getter means restating the whole loading condition — which is how
     * sequence came to hold a verbatim copy of the other terms, one `git blame`
     * away from silently missing the next one added.
     *
     * It lives **here** because this is the one mixin all three display
     * foundations compose. On `MultiRegionDisplayMixin` it was reachable by
     * one of the three, so the global family hard-coded `false` and LD could
     * express only the half `rendersCanvas` reaches — which drops the
     * pre-first-paint term alone and leaves the scrim free to park over the
     * placeholder on the durable cancel term. Same argument, one level down,
     * that put `rendersCanvas` on `RenderLifecycleMixin` beside `canvasDrawn`.
     */
    readonly loadingSuppressed: boolean;
} & {
    /**
     * #action
     */
    setError(error?: unknown): void;
    /**
     * #action
     * Unthrottled: a display writing a phase label by hand must see every
     * write land. The high-frequency RPC stream is thinned one level up, in
     * the callback factories.
     */
    setStatusMessage(status?: RpcStatus): void;
    /**
     * #action
     * Run `apply` only if the throttle window has elapsed.
     */
    throttleStatus(apply: () => void): void;
    /**
     * #action
     * Drop the active stop token and clear all status bookkeeping. Shared by
     * both cancel paths and runFetch's cleanup.
     */
    resetStatus(): void;
} & {
    /**
     * #action
     * Abort the in-flight fetch (if any) and clear its status. The shared
     * preamble of both cancel paths; the difference between them is only what
     * they do to `fetchCanceled` / `fetchGeneration` afterward.
     */
    stopActiveFetch(): void;
} & {
    /**
     * #action
     * Record one concurrent operation's latest status (keyed) and recompute
     * the shared statusMessage/statusProgress as the aggregate across all
     * in-flight keys. Pass undefined to drop a key. Used by displays that fan
     * a single fetch out into parallel per-region RPCs.
     */
    setRegionStatus(key: number, status?: RpcStatus): void;
    /**
     * #action
     * cancel any in-flight fetch and bump fetchGeneration (always bumps, so
     * callers can retrigger fetch autoruns even when nothing was in flight).
     * This is the *internal* reset `clearAllRpcData` runs — it clears any
     * user-cancel flag so the retrigger actually re-fetches.
     */
    cancelFetch(): void;
    /**
     * #action
     * User-initiated cancel from the loading overlay. Stops the in-flight
     * fetch and lands in a durable `fetchCanceled` state. Unlike
     * `cancelFetch`, it does NOT bump fetchGeneration — so the fetch autoruns
     * don't immediately restart the load. The user retries via `reload`
     * (the overlay's retry button), or it clears on the next viewport change.
     */
    cancelFetchByUser(): void;
    /**
     * #action
     * Release an in-flight fetch's stop token on teardown. Without this, a
     * display destroyed mid-fetch (track/view closed while loading) never
     * signals the worker to abort the now-useless work, and its in-flight HTTP
     * reads keep downloading. MST auto-chains lifecycle hooks, so a composing
     * display can still define its own beforeDestroy.
     */
    beforeDestroy(): void;
    /**
     * #action
     * Run a cancel-safe fetch (cancels any prior). The work callback gets a
     * FetchContext with a stopToken to forward to the RPC and an isStale()
     * check to short-circuit commits once the user has moved on. Abort
     * errors are swallowed; others are stored in `error` if not stale.
     */
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    /**
     * #method
     * An RPC `statusCallback` bound to this display: forwards progress to the
     * shared `statusMessage`, guarded by `isAlive` so a callback that fires
     * after the node is torn down (RPCs resolve their status stream
     * asynchronously) is a safe no-op. Pass directly as the `statusCallback`
     * RPC arg instead of re-inlining the guard at every call site.
     */
    makeStatusCallback(): (status: RpcStatus) => void;
    /**
     * #method
     * Per-region variant of `makeStatusCallback`: routes progress through
     * `setRegionStatus(key, …)` so N concurrent per-region fetches aggregate
     * into one status bar instead of clobbering each other. Same `isAlive`
     * guard; `setRegionStatus` owns the throttling (it has to thin only the
     * bar write, not the per-region bookkeeping).
     */
    makeRegionStatusCallback(key: number): (status: RpcStatus) => void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type FetchMixinType = ReturnType<typeof FetchMixin>;
