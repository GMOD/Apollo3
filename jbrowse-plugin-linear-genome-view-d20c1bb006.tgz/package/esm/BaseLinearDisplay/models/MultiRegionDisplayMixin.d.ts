import type { LinearGenomeViewModel } from '../../LinearGenomeView/model.ts';
import type { FetchContext } from './FetchMixin.ts';
import type { Region } from '@jbrowse/core/util';
import type { IAnyStateTreeNode } from '@jbrowse/mobx-state-tree';
import type { DisplayPhase } from '@jbrowse/render-core/displayPhase';
import type { IAutorunOptions } from 'mobx';
export type { FetchContext } from './FetchMixin.ts';
/**
 * True when the loaded region fully contains the visible `block`: same refName
 * and the integer-rounded block bounds lie within the loaded extent.
 * `Math.floor`/`Math.ceil` handle fractional bpPerPx where block edges fall on
 * non-integer genomic positions. Single source of truth for "is this block
 * already fetched" — shared by the FetchVisibleRegions autorun (deciding what to
 * refetch) and the `viewportWithinLoadedData` getter (deciding whether the on-screen data
 * is stale).
 */
export declare function isBlockCovered(loaded: Region | undefined, block: {
    refName: string;
    start: number;
    end: number;
}): boolean;
/**
 * #stateModel MultiRegionDisplayMixin
 * #displayFoundationDef Per-region fetch + render: the fetch autoruns, `rpcProps()` refetch wiring, and byte gating. The common case.
 * #category display
 *
 * Per-region fetch lifecycle for LGV-based GPU displays. Installs five autoruns
 * in `afterAttach` and exposes overridable hooks (`fetchNeeded`, `rpcProps`,
 * `isCacheValid`, `measuresBytesPreFlight`, `clearDisplaySpecificData`) plus the
 * `fetchRegions` / `loadedRegions` machinery.
 */
export default function MultiRegionDisplayMixin(): import("@jbrowse/mobx-state-tree").IModelType<Omit<Omit<Omit<{}, never>, never>, never>, {
    forceLoadTrack: boolean;
    byteEstimate: import("../../index.ts").ByteEstimate | undefined;
    gateMeasuredViewportKey: string | undefined;
} & {
    readonly measuresBytesInFetch: boolean;
    readonly measuresBytesPreFlight: boolean;
    readonly densityGateEnabled: boolean;
    readonly byteGateAdapterConfig: Record<string, unknown>;
    readonly configuredFetchSizeLimit: number;
    readonly densityTooLarge: boolean;
    readonly adapterFetchSizeLimit: number | undefined;
    readonly configForceLoad: boolean;
    readonly gateViewport: import("../../index.ts").GateViewport | undefined;
} & {
    readonly gateEnabled: boolean;
    readonly byteGateAdapterKey: string;
    readonly aboveForceLoadFloor: boolean;
    readonly gateExempt: boolean;
    readonly estimatedFetchBytes: number | undefined;
    readonly gateMeasurementStale: boolean;
} & {
    readonly gateByteLimit: number;
    readonly gateActive: boolean;
} & {
    readonly densityGateActive: boolean;
    resolvedByteLimit(): number | undefined;
} & {
    readonly tooLargeStatus: import("../../index.ts").RegionTooLargeStatus;
} & {
    readonly regionTooLarge: boolean;
    readonly regionTooLargeReason: string;
    readonly zoomCanReleaseGate: boolean;
} & {
    setByteEstimate(measurement: {
        bytes: number | undefined;
        viewport: import("../../index.ts").GateViewport;
    }): void;
    setGateMeasuredViewport(viewport: import("../../index.ts").GateViewport): void;
    clearByteEstimate(): void;
    setForceLoadTrack(flag: boolean): void;
    reload(): void;
} & {
    forceLoad(): void;
    byteGateBlocksFetch(regions: {
        refName: string;
        start: number;
        end: number;
        assemblyName: string;
    }[], ctx: {
        isStale: () => boolean;
    }): Promise<boolean>;
} & {
    afterAttach(): void;
} & {
    canvasDrawn: boolean;
    currentRenderingBackend: unknown;
    renderTick: number;
    autorunsInstalled: boolean;
    renderError: unknown;
} & {
    readonly canRender: boolean;
    readonly rendersCanvas: boolean;
    readonly paintInert: boolean;
} & {
    readonly painted: boolean;
} & {
    markCanvasDrawn(): void;
    resetCanvasDrawn(): void;
    stopRenderingBackend(): void;
    renderNow(): void;
    setRenderError(error: unknown): void;
} & {
    attachRenderingBackend<B>(backend: B, cbs: import("@jbrowse/render-core/RenderLifecycleMixin").RenderingBackendCallbacks<B>): void;
} & {
    activeStopToken: import("@jbrowse/core/util").StopToken | undefined;
    fetchGeneration: number;
    error: unknown;
    statusMessage: string | undefined;
    statusProgress: number | undefined;
    fetchCanceled: boolean;
    regionStatuses: Map<number, import("@jbrowse/core/util").RpcStatus>;
} & {
    readonly isLoading: boolean;
} & {
    readonly isLoadingOrCanceled: boolean;
    readonly loadingSuppressed: boolean;
} & {
    setError(error?: unknown): void;
    setStatusMessage(status?: import("@jbrowse/core/util").RpcStatus): void;
    throttleStatus(apply: () => void): void;
    resetStatus(): void;
} & {
    stopActiveFetch(): void;
} & {
    setRegionStatus(key: number, status?: import("@jbrowse/core/util").RpcStatus): void;
    cancelFetch(): void;
    cancelFetchByUser(): void;
    beforeDestroy(): void;
    runFetch: (work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
} & {
    makeStatusCallback(): (status: import("@jbrowse/core/util").RpcStatus) => void;
    makeRegionStatusCallback(key: number): (status: import("@jbrowse/core/util").RpcStatus) => void;
} & {
    /**
     * #volatile
     * regions whose data has been fetched and committed, keyed by
     * displayedRegionIndex; populated only after the fetch work callback
     * returns
     */
    loadedRegions: import("mobx").ObservableMap<number, Region>;
} & {
    /**
     * #getter
     * The containing LinearGenomeView, typed once for every display in this
     * family so no consumer repeats the `getContainingView` cast — the cast
     * `getContainingView` needs (it is view-type-agnostic) but which this
     * mixin has already committed to, since everything below reads
     * `visibleRegions` / `bufferedVisibleRegions` / `bpPerPx` off it.
     *
     * Three displays had each invented this getter under two names before it
     * was hoisted (`view` on HiC and Manhattan, `lgv` on MAF) while ~35 other
     * sites repeated the cast inline. `lgv` rather than `view` because a
     * display's containing view is not always an LGV — the comparative
     * displays' `view` is a synteny or dotplot view — so the name says which
     * one this is.
     *
     * Components and structural helpers keep calling `getContainingView`:
     * they take duck-typed model shapes that deliberately don't carry the
     * whole MST instance type, so there is no `lgv` on them to read.
     */
    readonly lgv: LinearGenomeViewModel;
    /**
     * #getter
     * The CSS width of this display's on-screen canvas, in px — and the
     * `canvasWidth` its `renderState` must carry, since the two have to
     * agree or the bp→px mapping is scaled against a box it doesn't fill.
     *
     * `trackWidthPx`, **not** `view.width`: `TrackRenderingContainer` insets
     * the rendering component by the 2px track outline and applies
     * `contain: strict`, so a `view.width`-wide canvas overhangs its own
     * container and the browser clips the overhang away. It renders almost
     * identically, which is why this drifted — MAF sized itself off
     * `view.width` until 2026-08 and nothing caught it.
     *
     * It is a getter rather than a note on each display because the choice
     * was being made by copying whichever neighbour the author read first,
     * out of four plausible view getters: `width` (the viewport),
     * `trackWidthPx` (this one), and `totalWidthPx` /
     * `totalWidthPxWithoutBorders` (the *content* width, which the global
     * family's heatmaps legitimately want and which is a different question,
     * not a different answer to this one).
     *
     * SVG export is the one place it does not apply: the export shell has no
     * track outline, so `renderSvg` overrides `canvasWidth` with the shell's
     * own width (see `LgvSvgBodyProps`).
     */
    readonly canvasWidthPx: number;
    /**
     * #getter
     * The render-lifecycle precondition for every LGV display (overrides
     * `RenderLifecycleMixin`'s default-true hook): don't run the upload/render
     * callbacks until the view is measured. Before that, `renderBlocks` →
     * `visibleRegions` → `view.width` throws by design, and the render
     * autorun's catch would show that as a GPU render-error banner. Gating here
     * — once, for all of them — is what lets a display's `renderState` be a
     * plain resolved getter and its render callback gate only on its own data.
     * The render-lifecycle twin of `autorunOnReadyView`.
     */
    readonly canRender: boolean;
    /**
     * #getter
     * true when every visible block lies within an already-fetched region —
     * i.e. the viewport shows data we actually loaded, not the stale fringe
     * left after a zoom-out/pan. Drives the loading overlay through the
     * pre-refetch debounce. Spatial only; see CLAUDE.md for why this is exact
     * and for the resolution-staleness gap.
     */
    readonly viewportWithinLoadedData: boolean;
    /**
     * #getter
     * Overridable hook (default false): a subclass returns true to mark an
     * extra terminal state where off-screen export can proceed with no loaded
     * data. Sequence sets it when zoomed past base resolution — it renders a
     * static "zoom in" message and fetches nothing, so `svgReady` would
     * otherwise never resolve.
     */
    readonly svgReadyExtraTerminal: boolean;
    /**
     * #getter
     * Fills `RenderLifecycleMixin`'s `paintInert` hook — see there for why a
     * failed fetch has to read as finished to the consumers outside the
     * display. The global family declares the identical override.
     */
    readonly paintInert: boolean;
    /**
     * #getter
     * Overridable hook (default false): whether a searchable feature layout
     * currently exists. Any display defining a feature-lookup method
     * (`searchFeatureByID`, `getFeatureById`) must override it, so callers can
     * tell "laid out, but off-display" from "no layout exists yet" — a
     * distinction only the display can make. See
     * plugins/linear-genome-view/src/BaseLinearDisplay/CLAUDE.md §"The two
     * readiness axes".
     */
    readonly layoutReady: boolean;
    /**
     * #getter
     * Shared cached view for every LGV-based GPU display. A single
     * displayedRegion may produce multiple render blocks (shared GPU
     * buffer, different scissor clips on screen). Plugins that want to
     * suppress rendering in certain states (e.g. no domain yet) can
     * override this getter to return [] — the autorun lifecycle will
     * then issue an empty-blocks render that clears the canvas.
     */
    readonly renderBlocks: import("@jbrowse/render-core/renderBlock").RenderBlock[];
} & {
    /**
     * #getter
     * This family's answer to the shared freshness question every display
     * foundation must answer (`dataCurrent`): the held data corresponds to
     * what is on screen right now. Here that is spatial — every visible block
     * lies within a fetched region — plus `loadedRegions.size`, which rules
     * out the vacuously-true empty viewport. Regions stream in one at a time,
     * so this (not "the first datum arrived") is what keeps a
     * multi-region/whole-genome export complete.
     *
     * Distinct from `viewportWithinLoadedData`, which is the raw coverage
     * predicate the fetch autorun and the loading overlay use.
     */
    readonly dataCurrent: boolean;
} & {
    /**
     * #getter
     * true once an off-screen (SVG) export can safely read this display's
     * data. Policy single-sourced in `computeSvgReady`; this family supplies
     * only its `dataCurrent` predicate. Off-screen renderers gate on it via
     * `awaitSvgReady(model)` instead of inlining the condition.
     */
    readonly svgReady: boolean;
    /**
     * #getter
     * The display's mutually-exclusive visual state, mapped in
     * `foundationDisplayPhase` — every foundation calls it and supplies only
     * its staleness argument, so a term added to `computeLoadingTerm`
     * reaches all three without being wired three times.
     *
     * This family's argument is spatial: `loading` also covers stale data
     * (viewport past loaded) still on screen through the pre-refetch
     * debounce. A thunk, so a suppressed or already-loading display doesn't
     * subscribe to viewport churn.
     *
     * A subclass customizes this through `loadingSuppressed` (FetchMixin),
     * never by overriding the getter — see that hook.
     */
    readonly displayPhase: DisplayPhase;
    /**
     * #getter
     * The RPC cache key watched by `SettingsInvalidate` — the subclass's
     * `rpcProps()` payload serialized to a string. `serializeRpcProps` owns
     * the why; `installGlobalFetchAutorun` keys its global-family counterpart
     * on the same function, so the two families invalidate on the same axis.
     */
    readonly rpcPropsCacheKey: string;
} & {
    /**
     * #action
     * Action wrapper so callers after async boundaries stay in MST strict
     * mode.
     */
    setLoadedRegion(displayedRegionIndex: number, region: Region): void;
    /**
     * #action
     * no-op base — subclasses override to clear rpcDataMap etc.
     */
    clearDisplaySpecificData(): void;
} & {
    /**
     * #action
     * full reset: cancels fetch, clears error, loadedRegions,
     * display-specific data, and the canvas-drawn flag. The too-large gate is
     * derived (a pure function of the cached estimate × viewport), so it needs
     * no explicit clear here — the fetch autorun re-measures at the new
     * viewport and the verdict follows.
     */
    clearAllRpcData(): void;
    /**
     * #action
     * Default reload: full reset. Subclasses with extra teardown can
     * override (and chain to `clearAllRpcData` directly if needed).
     */
    reload(): void;
} & {
    /**
     * #action
     * Overridable hook (no-op base): override to call
     * `this.fetchRegions(needed, async ctx => { ... })`.
     */
    fetchNeeded(_needed: {
        region: Region;
        displayedRegionIndex: number;
    }[]): void;
    /**
     * #action
     * Overridable hook (no-op base): called when `regionTooLarge` transitions
     * to true. Displays with transient hover/tooltip state override it to clear
     * that state — the too-large banner replaces the rendered content, so a
     * lingering hover would otherwise pin to a now-hidden feature. Wired to the
     * `ClearHoverOnRegionTooLarge` autorun, fired by the derived too-large gate.
     */
    onRegionTooLarge(): void;
} & {
    /**
     * #method
     * Overridable hook: return `false` to force re-fetch at the current
     * zoom (wiggle uses this for zoom-level changes).
     */
    isCacheValid(_displayedRegionIndex: number): boolean;
} & {
    /**
     * #action
     * Run a per-region fetch with byte-estimate gating. Marks regions as
     * loaded only AFTER the work callback has populated display-specific
     * data (rpcDataMap, cellData, etc) so the GPU upload autorun sees
     * committed data when it observes loadedRegions.
     */
    fetchRegions(needed: {
        region: Region;
        displayedRegionIndex: number;
    }[], work: (ctx: FetchContext) => Promise<void>): Promise<void>;
} & {
    /**
     * #action
     * installs the five fetch-lifecycle autoruns (DisplayedRegionsChange,
     * FetchVisibleRegions, SettingsInvalidate, ClearBlockingStateOnViewportChange,
     * ClearHoverOnRegionTooLarge)
     */
    afterAttach(): void;
}, import("@jbrowse/mobx-state-tree")._NotCustomized, import("@jbrowse/mobx-state-tree")._NotCustomized>;
export type MultiRegionDisplayMixinType = ReturnType<typeof MultiRegionDisplayMixin>;
export declare function autorunOnReadyView(self: IAnyStateTreeNode, fn: (view: LinearGenomeViewModel) => void, opts?: IAutorunOptions): void;
/**
 * Dev-only feedback-loop guard for the (undelayed) `SettingsInvalidate` autorun.
 * The classic `rpcProps()` trap (ARCHITECTURE.md §"rpcProps() loop trap") puts a
 * fetch-derived value in `rpcProps()`, so the autorun that reads it and clears
 * fetched data re-invalidates itself — MobX runs it until its 100-iteration
 * convergence guard throws a cryptic "Reaction doesn't converge". Call this at
 * the top of the body's mutating section: it throws a message naming the actual
 * cause the first time the body re-fires far more times in one synchronous tick
 * than any real settings change could, and — because it throws *before* the
 * `clearAllRpcData()` that perpetuates the cycle — that iteration's invalidating
 * mutation never runs, breaking the loop. No-op in production. (The debounced
 * `installGlobalFetchAutorun` variant loops on the async-fetch cadence, not
 * synchronously, so this within-tick counter does not catch it — that hazard is
 * documented at the call site instead.)
 */
export declare function makeSettingsLoopGuard(name: string): () => void;
interface FetchEachRegionModel {
    fetchRegions: (needed: {
        region: Region;
        displayedRegionIndex: number;
    }[], work: (ctx: FetchContext) => Promise<void>) => Promise<void>;
}
/**
 * The per-region fan-out on its own, without the `fetchRegions` wrapper: issue
 * `call` for every needed region in parallel and return the results paired with
 * their `displayedRegionIndex`, in `needed` order. Callers get one collected
 * array to commit from, which is what a cross-region decision needs (MAF picks
 * the sample set from whichever region actually discovered samples).
 *
 * Use this only inside a `fetchRegions` work callback you already own — it does
 * no staleness checking of its own, because the *caller* decides the
 * granularity: {@link fetchEachRegion} guards per region so an early result
 * still commits, while a display that commits atomically guards once around the
 * whole batch. Prefer `fetchEachRegion` unless you need the collected array or
 * a concurrent side-fetch under the same stop token.
 */
export declare function callEachRegion<R>(needed: {
    region: Region;
    displayedRegionIndex: number;
}[], ctx: FetchContext, call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>): Promise<{
    displayedRegionIndex: number;
    result: R;
}[]>;
/**
 * Run one RPC `call` per needed region, in parallel, under a single
 * stale-guarded `fetchRegions` wrapper. Centralizes the fan-out plus the two
 * `ctx.isStale()` guards every per-region display repeated by hand: skip a
 * region's commit, and skip the post-fetch step, once the user has moved on.
 * Forgetting either guard is a stale-data write, so this is a correctness
 * primitive as much as a dedup.
 *
 * `call` keeps the literal RPC method name at the call site, so its typed args
 * (`RpcCallArgs<M>`) and return (`RpcCallReturn<M>`) survive — `R` is inferred
 * from `call` and flows into `onResult` with no cast. The helper owns the
 * control flow; the display still owns its typed payload (and the structural
 * args + `statusCallback: self.makeRegionStatusCallback(displayedRegionIndex)`
 * it injects there — the index is the third `call` argument, so the parallel
 * per-region fetches aggregate into one bar instead of clobbering each other).
 * A display whose fetch genuinely diverges — canvas (prune + fold a too-large
 * result), MAF (a concurrent annotation fetch + a cross-region sample pick),
 * alignments (chain payload) — keeps its own `fetchNeeded`, calls `fetchRegions`
 * directly, and reaches for {@link callEachRegion} for the fan-out.
 */
export declare function fetchEachRegion<R>(self: FetchEachRegionModel, needed: {
    region: Region;
    displayedRegionIndex: number;
}[], opts: {
    call: (region: Region, ctx: FetchContext, displayedRegionIndex: number) => Promise<R>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
/**
 * Batched counterpart to {@link fetchEachRegion}: hands every needed region to
 * a single RPC `call`, which returns one result per region aligned to the input
 * order (`results[i]` ↔ `needed[i]`). Use when the adapter serves all regions in
 * one pass more efficiently than N independent calls — e.g. BigWig coalesces
 * adjacent on-disk blocks across region boundaries (`getFeaturesAsArraysMulti`),
 * which the per-region fan-out can't exploit; collapsed-intron views (many small
 * regions on one refName) benefit most. The single `ctx.isStale()` guard is the
 * same correctness primitive as the per-region helper — a moved-on viewport
 * skips both the commit and the post-fetch step. `call` keeps the literal RPC
 * method name at the call site so its typed args/return survive and `R` flows
 * into `onResult` with no cast.
 */
export declare function fetchAllRegions<R>(self: FetchEachRegionModel, needed: {
    region: Region;
    displayedRegionIndex: number;
}[], opts: {
    call: (regions: Region[], ctx: FetchContext) => Promise<R[]>;
    onResult: (displayedRegionIndex: number, result: R) => void;
    onComplete?: () => void;
}): Promise<void>;
export declare function onDisplayedRegionsChange(self: IAnyStateTreeNode, clear: () => void, name?: string): void;
