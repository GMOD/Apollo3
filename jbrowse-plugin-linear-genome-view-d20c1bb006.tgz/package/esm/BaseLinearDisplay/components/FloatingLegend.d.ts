import type { LegendItem, LegendSection } from '@jbrowse/core/ui';
export type { LegendItem, LegendMark, LegendSection, LegendSpec, LegendSwatch, } from '@jbrowse/core/ui';
declare const FloatingLegend: ({ items, sections, title, onDismiss, onDismissSection, maxItems, maxWidth, top, }: {
    items?: LegendItem[];
    sections?: LegendSection[];
    title?: string;
    onDismiss?: () => void;
    onDismissSection?: (id: string) => void;
    maxItems?: number;
    maxWidth?: number;
    top?: number;
}) => import("react").JSX.Element | null;
export default FloatingLegend;
