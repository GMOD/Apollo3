import type { TrackControlProps } from './types.ts';
export default function MuiTrackControl({ icon, tooltip, label, options, onClick, onDelete, warning, }: TrackControlProps): import("react").JSX.Element;
