import type { TrackControlComponent, TrackControlProps } from './types.ts';
export declare const TrackControlProvider: import("react").Provider<TrackControlComponent | undefined>;
/**
 * What every display renders for a bottom-right control: JBrowse's own Material
 * UI look, unless a `TrackControlProvider` above it says otherwise.
 *
 * Not an `observer` — it reads no observables, it only picks an implementation
 * and forwards. Callers that read model state build their props in their own
 * observer, the way `DisplayChrome` leaves observation to the components around
 * it.
 */
export default function TrackControl(props: TrackControlProps): import("react").JSX.Element;
