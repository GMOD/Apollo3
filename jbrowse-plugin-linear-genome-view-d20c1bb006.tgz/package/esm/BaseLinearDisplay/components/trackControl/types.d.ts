import type { ComponentType } from 'react';
/**
 * Icons are *named* rather than passed in as elements, which is the whole
 * mechanism: an element would have to come from somewhere, and every call site
 * would end up importing `@mui/icons-material` whatever the renderer was. A name
 * lets each implementation draw it its own way.
 *
 * A closed set on purpose — a display wanting a new one adds it here and to both
 * implementations, which is the moment to check the plain set still has an
 * answer.
 */
export type TrackControlIcon = 'height' | 'isoform' | 'filter';
/** One row of the control's menu. Rendered as a radio group. */
export interface TrackControlOption {
    label: string;
    selected: boolean;
    onSelect: () => void;
}
export interface TrackControlProps {
    icon: TrackControlIcon;
    /**
     * Always required: it is the only place the control explains itself, and
     * these controls are deliberately small and wordless.
     */
    tooltip: string;
    /**
     * Present: a text chip, for a state the user should notice without looking
     * (the isoform notice, the show-only count). Absent: a quiet icon button, for
     * a control that is always there and should not shout.
     */
    label?: string;
    /** Pressing opens these as a radio list. Mutually exclusive with `onClick`. */
    options?: TrackControlOption[];
    /** Pressing does this. Mutually exclusive with `options`. */
    onClick?: () => void;
    /** Adds a (×). What it means is the caller's business — dismiss, clear, undo. */
    onDelete?: () => void;
    /**
     * Something is wrong and a tooltip nobody opens is not a disclosure — today
     * this is features the layout dropped outright. Renders in an alert tone
     * rather than the quiet default.
     */
    warning?: boolean;
}
export type TrackControlComponent = ComponentType<TrackControlProps>;
