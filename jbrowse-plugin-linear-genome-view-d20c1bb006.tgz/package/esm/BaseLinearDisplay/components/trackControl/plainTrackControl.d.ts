import type { TrackControlProps } from './types.ts';
export default function PlainTrackControl({ icon, tooltip, label, options, onClick, onDelete, warning, }: TrackControlProps): import("react").JSX.Element;
