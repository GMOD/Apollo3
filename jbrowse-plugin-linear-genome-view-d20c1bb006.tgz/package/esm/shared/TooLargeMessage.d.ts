export interface TooLargeMessageModel {
    regionTooLargeReason: string;
    zoomCanReleaseGate: boolean;
    forceLoad: () => void;
}
declare const TooLargeMessage: ({ model, }: {
    model: TooLargeMessageModel;
}) => import("react").JSX.Element;
export default TooLargeMessage;
