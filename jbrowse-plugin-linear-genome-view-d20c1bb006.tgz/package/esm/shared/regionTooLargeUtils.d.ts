/**
 * The span below which the **density** axis stops gating: at this zoom a canvas
 * display is drawing few enough glyphs that a banner asking permission costs the
 * user more than the draw does. Lives with the gate rather than on the view
 * because the view never reads it — `aboveForceLoadFloor` on
 * `RegionTooLargeMixin` is the only comparison against it, and MAF's summary
 * swap reads that getter, so the threshold has one spelling.
 *
 * **It is not a floor on the byte axis, and used not to be only that.** The byte
 * gate now measures at the viewport it is judging (`RegionTooLargeMixin`
 * §"Measurement follows the viewport"), so "a small span is a small fetch" is
 * something it checks rather than assumes — and the check routinely fails. An
 * index quotes whole blocks, so the estimate goes flat wherever a query stops
 * splitting bins, and *where* that happens is a property of the file, not of the
 * index's bin width. Measured 2026-08-06 on files in this repo:
 * `volvox.maf.bed.gz` reports an identical 306,719 bytes from 25kb up to 100kb,
 * and the whole-genome `hs37d5.HG002…sv.vcf.gz` is flat at 15,408 from 7.8 Mb
 * down — 400x above where a 20kb floor would have looked. The old reading here
 * ("roughly a tabix/BAI linear index's own resolution, 16kb bins") described one
 * dense file and generalized from it.
 *
 * The density axis keeps the floor because its number is still a *model* — the
 * last fetch's features-per-bp times the current bpPerPx — with no measurement
 * under it at the span being judged. A repo-wide scan of all 60 indexed files
 * (same date) found nothing that would banner below this span on a display with
 * the density axis on, so removing it would be a change with no measured
 * benefit and an unmeasured risk.
 */
export declare const AUTO_FORCE_LOAD_BP = 20000;
export declare function getDisplayStr(totalBytes: number): string;
/**
 * One measurement of what a fetch would cost, taken at the viewport it
 * describes. **There is no second, derived byte number** — there used to be
 * (`estimatedBytesForVisibleSpan`, this one scaled by `visibleBp /
 * measuredSpanBp`) and the scaling was fiction: index estimates are quoted in
 * whole blocks, so they do not follow span, and the model under-reported by up
 * to three orders of magnitude on real files (see {@link AUTO_FORCE_LOAD_BP}).
 * The gate re-measures when the viewport moves under it instead — see
 * `RegionTooLargeMixin` §"Measurement follows the viewport".
 */
export interface ByteEstimate {
    /**
     * The adapter's cheap index-only estimate for {@link measuredSpanBp}, or
     * undefined when it has none. "Unmeasurable" rather than `0`, so the byte axis
     * stays out of the verdict instead of reading a zero as a measured value.
     */
    bytes: number | undefined;
    /**
     * The **visible** span this measurement was taken at, captured before the
     * round trip. Nothing divides by it any more; it is kept because two
     * consecutive measurements at two spans are the only evidence anyone has about
     * whether zooming shrinks this file's fetch ({@link zoomIneffective}).
     *
     * Not the span `bytes` covers: a display measures the regions it is about to
     * fetch, which for the `MultiRegionDisplayMixin` family are
     * `bufferedVisibleRegions` — half a screen each side, so twice the visible
     * span. The number the banner quotes is therefore the whole download rather
     * than the on-screen slice of it, which is the honest thing to ask permission
     * for.
     */
    measuredSpanBp: number;
    /**
     * The user zoomed in materially and the estimate did not fall — so this file
     * quotes the same blocks however far they go, and "zoom in to see features" is
     * advice that cannot work. Drives `zoomCanReleaseGate`, which is what the
     * banner offers a way out from.
     *
     * **Measured, never predicted.** False on a first measurement, because one
     * point is not evidence; set by {@link nextByteEstimate} when a later
     * measurement at a materially smaller span comes back materially unchanged,
     * and cleared again the moment one does fall. Predicting it instead would mean
     * sampling the index at a ladder of sub-spans up front, which costs 18x the
     * one call on a whole-genome region set (2.4s against 133ms, measured
     * 2026-08-06) to answer a question only a blocked track ever asks.
     */
    zoomIneffective: boolean;
}
/** What a measurement is about, captured before it is requested. */
export interface GateViewport {
    spanBp: number;
    key: string;
}
/**
 * Fold a fresh measurement into the stored one, carrying across the only thing
 * the stored one knows that the fresh one can't: whether zooming has been shown
 * not to help. See {@link ByteEstimate.zoomIneffective}.
 *
 * Deliberately a pure function rather than logic inside `setByteEstimate`, so
 * the "two points make the evidence" rule is testable without a model, and so
 * the thresholds sit next to the measurements that chose them.
 */
export declare function nextByteEstimate(previous: ByteEstimate | undefined, measurement: {
    bytes: number | undefined;
    viewport: GateViewport;
}): ByteEstimate;
export declare const TOO_MANY_FEATURES_REASON = "Too many features";
export declare function bytesTooLargeReason(bytes: number): string;
export declare function tooLargeBannerText(regionTooLargeReason: string, { zoomCanRelease }?: {
    zoomCanRelease?: boolean;
}): string;
/**
 * Resolve the effective byte budget: the adapter's self-reported limit, else the
 * display's configured default. A non-positive adapter limit means "no opinion"
 * (e.g. htsget/no-index adapters report 0) and is skipped — without this guard a
 * 0 would gate every request as too-large, and a negative sentinel (-1) would
 * survive `|| undefined` (truthy) and do the same.
 *
 * Both inputs are read on the main thread (`gateByteLimit`), so the banner and
 * the worker budget resolve one number. There is deliberately no force-load tier:
 * force-load is a boolean "render this track regardless" (`gateExempt`), not
 * a raised ceiling — see agent-docs/reference/REGION_TOO_LARGE.md § Force-load.
 */
export declare function resolveByteLimit({ adapterFetchSizeLimit, configFetchSizeLimit, }: {
    adapterFetchSizeLimit?: number;
    configFetchSizeLimit: number;
}): number;
export interface RegionTooLargeStatus {
    tooLarge: boolean;
    reason: string;
    /**
     * Which axis tripped, absent when nothing did. Not a second spelling of
     * `reason` — `zoomCanReleaseGate` has to branch on it, because the two axes
     * answer "would zooming in help?" differently and only one of them can
     * honestly say no. Screen density is features ÷ pixels, so it falls with
     * `bpPerPx` whatever the file looks like; bytes come in whole index blocks
     * and may not fall at all ({@link ByteEstimate.zoomIneffective}). Matching on
     * the reason string instead would tie the banner's logic to its wording.
     */
    axis?: 'bytes' | 'density';
}
/**
 * The comparison half of the verdict: which axis is over budget, and the banner
 * text for it. Bytes take precedence over density for both.
 *
 * Deliberately knows nothing about *whether* each axis applies — force-load, the
 * opt-in, and the `AUTO_FORCE_LOAD_BP` floor on the density axis live in
 * `gateActive` / `densityGateActive` on `RegionTooLargeMixin`, which are also
 * what stop the pre-flight RPC and the worker budgets. Those ask "may this axis
 * gate?", this one asks "does it?" — so each caller passes `undefined` / `false`
 * for an axis that is off rather than restating why.
 */
export declare function evaluateRegionTooLarge({ estimatedFetchBytes, byteLimit, densityTooLarge, }: {
    estimatedFetchBytes?: number;
    byteLimit?: number;
    densityTooLarge?: boolean;
}): RegionTooLargeStatus;
