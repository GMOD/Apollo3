/** Which question about a region set a byte budget asks. */
export type ByteEstimateScope = 'largestRegion' | 'wholeRequest';
/** Undefined, never 0, when no region could be measured. */
export declare function largestRegionBytes(perRegion: (number | undefined)[]): number | undefined;
/** A non-positive declared limit means "no opinion" (htsget reports 0). */
export declare function adapterByteLimit(declared: unknown, fallback: number): number;
export declare function overByteBudget(bytes: number | undefined, byteLimit: number | undefined): bytes is number;
