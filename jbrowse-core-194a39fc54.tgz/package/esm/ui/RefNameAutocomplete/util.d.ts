import BaseResult from '../../TextSearch/BaseResults.ts';
import type { RefNameMatchSource } from '../../util/selectNamedRegions.ts';
export declare const MAX_OPTIONS = 100;
export interface Option {
    isLimit?: boolean;
    result: BaseResult;
}
export declare function cap(options: Option[]): Option[];
/**
 * The browse/pre-fetch fallback list, shown while a typed query is in flight and
 * when it comes back empty (typed queries otherwise resolve through
 * fetchResults).
 *
 * The matching itself is `matchRefNames`, in core beside the glob semantics,
 * because Enter answers for the same typed text and the two must not each grow
 * their own reading of it. What is left here is presentation: how many rows to
 * materialize, and the bulk row.
 *
 * A glob may gather up to MAX_GLOB_REGIONS for that bulk row; a plain query
 * never needs more than the visible list, so it keeps the tighter bound and the
 * cost it always had. Collecting one past MAX_OPTIONS is what lets `cap` render
 * its "keep typing" hint.
 */
export declare function getRefNameOptions(assembly: RefNameMatchSource | undefined, inputValue: string): Option[];
export declare function getDeduplicatedResult(results: BaseResult[]): Option[];
export declare function coerceToResult(option: string | Option): BaseResult;
export declare function getOptionLabel(option: string | Option): string;
/**
 * What the end adornment occupies, and the number a caller passes as
 * `adornmentWidth`.
 *
 * The ⋮ button is drawn for consumer-supplied rows as well as for the help one,
 * so the reservation follows `menuItemCount || showHelp` — the same expression
 * `EndAdornment` renders on. Both read it here rather than adding the constants
 * up at the call site, which yields a box that has the button and is sized as
 * if it did not.
 */
export declare function adornmentReservePx({ showHelp, menuItemCount, }: {
    showHelp?: boolean;
    menuItemCount?: number;
}): number;
export declare function getInputWidth(value: string, minWidth: number, maxWidth: number, adornmentWidth?: number): number;
