export interface RemovalGroup {
    /** How the announcement and the reference doc name this group. */
    summary: string;
    /** `module#name` to the reason, which is this file's own audience. */
    names: Record<string, string>;
}
export declare const REMOVAL_GROUPS: RemovalGroup[];
export declare const KNOWN_REMOVALS: Record<string, string>;
